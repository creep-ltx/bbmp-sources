/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Thread.h"

DWORD WINAPI ThreadProcedure(LPVOID lpProperty)
{
  CThread *thread;

  thread = (CThread*)lpProperty;
  thread->ThreadProc();
  return 0;
}


CThread::CThread()
{
  Running = false;
  Handle = CreateThread(NULL, 0, &ThreadProcedure, (LPVOID)this, CREATE_SUSPENDED, NULL);
}

CThread::~CThread()
{
  Stop();
  CloseHandle(Handle);
}

void CThread::Run()
{
  Running = true;
  ResumeThread(Handle);
}

void CThread::Stop()
{
  if(Running)
  {
    Lock();
    Running = false;
    Release();
    WaitForSingleObject(Handle, INFINITE);
  }
}

void CThread::Wait()
{
  WaitForSingleObject(Handle, INFINITE);
}

void CThread::ThreadProc()
{
  while(true)
  {
    Lock();
    if(Running)
    {
      Work();
    }
    else
    {
      Release();
      return;
    }
    Release();
  }
}

void CThread::SetPriority(int priority)
{
  SetThreadPriority(Handle, priority);
}

HANDLE CThread::GetHandle()
{
  return Handle;
}