/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SOUNDFONT_LOADER_H
#define SOUNDFONT_LOADER_H

#include "DarkPlug.h"
#include "RIFFLoader.h"

#pragma pack(push)
#pragma pack(1)

struct sfVersionTag
{
  WORD wMajor;
  WORD wMinor;
};

struct sfPresetHeader
{
  CHAR  achPresetName[20];
  WORD  wPreset;
  WORD  wBank;
  WORD  wPresetBagNdx;
  DWORD dwLibrary;
  DWORD dwGenre;
  DWORD dwMorphology;
};

#pragma pack(pop)

struct SSoundFontInfo
{
  bool          Loaded;
  sfVersionTag *Version;
  char         *SoundEngine;
  char         *Name;
  char         *ROM;
  sfVersionTag *ROMVersion;
  char         *CreationDate;
  char         *SoundDesigner;
  char         *Product;
  char         *Copyright;
  char         *Comment;
  char         *Tools;
};

class CSoundFontLoader : public CRIFFLoader
{
public:
                 CSoundFontLoader(CBankServer *bankServer);
                ~CSoundFontLoader();
  EError         Load(char *fileName);
  virtual EError ParseChunk(SRIFFChunk *chunk, char *data, unsigned int level, int context);
  EError         AddBankInfo(char *infoName, char *format, ...);
  EError         Validate();
  EError         Generate();
  void           ReleaseData();
  void           InitData();
  char          *CopyChunkString(SRIFFChunk *chunk, char *data);
  EError         ParseInfo(SRIFFChunk *chunk, char *data);
  EError         ParsePresetData(SRIFFChunk *chunk, char *data);
  EError         GenerateInfo();
  EError         GeneratePresets();

private:
  CBankServer    *BankServer;
  int             BankIndex;
  SSoundFontInfo  Info;
  sfPresetHeader *Presets;
  int             PresetCount;
};

#endif