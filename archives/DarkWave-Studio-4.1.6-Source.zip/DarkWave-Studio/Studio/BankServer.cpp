/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "BankServer.h"
#include "Util.h"

// CBankInfo

CBankInfo::CBankInfo(char *name, char *text)
{
  Name = CopyString(name, &NameLength);
  Text = CopyString(text, &TextLength);
}

CBankInfo::~CBankInfo()
{
  delete Name;
  delete Text;
}

void CBankInfo::GetText(char *text)
{
  strcpy(text, Text);
}

void CBankInfo::GetName(char *name)
{
  strcpy(name, Name);
}

int CBankInfo::GetNameLength()
{
  return NameLength;
}

int CBankInfo::GetTextLength()
{
  return TextLength;
}

// CPreset

CPreset::CPreset(char *name)
{
  Name = 0;
  SetName(name);
}

CPreset::~CPreset()
{
  delete Name;
}

void CPreset::SetName(char *name)
{
  if(Name)
    delete Name;
  Name = CopyString(name, &NameLength);
}

void CPreset::GetName(char *name)
{
  strcpy(name, Name);
}

int CPreset::GetNameLength()
{
  return NameLength;
}

// CBank

CBank::CBank(char *name)
{
  Name = 0;
  SetName(name);
  BankInfo = new CArray<CBankInfo*>();
  Presets = new CArray<CPreset*>();
}

CBank::~CBank()
{
  int i;

  for(i = 0; i < BankInfo->Count; i++)
    delete BankInfo->Items[i];

  for(i = 0; i < Presets->Count; i++)
    delete Presets->Items[i];

  delete Name;
  delete BankInfo;
  delete Presets;
}

void CBank::SetName(char *name)
{
  if(Name != 0)
    delete Name;
  Name = CopyString(name, &NameLength);
}

void CBank::GetName(char *text)
{
  strcpy(text, Name);
}

int CBank::GetNameLength()
{
  return NameLength;
}

int CBank::AddInfo(char *infoName, char *infoText)
{
  CBankInfo *info;

  info = new CBankInfo(infoName, infoText);
  return BankInfo->AddItem(info);
}

int CBank::AddPreset(char *presetName)
{
  CPreset *preset;

  preset = new CPreset(presetName);
  return Presets->AddItem(preset);
}

int CBank::GetInfoCount()
{
  return BankInfo->Count;
}

CBankInfo *CBank::GetInfo(int index)
{
  if(index < 0 || index >= BankInfo->Count)
    return 0;
  else
    return BankInfo->Items[index];
}

CPreset *CBank::GetPreset(int index)
{
  if(index < 0 || index >= Presets->Count)
    return 0;
  else
    return Presets->Items[index];
}

int CBank::GetPresetCount()
{
  return Presets->Count;
}

// CHostBankServer

CHostBankServer::CHostBankServer()
{
  DispatchLevel = 0;
  Banks   = new CArray<CBank*>();
  Clients = new CArray<CBankClient*>();
}

CHostBankServer::~CHostBankServer()
{
  int i;

  for(i = 0; i < Banks->Count; i++)
    delete Banks->Items[i];

  delete Banks;
  delete Clients;
}

EError CHostBankServer::Connect(CBankClient *client)
{
  int i;

  if(!IsLocked())
    return errorNotLocked;
  if(InDispatch())
    return errorInvalidCallDuringEvent;

  for(i = 0; i < Clients->Count; i++)
    if(Clients->Items[i] == client)
      return errorFailed;
  
  Clients->AddItem(client);
  return errorOK;
}

EError CHostBankServer::Disconnect(CBankClient *client)
{
  int i;

  if(!IsLocked())
    return errorNotLocked;
  if(InDispatch())
    return errorInvalidCallDuringEvent;

  for(i = 0; i < Clients->Count; i++)
    if(Clients->Items[i] == client)
    {
      Clients->RemoveItem(i);
      return errorOK;
    }

  return errorFailed;
}

EError CHostBankServer::AddBankInfo(int bankIndex, char *infoName, char *infoText, int *infoIndex)
{
  int    index;
  EError error;
  CBank *bank;

  if(!IsLocked())
    return errorNotLocked;
  if(InDispatch())
    return errorInvalidCallDuringEvent;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  index = bank->AddInfo(infoName, infoText);
  OnAddBankInfo(bankIndex, index);
  if(infoIndex != 0)
    *infoIndex = index;
  return errorOK;
}

EError CHostBankServer::AddBank(char *bankName, int *bankIndex)
{
  CBank *bank;
  int    index;
  
  if(!IsLocked())
    return errorNotLocked;
  if(InDispatch())
    return errorInvalidCallDuringEvent;

  bank = new CBank(bankName);
  index = Banks->AddItem(bank);

  OnAddBank(index);

  if(bankIndex != 0)
    *bankIndex = index;

  return errorOK;
}

EError CHostBankServer::AddPreset(int bankIndex, char *presetName, int *presetIndex)
{
  EError err;
  CBank *bank;
  int    index;

  if(!IsLocked())
    return errorNotLocked;
  if(InDispatch())
    return errorInvalidCallDuringEvent;

  err = GrabBank(bankIndex, &bank);
  if(err != errorOK)
    return err;

  index = bank->AddPreset(presetName);
  OnAddPreset(bankIndex, index);
  if(presetIndex != 0)
    *presetIndex = index;
  return errorOK;
}



void CHostBankServer::BeginDispatch()
{
  DispatchLevel++;
}

void CHostBankServer::EndDispatch()
{
  DispatchLevel--;
}

bool CHostBankServer::InDispatch()
{
  if(DispatchLevel > 0)
    return true;
  else
    return false;
}

void CHostBankServer::OnAddBank(int bankIndex)
{
  int          i;
  CBankClient *client;

  BeginDispatch();
  for(i = 0; i < Clients->Count; i++)
  {
    client = Clients->Items[i];
    client->Lock();
    client->OnAddBank(bankIndex);
    client->Release();
  }
  EndDispatch();
}

void CHostBankServer::OnAddBankInfo(int bankIndex, int infoIndex)
{
  int          i;
  CBankClient *client;

  BeginDispatch();
  for(i = 0; i < Clients->Count; i++)
  {
    client = Clients->Items[i];
    client->Lock();
    client->OnAddBankInfo(bankIndex, infoIndex);
    client->Release();
  }
  EndDispatch();
}

void CHostBankServer::OnAddPreset(int bankIndex, int presetIndex)
{
  int          i;
  CBankClient *client;

  BeginDispatch();
  for(i = 0; i < Clients->Count; i++)
  {
    client = Clients->Items[i];
    client->Lock();
    client->OnAddPreset(bankIndex, presetIndex);
    client->Release();
  }
  EndDispatch();
}

EError CHostBankServer::GrabBank(int bankIndex, CBank **bank)
{
  if(bankIndex < 0 || bankIndex >= Banks->Count)
    return errorInvalidParameter;

  if(bank == 0)
    return errorInvalidParameter;

  *bank = Banks->Items[bankIndex];
  return errorOK;
}

EError CHostBankServer::GetBankNameLength(int bankIndex, int *nameLength)
{
  EError error;
  CBank *bank;

  if(!IsLocked())
    return errorNotLocked;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  if(nameLength == 0)
    return errorInvalidParameter;

  *nameLength = bank->GetNameLength();
  return errorOK;
}

EError CHostBankServer::GetBankName(int bankIndex, char *bankName)
{
  EError error;
  CBank *bank;

  if(!IsLocked())
    return errorNotLocked;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  if(bankName == 0)
    return errorInvalidParameter;

  bank->GetName(bankName);
  return errorOK;
}

EError CHostBankServer::GetBankInfoCount(int bankIndex, int *infoCount)
{
  EError error;
  CBank *bank;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  if(infoCount == 0)
    return errorInvalidParameter;

  *infoCount = bank->GetInfoCount();
  return errorOK;
}

EError CHostBankServer::GetPresetCount(int bankIndex, int *presetCount)
{
  EError error;
  CBank *bank;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  if(presetCount == 0)
    return errorInvalidParameter;

  *presetCount = bank->GetPresetCount();
  return errorOK;
}

EError CHostBankServer::GetBankInfoText(int bankIndex, int infoIndex, char *infoText)
{
  EError     error;
  CBank     *bank;
  CBankInfo *info;

  if(infoText == 0)
    return errorInvalidParameter;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  info = bank->GetInfo(infoIndex);
  if(info == 0)
    return errorInvalidParameter;

  info->GetText(infoText);

  return errorOK;
}

EError CHostBankServer::GetBankInfoName(int bankIndex, int infoIndex, char *infoName)
{
  EError     error;
  CBank     *bank;
  CBankInfo *info;

  if(infoName == 0)
    return errorInvalidParameter;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  info = bank->GetInfo(infoIndex);
  if(info == 0)
    return errorInvalidParameter;

  info->GetName(infoName);

  return errorOK;
}

EError CHostBankServer::GetBankInfoNameLength(int bankIndex, int infoIndex, int *nameLength)
{
  EError     error;
  CBank     *bank;
  CBankInfo *info;

  if(nameLength == 0)
    return errorInvalidParameter;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  info = bank->GetInfo(infoIndex);
  if(info == 0)
    return errorInvalidParameter;

  *nameLength = info->GetNameLength();

  return errorOK;
}

EError CHostBankServer::GetBankInfoTextLength(int bankIndex, int infoIndex, int *textLength)
{
  EError     error;
  CBank     *bank;
  CBankInfo *info;

  if(textLength == 0)
    return errorInvalidParameter;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  info = bank->GetInfo(infoIndex);
  if(info == 0)
    return errorInvalidParameter;

  *textLength = info->GetTextLength();

  return errorOK;
}

EError CHostBankServer::GetPresetName(int bankIndex, int presetIndex, char *presetName)
{
  EError   error;
  CBank   *bank;
  CPreset *preset;

  if(presetName == 0)
    return errorInvalidParameter;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  preset = bank->GetPreset(presetIndex);
  if(preset == 0)
    return errorInvalidParameter;

  preset->GetName(presetName);

  return errorOK;
}

EError CHostBankServer::GetPresetNameLength(int bankIndex, int presetIndex, int *nameLength)
{
  EError   error;
  CBank   *bank;
  CPreset *preset;

  if(nameLength == 0)
    return errorInvalidParameter;

  error = GrabBank(bankIndex, &bank);
  if(error != errorOK)
    return error;

  preset = bank->GetPreset(presetIndex);
  if(preset == 0)
    return errorInvalidParameter;

  *nameLength = preset->GetNameLength();

  return errorOK;
}