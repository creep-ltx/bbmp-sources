/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "MIDIOutputDevice.h"
#include "Error.h"

CMIDIOutputDevice::CMIDIOutputDevice(unsigned int deviceID)
{
  MIDIOUTCAPS caps;
  MMRESULT    s;
  size_t      len;

  ID = deviceID;
  OpenCount = 0;
  Handle = 0;

  s = midiOutGetDevCaps(ID, &caps, sizeof(caps));
  if(s != MMSYSERR_NOERROR)
    ThrowString("midiOutGetDevCaps Returned 0x%x For Device ID %n", s, ID);

  len = strlen(caps.szPname) + 1;
  Name = new char[len];
  strcpy(Name, caps.szPname);
}

CMIDIOutputDevice::~CMIDIOutputDevice()
{
  while(OpenCount > 0)
    Close();
  delete Name;
}

void CMIDIOutputDevice::Open()
{
  MMRESULT s;

  if(OpenCount == 0)
  {
    s = midiOutOpen(&Handle, ID, 0, 0, CALLBACK_NULL);
    if(s != MMSYSERR_NOERROR)
      ThrowString("midiOutOpen For Device <%s> Failed With Error Code 0x%x", Name, s);
  }
  OpenCount++;
}

void CMIDIOutputDevice::Close()
{
  MMRESULT s;

  if(OpenCount > 0)
  {
    OpenCount -= 1;
    if(OpenCount == 0)
    {
      s = midiOutClose(Handle);
      Handle = 0;
      if(s != MMSYSERR_NOERROR)
        ThrowString("midiInClose For Device <%s> Failed With Error Code 0x%x", Name, s);
    }
  }
}

void CMIDIOutputDevice::Write(unsigned char status, unsigned char data1, unsigned char data2)
{
  if(OpenCount > 0)
  {
    DWORD msg;

    msg = (DWORD)status | ((DWORD)data1 << 8) | ((DWORD)data2 << 16);

	midiOutShortMsg(Handle, msg);
  }
  else
    ThrowString("MIDIOutputDevice[%s]::Write() Called But Device Is Not Open", Name);
}