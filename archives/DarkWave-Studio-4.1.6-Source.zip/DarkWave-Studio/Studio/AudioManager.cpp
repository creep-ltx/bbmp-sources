/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "AudioManager.h"
#include "NullDriver.h"
#include "WaveOutDriver.h"
#include "ASIODriver.h"
#include "DirectSoundDriver.h"
#include "Core.h"


CAudioManager::CAudioManager()
{
  OutputDrivers = new CArray<CAudioOutputDriver*>();
  OutputDrivers->AddItem(new CNullDriver());
  OutputDrivers->AddItem(new CWaveOutDriver());
  OutputDrivers->AddItem(new CDirectSoundDriver);

  if(!(Core->Options->Audio.DisableASIO))
    OutputDrivers->AddItem(new CASIODriver());


  if((Core->Options->Audio.Driver >= 0 ) && (Core->Options->Audio.Driver < OutputDrivers->Count))
    if(!(OutputDrivers->Items[Core->Options->Audio.Driver]->CanOpen()))
      Core->Options->Audio.Driver = -1;
  
  if((Core->Options->Audio.Driver == -1) || (Core->Options->Audio.Driver >= OutputDrivers->Count))
  {
    if(OutputDrivers->Items[OUTPUT_DRIVER_DIRECT_SOUND]->CanOpen())
      Core->Options->Audio.Driver = OUTPUT_DRIVER_DIRECT_SOUND;
    else
    {
      if(OutputDrivers->Items[OUTPUT_DRIVER_WAVE]->CanOpen())
        Core->Options->Audio.Driver = OUTPUT_DRIVER_WAVE;
      else
        Core->Options->Audio.Driver = OUTPUT_DRIVER_NULL;
    }
  }
  
  OutputDriver = Core->Options->Audio.Driver;
  if(OutputDriver >= OutputDrivers->Count)
    OutputDriver = 0;
}

CAudioManager::~CAudioManager()
{
  int i;

  Core->Options->Audio.Driver = OutputDriver;

  for(i = 0; i < OutputDrivers->Count; i++)
    delete OutputDrivers->Items[i];
  delete OutputDrivers;
}

void CAudioManager::OpenOutput(AudioOutputWriteCallback *funcPtr)
{
  CAudioOutputDriver *driver;
  
  driver = GetOutputDriver();
  if(driver->CanOpen())
  {
    driver->SetWriteCallback(funcPtr);
    if((Core->MainWindow->Studio->Master) != 0)
    {
      bool update;

      Core->MainWindow->Studio->Lock();
      ((CMaster*)(Core->MainWindow->Studio->Master->Machine))->Lock();
      update = ((CMaster*)(Core->MainWindow->Studio->Master->Machine))->InitPorts();
      Core->Host->SetSampleRateAndBlockSamples(driver->GetSampleRate(), driver->GetBlockSamples());
      Core->MainWindow->Studio->SetSampleRate(driver->GetSampleRate());
      Core->MainWindow->Studio->SetBlockSamples(driver->GetBlockSamples());
      if(update)
        Core->MainWindow->Studio->Master->UpdatePorts();
      Core->MainWindow->Studio->DrawControl(); 
      Core->MainWindow->Studio->Update();
      ((CMaster*)(Core->MainWindow->Studio->Master->Machine))->Release();
      Core->MainWindow->Studio->Release();

    }
    driver->Open();
  }
}

void CAudioManager::CloseOutput()
{
  CAudioOutputDriver *driver;

  driver = GetOutputDriver();
  driver->Close();
}

CAudioOutputDriver *CAudioManager::GetOutputDriver()
{
  return OutputDrivers->Items[OutputDriver];
}

CAudioOutputDriver *CAudioManager::GetOutputDriver(int index)
{
  if(index < 0 || index >= OutputDrivers->Count)
    return 0;
  else
    return OutputDrivers->Items[index];
}

int CAudioManager::GetCurrentOutputDriver()
{
  return OutputDriver;
}

int CAudioManager::GetOutputDriverCount()
{
  return OutputDrivers->Count;
}