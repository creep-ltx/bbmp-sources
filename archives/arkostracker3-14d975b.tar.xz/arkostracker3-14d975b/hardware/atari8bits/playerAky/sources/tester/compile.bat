mads AtariAkyTest.asm
