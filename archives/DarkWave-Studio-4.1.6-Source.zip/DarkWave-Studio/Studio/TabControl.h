/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef TAB_CONTROL_H
#define TAB_CONTROL_H

#include "Control.h"
#include "Array.h"
#include "Font.h"
#include "BackBuffer.h"

struct STabItem
{
  CControl *Control;
  char     *Label;
  HICON     Icon;
  int       Left, Width;
};

class CTabControl : public CControl
{
public:
               CTabControl(CControl *parent, int x, int y, int width, int height);
              ~CTabControl();
  void         AddTab(CControl *control, char *name, int iconID);
  int          CalculateTabWidth(int index);
  void         DrawControl();
  virtual void OnResize(int newWidth, int newHeight);
  void         ShowTab(int index);
  void         SizeControl(int index);
  void         DrawTab(HDC hDC, int index);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonDoubleClick(int x, int y);

private:
  CArray<STabItem> *Controls;
  int               CurrentControl;
};

#endif