/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef IMPULSE_VIEW_H
#define IMPULSE_VIEW_H

#include "LiteControl.h"
#include "LiteContainer.h"

class CImpulseView : public CLiteControl
{
public:
       CImpulseView(CLiteContainer *parent, int x, int y, int width, int height, double dBRange, double alpha, bool twoTone);
      ~CImpulseView();
  void Update(int samples, double *data);
  void Draw(CFrameBuffer *frameBuffer);

private:
  CFrameBuffer *RenderBuffer;
  double         DBRange, Alpha;
  bool          TwoTone;
};

#endif