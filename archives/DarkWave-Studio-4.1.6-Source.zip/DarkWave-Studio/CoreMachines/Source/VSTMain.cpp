#include <windows.h>
#include "audioeffect.h"

AudioEffect* createEffectInstance(audioMasterCallback audioMaster, HINSTANCE hInstance);
HINSTANCE hInstance = 0;

extern "C" 
{
  __declspec(dllexport) AEffect* VSTCALLBACK VSTPluginMain(audioMasterCallback audioMaster)
  {
    AudioEffect* effect = createEffectInstance(audioMaster, hInstance);
	  if(!effect)
	    return 0;
    
    return effect->getAeffect();
  }

  __declspec(dllexport) AEffect* VSTCALLBACK MAIN(audioMasterCallback audioMaster)
  {
    return VSTPluginMain(audioMaster); 
  }

  __declspec(dllexport) BOOL WINAPI DllMain(HINSTANCE hInst, DWORD dwReason, LPVOID lpvReserved)
  {
    hInstance = hInst;
    return 1;
  }
}