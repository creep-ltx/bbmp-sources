/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "FileDialog.h"

CFileDialog::CFileDialog(const char *title, const char *filter)
{
  Title  = (char*)title;
  Filter = (char*)filter;
}

CFileDialog::~CFileDialog()
{
}

bool CFileDialog::ShowOpen(HWND parent, char fileName[MAX_FILE])
{
  OPENFILENAME ofn;

  memset(&ofn, 0, sizeof(OPENFILENAME));
  ofn.lStructSize = sizeof(OPENFILENAME);
  ofn.hwndOwner   = parent;
  ofn.lpstrFilter = Filter;
  ofn.lpstrFile   = fileName;
  ofn.nMaxFile    = MAX_FILE;
  ofn.lpstrTitle  = Title;
  ofn.Flags       = OFN_FILEMUSTEXIST;
 
  if(GetOpenFileName(&ofn))
    return true;
  else
    return false;
}