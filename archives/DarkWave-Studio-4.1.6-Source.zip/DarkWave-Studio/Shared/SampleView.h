/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SAMPLEVIEW_H
#define SAMPLEVIEW_H

#include "Control.h"
#include "BackBuffer.h"
#include "Sample.h"

#define SAMPLE_VIEW_MODE_SCOPE    0
#define SAMPLE_VIEW_MODE_SPECTRUM 1

class CSampleView : public CControl
{
public:
               CSampleView(CControl *parent, int x, int y, int width, int height);
              ~CSampleView();
  void         DrawControl();
  void         SetSample(CSample *sample);
  void         DrawWaveform(HDC hDC);
  void         SetMode(int mode);
  void         PerformFFT();
  void         DrawSpectrum(HDC hDC);

private:
  CSample     *Sample;
  int          Mode, FFTPoints;
  double      *FFTData;
};

#endif