/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <stdio.h>
#include "Connector.h"
#include "Core.h"

#define TYPE_BOX_WIDTH   16
#define TYPE_BOX_HEIGHT  11
#define RXTX_BOX_WIDTH  16
#define RXTX_BOX_HEIGHT 6

#define DEFAULT_WIDTH  64
#define DEFAULT_HEIGHT (TYPE_BOX_HEIGHT + 2)

CConnector::CConnector(CControl *parent, int x, int y, CPort *port, CMachineContainer *container)
: CControl(parent, "Connector", x, y, DEFAULT_WIDTH, DEFAULT_HEIGHT, true)
{
  Future = 0;
  RXCount = TXCount = 0;
  Connections = 0;
  ConnectionCount = 0;
  Port = port;
  if(((Port->Type & PT_CONTROL) == PT_CONTROL) && ((Port->Type & PT_INPUT) == PT_INPUT))
    Future = new CControlBuffer();
  Container = container;
  BackColor = (ColorManagerColor)FlatBack;
  SetTextColor(BackDC, ColorManager->GetColor((ColorManagerColor)FlatText));
  SetBkMode(BackDC, TRANSPARENT);
  SubInit = true;
  AutoSize();
  DrawControl();
}

CConnector::~CConnector()
{  
  if(Future)
  {
    delete Future;
    Future = 0;
  }
  ClearConnections();
}

void CConnector::DrawControl()
{
  HDC     hDC;
  int type, x;
  char *text;

  type = Port->Type;

  if((type & PT_CONTROL) == PT_CONTROL)
    text = "CT";
  else
  {
    if((type & PT_AUDIO) == PT_AUDIO)
    {
      if((type & PT_STEREO) == PT_STEREO)
        text = "ST";
      else
        text = "MO";
    }
    else
      text = "--";
  }

  hDC = BackDC;
  ColorManager->Lock();
  ColorManager->GetBrush(FlatBack)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();

  x = 1;

  DrawBox(hDC, x, 1, TYPE_BOX_WIDTH, TYPE_BOX_HEIGHT, text);

  x += TYPE_BOX_WIDTH + 1;
  if((type & PT_INPUT) == PT_INPUT)
  {
    DrawRXTX(hDC, x, 1, "In", RXCount != 0);
    x += RXTX_BOX_WIDTH + 1;
  }
  if((type & PT_OUTPUT) == PT_OUTPUT)
  {
    DrawRXTX(hDC, x, 1, "Out", TXCount != 0);
    x += RXTX_BOX_WIDTH + 1;
  }

  DrawBox(hDC, x, 1, Width - (x + 1), TYPE_BOX_HEIGHT, Port->Name);
}

void CConnector::DrawRXTX(HDC hDC, int x, int y, char *text, bool lit)
{
  DrawBox(hDC, x, y, RXTX_BOX_WIDTH, TYPE_BOX_HEIGHT - RXTX_BOX_HEIGHT, 0, lit);
  DrawLabel(hDC, x, 1 + (TYPE_BOX_HEIGHT - RXTX_BOX_HEIGHT), RXTX_BOX_WIDTH, RXTX_BOX_HEIGHT, text);
}

void CConnector::AutoSize()
{
  RECT    rect;
  HGDIOBJ oldFont;
  int     width;

  ColorManager->Lock();
  ColorManager->GetBrush(BackColor)->FillRect(DC, 0, 0, Width, Height);
  ColorManager->Release();

  rect.top = 1;
  rect.left = 1;
  rect.bottom = Height - 2;
  rect.right = Width - 2;
  oldFont = SelectObject(DC, Font->Handle);
  DrawText(DC, Port->Name, (int)strlen(Port->Name), &rect, DT_SINGLELINE | DT_CALCRECT);
  width = rect.right + 2;

  width += 4 + TYPE_BOX_WIDTH + 
    (((Port->Type & PT_INPUT)  == PT_INPUT)  ? (RXTX_BOX_WIDTH + 1) : 0) +
    (((Port->Type & PT_OUTPUT) == PT_OUTPUT) ? (RXTX_BOX_WIDTH + 1) : 0);
  Resize(width, Height);
}

LRESULT CConnector::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_LBUTTONDOWN:
    {
      Core->MainWindow->Studio->BringMachineToFront(Container);
      
      // disabled need for shift key
      //if((wParam & MK_SHIFT) == MK_SHIFT)
      //{
        Core->MainWindow->Studio->BeginUserConnect(this);
        return 0;
      //}
      break;
    }
  }

  return CControl::WindowProc(hWnd, msg, wParam, lParam);
}

void CConnector::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  SetTextColor(BackDC, ColorManager->GetColor((ColorManagerColor)FlatText));
  SetBkMode(BackDC, TRANSPARENT);
  DrawControl();
}

int CConnector::Connect(CConnector *connector, double volume)
{
  CConnection *connection, **connections;
  int          i;
  
  connector->TXCount += 1;
  RXCount += 1;

  connection = new CConnection(connector, this, volume);
  
  if(ConnectionCount == 0)
  {
    Connections = new CConnection*[1];
    Connections[0] = connection;
    ConnectionCount = 1;
  }
  else
  {
    connections = new CConnection*[ConnectionCount + 1];
    for(i = 0; i < ConnectionCount; i++)
      connections[i] = Connections[i];
    connections[ConnectionCount] = connection;
    delete Connections;
    Connections = connections;
    ConnectionCount += 1;
  }

 connector->Update();
 Update();

  return ConnectionCount - 1;
}

void CConnector::Disconnect(int index)
{
  int           i, j;
  CConnection **connections;
  CConnector   *connector;

  if((index >= 0) && (index < ConnectionCount))
  {
    connector = Connections[index]->Input;
    if(ConnectionCount == 1)
    {
      delete Connections[0];
      delete Connections;
      ConnectionCount = 0;
    }
    else
    {
      connections = new CConnection*[ConnectionCount + 1];

      i = 0;
      for(j = 0; j < ConnectionCount; j++)
      {
        if(j == index)
          delete Connections[j];
        else
          connections[i++] = Connections[j];
      }
      delete Connections;
      Connections = connections;
      ConnectionCount -= 1;
    }
  }
  else
    throw "Index Out Of Bounds";

  connector->TXCount -= 1;
  RXCount -= 1;
  connector->Update();
  Update();
}

void CConnector::ClearConnections()
{
  int i;

  if(ConnectionCount != 0)
  {
    for(i = 0; i < ConnectionCount; i++)
      delete Connections[i];
    delete Connections;
    Connections = 0;
    ConnectionCount = 0;
  }
}