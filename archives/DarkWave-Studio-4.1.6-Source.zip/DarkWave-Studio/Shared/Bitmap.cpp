/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <windows.h>
#include "Bitmap.h"

CBitmap::CBitmap(int resourceID)
{
  BITMAP bitmapData;
  int    s;

  Bitmap = LoadBitmap(AppInstance, MAKEINTRESOURCE(resourceID));
  if(Bitmap == NULL)
    throw "CBitmap - LoadBitmap Failed";

  s = GetObject(Bitmap, sizeof(BITMAP), &bitmapData);
  if(s == 0)
    throw "CBitmap - GetObject Failed";
  Width = bitmapData.bmWidth;
  Height = bitmapData.bmHeight;

  OldBitmap = 0;
  DC = 0;
}

CBitmap::~CBitmap()
{
  if(DC != 0)
  {
    SelectObject(DC, OldBitmap);
    DeleteDC(DC);
  }
  DeleteObject(Bitmap);
}

void CBitmap::Draw(HDC targetDC, int srcX, int srcY, int width, int height, int dstX, int dstY)
{
  if(DC == 0)
  {
    DC = CreateCompatibleDC(targetDC);
    OldBitmap = SelectObject(DC, Bitmap);
  }

  BitBlt(targetDC, dstX, dstY, width, height, DC, srcX, srcY, SRCCOPY);
}