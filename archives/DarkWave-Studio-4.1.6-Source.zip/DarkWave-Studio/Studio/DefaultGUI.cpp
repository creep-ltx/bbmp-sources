/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "DefaultGUI.h"
#include "Core.h"

#define MAX_HEIGHT       400
#define SCROLLBAR_WIDTH  16

#define SPACING_Y      22
#define SPACING_X      4

#define INDEX_X        SPACING_X
#define INDEX_WIDTH    48

#define NAME_X         (INDEX_X + INDEX_WIDTH + SPACING_X)
#define NAME_WIDTH     112

#define SLIDER_X       (NAME_X + NAME_WIDTH + SPACING_X)
#define SLIDER_Y       4 
#define SLIDER_WIDTH   129
#define SLIDER_HEIGHT  24


#define DISPLAY_X      (SLIDER_X + SLIDER_WIDTH + SPACING_X)
#define DISPLAY_WIDTH  96

#define LABEL_Y        10
#define LABEL_HEIGHT   16

#define CONTROL_WIDTH  (DISPLAY_X + DISPLAY_WIDTH + SPACING_X)
#define CONTROL_HEIGHT 10

CDefaultGUI::CDefaultGUI(CControl *parent, CMachine *machine)
: CControl(parent, "DefaultGUI", 0, 0, 32, 32, true)
{
  int i;

  ScrollBarV = 0;
  TotalHeight = 0;
  SubInit = true;
  SetFont(new CFont(DC, "Verdana", 9.0f, true));
  TopRow = 0;
  MaxTopRow = 0;
  VisibleRows = 0;

  Machine           = machine;
  PropertyCount    = machine->PropertyCount;
  if(PropertyCount > 0)
  {
    PropertyNames    = new char*[PropertyCount];
    PropertyDisplays = new char*[PropertyCount];
    PropertyValues   = new double[PropertyCount];
    Sliders           = new CDefaultGUISlider*[PropertyCount];

    for(i = 0; i < PropertyCount; i++)
    {
      PropertyNames[i] = new char[MAX_PROPERTY_NAME_STRING];
      Machine->GetPropertyName(i, PropertyNames[i]);

      PropertyDisplays[i] = new char[MAX_PROPERTY_DISPLAY_STRING];
      Machine->GetPropertyDisplay(i, PropertyDisplays[i]);

      PropertyValues[i] = Machine->GetProperty(i);

      Sliders[i] = new CDefaultGUISlider(this, i, SLIDER_X, SLIDER_Y + (SPACING_Y * i), SLIDER_WIDTH, SLIDER_HEIGHT);
      Sliders[i]->SetValue(PropertyValues[i]);
      Sliders[i]->Show();
    }
  
    TotalHeight = CONTROL_HEIGHT + (SPACING_Y * PropertyCount);
    if(TotalHeight > MAX_HEIGHT)
    {
      Resize(CONTROL_WIDTH + SCROLLBAR_WIDTH, MAX_HEIGHT);
      VisibleRows = ((Height - CONTROL_HEIGHT) / SPACING_Y);
      MaxTopRow = PropertyCount - 1 - VisibleRows;
      ScrollBarV = new CScrollBar(this, SCROLLBAR_VERTICAL, 
        Width - (SCROLLBAR_WIDTH + 1), 0, SCROLLBAR_WIDTH, Height, 0, MaxTopRow);
      ScrollBarV->Show();
    }
    else
    {
      VisibleRows = PropertyCount - 1;
      Resize(CONTROL_WIDTH, TotalHeight);
    }

  }
  else
  {
    PropertyNames    = 0;
    PropertyDisplays = 0;
    PropertyValues   = 0;
    Sliders           = 0;
  }

  DrawControl();
}

CDefaultGUI::~CDefaultGUI()
{
  int i;

  if(PropertyCount != 0)
  {
    for(i = 0; i < PropertyCount; i++)
    {
      delete PropertyNames[i];
      delete PropertyDisplays[i];
      delete Sliders[i];
    }
    delete PropertyNames;
    delete PropertyDisplays;
    delete PropertyValues;
    delete Sliders;
  }
}

void CDefaultGUI::DrawControl()
{
  HDC     hDC;
  int     i, y;
  HGDIOBJ oldFont;
  char    index[32];

  hDC = BackDC;

  ColorManager->Lock();
  ColorManager->GetBrush(BackColor)->FillRect(hDC, 0, 0, Width, Height);
  SetBkMode(hDC, TRANSPARENT);
  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlText));
  ColorManager->Release();

  oldFont = SelectObject(hDC, Font->Handle);
  
  y = 0;
  for(i = TopRow; i < PropertyCount && i <= TopRow + VisibleRows; i++)
  {
    sprintf(index, "[%04i]", i);
    DrawLabel(hDC, index,               DT_LEFT,   INDEX_X,   y + LABEL_Y, INDEX_WIDTH,   LABEL_HEIGHT);
    DrawLabel(hDC, PropertyNames[i],    DT_RIGHT,  NAME_X,    y + LABEL_Y, NAME_WIDTH,    LABEL_HEIGHT);
    DrawLabel(hDC, PropertyDisplays[i], DT_RIGHT,  DISPLAY_X, y + LABEL_Y, DISPLAY_WIDTH, LABEL_HEIGHT);
    y += SPACING_Y;
  }

  SelectObject(hDC, oldFont);
}

void CDefaultGUI::DrawLabel(HDC hDC, char *text, int flags, int x, int y, int width, int height)
{
  RECT rect;

  rect.left   = x;
  rect.top    = y;
  rect.bottom = y + height - 1;
  rect.right  = x + width - 1;
  DrawText(hDC, text, (int)strlen(text), &rect, DT_SINGLELINE | flags);
}

CDefaultGUISlider::CDefaultGUISlider(CDefaultGUI *gui, int index, int x, int y, int width, int height)
: CSlider(gui, x, y, width, height, SLIDER_HORIZONTAL)
{
  GUI = gui;
  Index = index;
}

void CDefaultGUISlider::OnChange(double newValue)
{
  CSlider::OnChange(newValue);
  GUI->OnSliderChange(Index, newValue);
}

void CDefaultGUI::OnSliderChange(int index, double newValue)
{
  if(PropertyValues[index] != newValue)
  {
    Machine->Lock();
    Machine->SetProperty(index, newValue);
    Machine->Release();
    OnPropertyChange(index);
  }
}

void CDefaultGUI::OnPropertyChange(int index)
{
  //Machine->Lock();
  if((index < 0) || (index >= Machine->PropertyCount))
    return;
  PropertyValues[index] = Machine->GetProperty(index);
  Sliders[index]->SetValue(PropertyValues[index]);
  Machine->GetPropertyDisplay(index, PropertyDisplays[index]);
  //Machine->Release();
  Update();
}

void CDefaultGUI::OnScrollY(int newPos)
{
  int i;

  TopRow = newPos;

  Update();
  for(i = 0; i < PropertyCount; i++)
  {
    if(i < TopRow)
      Sliders[i]->Hide();
    else
    {
      Sliders[i]->Move(SLIDER_X, SLIDER_Y + (SPACING_Y * (i - TopRow)));
      Sliders[i]->Show();
    }
  }
  UpdateWindow(Handle);
}

