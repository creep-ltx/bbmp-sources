/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "VSTLoader.h"
#include "Error.h"
#include "VST.h"
#include "VSTAdapter.h"
#include "Core.h"
#include <stdio.h>

void LoadVSTDLL(CHost *host, char *dir, char *dllPath, char *dllName, CMachineLoader *machineLoader, char *vstRoot)
{
  HMODULE module;
  vstMain main;
  char    text[1024];
  bool    newMainFormat = true;
  char    file[1024];
  size_t  i, j, n;

  j = 0;
  n = strlen(dllPath);
  for(i = 0; i < n; i++)
    if(dllPath[i] == '\\')
      j = i + 1;
  strcpy(file, dllPath + j);


  module = LoadLibrary(dllPath);
  if(module != 0)
  {
    sprintf(text, "Loading VST PlugIn %s...", file);
    Core->AboutBox->SetLabelText(text);

    main = (vstMain)GetProcAddress(module, "VSTPluginMain");
    if(main == 0)
    {
      newMainFormat = false;
      main = (vstMain)GetProcAddress(module, "main");
    }
    if(main != 0)
    {
      char menuPath[4096];
      
      if(strlen(dir) == strlen(vstRoot))
        strcpy(menuPath, "VST");
      else
        sprintf(menuPath, "VST\\%s", dir + strlen(vstRoot) + 1);
            
      machineLoader->AddEntry(new CVSTAdapterInfo(host, module, main, newMainFormat, dllName, dir, dllPath, menuPath));
    }
    else
      FreeLibrary(module);
  }
}

void LoadVSTMachines(CHost *host, char *vstPath, CMachineLoader *machineLoader, char *vstRoot)
{
  int             length, pathLength;
  char           *searchPath, *dllPath, *dirPath;
  WIN32_FIND_DATA findData;
  HANDLE          findHandle;
  bool            foundFile;

  length = (int)strlen(vstPath);
  searchPath = new char[length + 7];
  sprintf(searchPath, "%s\\*.dll", vstPath);

  findHandle = FindFirstFile(searchPath, &findData); 
  if(findHandle != INVALID_HANDLE_VALUE)
  {
    foundFile = true;
    while(foundFile)
    {
      if((findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
      {
        pathLength = (int)strlen(findData.cFileName);
        dllPath = new char[length + pathLength + 2];
        sprintf(dllPath, "%s\\%s", vstPath, findData.cFileName);
        try
        {
          LoadVSTDLL(host, vstPath, dllPath, findData.cFileName, machineLoader, vstRoot);
        }
        catch(char *theError)
        {
          DisplayError("%s", theError);
        }
        delete dllPath;
      }
      foundFile = (FindNextFile(findHandle, &findData) != 0);
    }
    FindClose(findHandle);
  }

  delete searchPath;

  length = (int)strlen(vstPath);
  searchPath = new char[length + 3];
  sprintf(searchPath, "%s\\*", vstPath);

  findHandle = FindFirstFile(searchPath, &findData); 
  if(findHandle != INVALID_HANDLE_VALUE)
  {
    foundFile = true;
    while(foundFile)
    {
      if((findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
      {
        if(strcmp(".", findData.cFileName) != 0 && strcmp("..", findData.cFileName) != 0)
        {
          pathLength = (int)strlen(findData.cFileName);
          dirPath = new char[length + pathLength + 2];
          sprintf(dirPath, "%s\\%s", vstPath, findData.cFileName);
          LoadVSTMachines(host, dirPath, machineLoader, vstRoot);
          delete dirPath;
        }
      }
      foundFile = (FindNextFile(findHandle, &findData) != 0);
    }
    FindClose(findHandle);
  }

  delete searchPath;
}