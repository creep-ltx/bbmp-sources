/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DARKPLUGADAPTER_H
#define DARKPLUGADAPTER_H

#include "aeffectx.h"
#include "audioeffectx.h"
#include "aeffeditor.h"
#include "DarkPlug.h"

class CDarkPlugAdapter;
class CLiteContainer;

class CHostAdapter : public CHost
{
public:
  CHostAdapter(audioMasterCallback audioMaster);
 ~CHostAdapter();

  virtual EError    DARKCALL RegisterMachineInfo(CMachineInfo *machineInfo);
  virtual EError    DARKCALL GetNoteFrequency(unsigned int note, double *frequency);
  virtual EError    DARKCALL GetBankServer(CBankServer **bankServer);
  virtual void      DARKCALL SetPropertyAutomated(CMachine *machine, int index, double value);
  virtual int       DARKCALL GetSamplePosition();
  virtual double    DARKCALL GetBPM();
  virtual int       DARKCALL GetSampleRate();
  virtual double    DARKCALL GetTPB();
  virtual int       DARKCALL GetSamplesPerTick();
  virtual int       DARKCALL GetBlockSamples();
  virtual bool      DARKCALL Supports(ESupports code);
  virtual int       DARKCALL GetCPUFeatures();
  virtual VstIntPtr Dispatch(AEffect *effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt);
private:
  audioMasterCallback AudioMaster;
};

class CDarkPlugAdapter : public AudioEffectX, public AEffEditor
{
public:
  CDarkPlugAdapter(CMachine *machine, audioMasterCallback audioMaster, int uid);
 ~CDarkPlugAdapter();

  virtual VstInt32 processEvents (VstEvents* events);
  virtual void     processReplacing(float** inputs, float** outputs, VstInt32 sampleFrames);
  virtual void     processDoubleReplacing(double** inputs, double** outputs, VstInt32 sampleFrames);
  virtual bool     getRect (ERect** rect);
  virtual bool     open (void* ptr);
	virtual void     setParameter(VstInt32 index, float value);
	virtual float    getParameter(VstInt32 index);
	virtual void     setParameterAutomated(VstInt32 index, float value);
	virtual void     getParameterLabel(VstInt32 index, char* label);
	virtual void     getParameterDisplay(VstInt32 index, char* text);
	virtual void     getParameterName(VstInt32 index, char* text);
  virtual void     setSampleRate(float sampleRate);
  virtual void     setBlockSize(VstInt32 blockSize);

  virtual VstInt32 getProgram();
	virtual void     setProgram (int program);
	virtual void     setProgramName (char *name);
	virtual void     getProgramName (char *name);
	virtual bool     getProgramNameIndexed (VstInt32 category, VstInt32 index, char* text);
  virtual void     close();
  virtual bool     beginSetProgram();
  virtual bool     endSetProgram();
  virtual VstInt32 beginLoadBank(VstPatchChunkInfo *ptr);
  virtual VstInt32 beginLoadProgram(VstPatchChunkInfo *ptr);
  virtual void     idle();
  virtual bool     getVendorString(char *text);
  virtual bool     getProductString(char *text);
 
private:
  CMachine            *Machine;
  audioMasterCallback  AudioMaster;
  CPort               *InPort, *OutPort;
  HWND                 GUI;
  int                  BlockSamples;
  ERect                Rect;
  short int            UID;
};

#endif