#ifndef MUTEX_H
#define MUTEX_H

#include <windows.h>

class CHostMutex
{
public:
      CHostMutex();
     ~CHostMutex();
 void Lock();
 void Release();
 bool IsLocked();

private:
  HANDLE Mutex;
  bool   Locked;
};

#endif