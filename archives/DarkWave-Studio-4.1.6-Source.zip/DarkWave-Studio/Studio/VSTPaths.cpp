/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "VSTPaths.h"
#include "../Resource.h"
#include <shlobj.h>
#include "Core.h"
#include "Util.h"

#define BUTTON_ADD    0
#define BUTTON_REMOVE 1

CVSTPaths::CVSTPaths(COptionsDialog *parent, int x, int y, int width, int height)
: COptionsFrame(parent, "VST Paths", x, y, width, height)
{
  int i;

  ToolBar = new CToolBar(this, 8, 16, width - 16, 30);
  AddButton = ToolBar->AddButton(IDI_ADD, BUTTON_ADD, 20, 20, "Add Path...", false);
  RemoveButton = ToolBar->AddButton(IDI_REMOVE, BUTTON_REMOVE, 20, 20, "Remove Selected Path", false);
  ToolBar->Show();
  ListBox = new CListBox(this, Font, 8, 54, width - 16, height - 60, 16);
  ListBox->SetDrawTextFlags(DT_PATH_ELLIPSIS);
  for(i = 0; i < Core->Options->VSTPaths.Count; i++)
    ListBox->AddItem(Core->Options->VSTPaths.Items[i]);
  ListBox->Show();
 
}

void CVSTPaths::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  ToolBar->Move(8, 16, newWidth - 16, 30);
  ListBox->Move(8, 54, newWidth - 16, newHeight - 60);
}

CVSTPaths::~CVSTPaths()
{
}

void CVSTPaths::ApplyChanges()
{
}

void CVSTPaths::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == RemoveButton)
  {
    int i;
    
    i = ListBox->GetSelection();
    if((i >= 0) && (i < Core->Options->VSTPaths.Count))
    {
      ListBox->RemoveItem(i);
      delete Core->Options->VSTPaths.Items[i];
      Core->Options->VSTPaths.RemoveItem(i);
    }
  }

  if(button == AddButton)
  {
    BROWSEINFO bi;
    char pszPath[MAX_PATH];
    LPITEMIDLIST pidl;

    memset(&bi, 0, sizeof(bi));
    bi.hwndOwner = Handle;
    bi.pszDisplayName = pszPath;
    bi.lpszTitle = "Select VST PlugIn Folder";
    if(pidl = SHBrowseForFolder(&bi))
    {
      if(SHGetPathFromIDList(pidl, pszPath))
      {
        ListBox->AddItem(pszPath);
        Core->Options->VSTPaths.AddItem(CopyString(pszPath));
      }
    }
  }
}
