/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Sample.h"
#include "Error.h"
#include <stdio.h>
#include <math.h>

#define WAV_ID        'FFIR'
#define WAV_FORMAT    'EVAW'
#define WAV_FORMAT_ID ' tmf'
#define WAV_DATA_ID   'atad'

#pragma pack(push, 1)

struct WAVHeader
{
  unsigned int ID;        // 'RIFF'
  unsigned int ChunkSize;
  unsigned int Format;    // 'WAVE'
};

struct WAVChunkHeader
{
  unsigned int   ChunkID;
  long           ChunkSize;
};

struct WAVFormat
{
  short          FormatTag;
  unsigned short Channels;
  unsigned long  SamplesPerSec;
  unsigned long  AvgBytesPerSec;
  unsigned short BlockAlign;
  unsigned short BitsPerSample;
};

#pragma pack(pop)

CSample::CSample()
{
  SampleRate = 0;
  Samples = 0;
  MonoData = 0;
}

CSample::CSample(int samples, double *data, int sampleRate)
{
  int i;

  SampleRate = sampleRate;
  Samples = samples;
  MonoData = new double[samples];
  Stereo = false;
  for(i = 0; i < samples; i++)
    MonoData[i] = data[i];
}

CSample::CSample(int samples, int sampleRate)
{
  int i;

  SampleRate = sampleRate;
  Samples = samples;
  MonoData = new double[samples];
  Stereo = false;
  for(i = 0; i < samples; i++)
    MonoData[i] = 0.0f;
}

CSample *CSample::Clone()
{
  CSample *newSample;

  newSample = new CSample(Samples, MonoData, SampleRate);
  return newSample;
}

CSample::~CSample()
{
  Free();
}

void CSample::Free()
{
  if(MonoData != 0)
  {
    delete MonoData;
    MonoData = 0;
  }
}

void CSample::LoadWAV(char *filePath)
{
  FILE          *file;
  WAVHeader      header;
  WAVChunkHeader chunkHeader;
  WAVFormat      format;
  size_t         n;
  bool           bMoreToRead = true;
  bool           bReadFormat = false;
  bool           bReadData   = false;
  int            s;
  signed short  *data, value;
  int            dataBytes, i;
  
  Free();

  file = fopen(filePath, "rb");
  if(file == 0)
    ThrowString("Can't Open File <%s>", filePath);

  n = fread(&header, sizeof(WAVHeader), 1, file);
  if(n != 1)
    ThrowString("Unexpected End Of File Reading <%s>", filePath);

  if((header.ID != WAV_ID) || (header.Format != WAV_FORMAT))
    ThrowString("Invalid File Format Reading <%S>", filePath);

  while(bMoreToRead)
  {
    n = fread(&chunkHeader, sizeof(WAVChunkHeader), 1, file);
    if(n != 1)
      ThrowString("Unexpected End Of File Reading <%s>", filePath);

    switch(chunkHeader.ChunkID)
    {
      case WAV_FORMAT_ID:
      {
        s = chunkHeader.ChunkSize - ((int)sizeof(WAVFormat));
        if(s < 0)
          ThrowString("Format Chunk In File <%s> Is Too Small", filePath);
        n = fread(&format, sizeof(WAVFormat), 1, file);
        if(n != 1)
          ThrowString("Unexpected End Of File Reading <%s>", filePath);
        if(s > 0)
        {
          s = fseek(file, s, SEEK_CUR);
          if(s != 0)
            ThrowString("Unexpected End Of File Reading <%s>", filePath);
        }
        bReadFormat = true;
        if(bReadData)
          bMoreToRead = false;
        break;
      }
      case WAV_DATA_ID:
      {
        dataBytes = chunkHeader.ChunkSize;
        data = new short[dataBytes / 2];
        n = fread(data, sizeof(char), dataBytes, file);
        if(n != dataBytes)
          ThrowString("Unexpected End Of File Reading <%s>", filePath);
        bReadData = true;
        if(bReadFormat)
          bMoreToRead = false;
        break;
      }
      default:
      {
        s = fseek(file, chunkHeader.ChunkSize, SEEK_CUR);  
        if(s != 0)
          ThrowString("Unexpected End Of File Reading <%s>", filePath);
      }
    }
  }

  if(format.FormatTag != 1)
  {
    delete data;
    ThrowString("Can't Read Non-PCM Format WAV File <%s>", filePath);
  }

  if(format.BitsPerSample != 16)
  {
    delete data;
    ThrowString("Only 16 Bit WAV Files Supported, <%s> Is %i-Bit", filePath, format.BitsPerSample);
  }

  if(format.Channels != 1)
  {
    delete data;
    ThrowString("Only Mono WAV Files Supported, <%s> Has %i Channels", filePath, format.Channels);
  }

  Samples = dataBytes / 2;
  MonoData = new double[Samples];
  for(i = 0; i < Samples; i++)
  {
    value = data[i];
    if(value < 0)
      MonoData[i] = (double)(value / 32768.0f);
    else
      MonoData[i] = (double)(value / 32767.0f);
  }
  delete data;
}

void CSample::SaveWAV(char *filePath)
{
  FILE           *file;
  WAVHeader       header;
  WAVChunkHeader  chunkHeader;
  WAVFormat       format;
  size_t          n;
  unsigned short *data;
  int             i;
  double           value;

  data = new unsigned short[Samples];
  for(i = 0; i < Samples; i++)
  {
    value = MonoData[i];

    if(value >= 0.0f)
    {
      if(value > 1.0f)
        data[i] = 32767;
      else
        data[i] = (short)(value * 32767.0f);
    }
    else
    {
      if(value < -1.0f)
        data[i] = -32768;
      else
        data[i] = (short)(value * 32768.0f);
    }
  }

  file = fopen(filePath, "wb");
  if(file == 0)
    ThrowString("Can't Open File <%s>", filePath);

  header.ID        = WAV_ID;
  header.Format    = WAV_FORMAT;
  header.ChunkSize = (sizeof(WAVChunkHeader) * 2) + sizeof(WAVFormat) + (2 * Samples);

  n = fwrite(&header, sizeof(WAVHeader), 1, file);
  if(n != 1)
    ThrowString("Can't Write To File <%s>", filePath);

  chunkHeader.ChunkID   = WAV_FORMAT_ID;
  chunkHeader.ChunkSize = sizeof(WAVFormat);

  n = fwrite(&chunkHeader, sizeof(WAVChunkHeader), 1, file);
  if(n != 1)
    ThrowString("Can't Write To File <%s>", filePath);

  format.FormatTag      = 1;
  format.Channels       = 1;
  format.SamplesPerSec  = SampleRate;
  format.AvgBytesPerSec = 2 * SampleRate;
  format.BlockAlign     = 2;
  format.BitsPerSample  = 16;

  n = fwrite(&format, sizeof(WAVFormat), 1, file);
  if(n != 1)
    ThrowString("Can't Write To File <%s>", filePath);

  chunkHeader.ChunkID = WAV_DATA_ID;
  chunkHeader.ChunkSize = 2 * Samples;

  n = fwrite(&chunkHeader, sizeof(WAVChunkHeader), 1, file);
  if(n != 1)
    ThrowString("Can't Write To File <%s>", filePath);

  n = fwrite(data, 2 * Samples, 1, file);
  if(n != 1)
    ThrowString("Can't Write To File <%s>", filePath);

  fclose(file);

  delete data;
}

void CSample::Normalize()
{
  double value, max, scale;
  int   i;

  max = 0.0f;
  for(i = 0; i < Samples; i++)
  {
    value = fabs(MonoData[i]);
    if(value > max)
      max = value;
  }
  if(max > 0.0f)
  {
    scale = 1.0f / max;
    for(i = 0; i < Samples; i++)
      MonoData[i] *= scale;
  }
}