/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "RoomView.h"
#include "Util.h"

#define STATE_IDLE 0
#define STATE_MOVE 1

CRoomView::CRoomView(CSpatialVerbGUI *parent, int x, int y, int width, int height, double alpha, CFrameBuffer *nodes, CSpatialVerb *machine)
: CLiteControl(parent, x, y, width, height)
{
  State = STATE_IDLE;
  Machine = machine;
  CurrentNode = -1;
  Nodes = nodes;
  ValidSource = false;
  Time = 0.0f;
  GUI = parent;
  Alpha = alpha;
  RenderBuffer = new CFrameBuffer(Width, Height, true);
  RenderBuffer->Fill(0);
}

CRoomView::~CRoomView()
{
  delete RenderBuffer;
}

void CRoomView::SetTime(double value)
{
  Time = value;
  Render();
}

void CRoomView::Draw(CFrameBuffer *frameBuffer)
{
  RenderBuffer->Draw(frameBuffer, X, Y, 0, 0, Width, Height);
}

void CRoomView::Update(CImageSource *leftImageSource, CImageSource *rightImageSource, 
  SSize *roomSize, SPos *srcLeftPos, SPos *srcRightPos, SPos *dstLeftPos,
  SPos *dstRightPos, double totalTime)
{
  LeftImageSource = leftImageSource;
  RightImageSource = rightImageSource;
  RoomSize = *roomSize;
  SrcLeftPos = *srcLeftPos;
  SrcRightPos = *srcRightPos;
  DstLeftPos = *dstLeftPos;
  DstRightPos = *dstRightPos;
  TotalTime = totalTime;
  Render();
}

void CRoomView::NodePos(SPos *pos, int *x, int *y)
{
  int width, height;

  if(RoomSize.width > RoomSize.height)
  {
    width  = Width - 2;
    height = (int)((double)width / RoomSize.width * RoomSize.height);
  }
  else
  {
    height = Height - 2;
    width  = (int)((double)height / RoomSize.height * RoomSize.width);
  }
 
  *x = (int)((1 - (Nodes->GetWidth()  >> 2)) + ((pos->x / RoomSize.width) * (width  - 1)));
  *y = (int)((1 - (Nodes->GetHeight() >> 2)) + ((pos->y / RoomSize.height)* (height - 1)));
}

void CRoomView::Render()
{
  int           x, y, xp, yp, width, height;
  double         level, r;
  unsigned char alpha, *pixel;
  SPos          pos;
  double         maxSize;
  const double   invNeg60 = -1.0f / 60.0f;

  if(RoomSize.width > RoomSize.height)
  {
    width  = Width - 2;
    height = (int)((double)width / RoomSize.width * RoomSize.height);
    maxSize = RoomSize.width;
  }
  else
  {
    height = Height - 2;
    width  = (int)((double)height / RoomSize.height * RoomSize.width);
    maxSize = RoomSize.height;
  }

  r = 0.015f * maxSize;

  xp = 1;
  yp = 1;

  RenderBuffer->Fill(0);
  RenderBuffer->DrawRect(xp - 1, yp - 1, width + 2, height + 2, 0, (unsigned char)(Alpha * 0xFF));

  for(x = 0; x < width; x++)
    for(y = 0; y < height; y++)
    {
      pos.x = (((double)x / (double)width)  * RoomSize.width);
      pos.y = (((double)y / (double)height) * RoomSize.height);

      level = RightImageSource->ConvergeGraphical(0, &pos, Time * TotalTime, r) +
               LeftImageSource->ConvergeGraphical(0, &pos, Time * TotalTime, r);
        
      if(level > 1.0f)
        level = 1.0f;
      
      alpha = (unsigned char)(level * Alpha * 0xFF);
      pixel = RenderBuffer->GetPixel4(x + xp, y + yp);
      pixel[3] = alpha;
    }

  RenderNode(NODE_SRCLEFT);
  RenderNode(NODE_SRCRIGHT);
  RenderNode(NODE_DSTLEFT);
  RenderNode(NODE_DSTRIGHT);

  Parent->Render(X, Y, Width, Height);
}

void CRoomView::RenderNode(int node)
{
  SPos          *pos;
  int            dstX, dstY, srcX, srcY, width, height, x, y;
  unsigned char *dst, *src;

  width  = Nodes->GetWidth() >> 1;
  height = Nodes->GetHeight() >> 1;

  switch(node)
  {
    case NODE_SRCLEFT:
      pos  = &SrcLeftPos;
      srcX = 0;
      srcY = 0;
      break;
    
    case NODE_SRCRIGHT:
      pos  = &SrcRightPos;
      srcX = width;
      srcY = 0;
      break;

    case NODE_DSTLEFT:
      pos  = &DstLeftPos;
      srcX = 0;
      srcY = height;
      break;

    case NODE_DSTRIGHT:
      pos  = &DstRightPos;
      srcX = width;
      srcY = height;
      break;

    default:
      return;
  }
    
  NodePos(pos, &dstX, &dstY);

  for(x = 0; x < width; x++)
    for(y = 0; y < height; y++)
    {
      dst = RenderBuffer->GetPixel4(dstX + x, dstY + y);
      if(dst)
      {
        src = Nodes->GetPixel3(srcX + x, srcY + y);
        dst[0] = src[0];
        dst[1] = src[1];
        dst[2] = src[2];
        dst[3] = (unsigned char)((0xFF - ((dst[0] + dst[1] + dst[2]) / 3)) * Alpha);
      }
    }
}

void CRoomView::OnLeftButtonDown(int x, int y)
{
  SPos *pos;

  if(CurrentNode != -1)
  {
    State = STATE_MOVE;
    pos = NodePosPtr(CurrentNode);
    StartPos.x = pos->x;
    StartPos.y = pos->y;
    StartX = x;
    StartY = y;
  }
}

void CRoomView::OnLeftButtonUp(int x, int y)
{
  State = STATE_IDLE;
}

void CRoomView::OnMouseMove(int x, int y)
{
  int   node, dx, dy, width, height;
  double mx, my;
  SPos  pos, *cpos;

  if(State == STATE_MOVE)
  {
    dx = x - StartX;
    dy = y - StartY;

    if(RoomSize.width > RoomSize.height)
    {
      width  = Width - 2;
      height = (int)((double)width / RoomSize.width * RoomSize.height);
      //maxSize = RoomSize.width;
    }
    else
    {
      height = Height - 2;
      width  = (int)((double)height / RoomSize.height * RoomSize.width);
      //maxSize = RoomSize.height;
    }

    mx = ((double)dx / (double)width)  * RoomSize.width;
    my = ((double)dy / (double)height) * RoomSize.height;

    pos.x = StartPos.x + mx;
    pos.y = StartPos.y + my;

    if(pos.x < 0.0f)
      pos.x = 0.0f;
    else if(pos.x > RoomSize.width)
      pos.x = RoomSize.width;

    if(pos.y < 0.0f)
      pos.y = 0.0f;
    else if(pos.y > RoomSize.height)
      pos.y = RoomSize.height;

    cpos = NodePosPtr(CurrentNode);
    if(cpos->x != pos.x && cpos->y != pos.y)
    {
      Machine->Lock();
      Machine->MoveNode(CurrentNode, &pos);
      Machine->Release();
    }
  }
  else
  {
    node = InNode(x - X, y - Y);
    if(CurrentNode != -1)
    {
      if(node == -1)
      {
        SetCursor(LoadCursor(NULL, IDC_ARROW));
        ReleaseCapture();
      }
    }
    else
    {
      if(node != -1)
      {
        SetCursor(LoadCursor(NULL, IDC_SIZEALL));
        SetCapture();
      }
    }

    CurrentNode = node;
  }
}

int CRoomView::InNode(int x, int y)
{
  int   node, nx, ny, width, height;
  SPos *pos;

  width  = Nodes->GetWidth()  >> 1;
  height = Nodes->GetHeight() >> 1;

  for(node = 3; node >= 0; node--)
  {
    pos = NodePosPtr(node);
    NodePos(pos, &nx, &ny);

    if(x >= nx && x < nx + width && y >= ny && y < ny + height)
      return node;
  }
  return -1;
}

SPos *CRoomView::NodePosPtr(int node)
{
  switch(node)
  {
    case NODE_SRCLEFT:
      return &SrcLeftPos;
    case NODE_SRCRIGHT:
      return &SrcRightPos;
    case NODE_DSTLEFT:
      return &DstLeftPos;
    case NODE_DSTRIGHT:
      return &DstRightPos;
    default:
      return 0;
  }
}