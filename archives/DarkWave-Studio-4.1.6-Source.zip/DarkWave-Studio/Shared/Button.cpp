/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Button.h"
#include "BackBuffer.h"
#include "Font.h"

#define STATE_IDLE     0
#define STATE_DOWN     1
#define STATE_DOWN_OUT 2
#define STATE_DISABLED 3

CButton::CButton(CControl *parent, CFont *font, char *text, int x, int y, int width, int height)
: CControl(parent, "Button", x, y, width, height, true)
{
  State      = STATE_IDLE;
  Font       = font;
  Text       = text;
  DrawControl();
}

CButton::~CButton()
{
}

void CButton::DrawControl()
{
  HDC     hDC;
  HGDIOBJ oldFont;
  RECT    r;
  bool    pressed, disabled;
  ColorManagerColor backColor;
  ColorManagerColor textColor;

  hDC      = BackDC;
  pressed  = State == STATE_DOWN;
  disabled = State == STATE_DISABLED;

  ColorManager->Lock();

  if(disabled)
  {
    backColor = (ColorManagerColor)ControlBackDisabled;
    textColor = (ColorManagerColor)ControlTextDisabled;
  }
  else
  {
    backColor = (ColorManagerColor)ControlBack;
    textColor = (ColorManagerColor)ControlText;
  }

  ColorManager->GetBrush(backColor)->FillRect(hDC, 0, 0, Width, Height);
  oldFont = SelectObject(hDC, Font->Handle);
  SetBkColor(hDC, ColorManager->GetColor(backColor));
  SetTextColor(hDC, ColorManager->GetColor(textColor));
  
  if(pressed)
  {
    r.left = 1;
    r.top  = 1;
  }
  else
  {
    r.left   = 0;
    r.top    = 0;
  }
  r.right  = r.left + Width  - 1;
  r.bottom = r.top  + Height - 1;

  DrawTextA(hDC, Text, (int)strlen(Text), &r, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
  
  SelectObject(hDC, oldFont);

  ColorManager->Release();

  DrawBorder(hDC, pressed ? bs3DSunken : bs3DRaised, 0, 0, Width - 1, Height - 1);
}

void CButton::OnLeftButtonDown(int x, int y)
{
  if(State == STATE_DISABLED)
    return;
  if(x >= 0 && x < Width && y >= 0 && y < Height)
  {
    State = STATE_DOWN;
    SetCapture(Handle);
    Update();
  }
}

void CButton::OnLeftButtonDoubleClick(int x, int y)
{
  if(State == STATE_DISABLED)
    return;
  OnLeftButtonDown(x, y);
}

void CButton::OnMouseMove(int x, int y)
{
  bool bIn;

  if(State == STATE_DISABLED)
    return;
  bIn = (x >= 0 && x < Width && y >= 0 && y < Height);

  if(State == STATE_DOWN)
  {
    if(!bIn)
    {
      State = STATE_DOWN_OUT;
      Update();
    }
  }
  else
  {
    if(State == STATE_DOWN_OUT && bIn)
    {
      State = STATE_DOWN;
      Update();
    }
  }
}

void CButton::OnLeftButtonUp(int x, int y)
{
  if(State == STATE_DISABLED)
    return;

  if(State != STATE_IDLE)
  {
    ReleaseCapture();
    if(State == STATE_DOWN)
      Parent->OnButtonPress(this);
    if(State != STATE_DISABLED)
      State = STATE_IDLE;
    Update();
  }
}

void CButton::Enable()
{
  State = STATE_IDLE;
  Update();
}

void CButton::Disable()
{
  State = STATE_DISABLED;
  Update();
}