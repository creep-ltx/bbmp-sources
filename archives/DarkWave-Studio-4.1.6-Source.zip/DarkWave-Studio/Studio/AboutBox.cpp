/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "AboutBox.h"
#include "FrameBuffer.h"
#include "Font.h"
#include "Label.h"
#include "Util.h"

#define STATE_IDLE   0
#define STATE_ONLINK 1

#define LABEL_BORDER  24
#define LABEL_X       LABEL_BORDER
#define LABEL_Y       216
#define LABEL_WIDTH   (492 - (LABEL_BORDER * 2))
#define LABEL_HEIGHT  (96  - LABEL_BORDER)

#define LINK_X      160
#define LINK_Y      120
#define LINK_WIDTH  260
#define LINK_HEIGHT 16

CAboutBox::CAboutBox(CControl *parent, CColorManager *colorManager, CFrameBuffer *background)
: CDialog(parent, "AboutBox", background->GetWidth(), background->GetHeight(), new CColorManager(colorManager), false, true, false)
{
  SetBorder(bs3DRaised);
  State = STATE_IDLE;
  ColorManager->SetColor((ColorManagerColor)ControlBack, RGB(0x00, 0x00, 0x00));
  ColorManager->SetColor((ColorManagerColor)ControlText, RGB(0xAA, 0xAA, 0xAA));
  Background = background;
  SetFont(new CFont(DC, "Verdana", 11.0f, true));
  Label = new CLabel(this, "", LABEL_X, LABEL_Y, LABEL_WIDTH, LABEL_HEIGHT, 0);
  Label->Show();
  Label->SetWantClicks(true);
  DrawControl();
}

CAboutBox::~CAboutBox()
{
  delete Label;
  delete ColorManager;
}

void CAboutBox::DrawControl()
{
  Background->Draw(GetBackBuffer());
}

void CAboutBox::Show(int showState)
{
  CDialog::Show(showState);
  if(showState == SW_SHOW)
    UpdateWindow(Handle);
}

void CAboutBox::OnLeftButtonDown(int x, int y)
{
  if(Parent != 0)
  {
    if(State == STATE_ONLINK)
    {
      SetCursor(LoadCursor(NULL, IDC_WAIT));
      ShowWebPage("http://www.experimentalscene.com");
    }
    else
      Hide();
  }
}

void CAboutBox::SetLabelText(char *text)
{
  Label->SetText(text);
}

void CAboutBox::OnMouseMove(int x, int y)
{
  bool inLink;

  inLink = (x >= LINK_X && x < LINK_X + LINK_WIDTH && y >= LINK_Y && y < LINK_Y + LINK_HEIGHT); 

  if(State == STATE_IDLE)
  {
    if(inLink)
    {
      State = STATE_ONLINK;
      SetCursor(LoadCursor(NULL, IDC_HAND));
      SetCapture(Handle);
    }
  }
  else
  {
    if(!inLink)
    {
      State = STATE_IDLE;
      SetCursor(LoadCursor(NULL, IDC_ARROW));
      ReleaseCapture();
    }
  }
}