/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef WAVEOUTDRIVER_H
#define WAVEOUTDRIVER_H

#define WAVE_MAX_LATENCY     16384
#define WAVE_MIN_LATENCY     2048
#define WAVE_GRANULARITY     512
#define WAVE_DEFAULT_LATENCY 8192

#include <windows.h>
#include <mmsystem.h>
#include "AudioOutputDriver.h"
#include "Mutex.h"

class CWaveOutDriver : public CAudioOutputDriver, private CHostMutex
{
public:
                CWaveOutDriver();
  virtual      ~CWaveOutDriver();
  virtual void  SetWriteCallback(AudioOutputWriteCallback *funcPtr);
  virtual int   GetBlockSamples();
  virtual int   GetSampleRate();
  virtual char *GetName();
  virtual void  Open();
  virtual void  Close();
          void  WriteBlock(int block);
          void  BlockFinished(WAVEHDR *header);
          int   GetDeviceCount();
          char *GetDeviceName(int index);
          int   GetDevice();
          int   GetDeviceFormats(int index);
          char *DescribeFormat(int format);
          void  FormatProperties(int format, int *sampleRate, int *bits, bool *stereo);
          int   GetFormat();
          int   ChooseFormat(int preferredFormat);
          void  SetDevice(int device);
          void  SetFormat(int format);
          int   GetLatency();
          void  SetLatency(int latency);
          int   CalcBlockSamples(int latency, int sampleRate);
  virtual int   GetNumChannels();
  virtual bool  CanOpen();

private:
  AudioOutputWriteCallback *WriteCallback;
  int                       SampleRate, BlockSamples, Bits;
  bool                      Stereo;
  HWAVEOUT                  WaveOut;
  void                     *Buffer[2];
  WAVEHDR                   Header[2];
  double                   *MixBuffer[2];
  bool                      PlayBlocks;
  WAVEOUTCAPS              *DeviceCaps;
  int                       DeviceCount;
  int                       Device, Format, Latency;
};

#endif