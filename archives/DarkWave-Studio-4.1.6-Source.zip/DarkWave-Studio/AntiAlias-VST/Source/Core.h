/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CORE_H
#define CORE_H

#include "DarkPlug.h"
#include "AntiAliasFilter.h"
#include "DarkPlugAdapter.h"
#include "DSP.h"

class CCore
{
public:
  CCore(int cpuFeatures, audioMasterCallback audioMaster);
 ~CCore();

  int                   CPUFeatures;
  CHostAdapter         *Host;
};

extern CCore *Core;
extern CDSP  *DSP;
extern HINSTANCE AppInstance;

#endif