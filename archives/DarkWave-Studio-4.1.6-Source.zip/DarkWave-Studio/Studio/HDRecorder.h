/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef HD_RECORDER_H
#define HD_RECORDER_H

#include <stdio.h>

#include "../Shared/Control.h"
#include "../Shared/Font.h"
#include "../Shared/ToolBar.h"
#include "../Shared/BackBuffer.h"
#include "../Shared/Label.h"
#include "../Shared/Array.h"
#include "../Shared/LiteContainer.h"
#include "../Shared/LiteControl.h"

class CHDRecorder;
class CHDTrackList;
class CHeavyKnob;
class CPeakMeter;
class CHDTrackMachine;

class CTimeDisplay : public CLiteContainer, public CLiteControl
{
public:
               CTimeDisplay(CControl *parent, int x, int y, int width, int height);
              ~CTimeDisplay();
  virtual void Draw(CFrameBuffer *frameBuffer);
  void         SetTime(double time);

private:
  double Time;
};

class CHDTrack : public CToolBar, public CMutex
{
public:
              CHDTrack(CHDTrackMachine *machine, CHDTrackList *parent, char *name, int x, int y, int width, int height, CFont *font);
             ~CHDTrack();

  void          SetFileName(char *newName);
  void          GetFileName(char *fileName);
  virtual void  OnToolBarButtonPress(CToolBarButton *button);
  void          Write(int samples, double *leftData, double *rightData);
  void          Write(int samples, double *monoData);
  void          Open();
  void          Close();
  void          SetName(char *name);
  void		      Idle();
  virtual void  OnResize(int newWidth, int newHeight);
  
  CHDTrackMachine *Machine;

private:
  CHeavyKnob      *VolumeKnob;
  CPeakMeter      *PeakMeter;
  CToolBarButton  *SaveButton, *RecordButton;
  CLabel          *NameLabel, *FileLabel;
  CTimeDisplay    *TimeDisplay;
  char             FileName[1024];
  bool             Recording;
  FILE            *File;
  double           Time;
  int              Samples, Format;
};


class CHDTrackList : public CControl
{
public:
              CHDTrackList(CHDRecorder *parent, int x, int y, int width, int height, CFont *font);
             ~CHDTrackList();
 virtual void OnResize(int newWidth, int newHeight);
 int          AddTrack(CHDTrackMachine *machine);
 void         RemoveTrack(CHDTrackMachine *machine);
 void         ClearTracks();

  CArray<CHDTrack*> *Items;
};

class CHDRecorder : public CControl
{
public:
                CHDRecorder(CControl *parent, int x, int y, int width, int height);
               ~CHDRecorder();
  virtual void  OnResize(int newWidth, int newHeight);
  int           AddTrack(CHDTrackMachine *machine);
  void          RemoveTrack(CHDTrackMachine *machine);
  CHDTrackList *TrackList;
  void          Idle();
  void			Start();
  void		    Stop();
  virtual void  OnToolBarButtonPress(CToolBarButton *button);

private:
  CToolBar       *ToolBar;
  CToolBarButton *RecordButton;
};

#endif