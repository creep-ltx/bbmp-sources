/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Slider.h"

#define HANDLE_WIDTH  10
#define HANDLE_HEIGHT 16

#define STATE_IDLE   0
#define STATE_MOVING 1

CSlider::CSlider(CControl *parent, int x, int y, int width, int height, int flags)
: CControl(parent, "Slider", x, y, width, height, true)
{
  Parent = parent;
  Flags = flags;
  Value = 0.0f;
  SubInit = true;
  State = STATE_IDLE;
  MouseCaptured = false;
  if(Flags & SLIDER_BORDER)
    SetBorder(bs3DRaised);
  DrawControl();
}

CSlider::~CSlider()
{
}

void CSlider::BeforeChange()
{
}

void CSlider::AfterChange()
{
}

void CSlider::DrawControl()
{
  HDC hDC;

  hDC = BackDC;

  CControl::DrawControl();
  if(Flags & SLIDER_VERTICAL)
    DrawGroove(hDC, (Width / 2) - 1, 2, 4, Height - 4); 
  else
    DrawGroove(hDC, 2, (Height / 2) - 1, Width - 4, 4); 

  DrawHandle(hDC);
}

void CSlider::DrawGroove(HDC hDC, int x, int y, int width, int height)
{
  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)Black)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);
  ColorManager->Release();
  DrawBorder(hDC, bs3DSunken, x, y, width, height);
}

void CSlider::DrawHandle(HDC hDC)
{
  HGDIOBJ oldPen, oldBrush;
  int     x1, y1, x2, y2;

  HandleRect(&x1, &y1, &x2, &y2);

  ColorManager->Lock();

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)Black)->Handle);
  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)HighlightBack)->Handle);

  Rectangle(hDC, x1, y1, x2, y2);
  
  SelectObject(hDC, oldPen);
  SelectObject(hDC, oldBrush);

  ColorManager->Release();

  DrawBorder(hDC, bs3DRaised, x1 + 1, y1 + 1, x2 - x1 - 2, y2 - y1 - 2);
}

void CSlider::HandleRect(int *x1, int *y1, int *x2, int *y2)
{
  if(Flags & SLIDER_VERTICAL)
  {
    *x1 = ((Width - HANDLE_HEIGHT) / 2) + 1;
    *y1 = 2 + (int)((1.0f - Value) * (Height - (3 + HANDLE_WIDTH)));
    *x2 = *x1 + HANDLE_HEIGHT - 1;
    *y2 = *y1 + HANDLE_WIDTH - 1;
  }
  else
  {
    *x1 = 2 + (int)(Value * (Width - (3 + HANDLE_WIDTH)));
    *y1 = ((Height - HANDLE_HEIGHT) / 2) + 1;
    *x2 = *x1 + HANDLE_WIDTH - 1;
    *y2 = *y1 + HANDLE_HEIGHT - 1;
  }
}

void CSlider::OnChange(double newValue)
{
  Value = newValue;
  Update();
  if(Parent != 0)
    Parent->OnSliderChange(this, newValue);
}

void CSlider::SetValue(double newValue)
{
  if(Value != newValue)
    OnChange(newValue);
}

void CSlider::OnRightButtonDown(int x, int y)
{
  if(MouseCaptured)
    if(x < 0 || x >= Width || y < 0 || y >= Height)
    {
      AfterChange();
      ReleaseCapture();
      Hide();
      MouseCaptured = false;
      return;
    }
}

void CSlider::OnLeftButtonDown(int x, int y)
{
  int x1, y1, x2, y2;

  if(MouseCaptured)
    if(x < 0 || x >= Width || y < 0 || y >= Height)
    {
      AfterChange();
      ReleaseCapture();
      Hide();
      MouseCaptured = false;
      return;
    }

  HandleRect(&x1, &y1, &x2, &y2);
  if(x >= x1 && x <= x2 && y >= y1 && y <= y2)
  {
    BeforeChange();
    State = STATE_MOVING;
    StartValue = Value;
    if(Flags & SLIDER_VERTICAL)
      StartPos = y;
    else
      StartPos = x;
    SetCapture(Handle);
  }
}

void CSlider::OnMouseMove(int x, int y)
{
  int    move;
  double newValue;

  if(State == STATE_MOVING)
  {
    if(Flags & SLIDER_VERTICAL)
    {
      move = StartPos - y;
      newValue = StartValue + ((double)move / (double)(Height - (3 + HANDLE_WIDTH))); 
    }
    else
    {
      move = x - StartPos;
      newValue = StartValue + ((double)move / (double)(Width - (3 + HANDLE_WIDTH))); 
    }

    if(newValue < 0.0f)
      newValue = 0.0f;
    else if(newValue > 1.0f)
      newValue = 1.0f;

    SetValue(newValue);
  }
}

void CSlider::OnLeftButtonUp(int x, int y)
{
  if(State == STATE_MOVING)
  {
    State = STATE_IDLE;
    ReleaseCapture();
    AfterChange();
  }
  if(MouseCaptured)
  {
    Hide();
    MouseCaptured = false;
    return;
  }
}

void CSlider::ShowPopup(int x, int y)
{
  POINT p;

  Move(x - (Width / 2), y - (Height / 2));
  Show();
  SetCapture(Handle);
  State = STATE_MOVING;
  StartValue = Value;
  GetCursorPos(&p);
  ScreenToClient(Handle, &p);

  if(Flags & SLIDER_VERTICAL)
    StartPos = p.y;
  else
    StartPos = p.x;
  
  MouseCaptured = true;
}

