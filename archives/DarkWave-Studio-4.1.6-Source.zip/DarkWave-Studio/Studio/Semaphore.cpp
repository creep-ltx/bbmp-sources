/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Semaphore.h"
#include "Error.h"

CSemaphore::CSemaphore()
{
  CSemaphore(0, 1);
}

CSemaphore::CSemaphore(int initialCount, int maxCount)
{
  Handle = CreateSemaphore(NULL, initialCount, maxCount, NULL);
  if(Handle == NULL)
    ThrowString("Can't Create Semaphore, Error Code 0x%x", GetLastError());
 }

CSemaphore::~CSemaphore()
{
  CloseHandle(Handle);
}

void CSemaphore::Lock()
{
  DWORD s;

  s = WaitForSingleObject(Handle, INFINITE);
  if(s != WAIT_OBJECT_0)
    ThrowString("Can't Lock Semaphore, Error Code 0x%x", s);
}

void CSemaphore::Release()
{
  Release(1);
}

void CSemaphore::Release(int count)
{
  BOOL s;

  s = ReleaseSemaphore(Handle, count, NULL);
  if(s == 0)
  {
    s = GetLastError();
    ThrowString("Can't Release Semaphore, Error Code 0x%x", s);
  }
}