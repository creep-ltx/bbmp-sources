/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define _WIN32_IE 0x0501

#include "ToolTip.h"
#include "Error.h"
#include <windows.h>
#include <commctrl.h>

extern HINSTANCE AppInstance;

// Tracking ToolTips Require Version 4.7 Of Common Controls

CToolTip::CToolTip(HWND parent)
{
  Handle = CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL,
    WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP,
    CW_USEDEFAULT, CW_USEDEFAULT,
    CW_USEDEFAULT, CW_USEDEFAULT,
    parent, NULL, AppInstance, NULL);
}

CToolTip::~CToolTip()
{
  DestroyWindow(Handle);
}

void CToolTip::AddTool(HWND hWnd, char *text, bool tracking)
{
  TOOLINFOA ti;
  LRESULT   s;
  
  memset(&ti, 0, sizeof(ti));

  ti.cbSize   = 40;
  ti.uFlags   = tracking ? TTF_IDISHWND | TTF_TRACK | TTF_ABSOLUTE : TTF_SUBCLASS;
  ti.hwnd     = hWnd;
  ti.hinst    = AppInstance;
  ti.uId      = tracking ? (UINT_PTR)(hWnd) : 0;
  ti.lpszText = text;
  
  GetClientRect(hWnd, &ti.rect);
  
  s = SendMessage(Handle, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFOA)&ti);	
#ifdef _DEBUG
  if(s != TRUE)
    DisplayError("CToolTip::AddTool() Failed - GetLastError() Returned 0x%x", GetLastError());
#endif
}

void CToolTip::TrackPosition(int x, int y)
{
  SendMessage(Handle, TTM_TRACKPOSITION, 0, MAKELPARAM(x, y));
}
void CToolTip::TrackActivate(HWND hWnd, bool activate)
{
  TOOLINFO ti;

  memset(&ti, 0, sizeof(TOOLINFO));

  ti.cbSize = 40;
  ti.uId    = (UINT_PTR)hWnd;
  ti.hwnd   = hWnd;

  SendMessage(Handle, TTM_TRACKACTIVATE, (WPARAM)(BOOL)activate ? TRUE : FALSE, (LPARAM)&ti); 
}

void CToolTip::UpdateText(HWND hWnd, char *text, bool tracking)
{
  TOOLINFOA ti;
  
  memset(&ti, 0, sizeof(TOOLINFOA));

  ti.cbSize   = 40;
  ti.uId      = tracking ? (UINT_PTR)hWnd : 0;
  ti.hwnd     = hWnd;
  ti.hinst    = AppInstance;
  ti.lpszText = text;

  SendMessage(Handle, TTM_UPDATETIPTEXT, (WPARAM)0, (LPARAM)&ti); 
}