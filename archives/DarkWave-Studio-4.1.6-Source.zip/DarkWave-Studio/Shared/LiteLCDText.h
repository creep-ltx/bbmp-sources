/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef LITE_LCD_TEXT_H
#define LITE_LCD_TEXT_H

#include "LiteControl.h"
#include "LiteContainer.h"
#include "Timer.h"
#include "BitFont.h"

class CLiteLCDText : public CLiteControl, public CTimerCallback
{
public:
               CLiteLCDText(CLiteContainer *parent, int x, int y, int width, int height, CBitFont *font, double alpha);
              ~CLiteLCDText();
  void         SetText(char *text);
  void         Render();
  virtual void Draw(CFrameBuffer *frameBuffer);
  virtual void OnTimer(CTimer *timer);

private:
  CBitFont     *Font;
  int           TextOffset;
  char         *Text;
  CFrameBuffer *RenderBuffer;
  double        Alpha;
  CTimer       *Timer;
};

#endif