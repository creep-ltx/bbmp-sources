/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "Error.h"
#include "Core.h"
#include "../Resource.h"

#define SIZEBAR_HEIGHT                6
#define SIZEBAR_WIDTH                 6
#define TOOLBAR_X                     0
#define TOOLBAR_Y                     0
#define TOOLBAR_WIDTH(w)              (w)
#define TOOLBAR_HEIGHT                30
#define BANKLIST_X                    8
#define BANKLIST_Y                    (TOOLBAR_Y + TOOLBAR_HEIGHT + 8)
#define BANKLIST_HEIGHT(h)            (h - (TOOLBAR_Y + TOOLBAR_HEIGHT + 16))
#define LIST_ITEMHEIGHT               18
#define BANKINFO_X(blw)               (BANKLIST_X + blw + 6)
#define BANKINFO_Y                    BANKLIST_Y
#define BANKINFO_WIDTH(w, blw)        (w - (blw + 22))
#define BANKINFO_HEIGHT(h)            (BANKLIST_HEIGHT(h) - 6)
#define PRESETLIST_X(blw)             BANKINFO_X(blw)
#define PRESETLIST_Y(bih)             (BANKINFO_Y + bih + 6)
#define PRESETLIST_WIDTH(w, blw)      (BANKINFO_WIDTH(w, blw) - 6)
#define PRESETLIST_HEIGHT(h, bih)     (h - (bih + TOOLBAR_HEIGHT + 22))
#define SAMPLELIST_X(blw, plw)        (PRESETLIST_X(blw) + plw + 6)
#define SAMPLELIST_Y(bih)             PRESETLIST_Y(bih)
#define SAMPLELIST_WIDTH(w, blw, plw) (PRESETLIST_WIDTH(w, blw) - plw)
#define SAMPLELIST_HEIGHT(h, bih)     PRESETLIST_HEIGHT(h, bih)

const char *LoadBankTitle  = "Load Bank";
const char *LoadBankFilter = "SoundFont Banks (*.sf2)\x00*.SF2\x00";

#include "BankExplorer.h"
#include "SoundFontLoader.h"

CBankExplorer::CBankExplorer(CHost *host, CControl *parent, int x, int y, int width, int height)
: CControl(parent, "BankExplorer", x, y, width, height, false),
  CBankClient(host)
{
  BankListPercent = 0.2f;
  BankListWidth   = 128;

  InfoViewPercent = 0.5f;
  InfoViewHeight  = 256;

  PresetListPercent = 0.5f;
  PresetListWidth   = 128;

  SetFont(new CFont(DC, "Verdana", 10.0f, false));

  LoadDialog = new CFileDialog(LoadBankTitle, LoadBankFilter);

  SetBorder(bs3DSunken);

  ToolBar = new CToolBar(this, TOOLBAR_X, TOOLBAR_Y, TOOLBAR_WIDTH(Width), TOOLBAR_HEIGHT);
  LoadButton = ToolBar->AddButton(IDI_OPEN, 0, 20, 20, "Load Bank", false);
  ToolBar->Show();

  BankList = new CListBox(this, Font, BANKLIST_X, BANKLIST_Y, BankListWidth, BANKLIST_HEIGHT(Height), LIST_ITEMHEIGHT);
  BankList->SetHeader("Banks");
  BankList->Show();

  InfoView = new CInfoView(this, Font, "BankInfo", BANKINFO_X(BankListWidth), BANKINFO_Y, BANKINFO_WIDTH(Width, BankListWidth), InfoViewHeight, LIST_ITEMHEIGHT);
  InfoView->SetHeader("Bank Information");
  InfoView->Show();

  PresetList = new CListBox(this, Font, PRESETLIST_X(BankListWidth), PRESETLIST_Y(InfoViewHeight), PresetListWidth, PRESETLIST_HEIGHT(Height, InfoViewHeight), LIST_ITEMHEIGHT);
  PresetList->SetHeader("Bank Presets");
  PresetList->Show();
  
  SampleList = new CListBox(this, Font, SAMPLELIST_X(BankListWidth, PresetListWidth), SAMPLELIST_Y(InfoViewHeight), SAMPLELIST_WIDTH(Width, BankListWidth, PresetListWidth), SAMPLELIST_HEIGHT(Height, InfoViewHeight), LIST_ITEMHEIGHT);
  SampleList->SetHeader("Bank Samples");
  SampleList->Show();

  BankListSizeBar   = new CSizeBar(this, SIZEBAR_STYLE_VERTICAL, BankListWidth, TOOLBAR_HEIGHT, SIZEBAR_WIDTH, Height - TOOLBAR_HEIGHT);
  InfoViewSizeBar   = new CSizeBar(this, SIZEBAR_STYLE_HORIZONTAL, BANKINFO_X(BankListWidth), TOOLBAR_HEIGHT + InfoViewHeight, BANKINFO_WIDTH(Width, BankListWidth), SIZEBAR_HEIGHT);
  PresetListSizeBar = new CSizeBar(this, SIZEBAR_STYLE_VERTICAL, PRESETLIST_X(BankListWidth) + PresetListWidth, BANKINFO_Y + InfoViewHeight + 8, SIZEBAR_WIDTH, PRESETLIST_HEIGHT(Height, InfoViewHeight)); 

  BankListSizeBar->Show();
  InfoViewSizeBar->Show();
  PresetListSizeBar->Show();

  SubInit = true;
  PerformLayout();
  ConnectBankServer();
}

CBankExplorer::~CBankExplorer()
{
  DisconnectBankServer();
  delete BankListSizeBar;
  delete InfoViewSizeBar;
  delete PresetListSizeBar;
  delete LoadDialog;
  delete ToolBar;
  delete LoadButton;
  delete BankList;
  delete InfoView;
  delete PresetList;
  delete SampleList;
}

void CBankExplorer::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
  {
    PerformLayout();
  }
}

void CBankExplorer::PerformLayout()
{
  BankListWidth = (Width - 24);
  BankListWidth = (int)(BankListWidth * BankListPercent);
  InfoViewHeight = BANKINFO_HEIGHT(Height);
  InfoViewHeight = (int)(InfoViewHeight * InfoViewPercent);
  PresetListWidth = PRESETLIST_WIDTH(Width, BankListWidth);
  PresetListWidth = (int)(PresetListWidth * PresetListPercent);

  ToolBar->Resize(TOOLBAR_WIDTH(Width), TOOLBAR_HEIGHT);
  BankList->Resize(BankListWidth, BANKLIST_HEIGHT(Height));
  InfoView->Resize(BANKINFO_WIDTH(Width, BankListWidth), InfoViewHeight);
  InfoView->Move(BANKINFO_X(BankListWidth), BANKINFO_Y);
  PresetList->Resize(PresetListWidth, PRESETLIST_HEIGHT(Height, InfoViewHeight));
  PresetList->Move(PRESETLIST_X(BankListWidth), PRESETLIST_Y(InfoViewHeight));
  SampleList->Move(SAMPLELIST_X(BankListWidth, PresetListWidth), SAMPLELIST_Y(InfoViewHeight), SAMPLELIST_WIDTH(Width, BankListWidth, PresetListWidth), SAMPLELIST_HEIGHT(Height, InfoViewHeight));
  
  BankListSizeBar->Move(BANKLIST_X + BankListWidth, TOOLBAR_HEIGHT + 8, SIZEBAR_WIDTH, Height - (TOOLBAR_HEIGHT + 16));
  InfoViewSizeBar->Move(BANKINFO_X(BankListWidth), TOOLBAR_HEIGHT + InfoViewHeight + 8, BANKINFO_WIDTH(Width, BankListWidth), SIZEBAR_HEIGHT);
  PresetListSizeBar->Move(PRESETLIST_X(BankListWidth) + PresetListWidth, BANKINFO_Y + InfoViewHeight + 6, SIZEBAR_WIDTH, PRESETLIST_HEIGHT(Height, InfoViewHeight)); 

}

void CBankExplorer::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == LoadButton)
    LoadBank();
}

void CBankExplorer::LoadBank()
{
  char fileName[MAX_FILE];

  fileName[0] = 0;

  if(LoadDialog->ShowOpen(Handle, fileName))
  {
    CSoundFontLoader *loader;
    EError            error;

    loader = new CSoundFontLoader(BankServer);
    error = loader->Load(fileName);
    delete loader;

    if(error != errorOK)
      DisplayError("Error 0x%x Occured While Loading '%s'", error, fileName);
  }
}

void CBankExplorer::OnAddBank(int bankIndex)
{
  EError error;
  char  *name;
  int    nameLength;

  error = BankServer->GetBankNameLength(bankIndex, &nameLength);
  if(error != errorOK)
    return;

  name = new char[nameLength + 1];
  error = BankServer->GetBankName(bankIndex, name);
  if(error != errorOK)
    return;

  BankList->AddItem(name, bankIndex);
  delete name;
}

void CBankExplorer::OnListSelChange(CListBox *listBox)
{
  if(listBox == BankList)
  {
    ShowBank(listBox->GetSelection());
  }
}

void CBankExplorer::ShowBank(int index)
{
  int    i, n, length;
  EError err;
  char  *text;

  InfoView->ShowBank(index);

  PresetList->Clear();
  err = BankServer->GetPresetCount(index, &n);
  if(err == errorOK)
  {
    for(i = 0; i < n; i++)
    {
      err = BankServer->GetPresetNameLength(index, i, &length);
      if(err == errorOK)
      {
        text = new char[length + 1];
        err = BankServer->GetPresetName(index, i, text);
        if(err == errorOK)
        {
          PresetList->AddItem(text, i);
        }
        delete text;
      }
    }
  }
}

float CBankExplorer::NewPercent(int amount, int max, float oldPercent)
{
  float newPercent;

  newPercent = oldPercent + ((float)(amount) / (float)max);
  if(newPercent < 0.1f)
    newPercent = 0.1f;
  else if(newPercent > 0.9f)
    newPercent = 0.9f;
  return newPercent;
}

void CBankExplorer::OnSizeX(CSizeBar *sizeBar, int amount)
{
  if(sizeBar == BankListSizeBar)
    BankListPercent = NewPercent(amount, Width - 24, BankListPercent);
  else if(sizeBar == PresetListSizeBar)
    PresetListPercent = NewPercent(amount, PRESETLIST_WIDTH(Width, BankListWidth), PresetListPercent);
  else
    return;
  PerformLayout();
}

void CBankExplorer::OnSizeY(CSizeBar *sizeBar, int amount)
{
  InfoViewPercent = NewPercent(amount, BANKINFO_HEIGHT(Height), InfoViewPercent);
  PerformLayout();
}

void CBankExplorer::OnListDblClick(CListBox *listBox)
{
  int bankIndex, presetIndex;

  if(listBox == PresetList)
  {
    bankIndex   = BankList->GetItemData(BankList->GetSelection());
    presetIndex = PresetList->GetItemData(PresetList->GetSelection());

    Core->MainWindow->PresetEditor->ShowPreset(bankIndex, presetIndex);
    Core->MainWindow->ShowControl(MAINWINDOW_CONTROL_PRESETEDITOR);
  }
}