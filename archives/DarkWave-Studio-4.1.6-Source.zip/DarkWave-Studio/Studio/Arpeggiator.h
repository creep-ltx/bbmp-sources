/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ARPEGGIATOR_H
#define ARPEGGIATOR_H

#include <DarkPlug.h>
#include "Control.h"
#include "LiteContainer.h"
#include "ToolBar.h"
#include "Label.h"
#include "UpDown.h"

class CArpeggiator;
class CArpeggiatorGUI;

struct SArpeggiatorGraphics
{
  CFrameBuffer *Background;
};

class CArpeggiatorGrid : public CLiteControl
{
public:

               CArpeggiatorGrid(CArpeggiatorGUI *parent, CArpeggiator *arpeggiator, int x, int y, int width, int height);
              ~CArpeggiatorGrid();
  virtual void Draw(CFrameBuffer *frameBuffer);
  virtual void OnMouseMove(int x, int y);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  int          RowAt(int y);
  int          ColAt(int x);

private:
  CArpeggiator *Arpeggiator;
  bool          Drawing, DrawValue;
};

class CArpeggiatorGUI : public CLiteContainer
{
public:
               CArpeggiatorGUI(HWND parent, CArpeggiator *arpeggiator, SArpeggiatorGraphics *graphics);
              ~CArpeggiatorGUI();

  virtual void OnUpDownChange(CUpDown *upDown);
  
private:
  CArpeggiator     *Arpeggiator;
  CToolBar         *ToolBar;
  CLabel           *TPBLabel,  *LengthLabel;
  CUpDown          *TPBUpDown, *LengthUpDown;
  CArpeggiatorGrid *Grid;
};

#define GRID_ROWS    12
#define GRID_COLS    32

class CArpeggiator : public CMachine
{
public:
                         CArpeggiator(CHost *host, SArpeggiatorGraphics *graphics);
  virtual               ~CArpeggiator();

  virtual void  DARKCALL Work();
  virtual HWND  DARKCALL CreateGUI(HWND parent);
  virtual void  DARKCALL SetSampleRate(int sampleRate);
  virtual void  DARKCALL SetBlockSamples(int blockSamples);
  virtual bool  DARKCALL IsSynth();

  virtual void  DARKCALL ReadProperties(char *data, int length, bool isInner);
  virtual void  DARKCALL WriteProperties(char **data, int *length, bool *isInner);

  int  GetTPB();
  int  GetLength();

  void SetTPB(int newTPB);
  void SetLength(int newPolyphony);

  void ClearCells();
  bool GetCell(int row, int col);
  void SetCell(int row, int col, bool v);

  void ProcessMessage(SControlMessage *message);
  void GenerateBlock(int sample, int samples);
  int  SamplesPerTick();

private:
  CArpeggiatorGUI      *GUI;
  int                   SampleRate, BlockSamples;
  SArpeggiatorGraphics *Graphics;
  int                   TPB, Length;
  bool                  Cell[GRID_ROWS][GRID_COLS];
  bool                  Trigger;
  int                   BaseNote;
  int                   Tick, TickSamples;
  CControlBuffer       *FutureBuffer;
};

class CArpeggiatorInfo : public CMachineInfo
{
public:
                             CArpeggiatorInfo();
  virtual                   ~CArpeggiatorInfo();
  virtual CMachine* DARKCALL CreateMachine();

private:
  SArpeggiatorGraphics *Graphics;
};

#endif