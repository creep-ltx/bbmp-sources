/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ToolBarButton.h"
#include "../Studio/Core.h"

#define STATE_IDLE         0
#define STATE_MOUSEOVER    1
#define STATE_PRESSED      2
#define STATE_PRESSED_DOWN 3

CToolBarButton::CToolBarButton(CControl *parent, int x, int y, int width, int height, 
  int iconID, int iconWidth, int iconHeight, int id, int style)
: CControl(parent, "ToolBarButton", x, y, width, height, true)
{
  Style = style;
  Pressed = false;
  Icon = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(iconID), IMAGE_ICON,
    iconWidth, iconHeight, 0);
  IconWidth  = iconWidth;
  IconHeight = iconHeight;
  
  State = STATE_IDLE;
  ID = id;
  Parent = parent;
  SubInit = true;
  AutoSizeWidth();
}

CToolBarButton::~CToolBarButton()
{
  DestroyIcon(Icon);
}

void CToolBarButton::DrawControl()
{
  bool bOver, bPressed;
  HDC  hDC;

  bOver = (State != STATE_IDLE);
  bPressed = (State == STATE_PRESSED_DOWN);
  if(Pressed)
  {
    bPressed = !bPressed;
    bOver = true;
  }

  CControl::DrawControl();

  hDC = BackDC;
  
  if(Icon != 0)
    if(bPressed)
      DrawIconEx(hDC, ((Width - IconWidth) / 2) + 1, ((Height - IconHeight) / 2) + 1, Icon,
      IconWidth, IconHeight, 0, NULL, DI_NORMAL); 
    else
      DrawIconEx(hDC, (Width - IconWidth) / 2, (Height - IconHeight) / 2, Icon,
      IconWidth, IconHeight, 0, NULL, DI_NORMAL); 

  if(bOver)
    if(bPressed)
      DrawBorder(hDC, bs3DSunken, 0, 0, Width, Height);
    else
      DrawBorder(hDC, bs3DRaised, 0, 0, Width, Height);
}

void CToolBarButton::AutoSizeWidth()
{
  if(Icon != 0)
  {
    Resize(IconWidth + 6, Height);
  }
}

void CToolBarButton::OnMouseMove(int x, int y)
{
  switch(State)
  {
    case STATE_IDLE:
      State = STATE_MOUSEOVER;
      Redraw();
      SetCapture(Handle);
      break;

    case STATE_MOUSEOVER:
      if(x < 0 || x >= Width || y < 0 || y >= Height)
      {
        State = STATE_IDLE;
        Redraw();
        ReleaseCapture();
      }
      break;

    case STATE_PRESSED:
      if(x >= 0 && x < Width && y >= 0 && y < Height)
      {
        State = STATE_PRESSED_DOWN;
        Redraw();
      }
      break;

    case STATE_PRESSED_DOWN:
      if(x < 0 || x >= Width || y < 0 || y >= Height)
      {
        State = STATE_PRESSED;
        Redraw();
      }
      break;
  }
}

void CToolBarButton::Redraw()
{
  DrawControl();
  OnPaint();
  GdiFlush();
}

void CToolBarButton::OnLeftButtonDown(int x, int y)
{
  if(x >= 0 && x < Width && y >= 0 && y < Height)
  {
    State = STATE_PRESSED_DOWN;
    Redraw();
  }
}

void CToolBarButton::OnLeftButtonUp(int x, int y)
{
  switch(State)
  {
    case STATE_PRESSED:
      State = STATE_IDLE;
      Redraw();
      ReleaseCapture();
      break;
    case STATE_PRESSED_DOWN:
      State = STATE_MOUSEOVER;
      if(Style & TOOLBARBUTTON_STYLE_TOGGLE)
        Pressed = !Pressed;
      Parent->OnToolBarButtonPress(this);
      Redraw();
      break;
  } 
}

void CToolBarButton::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
}

int CToolBarButton::GetID()
{
  return ID;
}

bool CToolBarButton::GetPressed()
{
  return Pressed;
}

void CToolBarButton::SetPressed(bool value)
{
  Pressed = value;
  Redraw();
}

void CToolBarButton::OnCaptureChanged(HWND newCapture)
{
  if(State == STATE_MOUSEOVER)
  {
    State = STATE_IDLE;
    Redraw();
  }
}