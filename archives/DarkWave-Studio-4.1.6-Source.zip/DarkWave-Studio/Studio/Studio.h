/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef STUDIO_H
#define STUDIO_H

#include "Control.h"
#include "MachineContainer.h"
#include "Master.h"
#include "PatternEditor.h"
#include "HDRecorder.h"
#include "Menu.h"
#include "BackBuffer.h"
#include "Pen.h"
#include "ScrollBar.h"
#include "Dialog.h"
#include "EditBox.h"
#include "RenameDialog.h"

class CStudio;

class CCableVolumeSlider : public CSlider
{
public:
               CCableVolumeSlider(CStudio *studio, int x, int y, int width, int height);
  void         SetConnection(CConnection *connection);
  virtual void OnChange(double newValue);

private:
  CConnection *Connection;
};

class CStudio : public CControl, public CMutex
{
public:
                     CStudio(CControl *parent, CPatternEditor *patternEditor, CHDRecorder *hdRecorder, int x, int y, int width, int height);
                    ~CStudio();
  char*              GenerateMachineName(char *baseName);
  CMachineContainer *FindMachine(char *name);
  CMachineContainer *AddMachine(char *name, int x, int y, CMachine *machine, CMachineInfo *machineInfo, CMachineLoaderEntry *entry);
  CMachineContainer *AddMachine(char *name, int x, int y, CMachine *machine, CMachineInfo *machineInfo, CMachineLoaderEntry *entry, char *properties, int propertyBytes, bool isInner);
  void               AddMachine(CMachineContainer *machine, int x, int y, int visibleControl);
  void               AddMachine(CMachineContainer *machine, int x, int y, int visibleControl, char *properties, int propertyBytes, bool isInner);
          void       SetMaster(CMachineContainer *master);
          void       Work(int nChannels, double **channels, int samples);
          void       InitContextMenus();
  virtual void       OnRightButtonUp(int x, int y);
          void       BeginUserConnect(CConnector *connector);
          void       BeginUserMove(CMachineContainer *container);
          LRESULT    WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
          void       OnResize(int newWidth, int newHeight);
          void       DrawControl();
          void       DrawCable(HDC hDC, int x1, int y1, int x2, int y2);
          void       DrawCableBorderLine(HDC hDC, POINT &p1, POINT &p2);
          void       DrawUserConnect(HDC hDC);
          void       DrawConnections(HDC hDC);
          void       DrawConnection(HDC hDC, CConnection *connection);
  CConnector        *ConnectorFromPort(CPort *port);
          void       ConnectorCentre(CConnector *connector, int *x, int *y);
  CConnector        *ConnectorAt(int x, int y);
          void       ConnectConnectors(CConnector *connector1, CConnector *connector2, double volume);
          bool       CanConnect(CConnector *connector1, CConnector *connector2);
          void       ShowAddMachineMenu(int x, int y);
          void       ShowCableMenu(int x, int y, CConnector *connector1, CConnector *connector2);
          bool       PointInCable(int x, int y, CConnector **connector1, CConnector **connector2);
          bool       PointInLine(int pointX, int pointY, int x1, int y1, int x2, int y2, int gap);
          void       DrawVolumeKnob(HDC hDC, int x1, int y1, int x2, int y2);
          double     LineAngle(int x1, int y1, int x2, int y2);
          void       RotatePoint(double angle, int xcentre, int ycentre, int radius, POINT *point);
          void       LineInRect(int rectX1, int rectY1, int rectX2, int rectY2, int lineX1, int lineY1, int lineX2, int lineY2, int *pointX, int *pointY);
          bool       PointInRect(int x1, int y1, int x2, int y2, int x, int y);
          void       AdjustCable(CConnection *connection, int *x1, int *y1, int *x2, int *y2);
  virtual void       OnLeftButtonDown(int x, int y);
          bool       PointInVolumeKnob(int x, int y, CConnection *connection, int *kx, int *ky);
          double     VolumeKnobPoints(int x1, int y1, int x2, int y2, POINT *p);
          void       BringMachineToFront(CMachineContainer *container);
          void       SizeScrollBars();
          void       OnScrollX(int newPos);
          void       OnScrollY(int newPos);
          void       RemoveMachine(CMachineContainer *machine);
          void       SetSampleRate(int sampleRate);
          void       SetBlockSamples(int blockSamples);
          int        GetMachineCount();
          void       ConnectConnectors(int m1, int c1, int m2, int c2, double volume);
          CConnector* GetConnector(int mi, int ci);
          CConnector* GetConnector(int index);
          void       ShowRenameDialog(CMachineContainer *machine);
          virtual void OnRenameDialogSuccess();
          void       Idle();
          void       ResetScrolling();
          
          int        MenuPathDepth(char *machinePath);
          void       MenuPathItem(char *machinePath, int depth, char *pathItem);
          int        AppendMachineMenu(HMENU parentMenu, int loaderItem, int depth);
          
          
          CMachineContainer*       AddMachine(char *instanceName, char *uniqueID, int x, int y, int visibleControl, char *properties, int propertyBytes, bool isInner);
          CMachineContainer*       AddMachine(char *instanceName, char *machineName, char *uniqueID, int x, int y, int visibleControl, char *properties, int propertyBytes, bool isInner, bool oldUniqueID);
          CConnector              *FindConnector(int machine, int port);

  CMachineContainer *FirstContainer;
  CMachineContainer *Master;
  
private:
  CMenu              *AddMachineMenu, *CableMenu;
  int                 OffsetX, OffsetY;
  int                 MouseX, MouseY, State;
  CMachineContainer  *CurrentContainer;
  CConnector         *CurrentConnector;
  CConnector         *CurrentConnector2;
  double              WorkingVolume;
  CCableVolumeSlider *CableVolumeSlider;
  CScrollBar         *ScrollBarH, *ScrollBarV;
  CControl           *ScrollBox;
  CPatternEditor     *PatternEditor;
  CHDRecorder        *HDRecorder;
  CRenameDialog      *RenameDialog;
  CMachineContainer  *RenameMachine;
};

#endif