#define IDR_DGENR8_BACKGROUND           102
#define IDR_MINBLEP                     109
#define IDR_DGENR8_KNOB                 121
