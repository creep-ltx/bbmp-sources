#ifndef SAVEASDIALOG_H
#define SAVEASDIALOG_H

bool SaveAsDialog(char *filter, char *defExt, char *fileName, int *nFilterIndex);
bool OpenDialog(char *filter, char *defExt, char *fileName, int *nFilterIndex);

#endif