/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Label.h"
#include "Font.h"
#include "BackBuffer.h"

CLabel::CLabel(CControl *parent, char *text, int x, int y, int width, int height, int flags)
: CControl(parent, text, x, y, width, height, true)
{
  WantClicks = false;
  Text  = 0;
  Flags = flags;
  SetText(text);
  SubInit = true;
  DrawControl();
}

CLabel::~CLabel()
{
  delete Text;
}

void CLabel::SetWantClicks(bool newWantClicks)
{
  WantClicks = newWantClicks;
}

void CLabel::OnLeftButtonDown(int x, int y)
{
  if(WantClicks)
    Parent->OnLeftButtonDown(X + x, Y + y);
}

void CLabel::SetText(char *text)
{
  int len;

  if(Text)
    delete Text;
	len = (int)strlen(text) + 1;
  Text = new char[len];
  strcpy(Text, text);
  if(SubInit)
  {
    DrawControl();
    CControl::OnPaint();
  }
}

void CLabel::DrawControl()
{
  HDC     hDC;
  RECT    r;
  HGDIOBJ oldFont;

  hDC = BackDC;

  CControl::DrawControl();
  SetBkMode(hDC, TRANSPARENT);
  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlText));

  r.left   = 0;
  r.top    = 0;
  r.right  = Width;
  r.bottom = Height;

  oldFont = SelectObject(hDC, Font->Handle);
  DrawTextA(hDC, Text, (int)strlen(Text), &r, Flags);
  SelectObject(hDC, oldFont);
}