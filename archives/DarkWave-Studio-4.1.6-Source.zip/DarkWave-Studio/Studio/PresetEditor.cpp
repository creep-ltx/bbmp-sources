/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#define BANKLIST_X         8
#define BANKLIST_Y         8
#define BANKLIST_WIDTH     128
#define BANKLIST_HEIGHT(h) (h - 16)
#define LIST_ITEMHEIGHT    16
#define BANKINFO_X         (BANKLIST_X + BANKLIST_WIDTH + 8)
#define BANKINFO_Y         BANKLIST_Y
#define BANKINFO_WIDTH(w)  (w - (BANKLIST_WIDTH + 24))
#define BANKINFO_HEIGHT(h) BANKLIST_HEIGHT(h)

#include "PresetEditor.h"

CPresetEditor::CPresetEditor(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "PresetEditor", x, y, width, height, false)
{
  SetBorder(bs3DSunken);
  SubInit = true;
}

CPresetEditor::~CPresetEditor()
{
}

void CPresetEditor::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  //if(SubInit)
  //{ resize shit
  //}
}

void CPresetEditor::ShowPreset(int bankIndex, int presetIndex)
{
}