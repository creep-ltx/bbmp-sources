/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef BACKBUFFER_H
#define BACKBUFFER_H

#include <windows.h>

class CBackBuffer 
{
public:
       CBackBuffer(HDC targetDC, int width, int height);
      ~CBackBuffer();
  void Resize(int width, int height);
  void Draw();
  void Draw(int x, int y, int width, int height);

  HDC     DC;
  HDC     TargetDC;
  HBITMAP Bitmap, OldBitmap;
  int     Width, Height;
};

#endif