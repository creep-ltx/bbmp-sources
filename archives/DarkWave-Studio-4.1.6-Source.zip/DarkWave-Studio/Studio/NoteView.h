/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef NOTEVIEW_H
#define NOTEVIEW_H

#include "Control.h"
#include "ScrollBar.h"
#include "BackBuffer.h"
#include "Font.h"
#include "Pattern.h"
#include "ControlView.h"
#include "Mutex.h"
#include "Menu.h"

#define NOTEVIEW_MODE_DRAW_IDLE      0
#define NOTEVIEW_MODE_DRAW_DRAG      1
#define NOTEVIEW_MODE_DRAW_SIZELEFT  2
#define NOTEVIEW_MODE_DRAW_SIZERIGHT 3

#define NOTEVIEW_MODE_SELECT_IDLE    4
#define NOTEVIEW_MODE_SELECT_SELECT  5
#define NOTEVIEW_MODE_SELECT_SIZE_N  6
#define NOTEVIEW_MODE_SELECT_SIZE_S  7
#define NOTEVIEW_MODE_SELECT_SIZE_E  8
#define NOTEVIEW_MODE_SELECT_SIZE_W  9
#define NOTEVIEW_MODE_SELECT_SIZE_NE 10
#define NOTEVIEW_MODE_SELECT_SIZE_NW 11
#define NOTEVIEW_MODE_SELECT_SIZE_SE 12
#define NOTEVIEW_MODE_SELECT_SIZE_SW 13

#define NOTEVIEW_MODE_PLAY_HIGHLIGHT 14
#define NOTEVIEW_MODE_PLAY_PRESSED   15

class CNoteView : public CControl, public CHostMutex
{
public:
                    CNoteView(CControl *parent, int x, int y, int width, int height, CScrollBar *scrollBarH, CControlView *controlView);
                   ~CNoteView();
  virtual void      OnResize(int newWidth, int newHeight);
  virtual void      OnPaint();
  virtual void      DrawControl();
  void              DrawKeys(HDC hDC);
  void              DrawGrid(HDC hDC);
  void              DrawNotes(HDC hDC);
  void              ScrollVertical(int offsetY);
  void              ScrollHorizontal(int offsetX);
  void              SizeControl();
  void              DrawKey(HDC hDC, int x, int y, int note);
  void              NoteLabel(int note, char *label);
  bool              IsKeyBlack(int note);
  virtual void      OnScrollY(int newPos);
  virtual void      OnScrollX(int newPos);
  void              LoadPattern(CPattern *pattern);
  void              SetNoteLength(int noteLength);
  virtual void      OnLeftButtonDown(int x, int y);
  virtual void      OnRightButtonDown(int x, int y);
  virtual void      OnRightButtonUp(int x, int y);
  CNote            *AddNote(int x, int y);
  int               NoteAt(int y);
  int               PosAt(int x);
  bool              NoteFits(int start, int length, int note);
  bool              NoteFits(int start, int length, int note, CNote *ignore);
  int               RowNote(int row);
  void              DrawNote(HDC hDC, CNote *note);
  int               NoteRow(int note);
  void              RemoveNote(int x, int y);
  CNote            *NoteAt(int pos, int note);
  void              UpdatePlayBar();
  void              UpdatePlayBar2();
  void              DrawPlayBar(double pos, bool clear);
  int               PlayBarX(double playBarPos);
  virtual void      OnMouseMove(int x, int y);
  int               DetermineMode(CNote *note, int x, int y);
  void              NoteRect(CNote *note, int *x1, int *y1, int *x2, int *y2);
  void              SetMode(int mode);
  int               PosX(int pos);
  int               RowY(int row);
  void              OnDrag(int x, int y);
  virtual void      OnLeftButtonUp(int x, int y);
  virtual void      OnLeftButtonDoubleClick(int x, int y);
  void              ClearSelection();
  void              DrawSelection(HDC hDC);
  void              DrawSelection(HDC hDC, int x1, int y1, int x2, int y2);
  void              InitSelectMenu();
  void              OnSelectMenu(int id, int x, int y);
  CNote            *CopyNotes(int row1, int col1, int row2, int col2, bool *clipVoiceMode);
  void              ClearNotes(int row1, int col1, int row2, int col2);
  void              PasteNotes(CNote* notes, int row1, int col1, bool clipVoiceMode);
  bool              InSelection(CNote *note);
  int               ChooseSelectMode(int x, int y);
  void              SetCursorBySelectMode(int selectMode);
  void              OnSizeSelectBox(int x, int y);
  void              DrawKey(int row);
  bool              IsNoteHighlighted(int note);
  bool              IsNotePressed(int note);

  
private:
  CScrollBar       *ScrollBarV, *ScrollBarH;
  CControlView     *ControlView;
  int               OffsetX, OffsetY;
  int               Rows, TopRow, TopRowY, BottomRow, MaxTopRow;
  CFont            *KeyFont;
  CPattern         *Pattern;
  int               Cols, LeftCol, LeftColX, RightCol, MaxLeftCol;
  int               NoteLength;
  double            PlayBarPos, PlayBarPos2;
  CMachine         *Machine;
  bool              VoiceMode;
  CNote            *CapturedNote;
  bool              Dragging;
  int               DragStartX, DragStartY, DragStartStart, DragStartLength, DragStartNote;
  int               SelectCol1, SelectRow1, SelectCol2, SelectRow2;
  CMenu            *SelectMenu;
  CNote            *ClipNotes;
  bool              ClipVoiceMode;
  int               Mode;
  int               CurrentNote, OldMode;
};

#endif