/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ABOUT_BOX_H
#define ABOUT_BOX_H

#include "Dialog.h"

class CBackBuffer;
class CFrameBuffer;
class CLabel;
class CFont;

class CAboutBox : public CDialog
{
public:
               CAboutBox(CControl *parent, CColorManager *colorManager, CFrameBuffer *background);
              ~CAboutBox();
  void         DrawControl();
  virtual void Show(int showState);
  virtual void OnLeftButtonDown(int x, int y);
  void         SetLabelText(char *text);
  virtual void OnMouseMove(int x, int y);

private:
  CFrameBuffer *Background;
  CLabel       *Label;
  int           State;
};

#endif