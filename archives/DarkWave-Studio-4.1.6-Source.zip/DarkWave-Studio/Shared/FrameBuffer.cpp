/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "FrameBuffer.h"
#include "Inflate.h"
#include "Error.h"

extern HINSTANCE AppInstance;

#define HEADER_BYTES 8

#ifdef _DEBUG
  // #define DEBUGPRINT
#endif

const unsigned char PNGHeader[HEADER_BYTES] =
{
  137, 80, 78, 71, 13, 10, 26, 10
};

CFrameBuffer::CFrameBuffer(int pngResourceID)
{
  HRSRC          resInfo;
  HGLOBAL        resource;
  unsigned char *data;
  int            length;

  Clear();

  resInfo  = FindResourceA(AppInstance, MAKEINTRESOURCEA(pngResourceID), "PNG");
  resource = LoadResource(AppInstance, resInfo);
  length   = SizeofResource(AppInstance, resInfo);
  data     = (unsigned char*)(LockResource(resource));
 
  LoadPNG(data, length);
  FreeResource(resource);
  SetClip(0, 0, Width, Height);
}

void CFrameBuffer::DrawRect(int x, int y, int width, int height, COLORREF color, unsigned char alpha)
{
  int i;
  
  for(i = x; i < x + width; i++)
  {
    SetPixel(i, y, color, alpha);
    SetPixel(i, y + height - 1, color, alpha);
  }

  for(i = y; i < y + height; i++)
  {
    SetPixel(x, i, color, alpha);
    SetPixel(x + width - 1, i, color, alpha);
  }
}

void CFrameBuffer::FillRect(int x, int y, int width, int height, COLORREF color, unsigned char alpha)
{
  int ix, iy;
  
  for(ix = x; ix < x + width; ix++)
    for(iy = y; iy < y + height; iy++)
      SetPixel(ix, iy, color, alpha);
}

void CFrameBuffer::SetPixel(int x, int y, COLORREF color, unsigned char alpha)
{
  unsigned char *pixel;

  if(Alpha)
  {
#ifdef _DEBUG
  if(x >= 0 && y >= 0 && x < Width && y < Height)
  {
#endif
    pixel = GetPixel4(x, y);
#ifdef _DEBUG
	if(pixel)
	{
#endif
	    pixel[0] = GetRValue(color);
	    pixel[1] = GetGValue(color);
	    pixel[2] = GetBValue(color);
		  pixel[3] = alpha;
#ifdef _DEBUG
	}
  }
#endif
  }
  else
  {
  #ifdef _DEBUG
    if(x >= 0 && y >= 0 && x < Width && y < Height)
    {
  #endif
      pixel = GetPixel3(x, y);
  #ifdef _DEBUG
      if(pixel)
      {
  #endif
	      pixel[0] = GetRValue(color);
	      pixel[1] = GetGValue(color);
	      pixel[2] = GetBValue(color);
  #ifdef _DEBUG
      }
  }
  #endif
}
}

void CFrameBuffer::SetClip(int x1, int y1, int x2, int y2)
{
  ClipX1 = x1;
  ClipY1 = y1;
  ClipX2 = x2;
  ClipY2 = y2;
}

CFrameBuffer::CFrameBuffer(int width, int height, bool alpha)
{
  int bpp;
  int i, n;

  SetClip(0, 0, width - 1, height - 1);

  if(alpha)
    bpp = 4;
  else
    bpp = 3;

  Width  = width;
  Height = height;
  Alpha  = alpha;

  n = Width * Height * bpp;
  Data = new unsigned char[n];
  for(i = 0; i < n; i++)
    Data[i] = 0xA0;
}

CFrameBuffer::~CFrameBuffer()
{
  Free();
}

void CFrameBuffer::Fill(COLORREF color)
{
  Fill(color, 0, 0, Width, Height);
}

void CFrameBuffer::Fill(COLORREF color, int x1, int y1, int w, int h)
{
  int x, y;
  unsigned char r, g, b, *pixel;
  
  if(x1 < ClipX1)
  {
    w    -= ClipX1 - x1;
    x1   += ClipX1 - x1;
  }

  if(y1 < ClipY1)
  {
    h  -= ClipY1 - y1;
    y1 += ClipY1 - y1;
  }

  if(x1 + w - 1 > ClipX2)
  {
    w -= x1 + w - (1 + ClipX2);
  }

  if(y1 + h - 1 > ClipY2)
  {
    h -= y1 + h - (1 + ClipY2);
  }

  r = GetRValue(color);
  g = GetGValue(color);
  b = GetBValue(color);

  if(Alpha)
    for(y = 0; y < h; y++)
    {
      for(x = 0; x < w; x++)
      {
        pixel    = GetPixel4(x + x1, y + y1);
        pixel[0] = r;
        pixel[1] = g;
        pixel[2] = b;
        pixel[3] = 0;
	    }
    }
  else
    for(y = 0; y < h; y++)
    {
      for(x = 0; x < w; x++)
      {
        pixel    = GetPixel3(x + x1, y + y1);
        pixel[0] = r;
        pixel[1] = g;
        pixel[2] = b;
	    }
    }
}

void CFrameBuffer::Clear()
{
  Width = Height = 0;
  Data = 0;
  Alpha = false;
}

void CFrameBuffer::Free()
{
  if(Data)
  {
    delete Data;
    Data = 0;
  }
}


void CFrameBuffer::LoadPNG(unsigned char *data, unsigned int length)
{
  unsigned int i, offset, chunkLength;
  bool         bMoreChunks;
  unsigned int chunkID;
  char         chunkIDtext[5];
  SDataSegs    dataSegs;

  dataSegs.Count       = 0;
  dataSegs.DataSegs    = 0;
  dataSegs.DataLengths = 0;

  if(HEADER_BYTES > length)
    throw "PNG File Is Too Small To Fit A Valid Header";

  for(i = 0; i < HEADER_BYTES; i++)
    if(data[i] != PNGHeader[i])
      throw "PNG File Header Not Found";

  offset = HEADER_BYTES;
  bMoreChunks = true;

  while(bMoreChunks)
  {
    if(offset + 8 > length)
      throw "Unexpected End Of File In PNG Image";

    chunkLength = ReadInt32(data, offset);          offset += 4;
    chunkID     = *(unsigned int *)(data + offset); offset += 4;
    
    if(offset + chunkLength > length)
      throw "Chunk Found Larger Than File In PNG Image";

    *(unsigned long *)chunkIDtext = chunkID;
    chunkIDtext[4] = 0;
#ifdef _DEBUGPRINT
    DebugPrint("Found Chunk [%s]\n", chunkIDtext);
#endif

    switch(chunkID)
    {
      case 'DNEI': // 'IEND'
        LoadPNGInflate(&dataSegs);
        bMoreChunks = false;
        break;

      case 'RDHI': // 'IHDR'
        LoadPNGHeader(data + offset, chunkLength);
        break;

      case 'TADI': // 'IDAT'
        LoadPNGData(data + offset, chunkLength, &dataSegs);
        break;
    }

    offset += chunkLength + 4;
  }

  if(dataSegs.Count != 0)
  {
    delete dataSegs.DataSegs;
    delete dataSegs.DataLengths;
  }
}

void CFrameBuffer::LoadPNGInflate(SDataSegs *dataSegs)
{
  unsigned int   deflatedLength, inflatedLength, i, j, n ;
  unsigned char *inflatedData, *deflatedData;
  int            x, y;
  unsigned int   filter;

  deflatedLength = 0;
  for(i = 0; i < dataSegs->Count; i++)
    deflatedLength += dataSegs->DataLengths[i];

  n = 0;
  deflatedData = new unsigned char[deflatedLength];
  for(i = 0; i < dataSegs->Count; i++)
    for(j = 0; j < dataSegs->DataLengths[i]; j++)
      deflatedData[n++] = dataSegs->DataSegs[i][j];

  if(Alpha)
    inflatedLength = (Width * Height * 4) + Height;
  else
    inflatedLength = (Width * Height * 3) + Height;

  inflatedData = new unsigned char[inflatedLength];
  n = Inflate(inflatedData, inflatedLength, deflatedData, deflatedLength);

#ifdef _DEBUGPRINT
  DebugPrint("Inflated [%i] Bytes Into [%i] Byte Buffer From [%i] Source Bytes\n",
    n, inflatedLength, deflatedLength);
#endif

  if(n != inflatedLength)
    throw "PNG: Not Enough Information Inflated";

  if(Alpha)
  {
    Data = new unsigned char[Width * Height * 4];
    n = j = 0;
    for(y = 0; y < Height; y++)
    {
      filter = inflatedData[n];
      n += 1;
      for(x = 0; x < Width; x++)
      {
        Data[j++] = inflatedData[n++];
        Data[j++] = inflatedData[n++];
        Data[j++] = inflatedData[n++];
        Data[j++] = inflatedData[n++];
      }
      FilterScanline(filter, y);
    }
  }
  else
  {
    Data = new unsigned char[Width * Height * 3];
    n = j = 0;
    for(y = 0; y < Height; y++)
    {
      filter = inflatedData[n];
      n += 1;
      for(x = 0; x < Width; x++)
      {
        Data[j++] = inflatedData[n++];
        Data[j++] = inflatedData[n++];
        Data[j++] = inflatedData[n++];
      }
      FilterScanline(filter, y);
    }
  }

  delete deflatedData;
  delete inflatedData;
}

//function PaethPredictor (a, b, c)
//   begin
//        ; a = left, b = above, c = upper left
//        p := a + b - c        ; initial estimate
//        pa := abs(p - a)      ; distances to a, b, c
//        pb := abs(p - b)
//        pc := abs(p - c)
//        ; return nearest of a,b,c,
//        ; breaking ties in order a,b,c.
//        if pa <= pb AND pa <= pc then return a
//        else if pb <= pc then return b
//        else return c
//   end

inline unsigned int PaethPredictor(unsigned int a, unsigned int b, unsigned int c)
{
  unsigned int p, pa, pb, pc;

  p = a + b - c;
  pa = abs((int)(p - a));
  pb = abs((int)(p - b));
  pc = abs((int)(p - c));
  if(pa <= pb && pa <= pc)
    return a;
  else if(pb <= pc)
    return b;
  else
    return c;
}

void CFrameBuffer::FilterScanline(unsigned int filter, unsigned int line)
{
  int i, prior, width;
  unsigned char *x;
  int bpp;

  if(Alpha)
    bpp = 4;
  else
    bpp = 3;

  prior = Width * bpp;
  width = prior;
  x = Data + (line * prior);

  switch(filter)
  {
    case 1: // sub filter
      for(i = 0; i < width; i++)
      {
        if(i >= bpp)
          *(x) = (*x + *(x-bpp));
        x++;
      }
      break;

    case 2: // up filter
      if(line > 0)
        for(i = 0; i < width; i++)
          *(x++) = (*x + *(x-prior));
      break;

    case 3: // average filter
    {
      unsigned char xmbpp, xprior;

      for(i = 0; i < width; i++)
      {
        if(i >= bpp)
          xmbpp = *(x-bpp);
        else
          xmbpp = 0;

        if(line > 0)
          xprior = *(x-prior);
        else
          xprior = 0;

        *(x++) = *x + ((xmbpp + xprior) >> 1);
      }
      break;

    }

    case 4: // paeth filter
    {
      unsigned char xmbpp, xprior, xprior2;

      for(i = 0; i < width; i++)
      {
        if(i >= bpp)
          xmbpp = *(x-bpp);
        else
          xmbpp = 0;

        if(line > 0)
          xprior = *(x-prior);
        else
          xprior = 0;

        if(i >= bpp && line > 0)
          xprior2 = *(x-(prior+bpp));
        else
          xprior2 = 0;

        *(x++) = *x + PaethPredictor(xmbpp, xprior, xprior2);
      }

      break;
    }
  }
}

unsigned char *CFrameBuffer::GetData()
{
  return Data;
}

void CFrameBuffer::LoadPNGData(unsigned char *data, unsigned int length, SDataSegs *dataSegs)
{
  unsigned int    i;
  unsigned char **newDataSegs;
  unsigned int   *newDataLengths;

  if(dataSegs->Count == 0)
  {
    dataSegs->DataSegs = new unsigned char *[1];
    dataSegs->DataLengths = new unsigned int [1];
    dataSegs->DataSegs[0] = data;
    dataSegs->DataLengths[0] = length;
  }
  else
  {
    newDataSegs = new unsigned char *[dataSegs->Count + 1];
    newDataLengths = new unsigned int [dataSegs->Count + 1];
    for(i = 0; i < dataSegs->Count; i++)
    {
      newDataSegs[i] = dataSegs->DataSegs[i];
      newDataLengths[i] = dataSegs->DataLengths[i];
    }
    newDataSegs[dataSegs->Count] = data;
    newDataLengths[dataSegs->Count] = length;
    delete dataSegs->DataSegs;
    delete dataSegs->DataLengths;
    dataSegs->DataSegs = newDataSegs;
    dataSegs->DataLengths = newDataLengths;
  }
  dataSegs->Count++;
}

void CFrameBuffer::LoadPNGHeader(unsigned char *data, unsigned int length)
{
  unsigned int offset = 0;
  unsigned char bitDepth, colorType, compressionMethod, filterMethod, interlaceMethod;

  if(length < 13)
    throw "PNG File's Header Chunk Too Small";

  Width             = ReadInt32(data, offset); offset += 4;
  Height            = ReadInt32(data, offset); offset += 4;
  bitDepth          = *(data + offset); offset += 1;
  colorType         = *(data + offset); offset += 1;
  compressionMethod = *(data + offset); offset += 1;
  filterMethod      = *(data + offset); offset += 1;
  interlaceMethod   = *(data + offset); offset += 1;

  if(bitDepth != 8)
    throw "Unsupported Bit Depth In PNG File";

  if(colorType == 2)
    Alpha = false;
  else if(colorType == 6)
    Alpha = true;
  else throw "Unsupported Color Type In PNG File";

  if(compressionMethod != 0)
    throw "Unsupported Compression Method In PNG File";

  if(filterMethod != 0)
    throw "Unsupported Filter Method In PNG File";

  if(interlaceMethod != 0)
    throw "Can't Read Interlaced PNG Files";
}

bool CFrameBuffer::GetAlpha()
{
  return Alpha;
}

int CFrameBuffer::GetHeight()
{
  return Height;
}

int CFrameBuffer::GetWidth()
{
  return Width;
}

#define DRAW_ALPHA_TO_ALPHA()                                         \
  a  = (double)pixSrc[3] * od255;                                     \
  a2 = 1.0 - a;                                                       \
                                                                      \
  pixDst[0]  = (unsigned char)((pixSrc[0] * a) + (a2 * pixDst[0]));   \
  pixDst[1]  = (unsigned char)((pixSrc[1] * a) + (a2 * pixDst[1]));   \
  pixDst[2]  = (unsigned char)((pixSrc[2] * a) + (a2 * pixDst[2]));   \
                                                                      \
  pixDst += 4;                                                        \
  pixSrc += 4;

#define DRAW_ALPHA_TO_OPAQUE()                                        \
  a  = (double)pixSrc[3] * od255;                                     \
  a2 = 1.0 - a;                                                       \
                                                                      \
  pixDst[0]  = (unsigned char)((pixSrc[0] * a) + (a2 * pixDst[0]));   \
  pixDst[1]  = (unsigned char)((pixSrc[1] * a) + (a2 * pixDst[1]));   \
  pixDst[2]  = (unsigned char)((pixSrc[2] * a) + (a2 * pixDst[2]));   \
                                                                      \
  pixSrc += 4;                                                        \
  pixDst += 3;

#define DRAW_OPAQUE_TO_ALPHA()                                        \
  pixDst[0] = pixSrc[0];                                              \
  pixDst[1] = pixSrc[1];                                              \
  pixDst[2] = pixSrc[2];                                              \
                                                                      \
  pixSrc += 3;                                                        \
  pixDst += 4;                                                        

#define DRAW_OPAQUE_TO_OPAQUE()                                       \
  pixDst[0] = pixSrc[0];                                              \
  pixDst[1] = pixSrc[1];                                              \
  pixDst[2] = pixSrc[2];                                              \
                                                                      \
  pixSrc += 3;                                                        \
  pixDst += 3;                                                        

#define V_3_1_5_OPTIMIZATION

void CFrameBuffer::Draw(CFrameBuffer *dst, int xDst, int yDst, int xSrc, int ySrc, int width, int height)
{
  unsigned char *pixSrc, *pixDst;
  int            width2, height2, x, y;
  bool           alpha2;
  double         a, a2;
  const double   od255 = 1.0 / 255.0;

  width2  = dst->GetWidth();
  height2 = dst->GetHeight();
  alpha2  = dst->GetAlpha();

  if(xSrc < 0)
  {
    width = width + xSrc; 
    xSrc  = 0;
  }

  if(ySrc < 0)
  {
    height = height + ySrc;
    ySrc   = 0;
  }

  if(xDst < 0)
  {
    width = width + xDst;
    xDst  = 0;
  }

  if(yDst < 0)
  {
    height = height + yDst;
    yDst   = 0;
  }

  if(xDst + width > width2)
    width += width2 - (xDst + width);

  if(yDst + height > height2)
    height += height2 - (yDst + height);

  if((width < 1) || (height < 1))
    return;

  if((xDst + width  < dst->ClipX1) || (xDst > dst->ClipX2) ||
     (yDst + height < dst->ClipY1) || (yDst > dst->ClipY2))
     return;
  
  if(xDst < dst->ClipX1)
  {
    width -= dst->ClipX1 - xDst;
    xSrc  += dst->ClipX1 - xDst;
    xDst  += dst->ClipX1 - xDst;
  }

  if(yDst < dst->ClipY1)
  {
    height -= dst->ClipY1 - yDst;
    ySrc   += dst->ClipY1 - yDst;
    yDst   += dst->ClipY1 - yDst;
  }

  if(xDst + width - 1 > dst->ClipX2)
  {
    width = dst->ClipX2 - xDst + 1;
  }

  if(yDst + height - 1 > dst->ClipY2)
  {
    height = dst->ClipY2 - yDst + 1;
  }

  if(Alpha)
  {
    if(dst->Alpha)
      for(y = 0; y < height; y++)
      {
        pixSrc  = GetPixel4(xSrc, ySrc + y);
        pixDst  = dst->GetPixel4(xDst, yDst + y);

#ifdef V_3_1_5_OPTIMIZATION
        for(x = 0; x <= (width - 8); x += 8)
        {
          DRAW_ALPHA_TO_ALPHA()
          DRAW_ALPHA_TO_ALPHA()
          DRAW_ALPHA_TO_ALPHA()
          DRAW_ALPHA_TO_ALPHA()
          DRAW_ALPHA_TO_ALPHA()
          DRAW_ALPHA_TO_ALPHA()
          DRAW_ALPHA_TO_ALPHA()
          DRAW_ALPHA_TO_ALPHA()
        }
#else
        x = 0;
#endif
        for(; x < width; x++)
        {
          DRAW_ALPHA_TO_ALPHA()
        }
    }
    else
      for(y = 0; y < height; y++)
      {
        pixSrc  = GetPixel4(xSrc, ySrc + y);
        pixDst  = dst->GetPixel3(xDst, yDst + y);

#ifdef V_3_1_5_OPTIMIZATION
        for(x = 0; x <= (width - 8); x += 8)
        {
          DRAW_ALPHA_TO_OPAQUE()
          DRAW_ALPHA_TO_OPAQUE()
          DRAW_ALPHA_TO_OPAQUE()
          DRAW_ALPHA_TO_OPAQUE()
          DRAW_ALPHA_TO_OPAQUE()
          DRAW_ALPHA_TO_OPAQUE()
          DRAW_ALPHA_TO_OPAQUE()
          DRAW_ALPHA_TO_OPAQUE()
        }
#else
        x = 0;
#endif
        for(; x < width; x++)
        {
           DRAW_ALPHA_TO_OPAQUE()
        }
      }
  }
  else
  {
    if(dst->Alpha)
      for(y = 0; y < height; y++)
      {
        pixSrc  = GetPixel3(xSrc, ySrc + y);
        pixDst  = dst->GetPixel4(xDst, yDst + y);

#ifdef V_3_1_5_OPTIMIZATION
        for(x = 0; x <= (width - 8); x += 8)
        {
          DRAW_OPAQUE_TO_ALPHA()
          DRAW_OPAQUE_TO_ALPHA()
          DRAW_OPAQUE_TO_ALPHA()
          DRAW_OPAQUE_TO_ALPHA()
          DRAW_OPAQUE_TO_ALPHA()
          DRAW_OPAQUE_TO_ALPHA()
          DRAW_OPAQUE_TO_ALPHA()
          DRAW_OPAQUE_TO_ALPHA()
        }
#else
        x = 0;
#endif
        for(; x < width; x++)
        {
          DRAW_OPAQUE_TO_ALPHA()
        }
      }
    else
      for(y = 0; y < height; y++)
      {
        pixSrc  = GetPixel3(xSrc, ySrc + y);
        pixDst  = dst->GetPixel3(xDst, yDst + y);

#ifdef V_3_1_5_OPTIMIZATION
        for(x = 0; x <= (width - 8); x += 8)
        {
          DRAW_OPAQUE_TO_OPAQUE()
          DRAW_OPAQUE_TO_OPAQUE()
          DRAW_OPAQUE_TO_OPAQUE()
          DRAW_OPAQUE_TO_OPAQUE()
          DRAW_OPAQUE_TO_OPAQUE()
          DRAW_OPAQUE_TO_OPAQUE()
          DRAW_OPAQUE_TO_OPAQUE()
          DRAW_OPAQUE_TO_OPAQUE()
        }
#else
        x = 0;
#endif
        for(; x < width; x++)
        {           
          DRAW_OPAQUE_TO_OPAQUE()
        }
      }
  }
}

void CFrameBuffer::Draw(CBackBuffer *dst, int x, int y, int width, int height)
{
  BITMAPINFOHEADER bmi;
  int              i, j, s, n, scann;
  unsigned char   *data, *srcPixel;

#ifdef _DEBUG
  if(!dst)
    return;

  if(Alpha)
    throw "Don't Support Drawing Alpha Bitmaps Into A BackBuffer";
#endif

  scann = ((Width * 3) & ~0x03);
  if(scann < (Width * 3))
    scann += 0x04;

  n = scann * height;
  data = new unsigned char[n];

  for(i = 0; i < height; i++)
  {
    s = (i * scann);// + (3 * x);
    srcPixel = this->GetPixel3(/*x*/0, (y + i));

    for(j = Width; j >= 8; j -= 8)
    {
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
    }

    for(; j > 0; j--)
    {
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
    }
  }
  memset(&bmi, 0, sizeof(BITMAPINFOHEADER));
  bmi.biSize = sizeof(BITMAPINFOHEADER);
  bmi.biWidth = Width;
  bmi.biHeight = -Height;
  bmi.biPlanes = 1;
  bmi.biBitCount = 24;
  bmi.biCompression = BI_RGB;
  bmi.biSizeImage = scann * Height;

  SetDIBits(dst->DC, dst->Bitmap, Height - (y + height), height, data, (BITMAPINFO*)&bmi, DIB_RGB_COLORS);
  delete data;
}

void CFrameBuffer::Draw(CBackBuffer *dst)
{
  BITMAPINFOHEADER bmi;
  int              i, j, s, n, scann;
  unsigned char   *data, *srcPixel;
  
#ifdef _DEBUG
  if(!dst)
    return;

  if(Alpha)
    throw "Don't Support Drawing Alpha Bitmaps Into A BackBuffer";
#endif

  scann = ((Width * 3) & ~0x03);
  if(scann < (Width * 3))
    scann += 0x04;

  n = scann * Height;
  data = new unsigned char[n];

  for(i = 0; i < Height; i++)
  {
    s = (i * scann);
    srcPixel = this->GetPixel3(0, i);

    for(j = Width; j >= 8; j -= 8)
    {
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
    }

    for(; j > 0; j--)
    {
      data[s + 2] = *(srcPixel++);
      data[s + 1] = *(srcPixel++);
      data[s]     = *(srcPixel++);
      s += 3;
    }
  }

  memset(&bmi, 0, sizeof(BITMAPINFOHEADER));
  bmi.biSize = sizeof(BITMAPINFOHEADER);
  bmi.biWidth = Width;
  bmi.biHeight = -Height;
  bmi.biPlanes = 1;
  bmi.biBitCount = 24;
  bmi.biCompression = BI_RGB;
  bmi.biSizeImage = 0;

  SetDIBits(dst->DC, dst->Bitmap, 0, Height, data, (BITMAPINFO*)&bmi, DIB_RGB_COLORS);
  delete data;
}

void CFrameBuffer::TextureFill(CFrameBuffer *dst, int X, int Y)
{
  int x, y;
  unsigned char *pSrc, *pDst;

  for(y = 0; y < dst->Height; y++)
    for(x = 0; x < dst->Width; x++)
    {
      pSrc = GetPixel3((X + x) % Width, (Y + y) % Height);
      pDst = dst->GetPixel3(x, y);

      pDst[0] = pSrc[0];
      pDst[1] = pSrc[1];
      pDst[2] = pSrc[2];
    }
}

void CFrameBuffer::TextureFill(CBackBuffer *dst, int X, int Y)
{
  BITMAPINFOHEADER bmi;
  int              x, y, x2, y2, s, n, scann;
  unsigned char   *data, *pixel;

#ifdef _DEBUG
  if(Alpha)
    throw "Don't Support Drawing Alpha Bitmaps Into A BackBuffer";
#endif

  scann = ((dst->Width * 3) & ~0x03);
  if(scann < (dst->Width * 3))
    scann += 0x04;

  n = scann * dst->Height;
  data = new unsigned char[n];

  for(y = 0; y < dst->Height; y++)
  {
    s = y * scann;
    y2 = (y + Y) % Height;

    for(x = 0; x < dst->Width; x++)
    {
      x2 = (x + X) % Width;
      pixel = GetPixel3(x2, y2);
      data[s]     = pixel[2];
      data[s + 1] = pixel[1];
      data[s + 2] = pixel[0];
      s += 3;
    }
  }
  memset(&bmi, 0, sizeof(BITMAPINFOHEADER));
  bmi.biSize = sizeof(BITMAPINFOHEADER);
  bmi.biWidth = dst->Width;
  bmi.biHeight = -(dst->Height);
  bmi.biPlanes = 1;
  bmi.biBitCount = 24;
  bmi.biCompression = BI_RGB;
  bmi.biSizeImage = 0;

  SetDIBits(dst->DC, dst->Bitmap, 0, dst->Height, data, (BITMAPINFO*)&bmi, DIB_RGB_COLORS);
  delete data;
}