/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SCROLLBAR_H
#define SCROLLBAR_H

#include "Control.h"
#include "BackBuffer.h"
#include "Timer.h"

#define SCROLLBAR_HORIZONTAL 0
#define SCROLLBAR_VERTICAL   1

class CScrollBar : public CControl, public CTimerCallback
{
public:
               CScrollBar(CControl *parent, int style, int x, int y, int width, int height, int minPos, int maxPos); 
              ~CScrollBar();
  void         DrawControl();
  void         DrawHorizontal(HDC hDC);
  void         DrawVertical(HDC hDC);
  void         DrawHandle(HDC hDC, int x, int y, int width, int height);
  void         DrawButton(HDC hDC, int orientation, bool pressed, int x, int y, int width, int height);
  virtual void OnResize(int newWidth, int newHeight);
  int          HandleX();
  int          HandleY();
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  virtual void OnMouseMove(int x, int y);
  void         SetPos(int newPos);
  void         SetPos(int newPos, bool forceRedraw);
  virtual void OnLeftButtonDoubleClick(int x, int y);
  void         SetMaxPos(int value);
  void         SizeHandle();
  void         SetPageSize(int value);
  int          GetMaxPos();
  virtual void OnTimer(CTimer *timer);
  void         SetLineSize(int value);
  int          GetPos();

private:
  int          Style, State, MinPos, MaxPos, Pos, MouseX, MouseY, InitialPos, HandleSize, PageSize, LineSize;
  CControl    *Parent;
  CTimer      *Timer;
};

#endif