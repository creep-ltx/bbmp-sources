/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "MenuButton.h"
#include "Core.h"

#define INDENT 1

#define CONTROL_WIDTH  (13 + INDENT)
#define CONTROL_HEIGHT (7  + INDENT)

#define STATE_IDLE         0
#define STATE_PRESSED      1
#define STATE_PRESSED_DOWN 2

CMenuButton::CMenuButton(CControl *parent, int x, int y)
: CControl(parent, "MenuButton", x, y, CONTROL_WIDTH, CONTROL_HEIGHT, true)
{
  Menu = new CMenu(this, true);
  DrawControl();
}

CMenuButton::~CMenuButton()
{
}

void CMenuButton::DrawControl()
{
  HDC     hDC;
  RECT    r;
  POINT   p[3];
  HGDIOBJ oldPen;
  int     x, y;
  bool    bPressed;
  HPEN    b1, b2;

  bPressed = (State == STATE_PRESSED_DOWN);

  ColorManager->Lock();

  if(bPressed)
  {
    x  = INDENT;
    y  = INDENT;
    b1 = ColorManager->GetPen((ColorManagerColor)ControlShadow)->Handle;
    b2 = ColorManager->GetPen((ColorManagerColor)ControlLight)->Handle;
  }
  else
  {
    x = 0;
    y = 0;
    b1 = ColorManager->GetPen((ColorManagerColor)ControlLight)->Handle;
    b2 = ColorManager->GetPen((ColorManagerColor)ControlShadow)->Handle;
  }

  hDC = BackDC;

  r.left   = 0;
  r.top    = 0;
  r.right  = Width;
  r.bottom = Height;
  
  FillRect(hDC, &r, ColorManager->GetBrush((ColorManagerColor)ControlBack)->Handle);

  p[0].x = x;
  p[0].y = y;
  p[1].x = x + (Width - INDENT) - 1;
  p[1].y = y;
  p[2].x = x + ((Width - INDENT) / 2);
  p[2].y = y + ((Height - INDENT) - 1);

  oldPen = SelectObject(hDC, b1);
  MoveToEx(hDC, p[2].x, p[2].y, NULL);
  LineTo(hDC, p[0].x, p[0].y);
  LineTo(hDC, p[1].x, p[1].y);

  SelectObject(hDC, b2);
  LineTo(hDC, p[2].x, p[2].y);

  SelectObject(hDC, oldPen);

  ColorManager->Release();
}

void CMenuButton::OnLeftButtonDown(int x, int y)
{
  POINT p;
  int   item;

  if(x >= 0 && x < Width && y >= 0 && y < Height)
  {
    State = STATE_PRESSED_DOWN;
    Update();

    p.x = 0;
    p.y = Height + 2;
    ClientToScreen(Handle, &p);
    item = Menu->ShowPopup(p.x, p.y);
    State = STATE_IDLE;
    Update();
    OnMenuItem(item);

  }
}

void CMenuButton::OnMenuItem(int item)
{
}

