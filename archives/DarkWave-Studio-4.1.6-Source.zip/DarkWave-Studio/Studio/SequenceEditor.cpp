/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "SequenceEditor.h"
#include "Core.h"
#include "Label.h"
#include "UpDown.h"
#include <math.h>

#define TOOLBAR_HEIGHT                   30
#define COMBO_ITEMHEIGHT                 18
#define COMBO_HEIGHT                     18
#define PATTERN_COMBO_WIDTH              120

#define BUTTON_ADDPATTERN                0
#define BUTTON_REMOVEPATTERN             1
#define BUTTON_PLAY                      2
#define BUTTON_RECORD                    3
#define BUTTON_STOP                      4
#define BUTTON_LOOP                      5

#define DEFAULT_SEQUENCE_LENGTH          64
#define DEFAULT_LOOP                     false

#define MIN_LENGTH  1.0f
#define MAX_LENGTH  4096.0f
#define LENGTH_STEP 1.0f

#define LENGTH_LABEL_WIDTH      120
#define LABEL_HEIGHT            14
#define LENGTH_UPDOWN_WIDTH     52
#define LENGTH_UPDOWN_HEIGHT    18

CSequenceEditor::CSequenceEditor(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "SequenceEditor", x, y, width, height, false)
{
  SequenceToolBar  = new CToolBar(this, 0, 0, Width, TOOLBAR_HEIGHT);
  TrackToolBar     = new CToolBar(this, 0, TOOLBAR_HEIGHT, Width, TOOLBAR_HEIGHT);
  Sequence = new CSequence(DEFAULT_SEQUENCE_LENGTH);

  PlayButton = SequenceToolBar->AddButton(IDI_PLAY, BUTTON_PLAY, 20, 20, "Play Pattern", true);
  Playing = false;
  PlayOffset = 0.0f;
  RecordButton = SequenceToolBar->AddButton(IDI_RECORD, BUTTON_RECORD, 20, 20, "Record Song", true);

  StopButton = SequenceToolBar->AddButton(IDI_STOP, BUTTON_STOP, 20, 20, "Stop Pattern", false);

  LoopButton = SequenceToolBar->AddButton(IDI_LOOP, BUTTON_LOOP, 20, 20, "Loop Pattern", true);
  Loop = DEFAULT_LOOP;
  LoopButton->SetPressed(Loop);

  LengthLabel = new CLabel(SequenceToolBar, "Sequence Length:", 0, 0, LENGTH_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  SequenceToolBar->AddControl(LengthLabel, "");
  LengthUpDown = new CUpDown(SequenceToolBar, 0, 0, LENGTH_UPDOWN_WIDTH, LENGTH_UPDOWN_HEIGHT, MIN_LENGTH, MAX_LENGTH, LENGTH_STEP, DEFAULT_SEQUENCE_LENGTH, false);
  SequenceToolBar->AddControl(LengthUpDown, "Sequence Length");


  SequenceView = new CSequenceView(this, x, TOOLBAR_HEIGHT * 2, Width, Height - (TOOLBAR_HEIGHT * 2));
  SequenceView->SetSequence(Sequence);

  PatternCombo = new CDropList(TrackToolBar, "PatternCombo", 0, 0, PATTERN_COMBO_WIDTH, COMBO_HEIGHT);
  TrackToolBar->AddControl(PatternCombo, "Select Pattern", PatternCombo->Handle);

  SequenceToolBar->Show();
  
  SequenceView->Show();

  TrackToolBar->Show();

  

  SubInit = true;
}

CSequenceEditor::~CSequenceEditor()
{
  delete TrackToolBar;
  delete SequenceToolBar;
  delete Sequence;
  delete SequenceView;
  delete PatternCombo;
  delete RecordButton;
  delete PlayButton;
  delete StopButton;
  delete LoopButton;
  delete LengthUpDown;
  delete LengthLabel;
}

void CSequenceEditor::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
    PerformLayout();
}

void CSequenceEditor::PerformLayout()
{
  SequenceToolBar->Move(0, 0, Width, TOOLBAR_HEIGHT);
  TrackToolBar->Move(0, TOOLBAR_HEIGHT, Width, TOOLBAR_HEIGHT);
  SequenceView->Move(0, TOOLBAR_HEIGHT * 2, Width, Height - (TOOLBAR_HEIGHT * 2));
}

void CSequenceEditor::AddTrack(CConnector *port)
{
  int i;

  for(i = 0; i < Sequence->Tracks->Count; i++)
  {
    if(Sequence->Tracks->Items[i]->Port == port)
      return;
  }

  Sequence->AddTrack(port);
  SequenceView->SizeControl();
  SequenceView->DrawControl();
}

void CSequenceEditor::ClearTracks()
{
  Sequence->Tracks->Clear();
  PatternCombo->Clear();
  SequenceView->SizeControl();
  SequenceView->DrawControl();
}

void CSequenceEditor::UpdatePatternCombo(int ntrack)
{
  CConnector     *port;
  CPattern       *pattern;
  CSequenceTrack *track;
  int             i, n;

  PatternCombo->Clear();
  
  if(ntrack == -1)
    return;

  if(ntrack < 0)
    return;

  if(ntrack >= Sequence->Tracks->Count)
    return;

  track = Sequence->Tracks->Items[ntrack];
  port = track->Port;
  
  for(i = n = 0; i < Core->MainWindow->PatternEditor->Patterns->Count; i++)
  {
    pattern = Core->MainWindow->PatternEditor->Patterns->Items[i];
    if(pattern->Port == port)
    {
      PatternCombo->AddItem(pattern->Name);
      if(track->DefaultPattern == 0)
      {
        track->DefaultPattern = pattern;
      }
      if(track->DefaultPattern == pattern)
      {
        PatternCombo->SetSelection(n);
      }
      n++;
    }
  }
}

void CSequenceEditor::OnComboSelect(CDropList *comboBox)
{
  CConnector     *port;
  CPattern       *pattern;
  CSequenceTrack *track;
  int             i, n;
  
  track = SequenceView->GetTrack(SequenceView->GetTrack());
  port = track->Port;
  
  for(i = n = 0; i < Core->MainWindow->PatternEditor->Patterns->Count; i++)
  {
    pattern = Core->MainWindow->PatternEditor->Patterns->Items[i];
    if(pattern->Port == port)
    {
      if(n == comboBox->GetSelection())
        track->DefaultPattern = pattern;
      n++;
    }
  }

}

void CSequenceEditor::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == RecordButton)
  {
	  if(RecordButton->GetPressed())
	  {
		  PlayButton->SetPressed(true);
		  Core->MainWindow->HDRecorder->Start();
		  Play();
	  }
	  else
	  {
		  PlayButton->SetPressed(false);
		  Core->MainWindow->HDRecorder->Stop();
		  Stop();
	  }
  }

  if(button == PlayButton)
  {
    Play();
  }

  if(button == StopButton)
  {
    Stop();
  }

  if(button == LoopButton)
  {
    Loop = LoopButton->GetPressed();
  }
}

void CSequenceEditor::OnAddPattern(CPattern *pattern)
{
  int ntrack;

  ntrack = SequenceView->GetTrack();
  if(ntrack != -1)
    if(SequenceView->GetTrack(ntrack)->Port == pattern->Port)
      UpdatePatternCombo(ntrack);
}

void CSequenceEditor::OnRemovePattern(CPattern *pattern)
{
  int i, j;
  CSequenceTrack *track;
  CSequenceEvent *ev;

  int ntrack;

  ntrack = SequenceView->GetTrack();
  if(ntrack != -1)
    if(SequenceView->GetTrack(ntrack)->Port == pattern->Port)
    {
      UpdatePatternCombo(ntrack);
    }

  for(i = 0; i < Sequence->Tracks->Count; i++)
  {
    track = Sequence->Tracks->Items[i];

    if(track->DefaultPattern == pattern)
      SequenceView->GetTrack(ntrack)->DefaultPattern = 0;

    for(j = 0; j < track->Events->Count;)
    {
      ev = track->Events->Items[j];
      if(ev->Pattern == pattern)
        track->Events->RemoveItem(j);
      else
        j++;
    }
  }
  
  SequenceView->DrawControl();
}

void CSequenceEditor::Play()
{
  Playing    = true;
  PlayOffset = 0.0f;
}

void CSequenceEditor::Stop()
{
  Playing = false;
  PlayButton->SetPressed(false);
  if(RecordButton->GetPressed())
  {
    RecordButton->SetPressed(false);
	  Core->MainWindow->HDRecorder->Stop();
  }
}

void CSequenceEditor::Work()
{
  CSequenceTrack *track;
  CSequenceEvent *ev;
  int i, j;

  for(i = 0; i < Sequence->Tracks->Count; i++)
  {
    track = Sequence->Tracks->Items[i];
    for(j = 0; j < track->Events->Count; j++)
    {
      ev = track->Events->Items[j];
      ev->Pattern->SetSample2(-1);
    }
  }

 if(Playing)
 {
    double bpm, samplesPerTick, sampleRate, offsetInc;
    double es, ef, sl4;
    int offset, s, blockSamples, samples;

    bpm = Core->Host->GetBPM();
    sampleRate = (double)Core->Host->GetSampleRate();
    blockSamples = Core->Host->GetBlockSamples();
    
    samplesPerTick = Core->Host->GetSamplesPerTick();
    offset = 0;
    sl4 = (Sequence->Length * 4.0);

    while(blockSamples)
    {
      offsetInc = (blockSamples / samplesPerTick);
      s = min(blockSamples, max(0, (int)(((PlayOffset + offsetInc) - sl4) * samplesPerTick)));
      samples = blockSamples;

      for(i = 0; i < Sequence->Tracks->Count; i++)
      {
        track = Sequence->Tracks->Items[i];
        for(j = 0; j < track->Events->Count; j++)
        {
          ev = track->Events->Items[j];
          es = (double)((ev->Start) * 4);
          ef = (double)((ev->Start + ev->Pattern->Length) * 4);

          if(((PlayOffset >= es) && (PlayOffset <= ef)) ||
             ((PlayOffset < es)  && (PlayOffset + offsetInc > es)))
          {
            int startSample;

            startSample = (int)((PlayOffset - es) * samplesPerTick);

            ev->Pattern->ProcessBlock(offset, startSample, samples, samplesPerTick);
            ev->Pattern->SetSample2(startSample);
          }
        }
      }

      if(s)
      {
        if(Loop)
        {
          offset += blockSamples - s;
          blockSamples = s;
          if(blockSamples < 0)
            blockSamples = 0;
          PlayOffset = 0.0;
        }
        else
        {
          blockSamples -= s;
          if(blockSamples <= 0)
          {
            blockSamples = 0;
            Stop();
          }
        }
      }
      else
      {
        PlayOffset += offsetInc;
        blockSamples = 0;
      }
    }
 }

 if(!Playing)
   Stop();
}

void CSequenceEditor::OnUpDownChange(CUpDown *upDown)
{
  if(upDown == LengthUpDown)
  {
    ResizeSequence((int)(LengthUpDown->GetValue()));
  }
}

void CSequenceEditor::ResizeSequence(int newLength)
{
  if(Sequence->Length > newLength)
  {
    int i, j;
    
    CSequenceTrack *track;
    CSequenceEvent *ev;

    for(i = 0; i < Sequence->Tracks->Count; i++)
    {
      track = Sequence->Tracks->Items[i];
      for(j = 0; j < track->Events->Count; j++)
      {
        ev = track->Events->Items[j];
        if((ev->Start + ev->Pattern->Length) > newLength)
        {
          track->Events->RemoveItem(j);
          delete ev;
        }
      }
    }
  }

  Sequence->Length = newLength;
  SequenceView->SizeControl();
  SequenceView->DrawControl();
  SequenceView->OnPaint();
}

void CSequenceEditor::OnResizePattern(CPattern *pattern)
{
  int i, j, k;
  
  CSequenceTrack *track;
  CSequenceEvent *ev, *ev2;

  for(i = 0; i < Sequence->Tracks->Count; i++)
  {
    track = Sequence->Tracks->Items[i];
    if(track->Port == pattern->Port)
    {
      for(j = 0; j < track->Events->Count; j++)
      {
        ev = track->Events->Items[j];
        if((ev->Start + ev->Pattern->Length) > Sequence->Length)
        {
          track->Events->RemoveItem(j);
          delete ev;
        }
        else
        {
          for(k = 0; k < track->Events->Count; k++)
          {
            ev2 = track->Events->Items[k];
            if(ev != ev2)
            {
              if(ev2->Start < ev->Start)
              {
                if(ev2->Start + ev2->Pattern->Length > ev->Start)
                {
                  track->Events->RemoveItem(k);
                  delete ev2;
                }
              }
              else
              {
                if((ev2->Start + ev2->Pattern->Length) < ev->Start + ev->Pattern->Length)
                {
                  track->Events->RemoveItem(k);
                  delete ev2;
                }
              }
            }
          }
        }
      }
    }
  }

}

void CSequenceEditor::Animate()
{
  Lock();
  if(Sequence != 0)
  {
    if(Playing)
      SequenceView->UpdatePlayBar(PlayOffset);
    else
      SequenceView->UpdatePlayBar(-1.0f);
  }
  Release();
}

void CSequenceEditor::RemoveMachine(CMachineContainer *machine)
{
  int  i;
  bool redraw = false;

  for(i = 0; i < Sequence->Tracks->Count; i++)
  {
    if(Sequence->Tracks->Items[i]->Port->Container == machine)
    {
      Sequence->Tracks->RemoveItem(i);
      SequenceView->RemoveTrack(i);
   
      redraw = true;
    }
  }

  if(redraw)
  {
    UpdatePatternCombo(SequenceView->GetTrack());
    SequenceView->SizeControl();
    SequenceView->DrawControl();
    SequenceView->OnPaint();
  }
}

#pragma pack(push)
#pragma pack(1)

typedef struct
{
  int Length;
  int Tracks;
} FSequence;

typedef struct
{
  int  Port;
  int  Size;
} SequenceTrack;

typedef struct
{
  int Start;
  int Pattern;
} SequenceEvent;

#pragma pack(pop)

void CSequenceEditor::WriteSequence(char **buffer, int *size)
{
  FSequence *s;
  SequenceTrack *t;
  SequenceEvent *e;
  char     *x;
  int       i, j;

  *size = sizeof(FSequence);
  for(i = 0; i < Sequence->Tracks->Count; i++)
  {
    *size += sizeof(SequenceTrack);
    *size += sizeof(SequenceEvent) * Sequence->Tracks->Items[i]->Events->Count;
  }
  *buffer = new char[*size];
  x = *buffer;
  s = (FSequence*)x;
  s->Length = Sequence->Length;
  s->Tracks = Sequence->Tracks->Count;
  x += sizeof(FSequence);

  for(i = 0; i < Sequence->Tracks->Count; i++)
  {
    t = (SequenceTrack*)x;
    t->Port = Sequence->Tracks->Items[i]->Port->Port->Index;
    t->Size = Sequence->Tracks->Items[i]->Events->Count;
    x += sizeof(SequenceTrack);
    for(j = 0; j < t->Size; j++)
    {
      e = (SequenceEvent*)x;
      e->Pattern = Sequence->Tracks->Items[i]->Events->Items[j]->Pattern->Index;
      e->Start = Sequence->Tracks->Items[i]->Events->Items[j]->Start;
      x += sizeof(SequenceEvent);
    }
  }
}

void CSequenceEditor::ReadSequence(char *buffer, int size)
{
  FSequence      *s;
  char           *x;
  int             i, j, k;
  CSequenceTrack *track;
  SequenceTrack  *t;
  SequenceEvent  *e;
  CPattern       *p;
  
  k = 0;
  x = buffer;
  s = (FSequence*)x;
  LengthUpDown->SetValue((float)s->Length);
  ResizeSequence(s->Length);

  x += sizeof(FSequence);

  for(i = 0; i < s->Tracks; i++)
  {
    t = (SequenceTrack*)x;
    x += sizeof(SequenceTrack);
    
    for(j = 0; j < t->Size; j++)
    {
      e = (SequenceEvent*)x;
      p = Core->MainWindow->PatternEditor->GetPattern(e->Pattern);
      
      if(p)
      {
        track = 0;

        for(k = 0; k < Sequence->Tracks->Count; k++)
          if(Sequence->Tracks->Items[k]->Port->Port == p->Port->Port)
          {     
            track = Sequence->Tracks->Items[k];
          }
      
        if(track)
          track->AddEvent(p, e->Start);
      }
      
      x += sizeof(SequenceEvent);
    }
  }

  SequenceView->Update();
}