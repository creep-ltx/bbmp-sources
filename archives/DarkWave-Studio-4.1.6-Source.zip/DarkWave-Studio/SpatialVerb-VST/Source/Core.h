#ifndef CORE_H
#define CORE_H

#include "DSP.h"
#include "ColorManager.h"
#include "DarkPlug.h"
#include "SpatialVerb.h"
#include "DarkPlugAdapter.h"

class CCore
{
public:
  CCore(int cpuFeatures, audioMasterCallback audioMaster);
 ~CCore();

  int                   CPUFeatures;
  SSpatialVerbGraphics  SpatialVerbGraphics;
  CHostAdapter         *Host;
};

extern CCore *Core;
extern HINSTANCE AppInstance;

#endif