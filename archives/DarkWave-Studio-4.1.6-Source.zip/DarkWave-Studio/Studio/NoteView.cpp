/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <math.h>
#include "NoteView.h"
#include "Core.h"
#include "Util.h"

#define SCROLLBAR_SIZE 16

#define MIN_NOTE   0
#define MAX_NOTE   127
#define ROW_HEIGHT 16
#define KEY_WIDTH  96
#define COL_WIDTH  (4 * CELL_WIDTH)
#define CELL_WIDTH 16

#define SELECT_MENU_CUT      1
#define SELECT_MENU_COPY     2
#define SELECT_MENU_PASTE    3
#define SELECT_MENU_DELETE   4
#define SELECT_MENU_DESELECT 5

const char* NoteLabels[12] = {"C",   "C#", "D",   "D#", "E",   "F",   "F#", "G",   "G#", "A",   "A#", "B"};
const bool  NoteSharps[12] = {false, true, false, true, false, false, true, false, true, false, true, false};

CNoteView::CNoteView(CControl *parent, int x, int y, int width, int height, CScrollBar *scrollBarH, CControlView *controlView)
: CControl(parent, "NoteView", x, y, width, height, true)
{  
  ClipNotes = 0;
  SelectMenu = 0;
  Dragging = false;
  CapturedNote = 0;
  ControlView = controlView;
  Pattern = 0;
  NoteLength = 1;
  PlayBarPos = -1;
  PlayBarPos2 = -1;
  Machine = 0;
  VoiceMode = false;
  Mode = NOTEVIEW_MODE_DRAW_IDLE;
  OldMode = Mode;
  ClearSelection();

  BackColor = (ColorManagerColor)WindowWorkspace;
  
  Rows      = 0;
  Cols      = 0;

  ScrollBarV = new CScrollBar(this, SCROLLBAR_VERTICAL, Width - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, Height, 0, 0);
  ScrollBarH = scrollBarH;
  ScrollBarV->SetLineSize(ROW_HEIGHT);
  ScrollBarH->SetLineSize(COL_WIDTH);
  SizeControl();

  KeyFont = new CFont(DC, "Verdana", 9.0f, true);

  InitSelectMenu();

  SubInit = true;
  ScrollVertical(0);
  DrawControl();
}

CNoteView::~CNoteView()
{
  delete SelectMenu;
  delete ScrollBarV;
  delete KeyFont;
}

void CNoteView::InitSelectMenu()
{
  SelectMenu = new CMenu(this, true);

  SelectMenu->Append(SELECT_MENU_CUT,      "Cut",      0);
  SelectMenu->Append(SELECT_MENU_COPY,     "Copy",     0);
  SelectMenu->Append(SELECT_MENU_PASTE,    "Paste",    0);
  SelectMenu->Append(SELECT_MENU_DELETE,   "Delete",   0);
  SelectMenu->Append(SELECT_MENU_DESELECT, "Deselect", 0);
}

void CNoteView::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
  {
    ScrollBarV->Move(newWidth - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, newHeight);
    SizeControl();
    ScrollVertical(OffsetY);
    Update();
  }
}

void CNoteView::OnPaint()
{
  CControl::OnPaint();
  DrawPlayBar(PlayBarPos, false);
  DrawPlayBar(PlayBarPos2, false);
}

int CNoteView::PlayBarX(double playBarPos)
{
  int x;

  if(playBarPos >= 0.0)
  {
    if(playBarPos >= (LeftCol * 4) && playBarPos <= ((RightCol + 1) * 4))
    {
      x = LeftColX + (int)((playBarPos - (LeftCol * 4)) * CELL_WIDTH);
      if(x >= KEY_WIDTH)
        return x;
    }
  }
  return -1;
}

void CNoteView::DrawPlayBar(double pos, bool clear)
{
  RECT r;

  r.left = PlayBarX(pos);
  if(r.left != -1)
  {
    r.top    = 0;
    r.right  = r.left + 2;
    r.bottom = Height - 1;
    if(clear)
      GetBackBuffer()->Draw(r.left, r.top, r.right - r.left + 1, r.bottom - r.top + 1);
    else
      InvertRect(DC, &r);
  }
}

void CNoteView::ClearSelection()
{
  SelectRow1 = SelectRow2 = -1;
  SelectCol1 = SelectCol2 = -1;
}

void CNoteView::DrawControl()
{
  HDC hDC;

  Lock();

  hDC = BackDC;
  SetBkMode(hDC, TRANSPARENT);
  ColorManager->Lock();
  ColorManager->GetBrush(BackColor)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();
  if(Pattern != 0)
  {
    DrawGrid(hDC);
    DrawNotes(hDC);
    DrawSelection(hDC);
  }
  DrawKeys(hDC);

  Release();
}

void CNoteView::DrawKey(int row)
{
  HDC     hDC;
  int     y;
  HGDIOBJ oldFont;
  
  if((row < TopRow) || (row > BottomRow))
    return;
  
  Lock();
  
  hDC = BackDC;
  SetBkMode(hDC, TRANSPARENT);
  
  oldFont = SelectObject(hDC, KeyFont->Handle);
  
  y = TopRowY + ((row - TopRow) * ROW_HEIGHT);
  DrawKey(hDC, 0, y, RowNote(row));
  
  SelectObject(hDC, oldFont);
 
  GetBackBuffer()->Draw(0, y, KEY_WIDTH, ROW_HEIGHT);
  
  Release();
  
}

void CNoteView::DrawKeys(HDC hDC)
{
  int     row;
  int     y;
  HGDIOBJ oldFont;

  oldFont = SelectObject(hDC, KeyFont->Handle);

  y = TopRowY;
  for(row = TopRow; row <= BottomRow; row++)
  {
    DrawKey(hDC, 0, y, RowNote(row));
    y += ROW_HEIGHT;
  }

  SelectObject(hDC, oldFont);
}

bool CNoteView::IsNoteHighlighted(int note)
{
  if((Mode == NOTEVIEW_MODE_PLAY_HIGHLIGHT) || (Mode == NOTEVIEW_MODE_PLAY_PRESSED))
    if(note == CurrentNote)
      return true;
  return false;
}

bool CNoteView::IsNotePressed(int note)
{
  if(Mode == NOTEVIEW_MODE_PLAY_PRESSED)
    if(note == CurrentNote)
      return true;
  return false;
}

void CNoteView::DrawKey(HDC hDC, int x, int y, int note)
{
  CBrush *brush;
  RECT    r;
  char    label[1024];
  ColorManagerColor keyColor, textColor;
  
  DrawBorder(hDC, bs3DRaised, x, y, KEY_WIDTH, ROW_HEIGHT);

  ColorManager->Lock();

  keyColor = IsKeyBlack(note) ? (IsNotePressed(note) ? KeyBlackBackPressed : KeyBlackBack) :
                                (IsNotePressed(note) ? KeyWhiteBackPressed : KeyWhiteBack);
  
  textColor = IsKeyBlack(note) ? (IsNoteHighlighted(note) ? KeyBlackTextActive : KeyBlackText) :
                                 (IsNoteHighlighted(note) ? KeyWhiteTextActive : KeyWhiteText);
  
  brush = ColorManager->GetBrush(keyColor);
  SetTextColor(hDC, ColorManager->GetColor(textColor));

  brush->FillRect(hDC, x + 1, y + 1, KEY_WIDTH - 2, ROW_HEIGHT - 2);
  
  ColorManager->Release();

  r.left   = x + 1;
  r.right  = x + KEY_WIDTH - 1;
  r.top    = y + 1;
  r.bottom = y + ROW_HEIGHT - 1;

  NoteLabel(note, label);

  DrawText(hDC, label, (int)strlen(label), &r, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
}

void CNoteView::ScrollVertical(int offsetY)
{
  OffsetY   = offsetY;
  TopRow    = min(MaxTopRow, offsetY / ROW_HEIGHT);
  TopRowY   = (TopRow * ROW_HEIGHT) - offsetY;
  BottomRow = min(Rows - 1, TopRow + (Height / ROW_HEIGHT) + 1);
}

void CNoteView::ScrollHorizontal(int offsetX)
{
  OffsetX   = offsetX;
  LeftCol   = min(MaxLeftCol, offsetX / COL_WIDTH);
  LeftColX  = KEY_WIDTH + (LeftCol * COL_WIDTH) - offsetX;
  RightCol  = min(Cols - 1, LeftCol + ((Width - KEY_WIDTH - SCROLLBAR_SIZE) / COL_WIDTH) + 1);
}

void CNoteView::SizeControl()
{
  ScrollBarV->SetMaxPos((Rows * ROW_HEIGHT) - Height);
  ScrollBarV->SetPageSize(Height - ROW_HEIGHT);
  MaxTopRow = min(Rows - 1, max(0, Rows - (Height / ROW_HEIGHT)));
  if(MaxTopRow > 0)
    ScrollBarV->Show();
  else
    ScrollBarV->Hide();

  ScrollBarH->SetMaxPos(max(0, (Cols * COL_WIDTH) - (Width - KEY_WIDTH - SCROLLBAR_SIZE)));
  ScrollBarH->SetPageSize((Width - KEY_WIDTH - SCROLLBAR_SIZE) - COL_WIDTH);
  MaxLeftCol = min(Cols - 1, max(0, Cols - ((Width - KEY_WIDTH - SCROLLBAR_SIZE) / COL_WIDTH)));
  if(MaxLeftCol > 0)
    ScrollBarH->Show();
  else
    ScrollBarH->Hide();
}

void CNoteView::NoteLabel(int note, char *label)
{
  int octave;

  label[0] = 0;
  
  if(VoiceMode)
    Machine->GetVoiceName(note, label);
  else
  {
    if(Machine)
      Machine->GetNoteLabel(note, label);
    if(label[0] == 0)
    {
      octave = (note - (note % 12)) / 12;
      note   = note % 12;
      sprintf(label, "%s-%i", NoteLabels[note], octave);
    }
  }
}

bool CNoteView::IsKeyBlack(int note)
{
  if(VoiceMode)
    return (note % 2) == 0;
  else
    return NoteSharps[note % 12];
}

void CNoteView::OnScrollY(int newPos)
{
  ScrollVertical(newPos);
  Update();
}

void CNoteView::OnScrollX(int newPos)
{
  ScrollHorizontal(newPos);
  Update();
}

void CNoteView::LoadPattern(CPattern *pattern)
{
  bool bSame = (Pattern == pattern);

  Pattern = pattern;
  if(Pattern != 0)
  {
    Machine = Pattern->Port->Container->Machine;
    if(Machine->VoiceCount > 0)
    {
      Rows = Machine->VoiceCount;
      VoiceMode = true;
    }
    else
    {
      Rows = MAX_NOTE - MIN_NOTE + 1;
      VoiceMode = false;
    }
    Cols = Pattern->Length;
    PlayBarPos = Pattern->GetPlayPos();
  }
  else
  {
    VoiceMode  = false;
    Machine    = 0;
    Rows       = 0;
    Cols       = 0;
    PlayBarPos = -1.0f;
  }
  SizeControl();
  if(!bSame)
  { 
    ScrollVertical(Rows ? ((MaxTopRow >> 1) * ROW_HEIGHT) : 0);
    ScrollHorizontal(0);
  }
  else
  {
    ScrollVertical(OffsetY);
    ScrollHorizontal(OffsetX);
  }
      ScrollBarH->SetPos(OffsetX);
    ScrollBarV->SetPos(OffsetY);

  Update();
}

void CNoteView::DrawGrid(HDC hDC)
{
  int     x, y, i;
  int     row, col;
  HGDIOBJ oldPen, oldPen2;
  CBrush *brush, *brush1, *brush2, *brush3;
  bool    b1, b2;

  ColorManager->Lock();
  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)GridLine)->Handle);

  brush1 = ColorManager->GetBrush((ColorManagerColor)GridCell);
  brush2 = ColorManager->GetBrush((ColorManagerColor)GridCellAlt);
  brush3 = ColorManager->GetBrush((ColorManagerColor)GridCellAlt2);

  x = LeftColX;
  for(col = LeftCol; col <= RightCol; col++)
  {
    y = TopRowY;
    b1 = ((col % 2) < 1);

    for(row = TopRow; row <= BottomRow; row++)
    {
      b2 = (((row + 4) % 24) < 12);

      if(b2)
        if(b1)
          brush = brush1;
        else
          brush = brush2;
      else
        if(b1)
          brush = brush2;
        else
          brush = brush3;
       
      brush->FillRect(hDC, x, y, COL_WIDTH, ROW_HEIGHT);
      MoveToEx(hDC, x, y + ROW_HEIGHT - 1, NULL);
      LineTo(hDC, x + COL_WIDTH, y + ROW_HEIGHT - 1);
      LineTo(hDC, x + COL_WIDTH, y - 1);
      oldPen2 = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)GridLineInner)->Handle);
      for(i = 0; i < 4; i++)
      {
        MoveToEx(hDC, x + (CELL_WIDTH * i), y, NULL);
        LineTo(hDC, x + (CELL_WIDTH * i), y + ROW_HEIGHT - 1);
      }
      SelectObject(hDC, oldPen2);
      y += ROW_HEIGHT;
    }
    x += COL_WIDTH;
  }

  SelectObject(hDC, oldPen);
  ColorManager->Release();
}

void CNoteView::DrawSelection(HDC hDC, int x1, int y1, int x2, int y2)
{
  CBrush *brush;

  ColorManager->Lock();

  brush = ColorManager->GetBrush((ColorManagerColor)SelectBox);

  brush->FillRect(hDC, x1, y1, x2 - x1, 2);
  brush->FillRect(hDC, x1, y2 - 2, x2 - x1, 2);

  brush->FillRect(hDC, x1, y1, 2, y2 - y1);
  brush->FillRect(hDC, x2 - 1, y1, 2, y2 - y1);

  ColorManager->Release();
}

void CNoteView::DrawSelection(HDC hDC)
{
  int row1, col1, row2, col2;
  int x1, y1, x2, y2;
  
  if(SelectRow1 == -1)
    return;
  
  row1 = min(SelectRow1, SelectRow2);
  row2 = max(SelectRow1, SelectRow2);
  col1 = min(SelectCol1, SelectCol2);
  col2 = max(SelectCol1, SelectCol2);

  if((row1 <= BottomRow) && (row2 >= TopRow) &&
    (col1 <= (RightCol * 4)) && (col2 >= (LeftCol * 4)))
  {
    x1 = LeftColX + (CELL_WIDTH * (col1 - (LeftCol * 4))) + 1;
    x2 = LeftColX + (CELL_WIDTH * ((col2 + 1) - (LeftCol * 4))) - 1;
    y1 = TopRowY + (ROW_HEIGHT * (row1 - TopRow));
    y2 = TopRowY + (ROW_HEIGHT * ((row2 + 1) - TopRow)) - 1;

    DrawSelection(hDC, x1, y1, x2, y2);
  }
}

void CNoteView::SetNoteLength(int noteLength)
{
  NoteLength = noteLength;
}

void CNoteView::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
}

void CNoteView::OnLeftButtonDown(int x, int y)
{
  if(Mode == NOTEVIEW_MODE_PLAY_HIGHLIGHT)
  {
    if(CurrentNote != -1)
    {
      Mode = NOTEVIEW_MODE_PLAY_PRESSED;
      DrawKey(NoteRow(CurrentNote));
      Pattern->SendNoteOn(CurrentNote);
    }
    return;
  }
  
  if((Mode >= NOTEVIEW_MODE_DRAW_IDLE) && (Mode < NOTEVIEW_MODE_SELECT_IDLE))
  {
    if(Mode == NOTEVIEW_MODE_DRAW_IDLE)
    {
      if((CapturedNote = AddNote(x, y)) != 0)
      {
        SetCapture(Handle);
        Dragging = true;
        DragStartX = x;
        DragStartY = y;
        DragStartStart  = CapturedNote->Start;
        DragStartLength = CapturedNote->Length;
        DragStartNote   = CapturedNote->Note;
        SetMode(NOTEVIEW_MODE_DRAW_SIZERIGHT);
        Update();
      }
    }
    else
    {
      Dragging = true;
      DragStartX = x;
      DragStartY = y;
      DragStartStart  = CapturedNote->Start;
      DragStartLength = CapturedNote->Length;
      DragStartNote   = CapturedNote->Note;
    }
  }
  if(Mode == NOTEVIEW_MODE_SELECT_IDLE)
  {
    Mode = ChooseSelectMode(x, y);
    if(Mode == NOTEVIEW_MODE_SELECT_IDLE)
    {
      SetCapture(Handle);
      Mode = NOTEVIEW_MODE_SELECT_SELECT;
      SelectCol1 = SelectCol2 = PosAt(x);
      SelectRow1 = SelectRow2 = NoteRow(NoteAt(y));
      Update();
    }
    else
    {
      SetCapture(Handle);
      SetCursorBySelectMode(Mode);
    }
  }

}

void CNoteView::OnLeftButtonUp(int x, int y)
{
  if(Mode == NOTEVIEW_MODE_PLAY_HIGHLIGHT)
    return;
 
  if(Mode == NOTEVIEW_MODE_PLAY_PRESSED)
  {
    Mode = NOTEVIEW_MODE_PLAY_HIGHLIGHT;
    if(CurrentNote != -1)
    {
      DrawKey(NoteRow(CurrentNote));
      Pattern->SendNoteOff(CurrentNote);
    }
    else
    {
      Mode = OldMode;
      ReleaseCapture();
    }
 
    return;
  }
  
  Dragging = false;
  if(Mode >= NOTEVIEW_MODE_SELECT_SELECT)
  {
    int t;

    ReleaseCapture();
    Mode = NOTEVIEW_MODE_SELECT_IDLE;
    
    if(SelectCol1 > SelectCol2)
    {
      t = SelectCol1;
      SelectCol1 = SelectCol2;
      SelectCol2 = t;
    }

    if(SelectRow1 > SelectRow2)
    {
      t = SelectRow1;
      SelectRow1 = SelectRow2;
      SelectRow2 = t;
    }
  }
}

void CNoteView::OnRightButtonDown(int x, int y)
{
  if((Mode >= NOTEVIEW_MODE_DRAW_IDLE) && (Mode < NOTEVIEW_MODE_SELECT_IDLE))
  {
    SetMode(NOTEVIEW_MODE_DRAW_IDLE);
    RemoveNote(x, y);
  }
}

void CNoteView::OnRightButtonUp(int x, int y)
{
  if(Mode == NOTEVIEW_MODE_SELECT_SELECT)
    SetMode(NOTEVIEW_MODE_SELECT_IDLE);

  if(Mode == NOTEVIEW_MODE_SELECT_IDLE)
  {
    int   id;
    POINT p;

    if((SelectRow1 != -1) && (SelectCol1 != -1) &&
       (SelectRow2 != -1) && (SelectCol2 != -1))
    {
      SelectMenu->EnableItem(SELECT_MENU_COPY);
      SelectMenu->EnableItem(SELECT_MENU_CUT);
      SelectMenu->EnableItem(SELECT_MENU_DELETE);
      SelectMenu->EnableItem(SELECT_MENU_DESELECT);
    }
    else
    {
      SelectMenu->DisableItem(SELECT_MENU_COPY);
      SelectMenu->DisableItem(SELECT_MENU_CUT);
      SelectMenu->DisableItem(SELECT_MENU_DELETE);
      SelectMenu->DisableItem(SELECT_MENU_DESELECT);
    }
    
    if(ClipNotes == 0)
      SelectMenu->DisableItem(SELECT_MENU_PASTE);
    else
      SelectMenu->EnableItem(SELECT_MENU_PASTE);

    p.x = x;
    p.y = y;
    ClientToScreen(Handle, &p);

    id = SelectMenu->ShowPopup(p.x, p.y);
    OnSelectMenu(id, x, y);
  }
}

CNote* CNoteView::CopyNotes(int row1, int col1, int row2, int col2, bool *clipVoiceMode)
{
  CNote *clipNotes = 0;
  CNote *clone;
  int    note1, note2, t;

  note1 = RowNote(row1);
  note2 = RowNote(row2);

  t = note1;
  if(note1 > note2)
  {
    note1 = note2;
    note2 = t;
  }

  if(Pattern)
  {
    CNote *currentNote = Pattern->FirstNote;

    while(currentNote)
    {
      if((currentNote->Note >= note1) && (currentNote->Note <= note2)
        && (currentNote->Start >= col1) && ((currentNote->Start + currentNote->Length - 1) <= col2))
      {
        clone = new CNote(currentNote->Start - col1, currentNote->Length, currentNote->Note - t);
        if(!clipNotes)
          clipNotes = clone;
        else
          clone->Attach(&clipNotes);
      }
      currentNote = currentNote->GetNext();
    }
  }

  *clipVoiceMode = VoiceMode;
  return clipNotes;
}

void CNoteView::ClearNotes(int row1, int col1, int row2, int col2)
{
  int  note1, note2;
  bool bUpdate = false;
  int  t;

  note1 = RowNote(row1);
  note2 = RowNote(row2);

  if(note1 > note2)
  {
    t = note1;
    note1 = note2;
    note2 = t;
  }

  if(Pattern)
  {
    CNote *currentNote = Pattern->FirstNote;

    while(currentNote)
    {
      if((currentNote->Note >= note1) && (currentNote->Note <= note2)
        && (currentNote->Start >= col1) && ((currentNote->Start + currentNote->Length - 1) <= col2))
      {
        Pattern->RemoveNote(currentNote);
        currentNote = Pattern->FirstNote;
        bUpdate = true;
      }
      else
        currentNote = currentNote->GetNext();
    }
  }

  if(bUpdate)
    Update();
}

void CNoteView::PasteNotes(CNote *clipNotes, int row1, int col1, bool clipVoiceMode)
{
  int note1 = RowNote(row1);
  CNote *currentNote;
  int start, length, note;
  bool bUpdate = false;

  currentNote = clipNotes;
  while(currentNote)
  {
    start  = currentNote->Start + col1;
    length = currentNote->Length;
    note   = (VoiceMode != clipVoiceMode) ? (note1 - currentNote->Note) : (currentNote->Note + note1);

    if(NoteFits(start, length, note))
    {
      Pattern->AddNote(start, length, note);
      bUpdate = true;
    }
    currentNote = currentNote->GetNext();
  }

  if(bUpdate)
  {
    ClearSelection();
    Update();
  }
}

void CNoteView::OnSelectMenu(int id, int x, int y)
{
  switch(id)
  {
    case SELECT_MENU_CUT:
    {
      if(ClipNotes)
      {
        delete ClipNotes;
        ClipNotes = 0;
      }
      ClipNotes = CopyNotes(SelectRow1, SelectCol1, SelectRow2, SelectCol2, &ClipVoiceMode); 
      ClearNotes(SelectRow1, SelectCol1, SelectRow2, SelectCol2);
      ClearSelection();
      Update();
      break;
    }
    case SELECT_MENU_COPY:   
    {
      if(ClipNotes)
      {
        delete ClipNotes;
        ClipNotes = 0;
      }
      ClipNotes = CopyNotes(SelectRow1, SelectCol1, SelectRow2, SelectCol2, &ClipVoiceMode); 
      break;
    }
    case SELECT_MENU_PASTE:  
    {
      if(ClipNotes)
        PasteNotes(ClipNotes, NoteRow(NoteAt(y)), PosAt(x), ClipVoiceMode);
      break;
    }
    case SELECT_MENU_DELETE: 
    {
      ClearNotes(SelectRow1, SelectCol1, SelectRow2, SelectCol2);
      ClearSelection();
      Update();
      break;
    }
    case SELECT_MENU_DESELECT:
    {
      ClearSelection();
      Update();
      break;
    }
  }
}

int CNoteView::DetermineMode(CNote *note, int x, int y)
{
  int x1, y1, x2, y2;

  if(note == 0)
    return NOTEVIEW_MODE_DRAW_IDLE;
  NoteRect(note, &x1, &y1, &x2, &y2);
  if(x <= (x1 + 4))
    return NOTEVIEW_MODE_DRAW_SIZELEFT;
  if(x >= (x2 - 4))
    return NOTEVIEW_MODE_DRAW_SIZERIGHT;
  return NOTEVIEW_MODE_DRAW_DRAG;
}

void CNoteView::SetMode(int mode)
{
  LPCSTR cursor;

  if(mode == NOTEVIEW_MODE_DRAW_IDLE)
    ClearSelection();

  if(Mode == mode)
    return;

  if(Mode == NOTEVIEW_MODE_SELECT_SELECT)
    if(mode == NOTEVIEW_MODE_SELECT_IDLE)
    {
      int t;

      if(SelectRow1 > SelectRow2)
      {
        t = SelectRow1;
        SelectRow1 = SelectRow2;
        SelectRow2 = t;
      }

      if(SelectCol1 > SelectCol2)
      {
        t = SelectCol1;
        SelectCol1 = SelectCol2;
        SelectCol2 = t;
      }
    }

  Mode = mode;
  switch(Mode)
  {
    case NOTEVIEW_MODE_DRAW_DRAG:
    {
      cursor = IDC_SIZEALL;
      break;
    }
    case NOTEVIEW_MODE_DRAW_SIZELEFT:
    case NOTEVIEW_MODE_DRAW_SIZERIGHT:
    {
      cursor = IDC_SIZEWE;
      break;
    }
    default:
    {
      cursor = IDC_ARROW;
    }
  }
  
  SetCursor(LoadCursor(NULL, cursor));
}

void CNoteView::OnDrag(int x, int y)
{
  int  amountPos, amountRow;
  int  newLength, newPos, newNote;
  bool update = false;

  if(!CapturedNote)
    return;

  switch(Mode)
  {
    case NOTEVIEW_MODE_DRAW_SIZERIGHT:
    {
      amountPos = (x - DragStartX) / CELL_WIDTH;    
      newLength = DragStartLength + amountPos;
      if(newLength > 0)
        if(NoteFits(CapturedNote->Start, newLength, CapturedNote->Note, CapturedNote))
        {
          CapturedNote->Length = newLength;
          update = true;
        }
      break;
    }
    case NOTEVIEW_MODE_DRAW_SIZELEFT:
    {
      amountPos = (x - DragStartX) / CELL_WIDTH;    
      newPos = DragStartStart + amountPos;
      newLength = DragStartLength - amountPos;
      if(newLength > 0)
        if(NoteFits(newPos, newLength, CapturedNote->Note, CapturedNote))
        {
          CapturedNote->Start  = newPos;
          CapturedNote->Length = newLength;
          update = true;
        }
      break;
    }
    case NOTEVIEW_MODE_DRAW_DRAG:
    {
      amountPos = (x - DragStartX) / CELL_WIDTH;
      amountRow = (y - DragStartY) / ROW_HEIGHT;
      newPos  = DragStartStart + amountPos;
      newNote = VoiceMode ? (DragStartNote + amountRow) : (DragStartNote  - amountRow);
      if(NoteFits(newPos, DragStartLength, newNote, CapturedNote))
      {
        CapturedNote->Start = newPos;
        CapturedNote->Note = newNote;
        update = true;
        break;
      }
      else
      {
        if(NoteFits(CapturedNote->Start, DragStartLength, newNote, CapturedNote))
        {
          CapturedNote->Note = newNote;
          update = true;
          break;
        }      
        else
        {
          if(NoteFits(newPos, DragStartLength, CapturedNote->Note, CapturedNote))
          {
            CapturedNote->Start = newPos;
            update = true;
            break;
          }
        }
      }
    }
  }

  if(update)
    Update();
}

void CNoteView::SetCursorBySelectMode(int selectMode)
{
  switch(selectMode)
  {
    case NOTEVIEW_MODE_SELECT_IDLE:
    {
      SetCursor(LoadCursor(NULL, IDC_ARROW));
      break;
    }
    case NOTEVIEW_MODE_SELECT_SIZE_N:
    case NOTEVIEW_MODE_SELECT_SIZE_S:
    {
      SetCursor(LoadCursor(NULL, IDC_SIZENS));
      break;
    }
    case NOTEVIEW_MODE_SELECT_SIZE_W:
    case NOTEVIEW_MODE_SELECT_SIZE_E:
    {
      SetCursor(LoadCursor(NULL, IDC_SIZEWE));
      break;
    }
    case NOTEVIEW_MODE_SELECT_SIZE_NE:
    case NOTEVIEW_MODE_SELECT_SIZE_SW:
    {
      SetCursor(LoadCursor(NULL, IDC_SIZENESW));
      break;
    }
    case NOTEVIEW_MODE_SELECT_SIZE_NW:
    case NOTEVIEW_MODE_SELECT_SIZE_SE:
    {
      SetCursor(LoadCursor(NULL, IDC_SIZENWSE));
      break;
    }
  }
}

void CNoteView::OnMouseMove(int x, int y)
{
  CNote *newNote, *oldNote;
  bool   redraw = false;
  int    iNewNote, iOldNote;
  
  if(!Pattern)
    return;

  if((Mode == NOTEVIEW_MODE_DRAW_IDLE) || (Mode == NOTEVIEW_MODE_SELECT_IDLE))
    if((x >= 0) && (x < KEY_WIDTH))
    {
      OldMode = Mode;
      Mode = NOTEVIEW_MODE_PLAY_HIGHLIGHT;
      SetCapture(Handle);
      CurrentNote = NoteAt(y);
      if(CurrentNote != -1)
      {
        DrawKey(NoteRow(CurrentNote));
      }     
      return;
    }
  
  if(Mode == NOTEVIEW_MODE_PLAY_HIGHLIGHT)
  {
    if((x >= 0) && (x < KEY_WIDTH))
    {
      iNewNote = NoteAt(y);
      
      if(CurrentNote != iNewNote)
      {
        iOldNote = CurrentNote;
        CurrentNote = iNewNote;
        if(iOldNote != -1)
          DrawKey(NoteRow(iOldNote));
        if(iNewNote != -1)
          DrawKey(NoteRow(iNewNote));
        else
        {
          Mode = OldMode;
          ReleaseCapture();
        }
      }
    }
    else
    {
      iOldNote = CurrentNote;
      CurrentNote = -1;
      if(iOldNote != -1)
        DrawKey(NoteRow(iOldNote));
      Mode = OldMode;
      ReleaseCapture();
    }
    return;
  }
  
  if(Mode == NOTEVIEW_MODE_PLAY_PRESSED)
  {
    if((x >= 0) && (x < KEY_WIDTH))
      iNewNote = NoteAt(y);
    else
      iNewNote = -1;
      
    if(CurrentNote != iNewNote)
    {
      iOldNote = CurrentNote;
      CurrentNote = iNewNote; 
      if(iOldNote != -1)
      {
        DrawKey(NoteRow(iOldNote));
        Pattern->SendNoteOff(iOldNote);
      }
      if(iNewNote != -1)
      {
        DrawKey(NoteRow(iNewNote));
        Pattern->SendNoteOn(iNewNote);
      }
    }
    
    return;
  }
  
  if((Mode >= NOTEVIEW_MODE_DRAW_IDLE) && (Mode < NOTEVIEW_MODE_SELECT_IDLE))
  {
    if(Dragging)
    {
      OnDrag(x, y);
      return;
    }

    newNote = NoteAt(PosAt(x), NoteAt(y));
    if(CapturedNote)
    {
      if(newNote == CapturedNote)
      {
        SetMode(DetermineMode(newNote, x, y));
        return;
      }
      oldNote = CapturedNote;
      CapturedNote = 0;
      DrawNote(BackDC, oldNote);
      redraw = true;
      ReleaseCapture();
    }
    if(newNote)
    {
      CapturedNote = newNote;
      SetCapture(Handle);
      DrawNote(BackDC, newNote);
      redraw = true;
      SetMode(DetermineMode(newNote, x, y));
    }
    else
      SetMode(NOTEVIEW_MODE_DRAW_IDLE);
    if(redraw)
      OnPaint();
  }

  if(Mode == NOTEVIEW_MODE_SELECT_SELECT)
  {
    int row2, col2;

    row2 = RowNote(NoteAt(y));
    col2 = PosAt(x);
    
    if((row2 != SelectRow2) || (col2 != SelectCol2))
    {
      if((row2 != -1) && (col2 != -1))
      {
        SelectRow2 = row2;
        SelectCol2 = col2;
        Update();
      }
    }
  }

  if(Mode == NOTEVIEW_MODE_SELECT_IDLE)
  {
    SetCursorBySelectMode(ChooseSelectMode(x, y));
  }

  if((Mode >= NOTEVIEW_MODE_SELECT_SIZE_N) && (Mode <= NOTEVIEW_MODE_SELECT_SIZE_SW))
  {
    OnSizeSelectBox(x, y);
  }
}

int CNoteView::ChooseSelectMode(int x, int y)
{
  int  row1, col1, row2, col2;
  int  x1, y1, x2, y2;
  bool bX, bY;

  row1 = min(SelectRow1, SelectRow2);
  row2 = max(SelectRow1, SelectRow2);
  col1 = min(SelectCol1, SelectCol2);
  col2 = max(SelectCol1, SelectCol2);

  x1 = LeftColX + (CELL_WIDTH * (col1 - (LeftCol * 4))) + 1;
  x2 = LeftColX + (CELL_WIDTH * ((col2 + 1) - (LeftCol * 4))) - 1;
  y1 = TopRowY + (ROW_HEIGHT * (row1 - TopRow));
  y2 = TopRowY + (ROW_HEIGHT * ((row2 + 1) - TopRow)) - 1;

  bX = ((x >= x1) && (x <= x2));
  bY = ((y >= y1) && (y <= y2));

  if(bX && bY)
  {
    if(x <= x1 + 2)
      if(y <= y1 + 2)
        return NOTEVIEW_MODE_SELECT_SIZE_NW;
      else
        if(y >= y2 - 2)
          return NOTEVIEW_MODE_SELECT_SIZE_SW;
        else
          return NOTEVIEW_MODE_SELECT_SIZE_W;
    else
      if(x >= x2 - 2)
        if(y <= y1 + 2)
          return NOTEVIEW_MODE_SELECT_SIZE_NE;
        else
          if(y >= y2 - 2)
            return NOTEVIEW_MODE_SELECT_SIZE_SE;
          else
            return NOTEVIEW_MODE_SELECT_SIZE_E;
      else
        if(y <= y1 + 2)
          return NOTEVIEW_MODE_SELECT_SIZE_N;
        else
          if(y >= y2 - 2)
            return NOTEVIEW_MODE_SELECT_SIZE_S;
  }
  return NOTEVIEW_MODE_SELECT_IDLE;
}

void CNoteView::OnSizeSelectBox(int x, int y)
{
  if((Mode == NOTEVIEW_MODE_SELECT_SIZE_N)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_NE)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_NW))
  {
    int row1;

    row1 = RowNote(NoteAt(y));
    if(row1 != -1)
      if(row1 != SelectRow1)
      {
        SelectRow1 = row1;
        Update();
      }
  }
  if((Mode == NOTEVIEW_MODE_SELECT_SIZE_S)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_SE)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_SW))
  {
    int row2;

    row2 = RowNote(NoteAt(y));
    if(row2 != -1)
      if(row2 != SelectRow2)
      {
        SelectRow2 = row2;
        Update();
      }
  }  
  if((Mode == NOTEVIEW_MODE_SELECT_SIZE_E)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_NE)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_SE))
  {
    int col2;

    col2 = PosAt(x);;
    if(col2 != -1)
      if(col2 != SelectCol2)
      {
        SelectCol2 = col2;
        Update();
      }
  }
  if((Mode == NOTEVIEW_MODE_SELECT_SIZE_W)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_NW)
    || (Mode == NOTEVIEW_MODE_SELECT_SIZE_SW))
  {
    int col1;

    col1 = PosAt(x);;
    if(col1 != -1)
      if(col1 != SelectCol2)
      {
        SelectCol1 = col1;
        Update();
      }
  }
}

CNote* CNoteView::AddNote(int x, int y)
{
  int    note, start;
  CNote *cnote;

  if(Pattern == 0)
    return 0;

  note  = NoteAt(y);
  start = PosAt(x);

  if(note != -1 && start != -1)
  {
    if(NoteFits(start, NoteLength, note))
    {
      cnote = Pattern->AddNote(start, NoteLength, note);
      Update();
      ControlView->Update();
      return cnote;
    }
  }

  return 0;
}

void CNoteView::RemoveNote(int x, int y)
{
  int    note, pos;
  CNote *cnote;

  if(Pattern == 0)
    return;

  note = NoteAt(y);
  pos  = PosAt(x);

  if(note != -1 && pos != -1)
  {
    cnote = NoteAt(pos, note);
    if(cnote != 0)
    {
      if(CapturedNote)
        ReleaseCapture();
      CapturedNote = 0;
      Dragging = false;
      Pattern->RemoveNote(cnote);
      Update();
      ControlView->Update();
    }
  }
}

int CNoteView::NoteAt(int y)
{
  int row, note;
  
  row = TopRow + ((y - TopRowY) / ROW_HEIGHT);
  if(row >= TopRow && row <= BottomRow)
  {
    note = RowNote(row); 
    return note;
  }
  else
    return -1;
}

int CNoteView::PosAt(int x)
{
  int pos;

  pos = (LeftCol * 4) + ((x - LeftColX) / CELL_WIDTH);
  if(pos >= 0 && pos < Cols * 4)
    return pos;
  else
    return -1;
}

bool CNoteView::NoteFits(int start, int length, int note, CNote *ignore)
{
  CNote *cnote;

  if(Pattern == 0)
    return false;

  if(VoiceMode)
  {
    if((note < 0) || (note >= Machine->VoiceCount))
      return false;
  }
  else
  {
    if((note < MIN_NOTE) || (note > MAX_NOTE))
      return false;
  }

  if(start >= 0 && start < Pattern->Length * 4)
    if(start + length <= Pattern->Length * 4)
    {
      cnote = Pattern->FirstNote;
      while(cnote != 0)
      {
        if((cnote->Note == note) && (cnote != ignore))
        {
          if(cnote->Start >= start && cnote->Start < start + length)
            return false;
          if(start > cnote->Start && start + length < cnote->Start)
            return false;
          if(cnote->Start + cnote->Length > start && cnote->Start + cnote->Length < start + length)
            return false;
          if(start + length > cnote->Start && start + length < cnote->Start + cnote->Length)
            return false;
        }
        cnote = cnote->GetNext();
      }
      return true;
    }

  return false;
}

bool CNoteView::NoteFits(int start, int length, int note)
{
  return NoteFits(start, length, note, 0);
}

void CNoteView::DrawNotes(HDC hDC)
{
  CNote *note;
  
  if(Pattern == 0)
    return;

  note = Pattern->FirstNote;
  while(note != 0)
  {
    DrawNote(hDC, note);
    note = note->GetNext();
  }
}

int CNoteView::PosX(int pos)
{
  return LeftColX + ((pos - (LeftCol * 4)) * CELL_WIDTH);
}

int CNoteView::RowY(int row)
{
  return TopRowY  + (row - TopRow) * ROW_HEIGHT;
}

void CNoteView::NoteRect(CNote *note, int *x1, int *y1, int *x2, int *y2)
{
  int row, pos;

  row = NoteRow(note->Note);
  pos = note->Start;
  *x1 = PosX(pos) + 1;
  *y1 = RowY(row) + 1;
  *x2 = *x1 + (note->Length * CELL_WIDTH) - 3;
  *y2 = *y1 + (ROW_HEIGHT - 1) - 3;
}

bool CNoteView::InSelection(CNote *note)
{
  int row1, col1, row2, col2, t, noteRow;

  row1 = SelectRow1;
  row2 = SelectRow2;
  if(row1 > row2)
  {
    t = row1;
    row1 = row2;
    row2 = t;
  }

  col1 = SelectCol1;
  col2 = SelectCol2;
  if(col1 > col2)
  {
    t = col1;
    col1 = col2;
    col2 = t;
  }

  if((row1 != -1) && (col1 != -1) && (row2 != -1) && (col2 != -1))
  {
    noteRow = NoteRow(note->Note);
    if((noteRow >= row1) && (noteRow <= row2))
    {
      if((note->Start >= col1) && ((note->Start + note->Length - 1) <= col2))
        return true;
      else
        return false;
    }
    else
      return false;
  }
  else
    return false;
}

void CNoteView::DrawNote(HDC hDC, CNote *note)
{
  int row, pos1, pos2;
  int x, y, width, height;
  ColorManagerColor color;

  row = NoteRow(note->Note);
  if(row >= TopRow && row <= BottomRow)
  {
    pos1 = note->Start;
    pos2 = note->Start + note->Length - 1;

    if(((pos2 >> 2) >= LeftCol) && ((pos1 >> 2) <= RightCol))
    {
      x      = PosX(pos1) + 1;
      y      = RowY(row);
      width  = (note->Length * CELL_WIDTH) - 1;
      height = ROW_HEIGHT - 1;

      if(x < LeftColX)
      {
        width -= LeftColX - x;
        x = LeftColX;
      }

      if(Mode >= NOTEVIEW_MODE_SELECT_IDLE)
      {
        if(InSelection(note))
          color = (ColorManagerColor)NoteBackHighlight;
        else
          color = (ColorManagerColor)NoteBack;
      }
      else
      {
        if(CapturedNote == note)
          color = (ColorManagerColor)NoteBackHighlight;
        else
          color = (ColorManagerColor)NoteBack;
      }

      HRGN clipRegion;

      clipRegion = CreateRectRgn(KEY_WIDTH, 0, Width - 1, Height - 1);
      SelectClipRgn(hDC, clipRegion);
      DeleteObject(clipRegion);

      ColorManager->Lock();
      ColorManager->GetBrush(color)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);
      DrawBorder(hDC, bs3DRaised, x, y, width, height, ColorManager->GetPen((ColorManagerColor)NoteLight), ColorManager->GetPen((ColorManagerColor)NoteShadow));
      ColorManager->Release();

      SelectClipRgn(hDC, NULL);
    }
  }
}

int CNoteView::RowNote(int row)
{
  if(VoiceMode)
    return row;
  else
    return MAX_NOTE - row;
}

int CNoteView::NoteRow(int note)
{
  if(VoiceMode)
    return note;
  else
    return MAX_NOTE - note;
}

CNote *CNoteView::NoteAt(int pos, int note)
{
  CNote *cnote;

  cnote = Pattern->FirstNote;
  while(cnote != 0)
  {
    if(cnote->Start <= pos && cnote->Start + cnote->Length > pos && cnote->Note == note)
      return cnote;
    cnote = cnote->GetNext();
  }
  return 0;
}

void CNoteView::UpdatePlayBar()
{
  double newPos;
  int    oldX, newX;
  
  Lock();

  newPos = Pattern->GetPlayPos();
  if(fabs(newPos - PlayBarPos) > 0.000001)
  {
    oldX = PlayBarX(PlayBarPos);
    newX = PlayBarX(newPos);
    PlayBarPos = newPos;
    if(oldX != newX)
    {
      OnPaint();
      GdiFlush();
    }
  }

  Release();
}

void CNoteView::UpdatePlayBar2()
{
  double newPos;
  int    oldX, newX;
  
  Lock();

  newPos = Pattern->GetPlayPos2();
  if(fabs(newPos - PlayBarPos2) > 0.000001)
  {
    oldX = PlayBarX(PlayBarPos2);
    newX = PlayBarX(newPos);
    PlayBarPos2 = newPos;
    if(oldX != newX)
    {
      OnPaint();
      GdiFlush();
    }
  }

  Release();
}

