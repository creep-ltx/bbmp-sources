/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CONVERTBLOCK_H
#define CONVERTBLOCK_H

#include <Limits.h>

  inline int ConvertAudioFloatToInt32(float x)
  {
    return(x < 0.0f ? (x <= -1.0f ? INT_MIN    : (int)(x * 2147483648.0f)) : 
                      (x >=  1.0f ? 2147483647 : (int)(x * 2147483647.0f)));
  }

  inline short ConvertAudioFloatToInt(float x)
  {
    return(x < 0.0f ? (x <= -1.0f ? -32768 : (int)(x * 32768.0f)) : 
                      (x >=  1.0f ?  32767 : (int)(x * 32767.0f)));
  }

  inline char ConvertAudioFloatToByte(float x)
  {
    return(x < 0.0f ? (x <= -1.0f ? -128 : (char)(x * 128.0f)) : 
                      (x >=  1.0f ?  127 : (char)(x * 127.0f)));
  }

  inline char ConvertAudioDoubleToByte(double x)
  {
    return(x < 0.0 ? (x <= -1.0 ? -128 : (char)(x * 128.0)) : 
                     (x >=  1.0 ?  127 : (char)(x * 127.0)));
  }

  inline short ConvertAudioDoubleToInt(double x)
  {
    return(x < 0.0 ? (x <= -1.0 ? -32768 : (int)(x * 32768.0)) : 
                     (x >=  1.0 ?  32767 : (int)(x * 32767.0)));
  }

  inline int ConvertAudioDoubleToInt32(double x)
  {
    return(x < 0.0 ? (x <= -1.0 ? INT_MIN    : (int)(x * 2147483648.0)) : 
                     (x >=  1.0 ? 2147483647 : (int)(x * 2147483647.0)));
  }

void ConvertStereoFloatToStereoFloat(float *inLeft, float *inRight, float *outPtr, unsigned int blockSize);
void ConvertMonoFloatToMonoInt(float *in, short *out, unsigned int blockSize);
void ConvertStereoFloatToStereoInt(float *inLeft, float *inRight, short *out, unsigned int blockSize);
void ConvertStereoFloatToMonoInt(float *inLeft, float *inRight, short *out, unsigned int blockSize);
void ConvertStereoFloatToStereoByte(float *inLeft, float *inRight, char *out, unsigned int blockSize);
void ConvertStereoFloatToMonoByte(float *inLeft, float *inRight, char *outPtr, unsigned int blockSize);
void ConvertStereoDoubleToStereoFloat(double *inLeft, double *inRight, float *outPtr, unsigned int blockSize);
void ConvertStereoDoubleToStereoInt(double *inLeft, double *inRight, short *outPtr, unsigned int blockSize);
void ConvertStereoDoubleToMonoFloat(double *inLeft, double *inRight, float *outPtr, unsigned int blockSize);
void ConvertMonoDoubleToMonoInt(double *in, short *out, unsigned int blockSize);
void ConvertMonoDoubleToMonoByte(double *in, char *out, unsigned int blockSize);
void ConvertMonoDoubleToMonoFloat(double *in, float *out, unsigned int blockSize);
void ConvertMonoFloatToMonoDouble(float *in, double *out, unsigned int blockSize);
void ConvertStereoDoubleToMonoByte(double *inLeft, double *inRight, char *outPtr, unsigned int blockSize);
void ConvertStereoDoubleToStereoByte(double *inLeft, double *inRight, char *outPtr, unsigned int blockSize);
void ConvertStereoDoubleToMonoInt(double *inLeft, double *inRight, short *outPtr, unsigned int blockSize);

#endif