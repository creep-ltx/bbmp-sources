/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "MIDIOutput.h"
#include "Core.h"

#define GUI_WIDTH      240
#define GUI_HEIGHT     64
#define TIME_ADJUST_MS 80

CMIDIOutputInfo::CMIDIOutputInfo()
{
  Name = "ES MIDI Output";
  UniqueID = "DarkPlug::ES MIDI Output";
}

CMachine *CMIDIOutputInfo::CreateMachine()
{
  return new CMIDIOutput(Core->Host);
}

CMIDIOutput::CMIDIOutput(CHost *host)
: CMachine(host)
{
  int i;

  GUI = 0;
  Ports = new CPort*[1];
  Ports[0] = new CPort(Core->Host, this, PT_CONTROL | PT_INPUT, "Control In");
  PortCount = 1;
  Device = 0;
  Channel = 0;
  FutureBuffer = new CControlBuffer();
  BlockSamples = Host->GetBlockSamples();
  SampleRate = Host->GetSampleRate();
  if(QueryPerformanceFrequency(&PerformanceFrequency) == 0)
    PerformanceFrequency.QuadPart = 0;
  PropertyCount = 128;
  Properties = new double[PropertyCount];
  for(i = 0; i < PropertyCount; i++)
    Properties[i] = 0.0;
}

CMIDIOutput::~CMIDIOutput()
{
  CloseDevice();
  delete Properties;
  delete Ports[0];
  delete Ports;
  delete FutureBuffer;
  if(GUI != 0)
    delete GUI;
}

bool CMIDIOutput::IsSynth()
{
  return false;
}

void CMIDIOutput::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

void CMIDIOutput::SetSampleRate(int sampleRate)
{
  SampleRate = sampleRate;
}
void CMIDIOutput::Work()
{
  SControlMessage message;
  bool            messageRead;
  int             sample;
  int             delay;

  FutureBuffer->CopyTo(Ports[0]->ControlBuffer);
  sample = 0;

  messageRead = Ports[0]->ControlBuffer->Read(&message);
  while(messageRead)
  {
    if(message.BlockSample >= BlockSamples)
    {
      message.BlockSample -= BlockSamples;
      FutureBuffer->Write(&message);
    }
    else
    {
	    if(Device != 0)
	    {
		    delay = ((message.BlockSample - sample) * 1000) / SampleRate;
		    if(delay > 0)
			  Sleep(delay);
		    switch(message.Type)
		    {
			    case CONTROL_MESSAGE_NOTE_ON:
			    {
			      Device->Write(0x90 + Channel, message.NoteOn.Note, (unsigned char)(message.NoteOn.Velocity * 127.0f));
			      break;
			    }
			    case CONTROL_MESSAGE_NOTE_OFF:
			    {
			      Device->Write(0x80 + Channel, message.NoteOff.Note, 0);
			      break;
			    }
          case CONTROL_MESSAGE_CONTROL_CHANGE:
          {
            if(message.ControlChange.Controller <= 127)
            {
              Device->Write(0xB0 + Channel, (unsigned char)(message.ControlChange.Controller), (unsigned char)(message.ControlChange.Value * 127.0f));
            }
            break;
          }
        }
      }
    }
    messageRead = Ports[0]->ControlBuffer->Read(&message);    
  }
}

HWND CMIDIOutput::CreateGUI(HWND parent)
{
  if(GUI == 0)
    GUI = new CMIDIOutputGUI(parent, this);
  return GUI->Handle;
}

CMIDIOutputGUI::CMIDIOutputGUI(HWND parent, CMIDIOutput *midiOutput)
: CControl(parent, Core->ColorManager, "MIDI Input", 0, 0, GUI_WIDTH, GUI_HEIGHT, false)
{
  int           i;
  CMIDIManager *midiManager;
  char          chanTxt[32];

  MIDIOutput = midiOutput;
    
  DeviceCombo  = new CDropList(this, "DeviceCombo",  8, 8,  GUI_WIDTH - 16, 16);
  ChannelCombo = new CDropList(this, "ChannelCombo", 8, 36, GUI_WIDTH - 16, 16);

  midiManager = Core->MIDIManager;
  for(i = 0; i < midiManager->OutputDeviceCount; i++)
    DeviceCombo->AddItem(midiManager->OutputDevices[i]->Name);

  for(i = 1; i <= 16; i++)
  {
    sprintf(chanTxt, "Channel %i", i);
    ChannelCombo->AddItem(chanTxt);
  }

  if(midiOutput->Device)
    DeviceCombo->SetSelection(midiOutput->Device->ID);

  ChannelCombo->SetSelection(midiOutput->Channel);

  DeviceCombo->Show();
  ChannelCombo->Show();
}

CMIDIOutputGUI::~CMIDIOutputGUI()
{
  delete DeviceCombo;
  delete ChannelCombo;
}

void CMIDIOutputGUI::OnComboSelect(CDropList *comboBox)
{
  if(comboBox == DeviceCombo)
  {
    OpenDevice(comboBox->GetSelection());
  }
  if(comboBox == ChannelCombo)
  {
    MIDIOutput->SetChannel(comboBox->GetSelection());
  }
}

void CMIDIOutputGUI::OpenDevice(int index)
{
  MIDIOutput->OpenDevice(index);
}

void CMIDIOutput::OpenDevice(int index)
{
  CloseDevice();

  if(index >= 0 && index < Core->MIDIManager->OutputDeviceCount)
  {
    Device = Core->MIDIManager->OutputDevices[index];
    Device->Open();
  }
}

void CMIDIOutput::CloseDevice()
{
  if(Device != 0)
  {
    Device->Close();
    Device = 0;
  }
}

void CMIDIOutput::SetChannel(int channel)
{
  Channel = channel;
  if(GUI)
    GUI->ChannelCombo->SetSelection(channel);
}


double DARKCALL CMIDIOutput::GetProperty(int index)
{
  return Properties[index];
}

void DARKCALL CMIDIOutput::SetProperty(int index, double value)
{
  SControlMessage message;

  Properties[index] = value;
  memset(&message, 0, sizeof(SControlMessage));
  message.BlockSample = 0;
  message.Type = CONTROL_MESSAGE_CONTROL_CHANGE;
  message.ControlChange.Controller = index;
  message.ControlChange.Value = value;
  Ports[0]->ControlBuffer->Write(&message);
}

void DARKCALL CMIDIOutput::GetPropertyName(int index, char *text)
{
  sprintf(text, "CC %i", index);
}

void DARKCALL CMIDIOutput::GetPropertyValueDisplay(int index, double value, char *text)
{
  sprintf(text, "%i", (unsigned char)(127.0 * value));
}

struct SMIDIOutputProperties
{
  int Device;
  int Channel;
};

void DARKCALL CMIDIOutput::ReadProperties(char *data, int length, bool isInner)
{
  if(length == sizeof(SMIDIOutputProperties))
  {
    SMIDIOutputProperties *properties;

    properties = (SMIDIOutputProperties*)data;
    OpenDevice(properties->Device);
    SetChannel(properties->Channel);
  }
}

void DARKCALL CMIDIOutput::WriteProperties(char **data, int *length, bool *isInner)
{
  SMIDIOutputProperties *properties;
  
  properties = new SMIDIOutputProperties;
  *data = (char*)properties;
  *length = sizeof(SMIDIOutputProperties);
  if(Device)
    properties->Device = Device->ID;
  else
    properties->Device = -1;
  properties->Channel = Channel;
  *isInner = false;
}
