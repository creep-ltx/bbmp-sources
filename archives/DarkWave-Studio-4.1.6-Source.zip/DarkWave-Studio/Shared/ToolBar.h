/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef TOOLBAR_H
#define TOOLBAR_H

#include "Control.h"
#include "BackBuffer.h"
#include "ToolBarButton.h"
#include "ToolTip.h"

class CToolBar : public CControl
{
public:
                  CToolBar(CControl *parent, int x, int y, int width, int height);
  virtual        ~CToolBar();
  void            AddControl(CControl *control, char *toolTip);
  void            AddControl(CControl *control, char *toolTip, HWND hwndTool);
  void            AddControl(CControl *control, char *toolTip, HWND hwndTool, int offsetY);
  virtual void    DrawControl();
  virtual void    OnToolBarButtonPress(CToolBarButton *button);
  CToolBarButton *AddButton(int iconID, int id, int iconWidth, int iconHeight, char *toolTip, bool toggle);
  virtual void    OnComboSelect(CDropList *comboBox);
  virtual void    OnUpDownChange(CUpDown *upDown);
  virtual void    OnResize(int newWidth, int newHeight);
  
private:
  CControl   **Controls, *Parent;
  int          ControlCount;
  CToolTip    *ToolTip;
};

#endif