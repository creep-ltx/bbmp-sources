/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Host.h"
#include "MachineContainer.h"
#include "Core.h"
#include "Util.h"

#define DEFAULT_BPM 140.0
#define DEFAULT_TPB 16.0

CDarkHost::CDarkHost(int blockSamples, int sampleRate, int cpuFeatures)
{
  CPUFeatures = cpuFeatures;
  BlockSamples = blockSamples;
  SampleRate = sampleRate;
  InitFrequencyTable();
  SamplePosition = 0;
  BPM = DEFAULT_BPM;
  TPB = DEFAULT_TPB;
  BankServer = new CHostBankServer();
}

CDarkHost::~CDarkHost()
{
  delete BankServer;
}

void CDarkHost::SetBPM(double value)
{
  BPM = value;
}

void CDarkHost::SetTPB(double value)
{
  TPB = value;
}

int CDarkHost::GetSampleRate()
{
  return SampleRate;
}

int CDarkHost::GetBlockSamples()
{
  return BlockSamples;
}

int CDarkHost::GetSamplesPerTick()
{
  return (int)((60.0 / (GetBPM() * GetTPB())) * (double)SampleRate);
}

void CDarkHost::InitFrequencyTable()
{
  int       i;
  const int numFrequencies = 128;
  double    k = 1.059463094359;	// 12th root of 2
  double    a = 6.875;	          // a

  a *= k;	// b
  a *= k;	// bb
  a *= k;	// c, frequency of midi note 0

  for(i = 0; i < MAX_NOTE; i++)	// 128 midi notes
  {
    NoteTable[i] = a;
    a *= k;
  }
}

EError CDarkHost::GetNoteFrequency(unsigned int note, double *frequency)
{
  if(note > MAX_NOTE)
  {
    *frequency = 0.0;
    return errorInvalidParameter;
  }
  else
  {
    *frequency = NoteTable[note];
    return errorOK;
  }
}

void CDarkHost::SetPropertyAutomated(CMachine *machine, int index, double value)
{
  if(machine->HostData != 0)
    ((CMachineContainer*)(machine->HostData))->SetPropertyAutomated(index, value);
  else
    machine->SetProperty(index, value);
}

void CDarkHost::UpdateSamplePosition(int samples)
{
  SamplePosition += samples;
}

void CDarkHost::ResetSamplePosition(int samples)
{
  SamplePosition = samples;
}

int CDarkHost::GetSamplePosition()
{
  return SamplePosition;
}

double CDarkHost::GetBPM()
{
  return BPM;
}

double CDarkHost::GetTPB()
{
  return TPB;
}

void CDarkHost::SetSampleRateAndBlockSamples(int sampleRate, int blockSamples)
{
  SampleRate = sampleRate;
  BlockSamples = blockSamples;
} 

EError CDarkHost::RegisterMachineInfo(CMachineInfo *machineInfo)
{
  Core->MachineLoader->AddEntry(machineInfo);
  return errorOK;
}

bool CDarkHost::Supports(ESupports code)
{
  switch(code)
  {
    case supportsBankServer:
      return true;
    default:
      return false;
  }
}

EError CDarkHost::GetBankServer(CBankServer **bankServer)
{
  *bankServer = BankServer;
  if(BankServer == 0)
    return errorFailed;
  else
    return errorOK;
}

int CDarkHost::GetCPUFeatures()
{
  return CPUFeatures;
}