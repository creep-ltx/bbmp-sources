/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ListBox.h"
#include "Util.h"
#include <commctrl.h>

// CListBoxItem

CListBoxItem::CListBoxItem(char *text, int itemData)
{
  Text = 0;
  SetText(text);
  ItemData = itemData;
}

CListBoxItem::~CListBoxItem()
{
  delete Text;
}

void CListBoxItem::SetText(char *text)
{
  if(Text != 0)
    delete Text;
  Text = CopyString(text, &TextLength);
}

// CListBox

CListBox::CListBox(CControl *parent, CFont *font, int x, int y, int width, int height, int itemHeight)
: CControl(parent, "ListContainer", x, y, width, height, true)
{
  DrawTextFlags = 0;
  Header = 0;
  Items = new CArray<CListBoxItem*>();
  ItemHeight = itemHeight;
  Selection = -1;
  Font = font;
  SubInit = true;
  SetBorder(bs3DSunken);
  DrawControl();
}

CListBox::~CListBox()
{
  Clear();
  if(Header)
    delete Header;
  delete Items;
}

void CListBox::SetHeader(char *text)
{
  if(Header)
    delete Header;
  Header = CopyString(text);
  Update();
}

void CListBox::DrawControl()
{
  HDC     hDC;
  int     i, y;
  HGDIOBJ oldFont;

  hDC = BackDC;
  
  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)TextAreaBack)->FillRect(hDC, 0, 0, Width, Height);
  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaText));
  SetBkMode(hDC, TRANSPARENT);
  oldFont = SelectObject(hDC, Font->Handle);

  y = 0;
  
  if(Header)
  {
    DrawHeader(hDC);
    y += ItemHeight;
  }

  for(i = 0; i < Items->Count; i++)
  {
    DrawItem(hDC, i, y);
    y += ItemHeight;
  }

  SelectObject(hDC, oldFont);
  ColorManager->Release();
}

void CListBox::DrawItem(HDC hDC, int index, int y)
{
  RECT          r;
  CListBoxItem *item;
  bool          selected;
  COLORREF      oldTextColor;

  selected = index == Selection;

  item = Items->Items[index];

  r.left   = 0;
  r.right  = Width - 1;
  r.top    = y;
  r.bottom = y + ItemHeight - 1;

  InflateRect(&r, -4, -1);

  if(selected)
  {
    oldTextColor = SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaSelText));
    ColorManager->GetBrush((ColorManagerColor)TextAreaSelBack)->FillRect(hDC, 0, y, Width, ItemHeight);
  }

  DrawTextA(hDC, item->Text, item->TextLength, &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER | DrawTextFlags); 
  
  if(selected)
  {
    SetTextColor(hDC, oldTextColor);
  }
}

void CListBox::SetDrawTextFlags(int flags)
{
  DrawTextFlags = flags;
  Update();
}

void CListBox::DrawHeader(HDC hDC)
{
  RECT          r;
  COLORREF      oldTextColor;

  r.left   = 0;
  r.right  = Width - 1;
  r.top    = 0;
  r.bottom = ItemHeight - 1;

  InflateRect(&r, -4, -1);

  ColorManager->GetBrush((ColorManagerColor)HighlightBack)->FillRect(hDC, 0, 0, Width, ItemHeight);
  oldTextColor = SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)HighlightText));  
  DrawTextA(hDC, Header, (int)strlen(Header), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER); 
  SetTextColor(hDC, oldTextColor);
}

int CListBox::AddItem(char *text)
{
  return AddItem(text, 0);
}

int CListBox::AddItem(char *text, int itemData)
{
  CListBoxItem *item;
  int           index;

  item = new CListBoxItem(text, itemData);
  index = Items->AddItem(item);
  Update();
  return index;
}

int CListBox::GetItemData(int index)
{
  if(index >= 0 && index < Items->Count)
    return Items->Items[index]->ItemData;
  else
    throw "GetItemData: Invalid Index";
}

void CListBox::Clear()
{
  int i;

  for(i = 0; i < Items->Count; i++)
    delete Items->Items[i];
  Items->Clear();
  Update();
}

void CListBox::RemoveItem(int index)
{
  if(index >= 0 && index < Items->Count)
  {
    delete Items->Items[index];
    Items->RemoveItem(index);
    Update();
  }
}

int CListBox::InItem(int x, int y)
{
  int item;

  if(x < 0 || x >= Width)
    return -1;
  if(y < 0 || y >= Height)
    return -1;
  
  if(Header)
    y -= ItemHeight;

  item = y / ItemHeight;
  if(item < 0 || item >= Items->Count)
    return -1;
  else
    return item;
}

void CListBox::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
  if(Selection >= 0 && Selection < Items->Count)
    Parent->OnListDblClick(this);
}

void CListBox::OnLeftButtonDown(int x, int y)
{
  int newSelection;

  newSelection = InItem(x, y);
  if(newSelection != Selection)
  {
    Selection = newSelection;
    Update();
    Parent->OnListSelChange(this);
  }
}

int CListBox::GetSelection()
{
  return Selection;
}