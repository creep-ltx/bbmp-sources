/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <math.h>
#include "SequenceView.h"
#include "Core.h"
#include "Util.h"
#include "audioeffect.h"

#define SCROLLBAR_SIZE 16

#define ROW_HEIGHT   16
#define TITLE_WIDTH  196
#define CELL_WIDTH   16

CSequenceView::CSequenceView(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "SequenceView", x, y, width, height, true)
{
  BackColor    = (ColorManagerColor)WindowWorkspace;
  Rows         = 0;
  Cols         = 0;
  Sequence     = 0;
  CurrentTrack = -1;
  State        = SEQUENCEVIEW_STATE_NONE;

  ScrollBarV = new CScrollBar(this, SCROLLBAR_VERTICAL,   Width - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, Height, 0, 0);
  ScrollBarH = new CScrollBar(this, SCROLLBAR_HORIZONTAL, 0, Height - SCROLLBAR_SIZE, Width, SCROLLBAR_SIZE, 0, 0);
  ScrollBarV->SetLineSize(ROW_HEIGHT);
  ScrollBarH->SetLineSize(CELL_WIDTH);

  TrackFont = new CFont(BackDC, "Verdana", 9.0f, true);

  SubInit = true;
  SizeControl();
  ScrollVertical(0);
  ScrollHorizontal(0);
  DrawControl();
}

CSequenceView::~CSequenceView()
{
  delete ScrollBarV;
  delete ScrollBarH;
}

void CSequenceView::SizeControl()
{
  if(Sequence)
  {
    Rows = Sequence->Tracks->Count;
    Cols = Sequence->Length;
  }
  else
  {
    Rows = 0;
    Cols = 0;
  }

  ScrollBarV->SetMaxPos((Rows * ROW_HEIGHT) - Height);
  ScrollBarV->SetPageSize(Height - ROW_HEIGHT);
  MaxTopRow = min(Rows - 1, max(0, Rows - (Height / ROW_HEIGHT)));
  if(MaxTopRow > 0)
    ScrollBarV->Show();
  else
    ScrollBarV->Hide();

  ScrollBarH->SetMaxPos(max(0, (Cols * CELL_WIDTH) - (Width - TITLE_WIDTH - SCROLLBAR_SIZE)));
  ScrollBarH->SetPageSize((Width - TITLE_WIDTH - SCROLLBAR_SIZE) - CELL_WIDTH);
  MaxLeftCol = min(max(0, Cols - 1), max(0, Cols - ((Width - TITLE_WIDTH - SCROLLBAR_SIZE) / CELL_WIDTH)));
  if(MaxLeftCol > 0)
    ScrollBarH->Show();
  else
    ScrollBarH->Hide();

  ScrollHorizontal(OffsetX);
  ScrollVertical(OffsetY);
}

void CSequenceView::ScrollVertical(int offsetY)
{
  OffsetY   = offsetY;
  TopRow    = min(MaxTopRow, offsetY / ROW_HEIGHT);
  TopRowY   = (TopRow * ROW_HEIGHT) - offsetY;
  BottomRow = min(Rows - 1, TopRow + (Height / ROW_HEIGHT) + 1);
}

void CSequenceView::ScrollHorizontal(int offsetX)
{
  OffsetX   = offsetX;
  LeftCol   = min(MaxLeftCol, offsetX / CELL_WIDTH);
  LeftColX  = TITLE_WIDTH + (LeftCol * CELL_WIDTH) - offsetX;
  RightCol  = min(Cols - 1, LeftCol + ((Width - TITLE_WIDTH - SCROLLBAR_SIZE) / CELL_WIDTH) + 1);
}

void CSequenceView::DrawControl()
{
  HDC hDC;
  
  Lock();
  
  hDC = CControl::GetBackBuffer()->DC;
  
  SetBkMode(hDC, TRANSPARENT);
  
  ColorManager->Lock();
  ColorManager->GetBrush(BackColor)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();
  if(Sequence != 0)
  {
    if(Sequence->Tracks->Count > 0)
    {
      DrawGrid(hDC);
      DrawEvents(hDC);
      DrawTitles(hDC);
    }
  }
  
  GdiFlush();
  
  Release();
}

void CSequenceView::OnPaint()
{
  Lock();
  GetBackBuffer()->Draw();
  DrawPlayBar(PlayBarPos, false);
  Release();
}

void CSequenceView::DrawTitles(HDC hDC)
{
  int     row;
  int     y;
  HGDIOBJ oldFont;

  oldFont = SelectObject(hDC, TrackFont->Handle);

  y = TopRowY;
  for(row = TopRow; row <= BottomRow; row++)
  {
    DrawTitle(hDC, 0, y, row);
    y += ROW_HEIGHT;
  }

  SelectObject(hDC, oldFont);
}

void CSequenceView::DrawTitle(HDC hDC, int x, int y, int track)
{
  CBrush *brush;
  RECT    r;
  char    label[1024];
  
  ColorManager->Lock();

  if(CurrentTrack == track)
  {
    DrawBorder(hDC, bs3DRaised, x, y, TITLE_WIDTH, ROW_HEIGHT);
    brush = ColorManager->GetBrush((ColorManagerColor)ControlBack);
    SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlText));
  }
  else
  {
    DrawBorder(hDC, bs3DRaised, x, y, TITLE_WIDTH, ROW_HEIGHT);
    brush = ColorManager->GetBrush((ColorManagerColor)ControlBackDisabled);
    SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlTextDisabled));
  }

  brush->FillRect(hDC, x + 1, y + 1, TITLE_WIDTH - 2, ROW_HEIGHT - 2);
  
  ColorManager->Release();

  r.left   = x + 2;
  r.right  = x + TITLE_WIDTH - 4;
  r.top    = y + 1;
  r.bottom = y + ROW_HEIGHT - 2;

  TrackLabel(track, label);
  
  DrawText(hDC, label, (int)strlen(label), &r, DT_SINGLELINE | DT_VCENTER);
}

void CSequenceView::TrackLabel(int track, char *label)
{
  CSequenceTrack *strack;

  strack = Sequence->Tracks->Items[track];
  strcpy(label, strack->Port->Container->Name);
  strcat(label, ".");
  strcat(label, strack->Port->Port->Name);
}

void CSequenceView::SetSequence(CSequence *sequence)
{  
  Sequence = sequence;
}

void CSequenceView::OnLeftButtonDown(int x, int y)
{
  int track;

  if((x >= 0) && (x < TITLE_WIDTH))
  {
    track = TrackAt(y);
    if(track != -1)
    {
      SetTrack(TrackAt(y));
      Update();
    }
  }
  else
  {
    if(State == SEQUENCEVIEW_STATE_HIGHLIGHT)
    {
      State = SEQUENCEVIEW_STATE_DRAG;
      DragX = x;
    }
    else
    {
      AddEvent(x, y);
      OnMouseMove(x, y);
    }
  }
}

void CSequenceView::OnLeftButtonUp(int x, int y)
{
  if(State == SEQUENCEVIEW_STATE_DRAG)
    State = SEQUENCEVIEW_STATE_HIGHLIGHT;
}

void CSequenceView::OnRightButtonDown(int x, int y)
{
  RemoveEvent(x, y);
  State = SEQUENCEVIEW_STATE_NONE;
  SetCursor(LoadCursor(NULL, IDC_ARROW));
  ReleaseCapture();
}

void CSequenceView::OnMouseMove(int x, int y)
{
  CSequenceEvent *ev;

  if(State == SEQUENCEVIEW_STATE_HIGHLIGHT)
  {
    ev = EventAt(x, y);
    if(DragEvent != ev)
    {
      DragEvent = ev;
      if(DragEvent)
      {
        DragStart = ev->Start;
        DragTrack = Sequence->Tracks->Items[TrackAt(y)];
        SetCursor(LoadCursor(NULL, IDC_SIZEWE));
        SetCapture(Handle);
      }
      else
      {
        State = SEQUENCEVIEW_STATE_NONE;
        SetCursor(LoadCursor(NULL, IDC_ARROW));
        ReleaseCapture();
      }
      Update();
    }
  }
  if(State == SEQUENCEVIEW_STATE_NONE)
  {
    ev = EventAt(x, y);
    if(ev)
    {
      DragEvent = ev;
      State = SEQUENCEVIEW_STATE_HIGHLIGHT;
      DragStart = ev->Start;
      DragTrack = Sequence->Tracks->Items[TrackAt(y)];
      SetCursor(LoadCursor(NULL, IDC_SIZEWE));
      SetCapture(Handle);
      Update();
    }
  }
  if(State == SEQUENCEVIEW_STATE_DRAG)
  {
    int newPos;

    newPos = DragStart + ((x - DragX) / CELL_WIDTH);
    if(newPos != DragEvent->Start)
    {
      if(EventFits(newPos, DragEvent->Pattern->Length, DragTrack, DragEvent))
      {
        DragEvent->Start = newPos;
        Update();
      }
    }
  }
}

void CSequenceView::DrawEvent(HDC hDC, int y, CSequenceEvent *ev)
{
  int  x, width, height;
  RECT r;
  char label[1024];
  ColorManagerColor color;

  x      = LeftColX + ((ev->Start - LeftCol) * CELL_WIDTH);

  width  = ev->Pattern->Length * CELL_WIDTH;
  height = ROW_HEIGHT - 1;

  if((State != SEQUENCEVIEW_STATE_NONE) && (DragEvent == ev))
    color = (ColorManagerColor)NoteBackHighlight;
  else
    color = (ColorManagerColor)NoteBack;

  ColorManager->Lock();

  ColorManager->GetBrush(color)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);

  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)NoteText));
  
  r.left   = x + 2;
  r.right  = x + width - 2;
  r.top    = y + 1;
  r.bottom = y + ROW_HEIGHT - 2;
  
  DrawBorder(hDC, bs3DRaised, x, y, width, height, ColorManager->GetPen((ColorManagerColor)NoteLight), ColorManager->GetPen((ColorManagerColor)NoteShadow));

  ColorManager->Release();

  strcpy(label, ev->Pattern->Name);
  
  DrawText(hDC, label, (int)strlen(label), &r, DT_SINGLELINE | DT_VCENTER);

}

void CSequenceView::DrawEvents(HDC hDC)
{
  int y, i, ntrack;
  CSequenceTrack *track;
  CSequenceEvent *ev;
  HGDIOBJ oldFont;

  y = TopRowY;

  if(!Sequence)
    return;

  oldFont = SelectObject(hDC, TrackFont->Handle);

  for(ntrack = TopRow; ntrack <= BottomRow; ntrack++)
  {
    track = GetTrack(ntrack);
    for(i = 0; i < track->Events->Count; i++)
    {
      ev = track->Events->Items[i];
      if(((ev->Start + ev->Pattern->Length) >= LeftCol) && (ev->Start <= RightCol))
      {
        DrawEvent(hDC, y, ev);
      }
    }

    y += ROW_HEIGHT;
  }

  SelectObject(hDC, oldFont);
}


void CSequenceView::DrawGrid(HDC hDC)
{
  int     x, y;
  int     row, col;
  HGDIOBJ oldPen, oldPen2;
  CBrush *brush;

  ColorManager->Lock();

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)GridLine)->Handle);

  x = LeftColX;
  for(col = LeftCol; col <= RightCol; col++)
  {
    y = TopRowY;
    if(col % 8 < 4)
      brush = ColorManager->GetBrush((ColorManagerColor)GridCell);
    else
      brush = ColorManager->GetBrush((ColorManagerColor)GridCellAlt);

    for(row = TopRow; row <= BottomRow; row++)
    {
      brush->FillRect(hDC, x, y, CELL_WIDTH - 1, ROW_HEIGHT - 1);
      MoveToEx(hDC, x, y + ROW_HEIGHT - 1, NULL);
      LineTo(hDC, x + CELL_WIDTH - 1, y + ROW_HEIGHT - 1);
      LineTo(hDC, x + CELL_WIDTH - 1, y - 1);
      oldPen2 = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)GridLineInner)->Handle);
      MoveToEx(hDC, x + CELL_WIDTH, y, NULL);
      LineTo(hDC, x + CELL_WIDTH, y + ROW_HEIGHT - 1);
      SelectObject(hDC, oldPen2);
      y += ROW_HEIGHT;
    }
    x += CELL_WIDTH;
  }

  SelectObject(hDC, oldPen);

  ColorManager->Release();
}

int CSequenceView::PlayBarX(double playBarPos)
{
  int x;

  if(playBarPos >= 0.0)
  {
    if(playBarPos >= (LeftCol * 4) && playBarPos <= (RightCol + 1) * 4)
    {
      x = LeftColX + (int)(((playBarPos * 0.25f) - LeftCol) * CELL_WIDTH);
      if(x >= TITLE_WIDTH)
        return x;
    }
  }
  return -1;
}

void CSequenceView::DrawPlayBar(double pos, bool clear)
{
  RECT r;

  r.left = PlayBarX(PlayBarPos);
  if(r.left != -1)
  {
    r.top    = 0;
    r.right  = r.left + 2;
    r.bottom = Height - 1;
    if(clear)
      GetBackBuffer()->Draw(r.left, r.top, r.right - r.left + 1, r.bottom - r.top + 1);
    else
      InvertRect(DC, &r);
  }
}

void CSequenceView::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
  {
    ScrollBarV->Move(newWidth  - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, newHeight);
    ScrollBarH->Move(0, newHeight - SCROLLBAR_SIZE, newWidth, SCROLLBAR_SIZE); 
    SizeControl();
    ScrollVertical(OffsetY);
    ScrollHorizontal(OffsetX);
    Update();
  }
}

void CSequenceView::OnScrollY(int newPos)
{
  ScrollVertical(newPos);
  Update();
}

void CSequenceView::OnScrollX(int newPos)
{
  ScrollHorizontal(newPos);
  Update();
}

void CSequenceView::SetTrack(int track)
{
  CurrentTrack = track;
  Core->MainWindow->SequenceEditor->UpdatePatternCombo(track);    
}

int CSequenceView::TrackAt(int y)
{
  int row, track;
  
  row = TopRow + ((y - TopRowY) / ROW_HEIGHT);
  if((row >= 0) && (row < Rows))
  {
    track = row; 
    return track;
  }
  else
    return -1;
}

int CSequenceView::PosAt(int x)
{
  int pos;

  if(x < LeftColX)
    return -1;
  pos = LeftCol + ((x - LeftColX) / CELL_WIDTH);
  if((pos >= 0) && (pos < Cols))
    return pos;
  else
    return -1;
}

bool CSequenceView::EventFits(int start, int length, int ntrack)
{
  CSequenceTrack *track;
  int i, spl;
  CSequenceEvent *ev;

  spl = start + length;

  track = Sequence->Tracks->Items[ntrack];

  if((start >= 0) && (spl <= Sequence->Length))
  {
    for(i = 0; i < track->Events->Count; i++)
    {
      ev = track->Events->Items[i];
      if(ev->Start < start)
      {
        if(ev->Start + ev->Pattern->Length > start)
          return false;
      }
      else
      {
        if(ev->Start < spl)
          return false;
      }
    }
    return true;
  }
  else
    return false;
}

bool CSequenceView::EventFits(int start, int length, CSequenceTrack *track, CSequenceEvent *ignore)
{
  int i, spl;
  CSequenceEvent *ev;

  spl = start + length;

  if((start >= 0) && (spl <= Sequence->Length))
  {
    for(i = 0; i < track->Events->Count; i++)
    {
      ev = track->Events->Items[i];
      if(ev != ignore)
      {
        if(ev->Start < start)
        {
          if(ev->Start + ev->Pattern->Length > start)
            return false;
        }
        else
        {
          if(ev->Start < spl)
            return false;
        }
      }
    }
    return true;
  }
  else
    return false;
}

CSequenceTrack* CSequenceView::GetTrack(int ntrack)
{
  if(Sequence == 0)
    return 0;
  if((ntrack >= 0) && (ntrack < Sequence->Tracks->Count))
  {
    return Sequence->Tracks->Items[ntrack];
  }
  else
    return 0;
}

int CSequenceView::GetTrack()
{
  return CurrentTrack;
}


void CSequenceView::AddEvent(int x, int y)
{
  int ntrack, pos;
  CPattern *pattern;
  CSequenceTrack *track;

  ntrack = TrackAt(y);
  pos = PosAt(x);

  if(ntrack != -1 && pos != -1 && (ntrack == CurrentTrack))
  {
    if((ntrack >= 0) && (ntrack < Sequence->Tracks->Count))
    {
      track = GetTrack(ntrack);
      pattern = track->DefaultPattern;
      if(pattern)
      {
        if(EventFits(pos, pattern->Length, ntrack))
        {
          track->AddEvent(pattern, pos);
          Update();
        }
      }
    }
  }
}

CSequenceEvent* CSequenceView::EventAt(int x, int y)
{
  int i, ntrack, pos;
  CSequenceTrack *track;
  CSequenceEvent *ev;

  ntrack = TrackAt(y);
  pos = PosAt(x);

  if(ntrack != -1 && pos != -1)
  {
    if((ntrack >= 0) && (ntrack < Sequence->Tracks->Count))
    {
      track = GetTrack(ntrack);
      
      for(i = 0; i < track->Events->Count; i++)
      {
        ev = track->Events->Items[i];
        if((ev->Start <= pos) && ((ev->Start + ev->Pattern->Length) > pos))
        {
          return ev;
        }
      }
    }
  }

  return 0;
}

void CSequenceView::RemoveEvent(int x, int y)
{
  CSequenceEvent *ev;

  ev = EventAt(x, y);
  if(ev)
  {
    Sequence->Tracks->Items[TrackAt(y)]->RemoveEvent(ev);
    Update();
  }
}

void CSequenceView::UpdatePlayBar(double newPos)
{
  int oldX, newX;
  
  oldX = PlayBarX(PlayBarPos);
  newX = PlayBarX(newPos);
  
  if(oldX != newX)
  {
    PlayBarPos = newPos;
    OnPaint();
  }
}

void CSequenceView::RemoveTrack(int track)
{
  if(CurrentTrack == track)
    CurrentTrack = 0;
  SizeControl();
}