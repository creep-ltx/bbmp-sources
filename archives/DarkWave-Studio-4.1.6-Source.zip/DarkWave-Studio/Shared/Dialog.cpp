/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Dialog.h"

CDialog::CDialog(CControl *parent, char *name, int width, int height, CColorManager *colorManager, bool caption, bool backBuffer, bool sizeBox)
: CWindow(colorManager)
{
  int  x, y, style;
  RECT r;
  
  Parent = parent;
 
  GetWindowRect(GetDesktopWindow(), &r);
  X = x = r.left + (((r.right  - r.left) - width)  >> 1);
  Y = y = r.top  + (((r.bottom - r.top)  - height) >> 1);

  style = WS_CLIPCHILDREN | WS_POPUP | WS_CLIPSIBLINGS;
  if(caption)
    style |= WS_SYSMENU | WS_MINIMIZEBOX | WS_CAPTION | (sizeBox ? WS_SIZEBOX : 0);

  Init(name, x, y, width, height, style, caption ? WS_EX_DLGMODALFRAME : 0, true); 
  if(backBuffer)
    MakeBackBuffer();
}

CDialog::~CDialog()
{
}

void CDialog::Show(int showState)
{
  if(showState == SW_SHOW)
    if(Parent)
      Parent->Disable();

  if(showState == SW_HIDE)
    if(Parent)
      Parent->Enable();

  ShowWindow(Handle, showState);
}

void CDialog::Show()
{
  Show(SW_SHOW);
}