/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "RenameDialog.h"
#include "Font.h"
#include "Button.h"

#define RENAME_DIALOG_WIDTH  320
#define RENAME_DIALOG_HEIGHT 80

#define SPACING  8
#define BUTTON_W 64
#define BUTTON_H 24
#define OK_X     (RENAME_DIALOG_WIDTH - (SPACING + BUTTON_W))
#define OK_Y     (RENAME_DIALOG_HEIGHT - (SPACING + BUTTON_H))
#define OK_W     BUTTON_W
#define OK_H     BUTTON_H
#define CANCEL_X (OK_X - (SPACING + BUTTON_W))
#define CANCEL_Y OK_Y
#define CANCEL_W BUTTON_W
#define CANCEL_H BUTTON_H
#define LABEL_W  40
#define LABEL_H  18
#define LABEL_X  SPACING
#define LABEL_Y  (SPACING + 2)
#define EDIT_X   (LABEL_X + LABEL_W + SPACING)
#define EDIT_Y   SPACING
#define EDIT_W   (RENAME_DIALOG_WIDTH - ((3 * SPACING) + LABEL_W))
#define EDIT_H   18

CRenameDialog::CRenameDialog(CControl *parent, char *caption, char *label)
: CDialog(parent, caption, RENAME_DIALOG_WIDTH, RENAME_DIALOG_HEIGHT, parent->ColorManager, true, false, false)
{
  SetFont(new CFont(DC, "Verdana", 10.0f, true));
  Label   = new CLabel(this, label, LABEL_X, LABEL_Y, LABEL_W, LABEL_H, DT_VCENTER);
  Label->Show();
  EditBox = new CEditBox(this, "EditBox", EDIT_X, EDIT_Y, EDIT_W, EDIT_H, false);
  EditBox->Show();
  CancelButton = new CButton(this, Font, "Cancel", CANCEL_X, CANCEL_Y, CANCEL_W, CANCEL_H);
  CancelButton->Show();
  OKButton = new CButton(this, Font, "OK", OK_X, OK_Y, OK_W, OK_H);
  OKButton->Show();
}

CRenameDialog::~CRenameDialog()
{
}

void CRenameDialog::SetEditText(char *text)
{
  EditBox->SetText(text);
}

void CRenameDialog::GetEditText(char *text)
{
  char *str;

  str = EditBox->GetText();
  strcpy(text, str);
  delete str;
}

void CRenameDialog::OnButtonPress(CButton *button)
{
  CControl::Hide();
  if(button == OKButton)
  {
    Parent->OnRenameDialogSuccess();
  }
}

