/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <stdarg.h>
#include "SoundFontLoader.h"
#include "Util.h"

#define CHUNKTYPE_SOUNDFONT_BANK 'kbfs'

#define RIFF_CONTEXT_INFO        1
#define RIFF_CONTEXT_SDTA        2
#define RIFF_CONTEXT_PDTA        3

#define CHUNKTYPE_INFO           'OFNI'
#define CHUNKTYPE_IFIL           'lifi'
#define CHUNKTYPE_ISNG           'gnsi'
#define CHUNKTYPE_INAM           'MANI'
#define CHUNKTYPE_IROM           'mori'
#define CHUNKTYPE_IVER           'revi'
#define CHUNKTYPE_ICRD           'DRCI'
#define CHUNKTYPE_IENG           'GNEI'
#define CHUNKTYPE_IPRD           'DRPI'
#define CHUNKTYPE_ICOP           'POCI'
#define CHUNKTYPE_ICMT           'TMCI'
#define CHUNKTYPE_ISFT           'TFSI'

#define CHUNKTYPE_SDTA           'atds'

#define CHUNKTYPE_PDTA           'atdp'
#define CHUNKTYPE_PHDR           'rdhp'

CSoundFontLoader::CSoundFontLoader(CBankServer *bankServer)
{
  BankServer = bankServer;
  Presets    = 0;
}

CSoundFontLoader::~CSoundFontLoader()
{
}

EError CSoundFontLoader::Load(char *fileName)
{
  EError error;

  InitData();

  error = CRIFFLoader::Load(fileName, CHUNKTYPE_SOUNDFONT_BANK);
  if(error != errorOK)
    return error;

  error = Validate();
  if(error != errorOK)
  {
    ReleaseData();
    return error;
  }

  error = Generate();
  ReleaseData();
  return error;
}

void CSoundFontLoader::InitData()
{
  memset(&Info, 0, sizeof(SSoundFontInfo));
  BankIndex = -1;
}

EError CSoundFontLoader::ParsePresetData(SRIFFChunk *chunk, char *data)
{
  int recordLength, records;

  if(chunk->Type == CHUNKTYPE_PHDR)
  {
    recordLength = sizeof(sfPresetHeader);
    records = chunk->Length / recordLength;
    if(records < 2)
      return errorBadFile;
    if((records * recordLength) != chunk->Length)
      return errorBadFile;
    Presets = (sfPresetHeader*)data;
    PresetCount = records - 1;
    return errorOK;
  }
  return errorOK;
}

EError CSoundFontLoader::ParseInfo(SRIFFChunk *chunk, char *data)
{
  if(chunk->Type == CHUNKTYPE_IFIL)
  {
    sfVersionTag *tag;

    if(chunk->Length != sizeof(sfVersionTag))
      return errorBadFile;
    tag = (sfVersionTag*)data;
    if(tag->wMajor != 2)
      return errorBadFile;
    Info.Version = tag;
    return errorOK;
  }
  if(chunk->Type == CHUNKTYPE_ISNG)
  {
    Info.SoundEngine = CopyChunkString(chunk, data);
    if(Info.SoundEngine != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_INAM)
  {
    Info.Name = CopyChunkString(chunk, data);
    if(Info.Name != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_IROM)
  {
    Info.ROM = CopyChunkString(chunk, data);
    if(Info.ROM != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_IVER)
  {
    sfVersionTag *tag;

    if(chunk->Length != sizeof(sfVersionTag))
      return errorBadFile;
    tag = (sfVersionTag*)data;
    Info.ROMVersion = tag;
    return errorOK;
  }
  if(chunk->Type == CHUNKTYPE_ICRD)
  {
    Info.CreationDate = CopyChunkString(chunk, data);
    if(Info.CreationDate != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_IENG)
  {
    Info.SoundDesigner = CopyChunkString(chunk, data);
    if(Info.SoundDesigner != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_IPRD)
  {
    Info.Product = CopyChunkString(chunk, data);
    if(Info.Product != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_ICOP)
  {
    Info.Copyright = CopyChunkString(chunk, data);
    if(Info.Copyright != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_ICMT)
  {
    Info.Comment = CopyChunkString(chunk, data);
    if(Info.Comment != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  if(chunk->Type == CHUNKTYPE_ISFT)
  {
    Info.Tools = CopyChunkString(chunk, data);
    if(Info.Tools != 0)
      return errorOK;
    else
      return errorBadFile;
  }
  return errorOK;
}

EError CSoundFontLoader::ParseChunk(SRIFFChunk *chunk, char *data, unsigned int level, int context)
{
  SRIFFListChunk *list;
  EError          error;

  if(context == RIFF_CONTEXT_INFO)
    return ParseInfo(chunk, data);

  if(context == RIFF_CONTEXT_PDTA)
    return ParsePresetData(chunk, data);

  if(chunk->Type == CHUNKTYPE_LIST)
  {
    list = (SRIFFListChunk*)chunk;
    if(context == RIFF_CONTEXT_MAIN)
    {
      if(list->ListType == CHUNKTYPE_INFO)
      {
        error = ParseList(list, data, level, RIFF_CONTEXT_INFO);
        Info.Loaded = true;
        return error;
      }
      if(list->ListType == CHUNKTYPE_SDTA)
      {
        error = ParseList(list, data, level, RIFF_CONTEXT_SDTA);
        Info.Loaded = true;
        return error;
      }
      if(list->ListType == CHUNKTYPE_PDTA)
      {
        error = ParseList(list, data, level, RIFF_CONTEXT_PDTA);
        Info.Loaded = true;
        return error;
      }
      return errorBadFile;
    }
  }

  return errorOK;
}

EError CSoundFontLoader::AddBankInfo(char *infoName, char *format, ...)
{
  int     count;
  va_list list;
  char*   string;
  EError  error;

  va_start(list, format);
  count = _vscprintf(format, list);
  string = new char[count + 1];
  vsprintf(string, format, list);
  va_end(list);
  error = BankServer->AddBankInfo(BankIndex, infoName, string, 0);
  delete string;
  return error;
}

EError CSoundFontLoader::Validate()
{
  // Validate Info

  if(!Info.Loaded)
    return errorBadFile;

  if(Info.Name == 0 || Info.SoundEngine == 0 || Info.Version == 0)
    return errorBadFile;

  // Validate Preset Data

  if(Presets == 0)
    return errorBadFile;
  if(PresetCount < 1)
    return errorBadFile;

  return errorOK;
}

EError CSoundFontLoader::GeneratePresets()
{
  int    i, presetIndex;
  char   name[21];
  EError err;

  for(i = 0; i < PresetCount; i++)
  {
    CopyFixedString(20, Presets[i].achPresetName, name);
    err = BankServer->AddPreset(BankIndex, name, &presetIndex);
    if(err != errorOK)
      return err;
  }
  return errorOK;
}

EError CSoundFontLoader::GenerateInfo()
{
  EError error;

  error = AddBankInfo("SoundFont Version", "%i.%i", Info.Version->wMajor, Info.Version->wMinor);
  if(error == errorOK)
    error = AddBankInfo("Sound Engine", "%s", Info.SoundEngine);
  if(error == errorOK && Info.ROM != 0)
    error = AddBankInfo("ROM", "%s", Info.ROM);
  if(error == errorOK && Info.ROMVersion != 0)
    error = AddBankInfo("ROM Version", "%i.%i", Info.ROMVersion->wMajor, Info.ROMVersion->wMinor);
  if(error == errorOK && Info.CreationDate != 0)
    error = AddBankInfo("Creation Date", "%s", Info.CreationDate);
  if(error == errorOK && Info.SoundDesigner != 0)
    error = AddBankInfo("Sound Designer", "%s", Info.SoundDesigner);
  if(error == errorOK && Info.Product != 0)
    error = AddBankInfo("Product", "%s", Info.Product);
  if(error == errorOK && Info.Copyright != 0)
    error = AddBankInfo("Copyright", "%s", Info.Copyright);
  if(error == errorOK && Info.Comment != 0)
    error = AddBankInfo("Comment", "%s", Info.Comment);
  if(error == errorOK && Info.Tools != 0)
    error = AddBankInfo("Tools", "%s", Info.Tools);

  return error;
}

EError CSoundFontLoader::Generate()
{
  EError error;

  BankServer->Lock();
  
  error = BankServer->AddBank(Info.Name, &BankIndex);
  if(error == errorOK)
    error = GenerateInfo();
  if(error != errorOK)
  {
    BankServer->Release();
    return error;
  }
  error = GeneratePresets();
  if(error != errorOK)
  {
    BankServer->Release();
    return error;
  }  

  BankServer->Release();
  return errorOK;
}

void CSoundFontLoader::ReleaseData()
{
  if(Info.Loaded)
  {
    if(Info.Name != 0)
      delete Info.Name;
    if(Info.SoundEngine != 0)
      delete Info.SoundEngine;
  }
  Presets = 0;
  PresetCount = 0;
}

char *CSoundFontLoader::CopyChunkString(SRIFFChunk *chunk, char *data)
{
  int   n, i;
  char *text;

  n = chunk->Length;
  for(i = 0; i < n; i++)
  {
    if(data[i] == 0)
    {
      n = i;
      break;
    }
  }

  text = new char[n + 1];
  if(text == 0)
    return 0;
  for(i = 0; i < n; i++)
    text[i] = data[i];
  text[i] = 0;
  
  return text;
}