#define IDR_Y2KMUTTER                   104
#define IDR_SPATIALVERB_KNOB            107
#define IDR_SPATIALVERB_NODES           108
#define IDR_SPATIALVERB_SLIDER_H        109
#define IDR_SPATIALVERB_SLIDER_V        110
#define IDR_SPATIALVERB_BACKGROUND      118
