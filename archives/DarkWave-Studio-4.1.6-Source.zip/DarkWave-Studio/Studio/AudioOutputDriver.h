/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef AUDIOOUTPUTDRIVER_H
#define AUDIOOUTPUTDRIVER_H

#include "WaveFormats.h"

typedef void AudioOutputWriteCallback(int nChannels, double **channels, int samples);

class CAudioOutputDriver
{
public:
  virtual      ~CAudioOutputDriver();
  virtual void  SetWriteCallback(AudioOutputWriteCallback *funcPtr) = 0;
  virtual int   GetNumChannels() = 0;
  virtual int   GetBlockSamples() = 0;
  virtual int   GetSampleRate() = 0;
  virtual char *GetName() = 0;
  virtual void  Open() = 0;
  virtual void  Close() = 0;
  virtual bool  CanOpen() = 0;
};

#endif