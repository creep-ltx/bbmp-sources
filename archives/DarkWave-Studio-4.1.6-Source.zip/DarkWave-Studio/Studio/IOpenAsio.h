#include "asiosys.h"
#include "asio.h"

// Forward Declarations

typedef interface IOpenASIO IOpenASIO;

interface IOpenASIO : public IUnknown
{

	virtual STDMETHODIMP_(ASIOBool) Init(void *sysHandle) = 0;
	virtual STDMETHODIMP_(void) GetDriverName(char *name) = 0;	
	virtual STDMETHODIMP_(long) GetDriverVersion() = 0;
	virtual STDMETHODIMP_(void) GetErrorMessage(char *string) = 0;	
	virtual STDMETHODIMP_(ASIOError) Start() = 0;
	virtual STDMETHODIMP_(ASIOError) Stop() = 0;
	virtual STDMETHODIMP_(ASIOError) GetChannels(long *numInputChannels, long *numOutputChannels) = 0;
	virtual STDMETHODIMP_(ASIOError) GetLatencies(long *inputLatency, long *outputLatency) = 0;
	virtual STDMETHODIMP_(ASIOError) GetBufferSize(long *minSize, long *maxSize,
		long *preferredSize, long *granularity) = 0;
	virtual STDMETHODIMP_(ASIOError) CanSampleRate(ASIOSampleRate sampleRate) = 0;
	virtual STDMETHODIMP_(ASIOError) GetSampleRate(ASIOSampleRate *sampleRate) = 0;
	virtual STDMETHODIMP_(ASIOError) SetSampleRate(ASIOSampleRate sampleRate) = 0;
	virtual STDMETHODIMP_(ASIOError) GetClockSources(ASIOClockSource *clocks, long *numSources) = 0;
	virtual STDMETHODIMP_(ASIOError) SetClockSource(long reference) = 0;
	virtual STDMETHODIMP_(ASIOError) GetSamplePosition(ASIOSamples *sPos, ASIOTimeStamp *tStamp) = 0;
	virtual STDMETHODIMP_(ASIOError) GetChannelInfo(ASIOChannelInfo *info) = 0;
	virtual STDMETHODIMP_(ASIOError) CreateBuffers(ASIOBufferInfo *bufferInfos, long numChannels,
		long bufferSize, ASIOCallbacks *callbacks) = 0;
	virtual STDMETHODIMP_(ASIOError) DisposeBuffers() = 0;
	virtual STDMETHODIMP_(ASIOError) ControlPanel() = 0;
	virtual STDMETHODIMP_(ASIOError) Future(long selector,void *opt) = 0;
	virtual STDMETHODIMP_(ASIOError) OutputReady() = 0;
};
