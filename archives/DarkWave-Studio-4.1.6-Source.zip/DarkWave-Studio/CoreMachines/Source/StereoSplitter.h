/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef STEREO_SPLITTER_H
#define STEREO_SPLITTER_H

#include "DarkPlug.h"

class CStereoSplitter : public CMachine
{
public:
                         CStereoSplitter(CHost *host);
                        ~CStereoSplitter();
  virtual bool  DARKCALL IsSynth();
  virtual void  DARKCALL SetBlockSamples(int blockSamples);
  virtual void  DARKCALL SetSampleRate(int sampleRate);
  virtual void  DARKCALL Work();
  
  private:
    int BlockSamples;
};

class CStereoSplitterInfo : public CMachineInfo
{
public:
                             CStereoSplitterInfo(CHost *host);
  virtual CMachine* DARKCALL CreateMachine();

private:
  CHost *Host;
};


#endif