/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Menu.h"

CMenu::CMenu(CControl *parent, bool popup)
{
  Parent = parent;

  if(popup)
    Handle = CreatePopupMenu();
  else
    Handle = CreateMenu();
}

CMenu::~CMenu()
{
  DestroyMenu(Handle);
}

HMENU CMenu::GetHandle()
{
  return Handle;
}

void CMenu::Append(int id, char *text, int flags)
{
  AppendMenuA(Handle, MF_ENABLED | MF_STRING | flags, id, text);
}

void CMenu::RemoveItem(int id)
{
  DeleteMenu(Handle, id, 0);
}

void CMenu::AppendSeparator()
{
  AppendMenu(Handle, MF_SEPARATOR, 0, 0);
}

int CMenu::ShowPopup(int x, int y)
{
  return TrackPopupMenu(Handle, TPM_LEFTALIGN | TPM_TOPALIGN | TPM_RETURNCMD | TPM_LEFTBUTTON,
    x, y, 0, Parent->Handle, 0);
}

void CMenu::EnableItem(int id)
{
  EnableMenuItem(Handle, id, MF_BYCOMMAND | MF_ENABLED);
}

void CMenu::DisableItem(int id)
{
  EnableMenuItem(Handle, id, MF_BYCOMMAND | MF_GRAYED);
}
