/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "Distort.h"
#include "Resource.h"
#include "Util.h"

#include <stdio.h>
#include <math.h>

#define PROPERTY_AMP   0
#define PROPERTY_DRIVE 1
#define PROPERTY_WET   2
#define PROPERTY_DRY   3

#define PROPERTY_COUNT 4

const double DistortPropertyDefaults[PROPERTY_COUNT] =
{
  0.0, // Amp
  0.5, // Drive
  1.0, // Wet
  0.0  // Dry
};

const char* DistortPropertyNames[PROPERTY_COUNT] =
{
  "Amp",
  "Drive",
  "Wet",
  "Dry"
};

#define PROPERTY_FORMAT_PERCENT 0

#define PROPERTY_FORMAT_COUNT   1

const int DistortPropertyFormats[PROPERTY_COUNT] =
{
  PROPERTY_FORMAT_PERCENT, // Amp
  PROPERTY_FORMAT_PERCENT, // Drive
  PROPERTY_FORMAT_PERCENT, // Wet
  PROPERTY_FORMAT_PERCENT  // Dry
};

#define KNOB_COUNT   4
#define KNOB_Y       40
#define KNOB_HEIGHT  38

#define OVERDRIVE_DISPLAY_BORDER  4
#define OVERDRIVE_DISPLAY_X       (82 + OVERDRIVE_DISPLAY_BORDER)
#define OVERDRIVE_DISPLAY_Y       (43 + OVERDRIVE_DISPLAY_BORDER)
#define OVERDRIVE_DISPLAY_WIDTH   (96 - (2 * OVERDRIVE_DISPLAY_BORDER))
#define OVERDRIVE_DISPLAY_HEIGHT  (40 - (2 * OVERDRIVE_DISPLAY_BORDER))

const int DistortKnobX[KNOB_COUNT] =
{
  8,
  44,
  188,
  224
};

const int DistortKnobProperties[KNOB_COUNT] =
{
  PROPERTY_AMP,
  PROPERTY_DRIVE,
  PROPERTY_WET,
  PROPERTY_DRY
};

// OverDriveDisplay

COverDriveDisplay::COverDriveDisplay(CDistortGUI *distortGUI, CDistort *distort, int x, int y, int width, int height)
: CLiteControl(distortGUI, x, y, width, height)
{
  DistortGUI = distortGUI;
  Distort = distort;
  NumValues = width - 2;
  Values = new double[NumValues];
  RenderBuffer = new CFrameBuffer(Width, Height, true);
  Update();
}

COverDriveDisplay::~COverDriveDisplay()
{
  delete RenderBuffer;
}

void COverDriveDisplay::Update()
{
  int    i;
  double v, f;
  
  f = 1.0 / (double)(NumValues - 1);
  
  for(i = 0; i < NumValues; i++)
  {
    v = f * (double)i;
    Values[i] = Distort->OverDrive(v);
  }
  
  Render();
}

void COverDriveDisplay::Render()
{
  int x, y, y1, y2, i;
  double v;
  
  const unsigned char alpha = (unsigned char)(0.6 * 0xFF);
  const unsigned char alpha2 = alpha >> 1;
  
  RenderBuffer->Fill(0);
  
  RenderBuffer->DrawRect(0, 0, Width, Height, 0, alpha);

  v = (double)(Height - 3);
  
  for(i = 0; i < NumValues; i++)
  {
    x  = 1 + i;
    y1 = 1 + (int)((1.0 - Values[i]) * v);
    y2 = 1 + (int)v;
    y  = y1;
    
    RenderBuffer->SetPixel(x, y++, 0, alpha);
    while(y <= y2)
      RenderBuffer->SetPixel(x, y++, 0, alpha2);
  }
  
  Parent->Render(X, Y, Width, Height);
}

void COverDriveDisplay::Draw(CFrameBuffer *frameBuffer)
{
  RenderBuffer->Draw(frameBuffer, X, Y, 0, 0, Width, Height);
}

// CDistortGUI

CDistortGUI::CDistortGUI(HWND parent, CColorManager *colorManager, CDistort *machine, SDistortGraphics *graphics)
: CLiteContainer(parent, graphics->Background->GetWidth(), graphics->Background->GetHeight(), graphics->Background)
{
  int i;
  
  Graphics = graphics; 

  Knobs = new CLiteKnob*[KNOB_COUNT];
  for(i = 0; i < KNOB_COUNT; i++)
    Knobs[i] = new CLiteKnob(this, machine, DistortKnobProperties[i], Graphics->Knob, DistortKnobX[i], KNOB_Y, KNOB_HEIGHT);

  Distort = machine;

  OverDriveDisplay = new COverDriveDisplay(this, machine, OVERDRIVE_DISPLAY_X, OVERDRIVE_DISPLAY_Y, OVERDRIVE_DISPLAY_WIDTH, OVERDRIVE_DISPLAY_HEIGHT);
  
  Render();
  Show();
}

CDistortGUI::~CDistortGUI()
{
  int i;

  for(i = 0; i < KNOB_COUNT; i++)
    delete Knobs[i];
  delete Knobs;
}

void CDistortGUI::SetProperty(int index, double value)
{
  int i;

  for(i = 0; i < KNOB_COUNT; i++)
    if(DistortKnobProperties[i] == index)
      Knobs[i]->SetValue(value);
  
  if((index == PROPERTY_DRIVE) || (index == PROPERTY_AMP))
    OverDriveDisplay->Update();
}

// CDistort

CDistort::CDistort(CHost *host, SDistortGraphics *graphics)
: CMachine(host)
{
  int i;
  
  Host     = host;
  Graphics = graphics;
  
  GUI = 0;
  
  PropertyCount = PROPERTY_COUNT;
  Properties = new double[PROPERTY_COUNT];

  for(i = 0; i < PROPERTY_COUNT; i++)
    Properties[i] = DistortPropertyDefaults[i];
  
  AmpFollow   = Properties[PROPERTY_AMP];
  DriveFollow = Properties[PROPERTY_DRIVE];
  WetFollow   = Properties[PROPERTY_WET];
  DryFollow   = Properties[PROPERTY_DRY];
  
  Ports = new CPort*[3];
  Ports[0] = new CPort(host, this, PT_INPUT | PT_CONTROL, "Control In");
  Ports[1] = new CPort(host, this, PT_INPUT | PT_AUDIO | PT_STEREO, "Line In");
  Ports[2] = new CPort(host, this, PT_OUTPUT | PT_AUDIO | PT_STEREO, "Line Out");
  PortCount = 3;
  
  BlockSamples = host->GetBlockSamples();
}

CDistort::~CDistort()
{
  delete Ports[0];
  delete Ports[1];
  delete Ports[2];
  delete Ports;
  if(GUI != 0)
    delete GUI;
  delete Properties;
}

double CDistort::OverDrive(double in)
{
  return OverDrive(in, Properties[PROPERTY_AMP], Properties[PROPERTY_DRIVE]);
}

double CDistort::OverDrive(double in, double amp, double drive)
{
  double out;
  double power;
  
  if(in < -1.0)
    in = -1.0;
  else
    if(in > 1.0)
      in = 1.0;
  
  power = (1.0 + (amp * 4.0)) * pow(1.0 + (drive * 4.0), 1.0 - fabs(in));
  out   = power * in;
  
  if(out < -1.0)
    out = -1.0;
  else
    if(out > 1.0)
      out = 1.0;
  
  return out;
}

bool CDistort::IsSynth()
{
  return false;
}

bool CDistort::GetGUIRect(short *x1, short *y1, short *x2, short *y2)
{
  *x1 = 0;
  *x2 = Graphics->Background->GetWidth();
  *y1 = 0;
  *y2 = Graphics->Background->GetHeight();
  return true;
}

void CDistort::SetSampleRate(int sampleRate)
{
}

void CDistort::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

HWND CDistort::CreateGUI(HWND parent)
{
  if(GUI != 0)
  {
    delete GUI;
	  GUI = 0;
  }
  if(GUI == 0)
  {
    GUI = new CDistortGUI(parent, 0, this, Graphics);
  }
  return GUI->Handle;
}

void CDistort::Work()
{
  SControlMessage message;
  bool            gotMessage;
  int             firstSample, lastSample;

  gotMessage = Ports[0]->ControlBuffer->Read(&message);
  if(!gotMessage) // no messages, just generate signal
    ProcessBlock(0, BlockSamples);
  else // got one or more messages
  {
    if(message.BlockSample > 0) // process data before first block
      ProcessBlock(0, message.BlockSample);

    while(gotMessage) // process message and data until no more messages
    {
      ProcessMessage(&message);
      firstSample = message.BlockSample;
      gotMessage = Ports[0]->ControlBuffer->Read(&message);
      if(gotMessage)
        lastSample = message.BlockSample - 1;
      else
        lastSample = BlockSamples - 1;
      ProcessBlock(firstSample, lastSample - firstSample + 1);
    }
  }
}

void CDistort::ProcessMessage(SControlMessage *message)
{
  if(message->Type == CONTROL_MESSAGE_CONTROL_CHANGE)
  {
    SetProperty(message->ControlChange.Controller, message->ControlChange.Value);
  }
}

void CDistort::ProcessBlock(int start, int samples)
{
  int     i;
  double *pInLeft, *pInRight, *pOutLeft, *pOutRight;
  double  inLeft, inRight, outLeft, outRight;

  pInLeft   = Ports[1]->AudioBuffer->LeftData;
  pInRight  = Ports[1]->AudioBuffer->RightData;
  pOutLeft  = Ports[2]->AudioBuffer->LeftData;
  pOutRight = Ports[2]->AudioBuffer->RightData;

  for(i = start; i < samples; i++)
  {
    inLeft  = *(pInLeft++);
    inRight = *(pInRight++);
    
    AmpFollow   = AdjustVolume(Properties[PROPERTY_AMP],   AmpFollow);
    DriveFollow = AdjustVolume(Properties[PROPERTY_DRIVE], DriveFollow);
    WetFollow   = AdjustVolume(Properties[PROPERTY_WET],   WetFollow);
    DryFollow   = AdjustVolume(Properties[PROPERTY_DRY],   DryFollow);

	  outLeft  = 0.5 * ((DryFollow * inLeft)  + (WetFollow * OverDrive(inLeft, AmpFollow, DriveFollow)));
    outRight = 0.5 * ((DryFollow * inRight) + (WetFollow * OverDrive(inRight, AmpFollow, DriveFollow)));

    *(pOutLeft++)  = outLeft;
    *(pOutRight++) = outRight;
  }
}

double CDistort::GetProperty(int index)
{
  if(index >= 0 && index < PROPERTY_COUNT)
    return Properties[index];
  else
    return 0.0;
}

void CDistort::SetProperty(int index, double value)
{
  if(index >= 0 && index < PROPERTY_COUNT)
  {
    Properties[index] = value;

    if(GUI)
      GUI->SetProperty(index, value);

  }
}

void CDistort::GetPropertyName(int index, char *text)
{
  if(index >= 0 && index < PROPERTY_COUNT)
    strcpy(text, DistortPropertyNames[index]);
  else
    *text = 0;
}

void CDistort::GetPropertyValueDisplay(int index, double value, char *text)
{
  if(index >= 0 && index < PROPERTY_COUNT)
  {
    switch(DistortPropertyFormats[index])
    {
      case PROPERTY_FORMAT_PERCENT:
      default:
        sprintf(text, "%i%%", (int)(value * 100));
        break;
    }
  }
  else
    *text = 0;
}

// CDistortInfo

CDistortInfo::CDistortInfo(CHost* host)
{
  Host     = host;
  Name     = "ES Distort";
  UniqueID = "DarkPlug::ES Distort";
  Loaded   = false;
}

CDistortInfo::~CDistortInfo()
{
  if(Loaded)
  {
    delete Graphics.Background;
    delete Graphics.Knob;
  }
}

CMachine *CDistortInfo::CreateMachine()
{
  if(!Loaded)
  {
    Graphics.Background = new CFrameBuffer(IDR_DISTORT_BACKGROUND);
    Graphics.Knob       = new CFrameBuffer(IDR_DISTORT_KNOB);

    Loaded              = true;
  }
  return new CDistort(Host, &Graphics);
}