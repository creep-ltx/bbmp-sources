/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MACHINECONTAINER_H
#define MACHINECONTAINER_H

#include "DarkPlug.h"
#include "ListNode.h"
#include "Control.h"
#include "Font.h"
#include "BackBuffer.h"
#include "Connector.h"
#include "DefaultGUI.h"
#include "IconButton.h"
#include "MachineLoaderEntry.h"
#include "MenuButton.h"
#include "Mutex.h"
#include "Thread.h"
#include "Semaphore.h"
#include "ToolBar.h"
#include "DropList.h"
#include "Label.h"

#define CONTROL_ICONBUTTON 0
#define CONTROL_DEFAULTGUI 1
#define CONTROL_CUSTOMGUI  2

class CMachineContainer;

class CWorkThread : public CThread
{
public:
               CWorkThread();  
  virtual void Work();
};

class CMachineMenuButton : public CMenuButton
{
public:
               CMachineMenuButton(CMachineContainer *parent, int x, int y);
  virtual void OnMenuItem(int item);

private:
  CMachineContainer *Container;
};

class CMachineContainerIconButton : public CIconButton
{
public:
               CMachineContainerIconButton(CControl *parent, int x, int y, int width, int height, HICON icon, CMachineContainer *container);
  virtual void OnPress();

private:
  CMachineContainer *Container;
};

class CProgramToolBar : public CToolBar
{
public:
  CProgramToolBar(CMachineContainer *parent, int x, int y);
 ~CProgramToolBar();
 virtual void OnComboSelect(CDropList *comboBox);

private:
  CMachineContainer *MachineContainer;
  CLabel            *Label;
  CDropList         *DropList;
};

class CMachineContainer : public CListNode<CMachineContainer>, public CControl
{
public:
               CMachineContainer(char *name, char *uniqueID, int x, int y, int offsetX, int offsetY, CMachine *machine, CMachineInfo *machineInfo, CMachineLoaderEntry *entry, CControl *parent, char *properties, int propertyBytes, bool isInner);
              ~CMachineContainer();
          void DrawControl();
          void Work(bool async);
          void WorkAsync();
          void WaitAsync();
          void InitConnectors();
          void FreeConnectors();
          void PerformLayout();
          void AutoSize();
           int CalculateTitleWidth();
  LRESULT      WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
          void GetGUISize(int *width, int *height);
          void OnResize(int newWidth, int newHeight);
          void SetRegion();
          void SetPropertyAutomated(int index, double value);
          void Randomize();
          void Lock();
          void Release();
          void OnIconPress();
          void SetVisibleControl(int control);
          void OnMenuItem(int item);
          void PrepareToWork();
          void UpdatePorts();
          void ReadProperties(char *data, int length, bool isInner);
          void WriteProperties(char **data, int *length, bool *isInner);
          void WriteConnections(char **data, int *length);
          void ReadConnections(char *data, int length, bool hasVolume, bool volumeIsFloat);
          void Rename(char *text);
          void Mix(int samples, double *in, double *out, double powerRatio);
          
   CMachine          *Machine;
  CMachineInfo       *MachineInfo;
  CConnector        **Connectors;
  int                 ConnectorCount;
  CControl           *ConnectorPanel, *ChildPanel;
  HWND                CustomGUI;
  CDefaultGUI        *DefaultGUI;
  CMachineMenuButton *MenuButton;
  int                 OffsetX, OffsetY;
  char               *Name, *UniqueID;
  int                 VisibleControl;
  CProgramToolBar    *ProgramToolBar;
  bool                WorkDone;

private:
  CFont                        *TitleFont;
  CMachineContainerIconButton  *IconButton;
  CWorkThread                  *WorkThread;
  CSemaphore                   *WorkSemaphore;
};

#endif