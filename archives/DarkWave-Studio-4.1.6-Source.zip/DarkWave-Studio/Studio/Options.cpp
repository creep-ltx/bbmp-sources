/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define _WIN32_IE 0x500

#include <windows.h>
#include "WaveFormats.h"

extern HINSTANCE AppInstance;

#include "Options.h"
#include "Util.h"
#include <stdio.h>

#include <shlobj.h>

#define OPTIONS_FOLDER "DarkWave Studio"
#define OPTIONS_FILE   "DarkWave.opt"

// #define OPTIONS_RESET

COptions::COptions()
{
  OptionsDialog.Width  = 0;
  OptionsDialog.Height = 0;

  Audio.Driver             = -1;
  Audio.NullLatency        =  512;
  Audio.NullFormat         =  WAVE_FORMAT_4S16;
  Audio.WaveDevice         =  0;
  Audio.WaveLatency        =  512;
  Audio.WaveFormat         =  WAVE_FORMAT_4S16;
  Audio.DirectSoundDevice  =  0;
  Audio.DirectSoundLatency =  512;
  Audio.DirectSoundFormat  =  WAVE_FORMAT_4S16;
  Audio.ASIODevice         =  0;
  Audio.ASIOFormat         =  4;
  Audio.DisableASIO        =  false;
  Audio.MasterVolume       =  1.0;

  char fileName[1024];
  char searchPath[1024];
  int i, j, k;
  GetModuleFileName(AppInstance, fileName, 1024);
  for(i = j = 0; fileName[i] != 0; i++)
    if(fileName[i] == '\\')
    {
      k = j;
      j = i;
    }
  fileName[k] = 0; 
  
  sprintf(searchPath, "%s\\%s", fileName, "x86\\VST");
  VSTPaths.AddItem(CopyString(searchPath));
  
  sprintf(searchPath, "%s\\%s", fileName, "x64\\VST");
  VSTPaths.AddItem(CopyString(searchPath));

#ifndef OPTIONS_RESET
  char lpszPath[MAX_PATH];

  if(SHGetSpecialFolderPath(NULL, lpszPath, CSIDL_APPDATA, FALSE))
  {
    strcat(lpszPath, "\\");
    strcat(lpszPath, OPTIONS_FOLDER);
    strcat(lpszPath, "\\");
    strcat(lpszPath, OPTIONS_FILE);

    FILE *f = fopen(lpszPath, "rb");
    if(f)
    {
      if(fread(&Header, sizeof(Header), 1, f) == 1)
      {
        if(Header.Magic == OPTIONS_MAGIC)
        {
          if(Header.Version == 1)
          {
            int i;
            SVSTPathsHeader psh;
            SVSTPathHeader  ph;
            char            *p;

            fread(&Audio, sizeof(Audio), 1, f);
            
            for(i = 0; i < VSTPaths.Count; i++)
              delete VSTPaths.Items[i];
            VSTPaths.Clear();

            fread(&psh, sizeof(psh), 1, f);
            for(i = 0; i < psh.Count; i++)
            {
              fread(&ph, sizeof(ph), 1, f);
              p = new char[ph.Length];
              fread(p, ph.Length, 1, f);
              VSTPaths.AddItem(p);
            }
          }
          
          if(Header.Version >= 2)
          {
            int i;
            SVSTPathsHeader psh;
            SVSTPathHeader  ph;
            char            *p;

            if(Header.Version == 2)
            {
              SOptionsAudio2 oa2;

              fread(&oa2, sizeof(oa2), 1, f);

              Audio.Driver      = oa2.Driver + 1;
              Audio.NullFormat  = WAVE_FORMAT_44S16;
              Audio.NullLatency = 512;
              Audio.WaveDevice  = oa2.WaveDevice;
              Audio.WaveFormat  = oa2.WaveFormat;
              Audio.WaveLatency = oa2.WaveLatency;
              Audio.ASIODevice  = oa2.ASIODevice;
              Audio.ASIOFormat  = oa2.ASIOFormat;
              Audio.ASIOLatency = oa2.ASIOLatency;
              Audio.DisableASIO = false;
            }
            else
              if(Header.Version == 3)
              {
                SOptionsAudio3 oa3;
                
                fread(&oa3, sizeof(oa3), 1, f);
                
                Audio.Driver        = oa3.Driver;
                Audio.NullLatency   = oa3.NullLatency;
                Audio.NullFormat    = oa3.NullFormat;
                Audio.WaveDevice    = oa3.WaveDevice;
                Audio.WaveLatency   = oa3.WaveLatency;
                Audio.WaveFormat    = oa3.WaveFormat;
                Audio.ASIODevice    = oa3.ASIODevice;
                Audio.ASIOLatency   = oa3.ASIOLatency;
                Audio.ASIOFormat    = oa3.ASIOFormat;
                Audio.DisableASIO   = false;
  
              }
              else
                if(Header.Version == 4)
                {
                  SOptionsAudio4 oa4;

                  fread(&oa4, sizeof(oa4), 1, f);

                  Audio.Driver        = oa4.Driver;
                  Audio.NullLatency   = oa4.NullLatency;
                  Audio.NullFormat    = oa4.NullFormat;
                  Audio.WaveDevice    = oa4.WaveDevice;
                  Audio.WaveLatency   = oa4.WaveLatency;
                  Audio.WaveFormat    = oa4.WaveFormat;
                  Audio.ASIODevice    = oa4.ASIODevice;
                  Audio.ASIOLatency   = oa4.ASIOLatency;
                  Audio.ASIOFormat    = oa4.ASIOFormat;
                  Audio.DisableASIO   = oa4.DisableASIO;
                }
                else
                  if(Header.Version == 5)
                  {
                    SOptionsAudio5 oa5;

                    fread(&oa5, sizeof(oa5), 1, f);

                    Audio.Driver        = oa5.Driver;
                    Audio.NullLatency   = oa5.NullLatency;
                    Audio.NullFormat    = oa5.NullFormat;
                    Audio.WaveDevice    = oa5.WaveDevice;
                    Audio.WaveLatency   = oa5.WaveLatency;
                    Audio.WaveFormat    = oa5.WaveFormat;
                    Audio.ASIODevice    = oa5.ASIODevice;
                    Audio.ASIOLatency   = oa5.ASIOLatency;
                    Audio.ASIOFormat    = oa5.ASIOFormat;
                    Audio.DisableASIO   = oa5.DisableASIO;
                  }                
                  else
                    fread(&Audio, sizeof(Audio), 1, f);
         
            fread(&OptionsDialog, sizeof(OptionsDialog), 1, f);

            for(i = 0; i < VSTPaths.Count; i++)
              delete VSTPaths.Items[i];
            VSTPaths.Clear();

            fread(&psh, sizeof(psh), 1, f);
            for(i = 0; i < psh.Count; i++)
            {
              fread(&ph, sizeof(ph), 1, f);
              p = new char[ph.Length];
              fread(p, ph.Length, 1, f);
              VSTPaths.AddItem(p);
            }
          }
        }
      }
      fclose(f);
    }
  }

#endif
}

COptions::~COptions()
{
  char lpszPath[MAX_PATH];
  
  if(SHGetSpecialFolderPath(NULL, lpszPath, CSIDL_APPDATA, TRUE))
  {
    strcat(lpszPath, "\\");
    strcat(lpszPath, OPTIONS_FOLDER);

    CreateDirectory(lpszPath, NULL);

    strcat(lpszPath, "\\");
    strcat(lpszPath, OPTIONS_FILE);

    FILE *f = fopen(lpszPath, "wb");
    if(f)
    {
      int i;
      SVSTPathsHeader psh;
      SVSTPathHeader  ph;

      Header.Magic   = OPTIONS_MAGIC;
      Header.Version = OPTIONS_VERSION;

      fwrite(&Header, sizeof(Header), 1, f);
      fwrite(&Audio,  sizeof(Audio),  1, f);
      fwrite(&OptionsDialog, sizeof(OptionsDialog), 1, f);

      psh.Count = VSTPaths.Count;
      fwrite(&psh, sizeof(psh), 1, f);

      for(i = 0; i < psh.Count; i++)
      {
        ph.Length = (int)strlen(VSTPaths.Items[i]) + 1;
        fwrite(&ph, sizeof(ph), 1, f);
        fwrite(VSTPaths.Items[i], ph.Length, 1, f);
      }

      fclose(f);
    }
  }
}