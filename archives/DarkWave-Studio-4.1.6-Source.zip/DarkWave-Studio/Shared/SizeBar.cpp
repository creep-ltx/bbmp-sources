/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "SizeBar.h"

#define STATE_IDLE      0
#define STATE_MOUSEOVER 1
#define STATE_SIZEING   2

CSizeBar::CSizeBar(CControl *parent, int style, int x, int y, int width, int height)
: CControl(parent, "SizeBar", x, y, width, height, false)
{
  Parent = parent;
  Style  = style;
  State  = STATE_IDLE;
  SubInit = true;
}

CSizeBar::~CSizeBar()
{
}

void CSizeBar::OnPaint()
{
  DrawBorder(DC, bs3DRaised, 0, 0, Width, Height);
  ColorManager->Lock();
  ColorManager->GetBrush(BackColor)->FillRect(DC, 1, 1, Width - 2, Height - 2);
  ColorManager->Release();
}

void CSizeBar::OnMouseMove(int x, int y)
{
  POINT p;

  switch(State)
  {
    case STATE_IDLE:
      State = STATE_MOUSEOVER;
      SetCursor(LoadCursor(NULL, (Style & SIZEBAR_STYLE_VERTICAL) ? IDC_SIZEWE : IDC_SIZENS));
      SetCapture(Handle);
      break;
    
    case STATE_MOUSEOVER:
      if(x < 0 || x >= Width || y < 0 || y >= Height)
      {
        State = STATE_IDLE;
        SetCursor(LoadCursor(NULL, IDC_ARROW));
        ReleaseCapture();
      }
      break;

    case STATE_SIZEING:
      p.x = x;
      p.y = y;
      ClientToScreen(Handle, &p);

      if(Style & SIZEBAR_STYLE_VERTICAL)
      {
        if(p.x != MousePos)
        {
          Parent->OnSizeX(this, p.x - MousePos);
          MousePos = p.x;
        }
      }
      else
      {
        if(p.y != MousePos)
        {
          Parent->OnSizeY(this, p.y - MousePos);
          MousePos = p.y;
        }
      }
  }
} 

void CSizeBar::OnLeftButtonDown(int x, int y)
{
  POINT p;

  if(State == STATE_MOUSEOVER)
  {
    p.x = x;
    p.y = y;
    ClientToScreen(Handle, &p);

    State = STATE_SIZEING;
    if(Style & SIZEBAR_STYLE_VERTICAL)
      MousePos = p.x;
    else
      MousePos = p.y;
  }
}

void CSizeBar::OnLeftButtonUp(int x, int y)
{
  if(State == STATE_SIZEING)
  {
    State = STATE_MOUSEOVER;
  }
}