#ifndef HDTRACKMACHINE_H
#define HDTRACKMACHINE_H

#include "DarkPlug.h"

class CHDTrack;

class CHDTrackMachine : public CMachine
{
public:
               CHDTrackMachine(CHost *host, bool stereo);
  virtual     ~CHDTrackMachine();
  virtual void DARKCALL Work();
  virtual void DARKCALL SetSampleRate(int sampleRate);
  virtual void DARKCALL SetBlockSamples(int blockSamples);
  virtual void DARKCALL SetName(char *name);
  virtual bool DARKCALL IsSynth();
  virtual void DARKCALL ReadProperties(char *data, int length, bool isInner);
  virtual void DARKCALL WriteProperties(char **data, int *length, bool *isInner);

  bool Stereo;

private:
  int       SampleRate, BlockSamples;
  CHDTrack *Track;
};

class CHDTrackMachineInfoMono : public CMachineInfo
{
public:
                             CHDTrackMachineInfoMono();
  virtual CMachine* DARKCALL CreateMachine();
};

class CHDTrackMachineInfoStereo : public CMachineInfo
{
public:
                             CHDTrackMachineInfoStereo();
  virtual CMachine* DARKCALL CreateMachine();
};

#endif