/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

#include "BackBuffer.h"

struct SDataSegs
{
  unsigned int    Count;
  unsigned char **DataSegs;
  unsigned int   *DataLengths;
};

class CFrameBuffer
{
public:
                 CFrameBuffer(int pngResourceID);
                 CFrameBuffer(int width, int height, bool alpha);
                ~CFrameBuffer();

  int            GetWidth();
  int            GetHeight();
  bool           GetAlpha();
  unsigned char *GetData();
  void           SetClip(int x1, int y1, int x2, int y2);
  void           Draw(CFrameBuffer *dst, int xDst, int yDst, int xSrc, int ySrc, int width, int height);
  void           Draw(CBackBuffer *dst);
  void           Draw(CBackBuffer *dst, int x, int y, int width, int height);
  void           TextureFill(CBackBuffer *dst, int X, int Y);
  void           TextureFill(CFrameBuffer *dst, int X, int Y);
  unsigned char *GetPixel3(int x, int y);
  unsigned char *GetPixel4(int x, int y);
  void           Fill(COLORREF color);
  void           Fill(COLORREF color, int x, int y, int w, int h);
  void           FillRect(int x, int y, int width, int height, COLORREF color, unsigned char alpha);
  void           DrawRect(int x, int y, int width, int height, COLORREF color, unsigned char alpha);
  void           SetPixel(int x, int y, COLORREF color, unsigned char alpha);
  int            ClipX1, ClipX2, ClipY1, ClipY2;
private:
  void           Clear();
  void           LoadPNG(int resourceID);
  void           LoadPNG(unsigned char *data, unsigned int length);
  void           LoadPNGHeader(unsigned char *data, unsigned int length);
  void           LoadPNGData(unsigned char *data, unsigned int length, SDataSegs *dataSegs);
  void           LoadPNGInflate(SDataSegs *dataSegs);
  void           FilterScanline(unsigned int filter, unsigned int scanline);

  void           Free();
  
  int            Width, Height;
  unsigned char *Data;
  bool           Alpha;

  inline unsigned int ReadInt32(unsigned char *data, int offset)
  {   
    data += offset;
    unsigned int i = ((unsigned int)(*data)       << 24) +
                     ((unsigned int)(*(data + 1)) << 16) +
                     ((unsigned int)(*(data + 2)) << 8)  +
                      (unsigned int)(*(data + 3));

   return i;
  }
};

inline unsigned char *CFrameBuffer::GetPixel3(int x, int y)
{
  return Data + (((y * Width) + x) * 3);
}

inline unsigned char *CFrameBuffer::GetPixel4(int x, int y)
{
  return Data + (((y * Width) + x) * 4);
}


#endif