/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "HeavyKnob.h"

CHeavyKnob::CHeavyKnob(CControl *parent, int x, int y, int width, int height, CFrameBuffer *image)
: CLiteContainer(parent, width, height, 0)
{
  Move(x, y);
  Knob = new CLiteKnob(this, 0, 0, image, 0, 0, Height);
  Render();
}

CHeavyKnob::~CHeavyKnob()
{
  delete Knob;
}