/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Frame.h"
#include "BackBuffer.h"
#include "Font.h"

#define LABEL_EXTRA 6

CFrame::CFrame(CControl *parent, char *name, int x, int y, int width, int height)
: CControl(parent, name, x, y, width, height, true)
{
  Name = name;
  SubInit = true;
  DrawControl();
}

CFrame::~CFrame()
{
}

void CFrame::DrawControl()
{
  HDC     hDC;
  RECT    r;
  HGDIOBJ oldFont;

  hDC = BackDC;

  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, 0, 0, Width, Height);
  DrawBorder(hDC, bs3DRaised, 0, LABEL_EXTRA, Width, Height - LABEL_EXTRA);
  
  SetBkColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlBack));
  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlText));
  
  r.left   = LABEL_EXTRA;
  r.top    = 0;
  r.right  = Width - 1;
  r.bottom = LABEL_EXTRA << 1;
  
  oldFont = SelectObject(hDC, Font->Handle);
  DrawTextA(hDC, Name, (int)strlen(Name), &r, DT_SINGLELINE | DT_VCENTER);
  SelectObject(hDC, oldFont);
  ColorManager->Release();
}