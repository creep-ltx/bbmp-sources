/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Inflate.h"
#include "../ZLib/zlib.h"
#include "Error.h"

unsigned int Inflate(unsigned char *dst, unsigned int dstLength, unsigned char *src, unsigned int srcLength)
{
  int s;

  s = uncompress(dst, (uLongf*)&dstLength, src, srcLength);
  if(s == Z_OK)
  {
#ifdef _DEBUG
    DebugPrint("Inflated [%i] Bytes OK\n", dstLength);
#endif
    return dstLength;
  }
  else
  {
    switch(s)
    { 
      case Z_MEM_ERROR:
        throw "Inflate: Memory Error";

      case Z_BUF_ERROR:
        throw "Inflate: Buffer Error";

      case Z_DATA_ERROR:
        throw "Inflate: Data Error";

      default:
        throw "Inflate: Unknown Error";
    }
  }
}