/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef BANKSERVER_H
#define BANKSERVER_H

#include "DarkPlug.h"
#include "Array.h"

class CBankInfo
{
public:
       CBankInfo(char *name, char *text);
      ~CBankInfo();
  void SetName(char *name);
  void SetText(char *text);
  void GetName(char *name);
  void GetText(char *text);
  int  GetTextLength();
  int  GetNameLength();

private:
  char *Name, *Text;
  int   NameLength, TextLength;
};

class CPreset
{
public:
      CPreset(char *name);
     ~CPreset();
 void SetName(char *name);
 void GetName(char *name);
 int  GetNameLength();

private:
 char *Name;
 int   NameLength;
};

class CBank
{
public:
             CBank(char *name);
            ~CBank();
  void       SetName(char *name);
  void       GetName(char *text);
  int        GetNameLength();
  int        AddInfo(char *infoName, char *infoText);
  int        GetInfoCount();
  CBankInfo *GetInfo(int index);
  int        AddPreset(char *presetName);
  int        GetPresetCount();
  CPreset   *GetPreset(int index);

private:
 CArray<CBankInfo*> *BankInfo; 
 CArray<CPreset*>   *Presets;
 char               *Name;
 int                 NameLength;
};

class CHostBankServer : public CBankServer
{
public:
                 CHostBankServer();
                ~CHostBankServer();
  virtual EError DARKCALL Connect(CBankClient *client);
  virtual EError DARKCALL Disconnect(CBankClient *client);
  
  virtual EError DARKCALL AddBank(char *bankName, int *bankIndex);
  virtual EError DARKCALL AddBankInfo(int bankIndex, char *infoName, char *infoText, int *infoIndex);
  virtual EError DARKCALL GetBankName(int bankIndex, char *bankName);
  virtual EError DARKCALL GetBankNameLength(int bankIndex, int *nameLength);
  
  virtual EError DARKCALL GetBankInfoCount(int bankIndex, int *infoCount);
  virtual EError DARKCALL GetBankInfoNameLength(int bankIndex, int infoIndex, int *nameLength);
  virtual EError DARKCALL GetBankInfoName(int bankIndex, int infoIndex, char *infoName);
  virtual EError DARKCALL GetBankInfoTextLength(int bankIndex, int infoIndex, int *textLength);
  virtual EError DARKCALL GetBankInfoText(int bankIndex, int infoIndex, char *infoText);

  virtual EError DARKCALL AddPreset(int bankIndex, char *presetName, int *presetIndex);
  virtual EError DARKCALL GetPresetCount(int bankIndex, int *presetCount);
  virtual EError DARKCALL GetPresetName(int bankIndex, int presetIndex, char *presetName);
  virtual EError DARKCALL GetPresetNameLength(int bankIndex, int presetIndex, int *nameLength);

  bool    InDispatch();
  void    BeginDispatch();
  void    EndDispatch();
  void    OnAddBank(int bankIndex);
  void    OnAddBankInfo(int bankIndex, int infoIndex);
  void    OnAddPreset(int bankIndex, int presetIndex);

private:
  EError GrabBank(int bankIndex, CBank **bank);

  CArray<CBankClient*> *Clients;
  CArray<CBank*>       *Banks;
  int                   DispatchLevel;
};

#endif