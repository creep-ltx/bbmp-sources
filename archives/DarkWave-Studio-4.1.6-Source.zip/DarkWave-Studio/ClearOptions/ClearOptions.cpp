/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define _WIN32_WINNT 0x501
#define _WIN32_IE    0x500

#include <windows.h>
#include <stdio.h>
#include <shlobj.h>

#define OPTIONS_FOLDER "DarkWave Studio"
#define OPTIONS_FILE   "DarkWave.opt"

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, char* lpCmdLine, int nCmdShow)
{
  char lpszPath[MAX_PATH];

  if(SHGetSpecialFolderPath(NULL, lpszPath, CSIDL_APPDATA, FALSE))
  {
    OFSTRUCT ofStruct;

    strcat(lpszPath, "\\");
    strcat(lpszPath, OPTIONS_FOLDER);
    strcat(lpszPath, "\\");
    strcat(lpszPath, OPTIONS_FILE);

    memset(&ofStruct, 0, sizeof(ofStruct));

    if(OpenFile(lpszPath, &ofStruct, OF_EXIST) != HFILE_ERROR)
    {
      int s;

      s = MessageBox(NULL, "Clear DarkWave Studio Options?", "DarkWave Studio", MB_OKCANCEL);
      if(s == IDOK)
      {
        s = DeleteFile(lpszPath);
      }
    }
  }
}