/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef PATTERN_H
#define PATTERN_H

#include "Connector.h"
#include "Note.h"
#include "ControlTrack.h"

#define DEFAULT_VELOCITY ((1.0 / 127.0) * 100.0)

class CPattern
{
public:
         CPattern(int length, char *name, CConnector *port);
  void   CopyPattern(CPattern *originalPattern);
        ~CPattern();
  CNote *AddNote(int start, int length, int note);
  void   RemoveNote(CNote *note);
  void   Play(bool reset);  
  void   Play(bool reset, int sample);
  void   Stop(bool reset);
  void   Work();
  void   SetLoop(bool value);
  void   ProcessBlock(int offset, int sample, int samples, double samplesPerTick);
  double GetPlayPos();
  double GetPlayPos2();
  void   SetSample2(int sample);
  int    GetNoteCount();
  int    AddControlTrack(int parameter);
  void   RemoveControlTrack(int index);
  void   SetSampleRate(int sampleRate);
  void   SetBlockSamples(int blockSamples);
  void   ProcessFuture();
  void   Resize(int newLength);
  void   SendNoteOn(int note);
  void   SendNoteOff(int note);
  bool   Transpose(int amount);

  int                    Length, Index;
  char                  *Name;
  CConnector            *Port;
  CNote                 *FirstNote;
  bool                   Playing;
  CArray<CControlTrack*>*ControlTracks;
  CControlTrack         *VelocityTrack;
  CControlBuffer         Future;
  int                    SampleRate, BlockSamples;
  double                 BPM;

  int                    Sample, Sample2;
  bool            Loop, Stopping;
};

#endif