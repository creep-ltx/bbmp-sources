/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "MIDIInput.h"
#include "Core.h"

#define GUI_WIDTH      240
#define GUI_HEIGHT     64
#define TIME_ADJUST_MS 80

void MIDIInputProc(void *userData, unsigned char status, unsigned char data1, unsigned char data2)
{
  CMIDIInput *midiInput;

  midiInput = (CMIDIInput*)userData;
  midiInput->Lock();
  midiInput->MIDIMessage(status, data1, data2);
  midiInput->Release();
}

CMIDIInputInfo::CMIDIInputInfo()
{
  Name = "ES MIDI Input";
  UniqueID = "DarkPlug::ES MIDI Input";
}

CMachine *CMIDIInputInfo::CreateMachine()
{
  return new CMIDIInput(Core->Host);
}

CMIDIInput::CMIDIInput(CHost *host)
: CMachine(host)
{
  Channel = -1;
  GUI = 0;
  Ports = new CPort*[1];
  Ports[0] = new CPort(Core->Host, this, PT_CONTROL | PT_OUTPUT, "Control Out");
  PortCount = 1;
  Device = 0;
  ControlBuffer = new CControlBuffer();
  FutureBuffer = new CControlBuffer();
  BlockSamples = Host->GetBlockSamples();
  SampleRate = Host->GetSampleRate();
  if(QueryPerformanceFrequency(&PerformanceFrequency) == 0)
    PerformanceFrequency.QuadPart = 0;
}

CMIDIInput::~CMIDIInput()
{
  CloseDevice();
  delete Ports[0];
  delete Ports;
  delete ControlBuffer;
  delete FutureBuffer;
  if(GUI != 0)
    delete GUI;
}

bool CMIDIInput::IsSynth()
{
  return false;
}

void CMIDIInput::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

void CMIDIInput::SetSampleRate(int sampleRate)
{
  SampleRate = sampleRate;
}
void CMIDIInput::Work()
{
  SControlMessage message;
  bool            messageRead;
  int             sample;
  LARGE_INTEGER   blockTime, timeAdjust, messageTime;
  
  FutureBuffer->CopyTo(ControlBuffer);
  FutureBuffer->Clear();

  if(PerformanceFrequency.QuadPart == 0)
  {
    ControlBuffer->CopyTo(Ports[0]->ControlBuffer);
    ControlBuffer->Clear();
  }
  else
  {
    QueryPerformanceCounter(&blockTime);
    timeAdjust.QuadPart = (TIME_ADJUST_MS * PerformanceFrequency.QuadPart) / 1000;

    messageRead = ControlBuffer->Read(&message);
    while(messageRead)
    {
      messageTime.QuadPart = (message.Reserved.QuadPart + timeAdjust.QuadPart) -
        blockTime.QuadPart;

      sample = (int)((messageTime.QuadPart * SampleRate) / PerformanceFrequency.QuadPart);
      if(sample < 0)
        sample = 0;

      if(sample >= BlockSamples)
      {
        message.BlockSample -= BlockSamples;
        FutureBuffer->Write(&message);
      }
      else
      {
        message.BlockSample = sample;
        Ports[0]->ControlBuffer->Write(&message);
      }
      messageRead = ControlBuffer->Read(&message);
    }     
  }
}

HWND CMIDIInput::CreateGUI(HWND parent)
{
  if(GUI == 0)
    GUI = new CMIDIInputGUI(parent, this);
  
  return GUI->Handle;
}

CMIDIInputGUI::CMIDIInputGUI(HWND parent, CMIDIInput *midiInput)
: CControl(parent, Core->ColorManager, "MIDI Input", 0, 0, GUI_WIDTH, GUI_HEIGHT, false)
{
  int           i;
  CMIDIManager *midiManager;
  char          chanTxt[32];

  MIDIInput = midiInput;
    
  DeviceCombo = new CDropList(this, "DeviceCombo", 8, 8, GUI_WIDTH - 16, 16);
  ChannelCombo = new CDropList(this, "ChannelCombo", 8, 36, GUI_WIDTH - 16, 16);

  midiManager = Core->MIDIManager;
  for(i = 0; i < midiManager->InputDeviceCount; i++)
    DeviceCombo->AddItem(midiManager->InputDevices[i]->Name);

  ChannelCombo->AddItem("All Channels");
  for(i = 1; i <= 16; i++)
  {
    sprintf(chanTxt, "Channel %i", i);
    ChannelCombo->AddItem(chanTxt);
  }

  if(midiInput->Device)
    DeviceCombo->SetSelection(midiInput->Device->ID);

  ChannelCombo->SetSelection(midiInput->Channel + 1);

  DeviceCombo->Show();
  ChannelCombo->Show();
}

CMIDIInputGUI::~CMIDIInputGUI()
{
  delete DeviceCombo;
  delete ChannelCombo;
}

void CMIDIInputGUI::OnComboSelect(CDropList *comboBox)
{
    if(comboBox == DeviceCombo)
    {
      OpenDevice(comboBox->GetSelection());
    }

    if(comboBox == ChannelCombo)
    {
      int selection;

      selection = comboBox->GetSelection();
      MIDIInput->SetChannel(selection == 0 ? -1 : selection - 1);
    }
}

void CMIDIInputGUI::OpenDevice(int index)
{
  MIDIInput->OpenDevice(index);
}

void CMIDIInput::OpenDevice(int index)
{
  CloseDevice();

  if(index >= 0 && index < Core->MIDIManager->InputDeviceCount)
  {
    Device = Core->MIDIManager->InputDevices[index];
    Device->AddHook(&MIDIInputProc, this);
    Device->Open();
  }
}

void CMIDIInput::CloseDevice()
{
  if(Device != 0)
  {
    Device->RemoveHook(&MIDIInputProc, this);
    Device->Close();
    Device = 0;
  }
}

void CMIDIInput::SetChannel(int channel)
{
  Channel = channel;
  if(GUI)
    GUI->ChannelCombo->SetSelection(channel == -1 ? 0 : channel + 1);
}

void CMIDIInput::MIDIMessage(unsigned char status, unsigned char data1, unsigned char data2)
{
  SControlMessage message;

  ((CMachineContainer*)HostData)->Lock();

  if(status >= 0x90 && status <= 0x9F && data2 == 0) // NoteOn, Velocity = 0
    status -= 0x10;                                  // Convert To NoteOff

  if((status >= 0x90) && (status <= 0x9F)) // NoteOn (All Channels)
  {
    if(MIDIChannelMatch(Channel, status & 0xF))
    {
      memset(&message, 0, sizeof(SControlMessage));
      message.BlockSample = 0;
      message.Type = CONTROL_MESSAGE_NOTE_ON;
      message.NoteOn.Note      = data1;
      Core->Host->GetNoteFrequency(data1, &message.NoteOn.Frequency);
      message.NoteOn.Velocity  = ((1.0 / 127.0) * (double)data2);
      if(PerformanceFrequency.QuadPart != 0)
        QueryPerformanceCounter(&message.Reserved);
      else
        message.Reserved.QuadPart = 0;
      ControlBuffer->Write(&message);
    }
  }

  if((status >= 0x80) && (status <= 0x8F)) // NoteOff (All Channels)
  {
    if(MIDIChannelMatch(Channel, status & 0xF))
    {
      memset(&message, 0, sizeof(SControlMessage));
      message.BlockSample = 0;
      message.Type = CONTROL_MESSAGE_NOTE_OFF;
      message.NoteOff.Note      = data1;
      if(PerformanceFrequency.QuadPart != 0)
        QueryPerformanceCounter(&message.Reserved);
      else
        message.Reserved.QuadPart = 0;
      ControlBuffer->Write(&message);
    }
  }

  if((status >= 0xB0) && (status <= 0xBF)) // Control Change (All Channels)
  {
    if(MIDIChannelMatch(Channel, status & 0xF))
    {
      memset(&message, 0, sizeof(SControlMessage));
      message.BlockSample = 0;
      message.Type = CONTROL_MESSAGE_CONTROL_CHANGE;
      message.ControlChange.Controller = data1;
      message.ControlChange.Value = ((1.0 / 127.0) * (double)data2);
      if(PerformanceFrequency.QuadPart != 0)
        QueryPerformanceCounter(&message.Reserved);
      else
        message.Reserved.QuadPart = 0;
      ControlBuffer->Write(&message);
    }
  }

  ((CMachineContainer*)HostData)->Release();
}

struct SMIDIInputProperties
{
  int Device;
  int Channel;
};

void DARKCALL CMIDIInput::ReadProperties(char *data, int length, bool isInner)
{
  if(length == sizeof(SMIDIInputProperties))
  {
    SMIDIInputProperties *properties;

    properties = (SMIDIInputProperties*)data;
    OpenDevice(properties->Device);
    SetChannel(properties->Channel);
  }
}

void DARKCALL CMIDIInput::WriteProperties(char **data, int *length, bool *isInner)
{
  SMIDIInputProperties *properties;
  
  properties = new SMIDIInputProperties;
  *data = (char*)properties;
  *length = sizeof(SMIDIInputProperties);
  if(Device)
    properties->Device = Device->ID;
  else
    properties->Device = -1;
  properties->Channel = Channel;
  *isInner = false;
}
