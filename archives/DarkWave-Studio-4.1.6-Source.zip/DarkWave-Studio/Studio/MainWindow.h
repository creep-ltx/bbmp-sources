/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "../Shared/Window.h"
#include "MainToolBar.h"
#include "Studio.h"
#include "SampleAnalyzer.h"
#include "PatternEditor.h"
#include "SequenceEditor.h"
#include "PresetEditor.h"
#include "OptionsDialog.h"
#include "TabControl.h"
#include "BankExplorer.h"
#include "HDRecorder.h"
#include "LiteContainer.h"
#include "ProjectInfo.h"

#define MAINWINDOW_CONTROL_STUDIO         0
#define MAINWINDOW_CONTROL_PATTERNEDITOR  1
#define MAINWINDOW_CONTROL_SEQUENCEEDITOR 2
#define MAINWINDOW_CONTROL_HDRECORDER     3
#define MAINWINDOW_CONTROL_PROJECTINFO    4
#define MAINWINDOW_CONTROL_BANKEXPLORER   5
#define MAINWINDOW_CONTROL_PRESETEDITOR   6

class CMainWindow : public CWindow
{
public:
                  CMainWindow();
                 ~CMainWindow();
  virtual void    OnClose();
  virtual LRESULT WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
  virtual void    OnResize(int newWidth, int newHeight);
  void            ShowControl(int control);
  void            DrawControl();

  CStudio         *Studio;
  CPatternEditor  *PatternEditor;
  CSequenceEditor *SequenceEditor;
  CPresetEditor   *PresetEditor;
  CBankExplorer   *BankExplorer;
  CTabControl     *TabControl;
  CMainToolBar    *MainToolBar;
  CHDRecorder     *HDRecorder;
  CProjectInfo    *ProjectInfo;

private:
  CSampleAnalyzer *SampleAnalyzer;
  COptionsDialog  *OptionsDialog;
};

#endif