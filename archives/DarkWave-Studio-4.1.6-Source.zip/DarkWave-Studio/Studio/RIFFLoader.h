/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef RIFF_LOADER_H
#define RIFF_LOADER_H

#include "DarkPlug.h"

#define BYTE(n, v) ((v >> (n << 3)) & 0xFF)

#define RIFF_CONTEXT_MAIN 0

#define CHUNKTYPE_RIFF 'FFIR'
#define CHUNKTYPE_LIST 'TSIL'

#pragma pack(push)
#pragma pack(1)

struct SRIFFChunk
{
  unsigned int Type;
  unsigned int Length;
};

struct SRIFFHeaderChunk
{
  unsigned int Type;
  unsigned int Length;
  unsigned int FormType;
};

struct SRIFFListChunk
{
  unsigned int Type;
  unsigned int Length;
  unsigned int ListType;
};

#pragma pack(pop)

class CRIFFLoader
{
public:
                 CRIFFLoader();
                ~CRIFFLoader();
  EError         Load(char *fileName, unsigned int type);
  virtual EError ParseList(SRIFFListChunk *chunk, char *data, unsigned int level, int context);
  virtual EError ParseChunk(SRIFFChunk *chunk, char *data, unsigned int level, int context) = 0;

private:
  char *Data;
};

#endif