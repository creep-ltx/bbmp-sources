/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <math.h>
#include <windows.h>
#include <mmsystem.h>

#include "AudioOutOptions.h"
#include "Core.h"
#include "WaveOutDriver.h"
#include "ASIODriver.h"
#include "DirectSoundDriver.h"
#include "DropList.h"
#include "Label.h"
#include "Font.h"

float granular(int f, int granularity)
{
  if(granularity == 0)
    return (float)f;
  else
    return (float)(f - (f % granularity));
}

double LatencyToValue(int latency, int minLatency, int maxLatency, int granularity)
{
  return ((double)(latency - minLatency) / (double)(maxLatency - minLatency));
}

int ValueToLatency(double value, int minLatency, int maxLatency, int granularity)
{
  int latency;

  latency = minLatency + (int)(value * (double)(maxLatency - minLatency));

  return (int)granular(latency, granularity);
}

void SetLatencyLabel(CLabel *label, int latency)
{
  char text[128];

  sprintf(text, "Samples: %i", latency);
  label->SetText(text);
}

#define DRIVERLABEL_X         8
#define DRIVERLABEL_Y         24
#define DRIVERLABEL_WIDTH     40
#define DRIVERLABEL_HEIGHT    20
#define DRIVERCOMBO_X         (DRIVERLABEL_X + DRIVERLABEL_WIDTH + 8)
#define DRIVERCOMBO_Y         24
#define DRIVERCOMBO_WIDTH     (128 + 64)
#define DRIVERCOMBO_HEIGHT    16
#define COMBO_ITEMHEIGHT      16
#define DRIVERFRAME_X         8
#define DRIVERFRAME_Y         (DRIVERLABEL_Y + DRIVERLABEL_HEIGHT + 8)
#define DRIVERFRAME_WIDTH(w)  (w - 16)
#define DRIVERFRAME_HEIGHT(h) (h - (DRIVERFRAME_Y + 8))

void CAudioOutOptions::OnResize(int newWidth, int newHeight)
{
  int i;

  for(i = 0; i < Core->AudioManager->GetOutputDriverCount(); i++)
  {
    DriverOptions[i]->Resize(DRIVERFRAME_WIDTH(newWidth), DRIVERFRAME_HEIGHT(newHeight));
  }
  CControl::OnResize(newWidth, newHeight);
}

CAudioOutOptions::CAudioOutOptions(COptionsDialog *parent, int x, int y, int width, int height)
: COptionsFrame(parent, "Audio Output Options", x, y, width, height)
{
  int i, driver;

  DriverChanged = false;

  driver = Core->AudioManager->GetCurrentOutputDriver();

  DriverLabel = new CLabel(this, "Driver:", DRIVERLABEL_X, DRIVERLABEL_Y, DRIVERLABEL_WIDTH, DRIVERLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER | DT_RIGHT);
  DriverLabel->Show();

  DriverCombo = new CDropList(this, "Drivers", DRIVERCOMBO_X, DRIVERCOMBO_Y, DRIVERCOMBO_WIDTH, DRIVERCOMBO_HEIGHT);
  for(i = 0; i < Core->AudioManager->GetOutputDriverCount(); i++)
    DriverCombo->AddItem(Core->AudioManager->GetOutputDriver(i)->GetName());
  DriverCombo->SetSelection(driver);
  DriverCombo->Show();

  DriverOptionCount = Core->AudioManager->GetOutputDriverCount();
  DriverOptions = new CAudioOutDriverOptions*[DriverOptionCount];
  DriverOptions[0] = new CNullOutOptions(this, DRIVERFRAME_X, DRIVERFRAME_Y, DRIVERFRAME_WIDTH(Width), DRIVERFRAME_HEIGHT(Height));
  DriverOptions[1] = new CWaveOutOptions(this, DRIVERFRAME_X, DRIVERFRAME_Y, DRIVERFRAME_WIDTH(Width), DRIVERFRAME_HEIGHT(Height));
  DriverOptions[2] = new CDirectSoundOptions(this, DRIVERFRAME_X, DRIVERFRAME_Y, DRIVERFRAME_WIDTH(Width), DRIVERFRAME_HEIGHT(Height));
  if(!(Core->Options->Audio.DisableASIO))
    DriverOptions[3] = new CASIOOutOptions(this, DRIVERFRAME_X, DRIVERFRAME_Y, DRIVERFRAME_WIDTH(Width), DRIVERFRAME_HEIGHT(Height));

  if(driver >= 0 && driver < DriverOptionCount)
    CurrentDriverOptions = DriverOptions[driver];
  else
    CurrentDriverOptions = 0;

  if(CurrentDriverOptions)
    CurrentDriverOptions->Show();
}

void CAudioOutOptions::OnComboSelect(CDropList *comboBox)
{
  if(comboBox == DriverCombo)
  {
    OnChange();
    CurrentDriverOptions->Hide();
    CurrentDriverOptions = DriverOptions[DriverCombo->GetSelection()];
    CurrentDriverOptions->Show();
    DriverChanged = true;
  }
}

CAudioOutOptions::~CAudioOutOptions()
{
  int i;

  delete DriverLabel;
  delete DriverCombo;

  for(i = 0; i < DriverOptionCount; i++)
    delete DriverOptions[i];
  delete DriverOptions;
}

void CAudioOutOptions::ApplyChanges()
{
  int  i, j;
  bool reset = false;

  for(i = 0; i < DriverOptionCount; i++)
    if(DriverOptions[i]->ApplyChanges() || DriverChanged)
      if(CurrentDriverOptions == DriverOptions[i])
      {
        j = i;
        reset = true;
      }

  DriverChanged = false;

  if(reset)
  {
    Core->ResetAudioOutput(j);
  }
}

// Audio Out Driver Options

CAudioOutDriverOptions::CAudioOutDriverOptions(CAudioOutOptions *parent, char *name, int x, int y, int width, int height)
: CFrame(parent, name, x, y, width, height)
{
  AudioOutOptions = parent;
}

CAudioOutDriverOptions::~CAudioOutDriverOptions()
{
}

void CAudioOutDriverOptions::OnChange()
{
  AudioOutOptions->OnChange();
}

// Null Out Options

#define NULLOUT_DEVICELABEL_X         8
#define NULLOUT_DEVICELABEL_Y         24
#define NULLOUT_DEVICELABEL_WIDTH     48
#define NULLOUT_DEVICELABEL_HEIGHT    20

#define NULLOUT_DEVICECOMBO_X         (NULLOUT_DEVICELABEL_X + NULLOUT_DEVICELABEL_WIDTH + 8)
#define NULLOUT_DEVICECOMBO_Y         NULLOUT_DEVICELABEL_Y
#define NULLOUT_DEVICECOMBO_WIDTH(w)  (w - (NULLOUT_DEVICECOMBO_X + 8))
#define NULLOUT_DEVICECOMBO_HEIGHT    16

#define NULLOUT_FORMATLABEL_X         NULLOUT_DEVICELABEL_X
#define NULLOUT_FORMATLABEL_Y         (NULLOUT_DEVICELABEL_Y + NULLOUT_DEVICELABEL_HEIGHT + 8)
#define NULLOUT_FORMATLABEL_WIDTH     NULLOUT_DEVICELABEL_WIDTH
#define NULLOUT_FORMATLABEL_HEIGHT    NULLOUT_DEVICELABEL_HEIGHT

#define NULLOUT_FORMATCOMBO_X         NULLOUT_DEVICECOMBO_X
#define NULLOUT_FORMATCOMBO_Y         NULLOUT_FORMATLABEL_Y
#define NULLOUT_FORMATCOMBO_WIDTH(w)  NULLOUT_DEVICECOMBO_WIDTH(w)
#define NULLOUT_FORMATCOMBO_HEIGHT    NULLOUT_DEVICECOMBO_HEIGHT

#define NULLOUT_LATENCYLABEL_X        NULLOUT_FORMATLABEL_X
#define NULLOUT_LATENCYLABEL_Y        (NULLOUT_FORMATLABEL_Y + NULLOUT_FORMATLABEL_HEIGHT + 8)
#define NULLOUT_LATENCYLABEL_WIDTH(w)  (DRIVERFRAME_WIDTH(w))
#define NULLOUT_LATENCYLABEL_HEIGHT   (NULLOUT_DEVICELABEL_HEIGHT)

#define NULLOUT_LATENCYSLIDER_X        NULLOUT_LATENCYLABEL_X
#define NULLOUT_LATENCYSLIDER_Y        (NULLOUT_LATENCYLABEL_Y + NULLOUT_LATENCYLABEL_HEIGHT + 8) 
#define NULLOUT_LATENCYSLIDER_WIDTH(w) DRIVERFRAME_WIDTH(w)
#define NULLOUT_LATENCYSLIDER_HEIGHT   NULLOUT_LATENCYLABEL_HEIGHT

void CNullOutOptions::OnResize(int newWidth, int newHeight)
{
  DeviceCombo->Resize(NULLOUT_DEVICECOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  FormatCombo->Resize(NULLOUT_FORMATCOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  LatencySlider->Resize(NULLOUT_LATENCYSLIDER_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  LatencyLabel->Resize(NULLOUT_LATENCYLABEL_WIDTH(newWidth), NULLOUT_LATENCYLABEL_HEIGHT);
  CControl::OnResize(newWidth, newHeight);
}

CNullOutOptions::CNullOutOptions(CAudioOutOptions *parent, int x, int y, int width, int height)
: CAudioOutDriverOptions(parent, "Null Out Options", x, y, width, height)
{
  int i;

  DeviceLabel = new CLabel(this, "Device:", NULLOUT_DEVICELABEL_X, NULLOUT_DEVICELABEL_Y, NULLOUT_DEVICELABEL_WIDTH, NULLOUT_DEVICELABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  DeviceCombo = new CDropList(this, "Device", NULLOUT_DEVICECOMBO_X, NULLOUT_DEVICECOMBO_Y, NULLOUT_DEVICECOMBO_WIDTH(Width), NULLOUT_DEVICECOMBO_HEIGHT);

  FormatLabel = new CLabel(this, "Format:", NULLOUT_FORMATLABEL_X, NULLOUT_FORMATLABEL_Y, NULLOUT_FORMATLABEL_WIDTH, NULLOUT_FORMATLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  FormatCombo = new CDropList(this, "Format", NULLOUT_FORMATCOMBO_X, NULLOUT_FORMATCOMBO_Y, NULLOUT_FORMATCOMBO_WIDTH(Width), NULLOUT_FORMATCOMBO_HEIGHT);

  Driver = (CNullDriver*)Core->AudioManager->GetOutputDriver(OUTPUT_DRIVER_NULL);
  DeviceCount = Driver->GetDeviceCount();
  Device = Driver->GetDevice();

  for(i = 0; i < DeviceCount; i++)
    DeviceCombo->AddItem(Driver->GetDeviceName(i));

  DeviceFormats = 0;
  ShowDevice(Device);

  LatencyLabel = new CLabel(this, "Buffer:", NULLOUT_LATENCYLABEL_X, NULLOUT_LATENCYLABEL_Y, NULLOUT_LATENCYLABEL_WIDTH(Width), NULLOUT_LATENCYLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER); 
  
  LatencySlider = new CSlider(this, NULLOUT_LATENCYSLIDER_X, NULLOUT_LATENCYSLIDER_Y, NULLOUT_LATENCYSLIDER_WIDTH(Width), NULLOUT_LATENCYSLIDER_HEIGHT, SLIDER_HORIZONTAL);
  Latency = Driver->GetLatency();
  LatencySlider->SetValue(LatencyToValue(Latency, NULL_MIN_LATENCY, NULL_MAX_LATENCY, NULL_GRANULARITY));
  SetLatencyLabel(LatencyLabel, Latency);

  DeviceLabel->Show();
  DeviceCombo->Show();
  FormatLabel->Show();
  FormatCombo->Show();
  LatencyLabel->Show();
  LatencySlider->Show();
}

CNullOutOptions::~CNullOutOptions()
{
  delete DeviceLabel;
  delete DeviceCombo;
  delete FormatLabel;
  delete FormatCombo;
}

void CNullOutOptions::ShowDevice(int device)
{
  const int firstFormat = WAVE_FORMAT_1M08;
  const int lastFormat  = WAVE_FORMAT_96S16;
  int       i, format, supportedFormats, currentFormat;
    
  if(DeviceFormats)
    delete DeviceFormats;

  FormatCombo->Clear();

  if(device < 0 || device >= DeviceCount)
    return;

  supportedFormats = Driver->GetDeviceFormats(device);
  currentFormat    = Driver->GetFormat();
  DeviceFormat     = 0;

  DeviceFormatCount = 0;
  for(format = firstFormat; format <= lastFormat; format <<= 1)
    if(format & supportedFormats)
      DeviceFormatCount++;

  i = 0;
  DeviceFormats = new int[DeviceFormatCount];

  for(format = firstFormat; format <= lastFormat; format <<= 1)
    if(format & supportedFormats)
    {
      char *text;

      DeviceFormats[i] = format;
      if(format == currentFormat)
        DeviceFormat = i;
      i++;
      text = Driver->DescribeFormat(format);
      FormatCombo->AddItem(text);
      delete text;
    }

  Device = device;
  DeviceCombo->SetSelection(device);
  FormatCombo->SetSelection(DeviceFormat);
}

void CNullOutOptions::OnComboSelect(CDropList *comboBox)
{
  if(comboBox == DeviceCombo)
  {
    ShowDevice(DeviceCombo->GetSelection());
    OnChange();
  }

  if(comboBox == FormatCombo)
  {
    DeviceFormat = FormatCombo->GetSelection();
    OnChange();
  }
}

bool CNullOutOptions::ApplyChanges()
{
  bool changed = false;

  if(!Driver)
    return false;

  if(Driver->GetDevice() == -1)
    return false;

  if(Driver->GetDevice() != Device)
  {
    Driver->SetDevice(Device);
    changed = true;
  }

  if(Driver->GetFormat() != DeviceFormats[DeviceFormat])
  {
    Driver->SetFormat(DeviceFormats[DeviceFormat]);
    changed = true;
  }

  if(Driver->GetLatency() != Latency)
  {
    Driver->SetLatency(Latency);
    changed = true;
  }

  return changed;
}

void CNullOutOptions::OnSliderChange(CSlider *slider, double value)
{
  int newLatency;

  if(slider == LatencySlider)
  {
    newLatency = ValueToLatency(value, NULL_MIN_LATENCY, NULL_MAX_LATENCY, NULL_GRANULARITY);
    if(newLatency != Latency)
    {
      Latency = newLatency;
      SetLatencyLabel(LatencyLabel, Latency);
      OnChange();
    }
  }
}

// Wave Out Options

#define WAVEOUT_DEVICELABEL_X         8
#define WAVEOUT_DEVICELABEL_Y         24
#define WAVEOUT_DEVICELABEL_WIDTH     48
#define WAVEOUT_DEVICELABEL_HEIGHT    20

#define WAVEOUT_DEVICECOMBO_X         (WAVEOUT_DEVICELABEL_X + WAVEOUT_DEVICELABEL_WIDTH + 8)
#define WAVEOUT_DEVICECOMBO_Y         WAVEOUT_DEVICELABEL_Y
#define WAVEOUT_DEVICECOMBO_WIDTH(w)  (w - (WAVEOUT_DEVICECOMBO_X + 8))
#define WAVEOUT_DEVICECOMBO_HEIGHT    16

#define WAVEOUT_FORMATLABEL_X         WAVEOUT_DEVICELABEL_X
#define WAVEOUT_FORMATLABEL_Y         (WAVEOUT_DEVICELABEL_Y + WAVEOUT_DEVICELABEL_HEIGHT + 8)
#define WAVEOUT_FORMATLABEL_WIDTH     WAVEOUT_DEVICELABEL_WIDTH
#define WAVEOUT_FORMATLABEL_HEIGHT    WAVEOUT_DEVICELABEL_HEIGHT

#define WAVEOUT_FORMATCOMBO_X         WAVEOUT_DEVICECOMBO_X
#define WAVEOUT_FORMATCOMBO_Y         WAVEOUT_FORMATLABEL_Y
#define WAVEOUT_FORMATCOMBO_WIDTH(w)  WAVEOUT_DEVICECOMBO_WIDTH(w)
#define WAVEOUT_FORMATCOMBO_HEIGHT    WAVEOUT_DEVICECOMBO_HEIGHT

#define WAVEOUT_LATENCYLABEL_X        WAVEOUT_FORMATLABEL_X
#define WAVEOUT_LATENCYLABEL_Y        (WAVEOUT_FORMATLABEL_Y + WAVEOUT_FORMATLABEL_HEIGHT + 8)
#define WAVEOUT_LATENCYLABEL_WIDTH(w)  DRIVERFRAME_WIDTH(w)
#define WAVEOUT_LATENCYLABEL_HEIGHT   (WAVEOUT_DEVICELABEL_HEIGHT)

#define WAVEOUT_LATENCYSLIDER_X        WAVEOUT_LATENCYLABEL_X
#define WAVEOUT_LATENCYSLIDER_Y        (WAVEOUT_LATENCYLABEL_Y + WAVEOUT_LATENCYLABEL_HEIGHT + 8) 
#define WAVEOUT_LATENCYSLIDER_WIDTH(w) DRIVERFRAME_WIDTH(w)
#define WAVEOUT_LATENCYSLIDER_HEIGHT   WAVEOUT_LATENCYLABEL_HEIGHT

void CWaveOutOptions::OnResize(int newWidth, int newHeight)
{
  DeviceCombo->Resize(WAVEOUT_DEVICECOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  FormatCombo->Resize(WAVEOUT_FORMATCOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  LatencySlider->Resize(WAVEOUT_LATENCYSLIDER_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  LatencyLabel->Resize(WAVEOUT_LATENCYLABEL_WIDTH(newWidth), WAVEOUT_LATENCYLABEL_HEIGHT);
  CControl::OnResize(newWidth, newHeight);
}

CWaveOutOptions::CWaveOutOptions(CAudioOutOptions *parent, int x, int y, int width, int height)
: CAudioOutDriverOptions(parent, "Wave Out Options", x, y, width, height)
{
  int i;

  DeviceLabel = new CLabel(this, "Device:", WAVEOUT_DEVICELABEL_X, WAVEOUT_DEVICELABEL_Y, WAVEOUT_DEVICELABEL_WIDTH, WAVEOUT_DEVICELABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  DeviceCombo = new CDropList(this, "Device", WAVEOUT_DEVICECOMBO_X, WAVEOUT_DEVICECOMBO_Y, WAVEOUT_DEVICECOMBO_WIDTH(Width), WAVEOUT_DEVICECOMBO_HEIGHT);

  FormatLabel = new CLabel(this, "Format:", WAVEOUT_FORMATLABEL_X, WAVEOUT_FORMATLABEL_Y, WAVEOUT_FORMATLABEL_WIDTH, WAVEOUT_FORMATLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  FormatCombo = new CDropList(this, "Format", WAVEOUT_FORMATCOMBO_X, WAVEOUT_FORMATCOMBO_Y, WAVEOUT_FORMATCOMBO_WIDTH(Width), WAVEOUT_FORMATCOMBO_HEIGHT);

  Driver = (CWaveOutDriver*)Core->AudioManager->GetOutputDriver(OUTPUT_DRIVER_WAVE);
  DeviceCount = Driver->GetDeviceCount();
  Device = Driver->GetDevice();

  for(i = 0; i < DeviceCount; i++)
    DeviceCombo->AddItem(Driver->GetDeviceName(i));

  DeviceFormats = 0;
  ShowDevice(Device);

  LatencyLabel = new CLabel(this, "Buffer:", WAVEOUT_LATENCYLABEL_X, WAVEOUT_LATENCYLABEL_Y, WAVEOUT_LATENCYLABEL_WIDTH(Width), WAVEOUT_LATENCYLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER); 
  
  LatencySlider = new CSlider(this, WAVEOUT_LATENCYSLIDER_X, WAVEOUT_LATENCYSLIDER_Y, WAVEOUT_LATENCYSLIDER_WIDTH(Width), WAVEOUT_LATENCYSLIDER_HEIGHT, SLIDER_HORIZONTAL);
  if(Device >= 0)
  {
    Latency = Driver->GetLatency();
    LatencySlider->SetValue(LatencyToValue(Latency, WAVE_MIN_LATENCY, WAVE_MAX_LATENCY, WAVE_GRANULARITY));
    SetLatencyLabel(LatencyLabel, Latency);
  }
  else
  {
    Latency = 0;
    LatencySlider->SetValue(0.0);
    SetLatencyLabel(LatencyLabel, Latency);
  }

  DeviceLabel->Show();
  DeviceCombo->Show();
  FormatLabel->Show();
  FormatCombo->Show();
  LatencyLabel->Show();
  LatencySlider->Show();
}

CWaveOutOptions::~CWaveOutOptions()
{
  delete DeviceLabel;
  delete DeviceCombo;
  delete FormatLabel;
  delete FormatCombo;
}

void CWaveOutOptions::ShowDevice(int device)
{
  const int firstFormat = WAVE_FORMAT_1M08;
  const int lastFormat  = WAVE_FORMAT_96S16;
  int       i, format, supportedFormats, currentFormat;
    
  if(DeviceFormats)
    delete DeviceFormats;

  FormatCombo->Clear();

  if(device < 0 || device >= DeviceCount)
    return;

  supportedFormats = Driver->GetDeviceFormats(device);
  currentFormat    = Driver->GetFormat();
  DeviceFormat     = 0;

  DeviceFormatCount = 0;
  for(format = firstFormat; format <= lastFormat; format <<= 1)
    if(format & supportedFormats)
      DeviceFormatCount++;

  i = 0;
  DeviceFormats = new int[DeviceFormatCount];

  for(format = firstFormat; format <= lastFormat; format <<= 1)
    if(format & supportedFormats)
    {
      char *text;

      DeviceFormats[i] = format;
      if(format == currentFormat)
        DeviceFormat = i;
      i++;
      text = Driver->DescribeFormat(format);
      FormatCombo->AddItem(text);
      delete text;
    }

  Device = device;
  DeviceCombo->SetSelection(device);
  FormatCombo->SetSelection(DeviceFormat);
}

void CWaveOutOptions::OnComboSelect(CDropList *comboBox)
{
  if(comboBox == DeviceCombo)
  {
    ShowDevice(DeviceCombo->GetSelection());
    OnChange();
  }

  if(comboBox == FormatCombo)
  {
    DeviceFormat = FormatCombo->GetSelection();
    OnChange();
  }
}

bool CWaveOutOptions::ApplyChanges()
{
  bool changed = false;

  if(!Driver)
    return false;

  if(Driver->GetDevice() == -1)
    return false;

  if(Driver->GetDevice() != Device)
  {
    Driver->SetDevice(Device);
    changed = true;
  }

  if(Driver->GetFormat() != DeviceFormats[DeviceFormat])
  {
    Driver->SetFormat(DeviceFormats[DeviceFormat]);
    changed = true;
  }

  if(Driver->GetLatency() != Latency)
  {
    Driver->SetLatency(Latency);
    changed = true;
  }

  return changed;
}

void CWaveOutOptions::OnSliderChange(CSlider *slider, double value)
{
  int newLatency;

  if(slider == LatencySlider)
  {
    newLatency = ValueToLatency(value, WAVE_MIN_LATENCY, WAVE_MAX_LATENCY, WAVE_GRANULARITY);
    if(newLatency != Latency)
    {
      Latency = newLatency;
      SetLatencyLabel(LatencyLabel, Latency);
      OnChange();
    }
  }
}
// DirectSound Options

#define DSOUND_DEVICELABEL_X         8
#define DSOUND_DEVICELABEL_Y         24
#define DSOUND_DEVICELABEL_WIDTH     48
#define DSOUND_DEVICELABEL_HEIGHT    20

#define DSOUND_DEVICECOMBO_X         (DSOUND_DEVICELABEL_X + DSOUND_DEVICELABEL_WIDTH + 8)
#define DSOUND_DEVICECOMBO_Y         DSOUND_DEVICELABEL_Y
#define DSOUND_DEVICECOMBO_WIDTH(w)  (w - (DSOUND_DEVICECOMBO_X + 8))
#define DSOUND_DEVICECOMBO_HEIGHT    16

#define DSOUND_FORMATLABEL_X         DSOUND_DEVICELABEL_X
#define DSOUND_FORMATLABEL_Y         (DSOUND_DEVICELABEL_Y + DSOUND_DEVICELABEL_HEIGHT + 8)
#define DSOUND_FORMATLABEL_WIDTH     DSOUND_DEVICELABEL_WIDTH
#define DSOUND_FORMATLABEL_HEIGHT    DSOUND_DEVICELABEL_HEIGHT

#define DSOUND_FORMATCOMBO_X         DSOUND_DEVICECOMBO_X
#define DSOUND_FORMATCOMBO_Y         DSOUND_FORMATLABEL_Y
#define DSOUND_FORMATCOMBO_WIDTH(w)  DSOUND_DEVICECOMBO_WIDTH(w)
#define DSOUND_FORMATCOMBO_HEIGHT    DSOUND_DEVICECOMBO_HEIGHT

#define DSOUND_LATENCYLABEL_X        DSOUND_FORMATLABEL_X
#define DSOUND_LATENCYLABEL_Y        (DSOUND_FORMATLABEL_Y + DSOUND_FORMATLABEL_HEIGHT + 8)
#define DSOUND_LATENCYLABEL_WIDTH(w)  DRIVERFRAME_WIDTH(w)
#define DSOUND_LATENCYLABEL_HEIGHT   (DSOUND_DEVICELABEL_HEIGHT)

#define DSOUND_LATENCYSLIDER_X        DSOUND_LATENCYLABEL_X
#define DSOUND_LATENCYSLIDER_Y        (DSOUND_LATENCYLABEL_Y + DSOUND_LATENCYLABEL_HEIGHT + 8) 
#define DSOUND_LATENCYSLIDER_WIDTH(w) DRIVERFRAME_WIDTH(w)
#define DSOUND_LATENCYSLIDER_HEIGHT   DSOUND_LATENCYLABEL_HEIGHT

void CDirectSoundOptions::OnResize(int newWidth, int newHeight)
{
  DeviceCombo->Resize(DSOUND_DEVICECOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  FormatCombo->Resize(DSOUND_FORMATCOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  LatencySlider->Resize(DSOUND_LATENCYSLIDER_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  LatencyLabel->Resize(DSOUND_LATENCYLABEL_WIDTH(newWidth), DSOUND_LATENCYLABEL_HEIGHT);
  CControl::OnResize(newWidth, newHeight);
}

CDirectSoundOptions::CDirectSoundOptions(CAudioOutOptions *parent, int x, int y, int width, int height)
: CAudioOutDriverOptions(parent, "DirectSound Options", x, y, width, height)
{
  int i;

  DeviceLabel = new CLabel(this, "Device:", DSOUND_DEVICELABEL_X, DSOUND_DEVICELABEL_Y, DSOUND_DEVICELABEL_WIDTH, DSOUND_DEVICELABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  DeviceCombo = new CDropList(this, "Device", DSOUND_DEVICECOMBO_X, DSOUND_DEVICECOMBO_Y, DSOUND_DEVICECOMBO_WIDTH(Width), DSOUND_DEVICECOMBO_HEIGHT);

  FormatLabel = new CLabel(this, "Format:", DSOUND_FORMATLABEL_X, DSOUND_FORMATLABEL_Y, DSOUND_FORMATLABEL_WIDTH, DSOUND_FORMATLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  FormatCombo = new CDropList(this, "Format", DSOUND_FORMATCOMBO_X, DSOUND_FORMATCOMBO_Y, DSOUND_FORMATCOMBO_WIDTH(Width), DSOUND_FORMATCOMBO_HEIGHT);

  Driver = (CDirectSoundDriver*)Core->AudioManager->GetOutputDriver(OUTPUT_DRIVER_DIRECT_SOUND);
  DeviceCount = Driver->GetDeviceCount();
  Device = Driver->GetDevice();

  for(i = 0; i < DeviceCount; i++)
    DeviceCombo->AddItem(Driver->GetDeviceName(i));

  DeviceFormats = 0;
  ShowDevice(Device);

  LatencyLabel = new CLabel(this, "Buffer:", DSOUND_LATENCYLABEL_X, DSOUND_LATENCYLABEL_Y, DSOUND_LATENCYLABEL_WIDTH(Width), DSOUND_LATENCYLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER); 
  
  LatencySlider = new CSlider(this, DSOUND_LATENCYSLIDER_X, DSOUND_LATENCYSLIDER_Y, DSOUND_LATENCYSLIDER_WIDTH(Width), DSOUND_LATENCYSLIDER_HEIGHT, SLIDER_HORIZONTAL);
  if(Device >= 0)
  {
    Latency = Driver->GetLatency();
    LatencySlider->SetValue(LatencyToValue(Latency, DSOUND_MIN_LATENCY, DSOUND_MAX_LATENCY, DSOUND_GRANULARITY));
    SetLatencyLabel(LatencyLabel, Latency);
  }
  else
  {
    Latency = 0;
    LatencySlider->SetValue(0.0);
    SetLatencyLabel(LatencyLabel, Latency);
  }

  DeviceLabel->Show();
  DeviceCombo->Show();
  FormatLabel->Show();
  FormatCombo->Show();
  LatencyLabel->Show();
  LatencySlider->Show();
}

CDirectSoundOptions::~CDirectSoundOptions()
{
  delete DeviceLabel;
  delete DeviceCombo;
  delete FormatLabel;
  delete FormatCombo;
  delete LatencyLabel;
  delete LatencySlider;
}

void CDirectSoundOptions::ShowDevice(int device)
{
  const int firstFormat = WAVE_FORMAT_1M08;
  const int lastFormat  = WAVE_FORMAT_96S16;
  int       i, format, supportedFormats, currentFormat;
    
  if(DeviceFormats)
    delete DeviceFormats;

  FormatCombo->Clear();

  if(device < 0 || device >= DeviceCount)
    return;

  supportedFormats = Driver->GetDeviceFormats(device);
  currentFormat    = Driver->GetFormat();
  DeviceFormat     = 0;

  DeviceFormatCount = 0;
  for(format = firstFormat; format <= lastFormat; format <<= 1)
    if(format & supportedFormats)
      DeviceFormatCount++;

  i = 0;
  DeviceFormats = new int[DeviceFormatCount];

  for(format = firstFormat; format <= lastFormat; format <<= 1)
    if(format & supportedFormats)
    {
      char *text;

      DeviceFormats[i] = format;
      if(format == currentFormat)
        DeviceFormat = i;
      i++;
      text = Driver->DescribeFormat(format);
      FormatCombo->AddItem(text);
      delete text;
    }

  Device = device;
  DeviceCombo->SetSelection(device);
  FormatCombo->SetSelection(DeviceFormat);
}

void CDirectSoundOptions::OnComboSelect(CDropList *comboBox)
{
  if(comboBox == DeviceCombo)
  {
    ShowDevice(DeviceCombo->GetSelection());
    OnChange();
  }

  if(comboBox == FormatCombo)
  {
    DeviceFormat = FormatCombo->GetSelection();
    OnChange();
  }
}

bool CDirectSoundOptions::ApplyChanges()
{
  bool changed = false;

  if(!Driver)
    return false;

  if(Driver->GetDevice() == -1)
    return false;

  if(Driver->GetDevice() != Device)
  {
    Driver->SetDevice(Device);
    changed = true;
  }

  if(Driver->GetFormat() != DeviceFormats[DeviceFormat])
  {
    Driver->SetFormat(DeviceFormats[DeviceFormat]);
    changed = true;
  }

  if(Driver->GetLatency() != Latency)
  {
    Driver->SetLatency(Latency);
    changed = true;
  }

  return changed;
}

void CDirectSoundOptions::OnSliderChange(CSlider *slider, double value)
{
  int newLatency;

  if(slider == LatencySlider)
  {
    newLatency = ValueToLatency(value, DSOUND_MIN_LATENCY, DSOUND_MAX_LATENCY, DSOUND_GRANULARITY);
    if(newLatency != Latency)
    {
      Latency = newLatency;
      SetLatencyLabel(LatencyLabel, Latency);
      OnChange();
    }
  }
}

// ASIO Out Options

#define ASIOOUT_DEVICELABEL_X         8
#define ASIOOUT_DEVICELABEL_Y         24
#define ASIOOUT_DEVICELABEL_WIDTH     48
#define ASIOOUT_DEVICELABEL_HEIGHT    20

#define ASIOOUT_DEVICECOMBO_X         (ASIOOUT_DEVICELABEL_X + ASIOOUT_DEVICELABEL_WIDTH + 8)
#define ASIOOUT_DEVICECOMBO_Y         ASIOOUT_DEVICELABEL_Y
#define ASIOOUT_DEVICECOMBO_WIDTH(w)  (w - (ASIOOUT_DEVICECOMBO_X + 8))
#define ASIOOUT_DEVICECOMBO_HEIGHT    16

#define ASIOOUT_FORMATLABEL_X         ASIOOUT_DEVICELABEL_X
#define ASIOOUT_FORMATLABEL_Y         (ASIOOUT_DEVICELABEL_Y + ASIOOUT_DEVICELABEL_HEIGHT + 8)
#define ASIOOUT_FORMATLABEL_WIDTH     ASIOOUT_DEVICELABEL_WIDTH
#define ASIOOUT_FORMATLABEL_HEIGHT    ASIOOUT_DEVICELABEL_HEIGHT

#define ASIOOUT_FORMATCOMBO_X         ASIOOUT_DEVICECOMBO_X
#define ASIOOUT_FORMATCOMBO_Y         ASIOOUT_FORMATLABEL_Y
#define ASIOOUT_FORMATCOMBO_WIDTH(w)  ASIOOUT_DEVICECOMBO_WIDTH(w)
#define ASIOOUT_FORMATCOMBO_HEIGHT    ASIOOUT_DEVICECOMBO_HEIGHT

#define ASIOOUT_LATENCYLABEL_X        ASIOOUT_FORMATLABEL_X
#define ASIOOUT_LATENCYLABEL_Y        (ASIOOUT_FORMATLABEL_Y + ASIOOUT_FORMATLABEL_HEIGHT + 8)
#define ASIOOUT_LATENCYLABEL_WIDTH(w) (DRIVERFRAME_WIDTH(w))
#define ASIOOUT_LATENCYLABEL_HEIGHT   (ASIOOUT_DEVICELABEL_HEIGHT)

#define ASIOOUT_LATENCYSLIDER_X        (ASIOOUT_LATENCYLABEL_X)
#define ASIOOUT_LATENCYSLIDER_Y        (NULLOUT_LATENCYLABEL_Y + ASIOOUT_LATENCYLABEL_HEIGHT + 8) 
#define ASIOOUT_LATENCYSLIDER_WIDTH(w) (DRIVERFRAME_WIDTH(w))
#define ASIOOUT_LATENCYSLIDER_HEIGHT   ASIOOUT_LATENCYLABEL_HEIGHT

#define ASIOOUT_CHANNELS_X            ASIOOUT_FORMATLABEL_X
#define ASIOOUT_CHANNELS_Y            (ASIOOUT_LATENCYSLIDER_Y + 24)
#define ASIOOUT_CHANNELS_WIDTH(w)     (DRIVERFRAME_WIDTH(w))
#define ASIOOUT_CHANNELS_HEIGHT       ASIOOUT_LATENCYLABEL_HEIGHT

void CASIOOutOptions::OnResize(int newWidth, int newHeight)
{
  DeviceCombo->Resize(ASIOOUT_DEVICECOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  FormatCombo->Resize(ASIOOUT_FORMATCOMBO_WIDTH(newWidth), COMBO_ITEMHEIGHT);
  ChannelsLabel->Resize(ASIOOUT_CHANNELS_WIDTH(newWidth), ASIOOUT_CHANNELS_HEIGHT);
  LatencyLabel->Resize(ASIOOUT_LATENCYLABEL_WIDTH(newWidth), ASIOOUT_LATENCYLABEL_HEIGHT);
  LatencySlider->Resize(ASIOOUT_LATENCYSLIDER_WIDTH(newWidth), ASIOOUT_LATENCYSLIDER_HEIGHT);
  CControl::OnResize(newWidth, newHeight);
}

CASIOOutOptions::CASIOOutOptions(CAudioOutOptions *parent, int x, int y, int width, int height)
: CAudioOutDriverOptions(parent, "ASIO Out Options", x, y, width, height)
{
  int i;

  DeviceFormats = 0;

  DeviceLabel = new CLabel(this, "Device:", ASIOOUT_DEVICELABEL_X, ASIOOUT_DEVICELABEL_Y, ASIOOUT_DEVICELABEL_WIDTH, ASIOOUT_DEVICELABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  DeviceCombo = new CDropList(this, "Device", ASIOOUT_DEVICECOMBO_X, ASIOOUT_DEVICECOMBO_Y, ASIOOUT_DEVICECOMBO_WIDTH(Width), ASIOOUT_DEVICECOMBO_HEIGHT);

  FormatLabel = new CLabel(this, "Format:", ASIOOUT_FORMATLABEL_X, ASIOOUT_FORMATLABEL_Y, ASIOOUT_FORMATLABEL_WIDTH, ASIOOUT_FORMATLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  FormatCombo = new CDropList(this, "Format", ASIOOUT_FORMATCOMBO_X, ASIOOUT_FORMATCOMBO_Y, ASIOOUT_FORMATCOMBO_WIDTH(Width), ASIOOUT_FORMATCOMBO_HEIGHT);

  ChannelsLabel = new CLabel(this, "Channels:", ASIOOUT_CHANNELS_X, ASIOOUT_CHANNELS_Y, ASIOOUT_CHANNELS_WIDTH(Width), ASIOOUT_CHANNELS_HEIGHT, DT_SINGLELINE | DT_VCENTER);
  
  Driver = (CASIODriver*)Core->AudioManager->GetOutputDriver(OUTPUT_DRIVER_ASIO);
  DeviceCount = Driver->GetDeviceCount();
  Device = Driver->GetDevice();

  for(i = 0; i < DeviceCount; i++)
    DeviceCombo->AddItem(Driver->GetDeviceName(i));

  ShowDevice(Device);

  LatencyLabel = new CLabel(this, "Buffer:", ASIOOUT_LATENCYLABEL_X, ASIOOUT_LATENCYLABEL_Y, ASIOOUT_LATENCYLABEL_WIDTH(Width), ASIOOUT_LATENCYLABEL_HEIGHT, DT_SINGLELINE | DT_VCENTER); 
  
  LatencySlider = new CSlider(this, ASIOOUT_LATENCYSLIDER_X, ASIOOUT_LATENCYSLIDER_Y, ASIOOUT_LATENCYSLIDER_WIDTH(Width), ASIOOUT_LATENCYSLIDER_HEIGHT, SLIDER_HORIZONTAL);
  if(Device >= 0)
  {
    Latency = Driver->GetLatency();
    LatencySlider->SetValue(LatencyToValue(Latency, Driver->GetMinBufferSize(Device), Driver->GetMaxBufferSize(Device), Driver->GetGranularity(Device)));
    SetLatencyLabel(LatencyLabel, Latency);
  }
  else
  {
    Latency = 0;
    LatencySlider->SetValue(0.0);
    SetLatencyLabel(LatencyLabel, Latency);
  }

  DeviceLabel->Show();
  DeviceCombo->Show();
  FormatLabel->Show();
  FormatCombo->Show();
  LatencyLabel->Show();
  LatencySlider->Show();
  ChannelsLabel->Show();
}

CASIOOutOptions::~CASIOOutOptions()
{
  delete ChannelsLabel;
  delete DeviceLabel;
  delete DeviceCombo;
  delete FormatLabel;
  delete FormatCombo;
}

void CASIOOutOptions::ShowDevice(int device)
{
  int i, format, supportedFormats, currentFormat, channels;
  char tmp[64];

  if(DeviceFormats)
    delete DeviceFormats;

  FormatCombo->Clear();

  if(device < 0 || device >= DeviceCount)
    return;

  supportedFormats = Driver->GetDeviceFormats(device);
  currentFormat    = Driver->GetFormat();
  DeviceFormat     = 0;

  DeviceFormatCount = 0;
  for(format = 1; format <= (1 << 5); format <<= 1)
    if(format & supportedFormats)
      DeviceFormatCount++;

  i = 0;
  DeviceFormats = new int[DeviceFormatCount];

  if(supportedFormats == 0)
  {
    char *text;

    DeviceFormats[i] = 0;
    DeviceFormat     = 0;
    text = Driver->DescribeFormat(DeviceFormat);
    FormatCombo->AddItem(text);
    delete text;
  }

  for(format = 1; format <= (1 << 5); format <<= 1)
    if(format & supportedFormats)
    {
      char *text;

      DeviceFormats[i] = format;
      if(format == currentFormat)
        DeviceFormat = i;
      i++;
      text = Driver->DescribeFormat(format);
      FormatCombo->AddItem(text);
      delete text;
    }

  Device = device;
  DeviceCombo->SetSelection(device);
  FormatCombo->SetSelection(DeviceFormat);

  channels = Driver->GetDeviceChannels(Device);
  sprintf(tmp, "Channels: %i", channels);
  ChannelsLabel->SetText(tmp);
}

void CASIOOutOptions::OnComboSelect(CDropList *comboBox)
{
  if(comboBox == DeviceCombo)
  {
    ShowDevice(DeviceCombo->GetSelection());
    OnChange();
  }

  if(comboBox == FormatCombo)
  {
    DeviceFormat = FormatCombo->GetSelection();
    OnChange();
  }
}

bool CASIOOutOptions::ApplyChanges()
{
  bool changed = false;

  if(Device != -1)
  {
	  if(Driver->GetDevice() != Device)
	  {
		  Driver->SetDevice(Device);
		  changed = true;
	  }

	  if(Driver->GetFormat() !=  DeviceFormats[DeviceFormat])
	  {
		  Driver->SetFormat(DeviceFormats[DeviceFormat]);
		  changed = true;
	  }

	  if(Driver->GetLatency() != Latency)
	  {
		  Driver->SetLatency(Latency);
		  changed = true;
	  }
  }

  return changed;
}

void CASIOOutOptions::OnSliderChange(CSlider *slider, double value)
{
  int newLatency;

  if(slider == LatencySlider)
  {
    newLatency = ValueToLatency(value, Driver->GetMinBufferSize(Device), Driver->GetMaxBufferSize(Device), Driver->GetGranularity(Device));
    if(newLatency != Latency)
    {
      Latency = newLatency;
      SetLatencyLabel(LatencyLabel, Latency);
      OnChange();
    }
  }
}

