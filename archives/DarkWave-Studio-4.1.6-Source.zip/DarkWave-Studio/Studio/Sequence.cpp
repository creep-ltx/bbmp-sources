/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "Sequence.h"

CSequence::CSequence(int length)
{
  Length = length;
  Tracks = new CArray<CSequenceTrack*>;
}

CSequence::~CSequence()
{
  delete Tracks;
}

void CSequence::AddTrack(CConnector *port)
{
  Tracks->AddItem(new CSequenceTrack(port));
}

CSequenceTrack::CSequenceTrack(CConnector *port)
{
  Port = port;
  DefaultPattern = 0;
  Events = new CArray<CSequenceEvent*>;
}

CSequenceTrack::~CSequenceTrack()
{
  delete Events;
}

void CSequenceTrack::AddEvent(CPattern *pattern, int start)
{
  Events->AddItem(new CSequenceEvent(pattern, start));
}

void CSequenceTrack::RemoveEvent(CSequenceEvent *event)
{
  int i;

  for(i = 0; i < Events->Count; i++)
  {
    if(Events->Items[i] == event)
    {
      Events->RemoveItem(i);
      break;
    }
  }
}

CSequenceEvent::CSequenceEvent(CPattern *pattern, int start)
{
  Pattern = pattern;
  Start = start;
}

CSequenceEvent::~CSequenceEvent()
{
}