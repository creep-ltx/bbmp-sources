/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MACHINE_LOADER_H
#define MACHINE_LOADER_H

#include "MachineLoaderEntry.h"
#include "Array.h"

class CMachineLoader
{
public:
       CMachineLoader();
      ~CMachineLoader();
  void SearchPath(char *path);
  void LoadDLL(char *path);
  void AddEntry(CMachineInfo *machineInfo);
  void CreateMachine(char *name, CMachine **machine, CMachineInfo **machineInfo);
  void Sort();
  int  MenuPathDepth(char *machinePath);
  void MenuPathItem(char *machinePath, int depth, char *pathItem);
  bool CompareMachineInfo(CMachineInfo *m1, CMachineInfo *m2);
  
  CArray<CMachineLoaderEntry*> *Entries;
};

#endif