/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "PeakMeter.h"
#include "Util.h"

#define HIGH_LEDS 4
#define MID_LEDS  4

const float MinPowerRatio = 3.051757813e-5f;
const float MaxPowerRatio = 32.0f; // 2^HIGH_LEDS
const float Inv1000       = 1.0f / 1000.0f;
const float FadeRate      = 48.0f; // dB / Second
const float MinDB         = -90.0f;
const float Scale         = 3.0f;
const float Delay         = 1.0f;

CPeakMeter::CPeakMeter(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "PeakMeter", x, y, width, height, true)
{
  PeakDBLeft = PeakDBRight = CurrentDBLeft = CurrentDBRight = MinDB;
  LastTickLeft = LastTickRight = 0;
  SetBorder(bs3DSunken);
  FrameBuffer = new CFrameBuffer(Width, Height, false);
  DrawControl();
}

CPeakMeter::~CPeakMeter()
{
  delete FrameBuffer;
}

void CPeakMeter::DrawLED(int x1, int y1, int height, int offset, COLORREF colors[3], bool on)
{
  int x, y, x2, y2;
  unsigned char *p, r, g, b;
  int color;

  if(offset < HIGH_LEDS)
    color = 2;
  else if(offset < HIGH_LEDS + MID_LEDS)
    color = 1;
  else
    color = 0;

  r = GetRValue(colors[color]);
  g = GetGValue(colors[color]);
  b = GetBValue(colors[color]);

  if(!on)
  {
    r = (0xFF >> 2) + (r >> 3);
    g = (0xFF >> 2) + (g >> 3);
    b = (0xFF >> 2) + (b >> 3);
  }

  x2 = x1 + PEAK_METER_LED_WIDTH - 1;
  y2 = y1 + height - 1;

  if(on)
  {
    x1 -= 1;
    x2 += 1;
    y1 -= 1;
    y2 += 1;
  }

  for(x = x1; x <= x2; x++)
  {
    for(y = y1; y <= y2; y++)
    {
      p = FrameBuffer->GetPixel3(x, y);
      if(on && ((x == x1 || x == x2) || (y == y1 || y == y2)))
      {
        p[0] += (r >> 2);
        p[1] += (g >> 2);
        p[2] += (b >> 2);
      }
      else
      {
        p[0] = r;
        p[1] = g;
        p[2] = b;
      }
    }
  }
}

void CPeakMeter::DrawBar(int x, int y, int ledHeight, int ledCount, double currentDB, double peakDB, double minDB, COLORREF colors[3])
{
  int    i;
  double dB1, dB2;
  bool   on;

  dB1 = minDB;

  for(i = 0; i < ledCount; i++)
  {
    dB2 = dB1 + Scale;

    on = (currentDB > dB1 || (peakDB > dB1 && peakDB <= dB2));
    DrawLED(x, y, ledHeight, ledCount - (i + 1), colors, on);

    x += PEAK_METER_LED_WIDTH + PEAK_METER_LED_GAP;
    dB1 = dB2;
  }
}

void CPeakMeter::DrawControl()
{
  int x, y, ledAreaWidth, leds, ledWidth, ledHeight;
  COLORREF colors[3];
  float minDB;

  colors[0] = ColorManager->GetColor((ColorManagerColor)MeterLow);
  colors[1] = ColorManager->GetColor((ColorManagerColor)MeterMid);
  colors[2] = ColorManager->GetColor((ColorManagerColor)MeterHigh);

  FrameBuffer->Fill(0);

  ledWidth     = (PEAK_METER_LED_WIDTH + PEAK_METER_LED_GAP); 
  ledAreaWidth = Width - (PEAK_METER_BORDER_H * 2);
  leds         = ledAreaWidth / ledWidth;
  ledHeight    = (Height - (PEAK_METER_BORDER_V * 3)) >> 1;
  minDB        = (leds - HIGH_LEDS) * -Scale;

  x = PEAK_METER_BORDER_H;
  y = PEAK_METER_BORDER_V;
  DrawBar(x, y, ledHeight, leds, CurrentDBLeft, PeakDBLeft, minDB, colors);

  y += ledHeight + PEAK_METER_BORDER_V;
  DrawBar(x, y, ledHeight, leds, CurrentDBRight, PeakDBRight, minDB, colors);

  FrameBuffer->Draw(GetBackBuffer());
}

double CPeakMeter::ClipPeakToDB(double value)
{
  double dB;

  //if(value < MinPowerRatio)
  //  dB = MinDB;
  //else
  //{
  //  if(value > MaxPowerRatio)
  //    value = MaxPowerRatio;
    dB = PowerRatioTodB(value);
  //}
  return dB;
}

void CPeakMeter::MaxPeakDB(double newDB, double &oldDB, DWORD &lastTick)
{
  if(newDB > oldDB)
  {
    oldDB    = newDB;
    lastTick = 0;
  }
}

void CPeakMeter::SetPeak(double left, double right)
{
  double dBLeft, dBRight;

  dBLeft  = ClipPeakToDB(left);
  dBRight = ClipPeakToDB(right);

  MaxPeakDB(dBLeft,  PeakDBLeft,  LastTickLeft);
  MaxPeakDB(dBRight, PeakDBRight, LastTickRight);
  CurrentDBLeft  = dBLeft;
  CurrentDBRight = dBRight;
}

void CPeakMeter::IdleInner(DWORD &lastTick, DWORD thisTick, double &peakDB)
{
  double thisDB, interval;

  if(lastTick == 0 || thisTick < lastTick)
  {
    thisDB = peakDB;
    lastTick = thisTick;
  }
  else
  {
    interval = ((float)thisTick - lastTick) * Inv1000;
    if(interval > Delay)
    {
      thisDB = peakDB - ((interval - Delay) * FadeRate);
      lastTick = thisTick - (int)(Delay * 1000.0);
    }
    else
    {
      thisDB = peakDB;
    }
    if(thisDB < MinDB)
      thisDB = MinDB;
  }
  peakDB = thisDB;
  KillDenormal(peakDB);
}

void CPeakMeter::Idle()
{
  DWORD thisTick;

  thisTick = GetTickCount();
  IdleInner(LastTickLeft,  thisTick, PeakDBLeft);
  IdleInner(LastTickRight, thisTick, PeakDBRight);
  Redraw();
}

void CPeakMeter::Redraw()
{
  DrawControl();
  OnPaint();
}