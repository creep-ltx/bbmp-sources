/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Window.h"

#define WINDOW_CLASS_NAME "DarkWaveWindow"

ATOM WindowClass = 0;

LRESULT CALLBACK WindowProcedure(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  CWindow *window;

#ifdef WIN64
  window = (CWindow*)(GetWindowLongPtr(hWnd, GWLP_USERDATA));
#else
  window = (CWindow*)(GetWindowLong(hWnd, GWL_USERDATA));
#endif

  if(window == 0)
    return DefWindowProc(hWnd, msg, wParam, lParam);
  else
    return window->WindowProc(hWnd, msg, wParam, lParam);
};

void RegisterWindowClass()
{
  WNDCLASSEXA wndClass;

  memset(&wndClass, 0, sizeof(WNDCLASSEX));
  
  wndClass.cbSize         = sizeof(WNDCLASSEX);
  wndClass.style          = CS_DBLCLKS | CS_HREDRAW | CS_OWNDC | CS_VREDRAW;
  wndClass.lpfnWndProc    = WindowProcedure;
  wndClass.hInstance      = AppInstance;
  wndClass.lpszClassName  = WINDOW_CLASS_NAME;
  wndClass.hCursor        = LoadCursor(0, IDC_ARROW);

  WindowClass = RegisterClassExA(&wndClass);
  if(!WindowClass)
    throw "Can't Register Window Class";
}

CWindow::CWindow(char *name, int width, int height, CColorManager *colorManager)
: CControl(colorManager)
{
  Parent = 0;
  Init(name, CW_USEDEFAULT, 0, width, height, WS_CLIPCHILDREN | WS_CAPTION | WS_SIZEBOX | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX, 0, false);
}

void CWindow::SetText(char *text)
{
  SetWindowTextA(Handle, text);
}

CWindow::CWindow(CColorManager *colorManager)
: CControl(colorManager)
{
  Parent = 0;
}

void CWindow::Init(char *name, int x, int y, int width, int height, int style, int exStyle, bool adjust)
{
  HWND  parent;
  RECT  r;

  X = x;
  Y = y;

  Border = false;

  Handle = 0;
  DC = 0;

  if(WindowClass == 0)
    RegisterWindowClass();
  
  if(Parent != 0)
    parent = Parent->Handle;
  else
    parent = 0;

  r.left   = 0;
  r.top    = 0;
  r.right  = width - 1;
  r.bottom = height - 1;

  if(adjust)
    AdjustWindowRectEx(&r, style, FALSE, exStyle);

  Handle = CreateWindowExA(exStyle, WINDOW_CLASS_NAME, name, 
    style, x + r.left, y + r.top, r.right - r.left, r.bottom - r.top, 
    parent, NULL, AppInstance, NULL);

  DC = GetDC(Handle);
  Width = width;
  Height = height;
  //GetWindowOrgEx(DC, &windowPos);
  //X = windowPos.x;
  //Y = windowPos.y;

#ifdef WIN64
  SetWindowLongPtr(Handle, GWLP_USERDATA, (LONG_PTR)this);
#else
  SetWindowLong(Handle, GWL_USERDATA, (LONG)this);
#endif
}

CWindow::~CWindow()
{
  DestroyWindow(Handle);
  Handle = 0;
}

void CWindow::OnClose()
{
}

LRESULT CWindow::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_CLOSE:
    {
      OnClose();
      return 0;
    }
  }

  return CControl::WindowProc(hWnd, msg, wParam, lParam);
}
