/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "SampleView.h"
#include "FFT.h"
#include "Complex.h"
#include "Wave.h"
#include <math.h>

#define FFT_LOOPS  1
#define FFT_POINTS 256

CSampleView::CSampleView(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "SampleView", x, y, width, height, true)
{
  Sample = 0;
  SubInit = true;
  SetBorder(bs3DSunken);
  Mode = SAMPLE_VIEW_MODE_SCOPE;
  FFTPoints = 0;
  FFTData = 0;
  DrawControl();
}

CSampleView::~CSampleView()
{
  if(Sample != 0)
    delete Sample;

  if(FFTData != 0)
    delete FFTData;
}

void CSampleView::DrawControl()
{
  HDC hDC;

  hDC = BackDC;

  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)LCDBack)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();
  
  if(Sample != 0)
  {
    if(Mode == SAMPLE_VIEW_MODE_SCOPE)
      DrawWaveform(hDC);
    if(Mode == SAMPLE_VIEW_MODE_SPECTRUM)
      DrawSpectrum(hDC);
  }
}

void CSampleView::DrawWaveform(HDC hDC)
{
  int     samples;
  int     x, y;
  double  sample, sampleInc, value;
  HGDIOBJ oldPen;

  sample = 0.0f;
  samples = Sample->Samples;
  sampleInc = (float)samples / (float)Width;

  ColorManager->Lock();
  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)LCDLight)->Handle);

  for(x = 0; x < Width; x++)
  {
    value = Sample->MonoData[(int)sample];
    y = (int)((((-value) + 1.0f) * 0.5f) * (Height - 1));
    if(x == 0)
      MoveToEx(hDC, 0, y, NULL);
    LineTo(hDC, x, y);
    sample += sampleInc;
  }

  SelectObject(hDC, oldPen);
  ColorManager->Release();
}

void CSampleView::SetSample(CSample *sample)
{
  if(Sample != 0)
    Sample = 0;
  Sample = sample->Clone();
  if(Mode == SAMPLE_VIEW_MODE_SPECTRUM)
    PerformFFT();
  Update();
}

void CSampleView::SetMode(int mode)
{
  if(mode != Mode)
  {
    Mode = mode;
    if(Mode == SAMPLE_VIEW_MODE_SPECTRUM)
      PerformFFT();
    else
    {
      if(FFTData)
        delete FFTData;
      FFTData = 0;
      FFTPoints = 0;
    }
    Update();
  }
}

void CSampleView::PerformFFT()
{
  double  phase, phaseStep, *complex;
  int     i, it2;
  CWave  *wave;

  if(FFTData != 0)
  {
    delete FFTData;
    FFTData = 0;
    FFTPoints = 0;
  }

  if(Sample != 0)
  {  
    wave = new CWave(Sample->Samples);
    for(i = 0; i < Sample->Samples; i++)
      wave->Data[i] = Sample->MonoData[i];
    phase = 0.0f;
    FFTPoints = FFT_POINTS;
    phaseStep = (1.0f / (float)FFTPoints) * (float)FFT_LOOPS;

    FFTData = new double[FFTPoints];
    complex = new double[FFTPoints * 2];

    for(i = 0; i < FFTPoints; i++)
    {
      it2 = i * 2;
      complex[it2] = wave->GetSample(phase);
      complex[it2 + 1] = 0.0f;
      phase += phaseStep;
      while(phase > 1.0f)
        phase -= 1.0f;
    }
    FFT(complex, FFTPoints);

    for(i = 0; i < FFTPoints; i++)
    {
      it2 = i * 2;
      FFTData[i] = cabs(complex[it2], complex[it2 + 1]);
    }

    delete complex;
    delete wave;
  }
}

double clip(double value)
{
  value = fabs(value);
  return value;
}

void CSampleView::DrawSpectrum(HDC hDC)
{
  int     samples;
  int     x, y, i;
  double  value, maxValue;
  HGDIOBJ oldPen;

  samples = FFTPoints / 2;

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)LCDLight)->Handle);

  maxValue = 0.0f;
  for(i = 0; i < samples; i++)
  {
    value = clip(FFTData[i]);
    if(value > maxValue)
      maxValue = value;
  }
  maxValue = 1.0f / maxValue;

  for(i = 0; i < Width; i++)
  {
    value = clip(FFTData[(i * samples) / Width]) * maxValue;
    x = i;
    y = (int)((1.0f - value) * (Height - 1));
    if(x == 0)
      MoveToEx(hDC, x, y, NULL);
    LineTo(hDC, x, y);
  }

  SelectObject(hDC, oldPen);
}