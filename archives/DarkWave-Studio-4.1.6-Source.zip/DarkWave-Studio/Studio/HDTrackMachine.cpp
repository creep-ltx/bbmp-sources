/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "HDTrackMachine.h"
#include "Core.h"

CHDTrackMachine::CHDTrackMachine(CHost *host, bool stereo)
: CMachine(host)
{
  int i;

  BlockSamples = host->GetBlockSamples();
  Stereo = stereo;
  Ports = new CPort*[2];
  Ports[0] = new CPort(host, this, PT_AUDIO | PT_INPUT  | (stereo ? PT_STEREO : 0), "Line In");
  Ports[1] = new CPort(host, this, PT_AUDIO | PT_OUTPUT | (stereo ? PT_STEREO : 0), "Line Out");
  PortCount = 2;

  i = Core->MainWindow->HDRecorder->AddTrack(this);
  Track = Core->MainWindow->HDRecorder->TrackList->Items->Items[i];
}

CHDTrackMachine::~CHDTrackMachine()
{
  delete Ports[0];
  delete Ports[1];
  delete Ports;
  Core->MainWindow->HDRecorder->RemoveTrack(this);
  Track = 0;
}

#define HDTRACKDATA_MAGIC 'HDTM'

struct SHDTrackData
{
  int  Magic;
  char Name[1024];
};

void DARKCALL CHDTrackMachine::ReadProperties(char *data, int length, bool isInner)
{
  if(!isInner)
  {
    SHDTrackData *d;

    if(length >= sizeof(SHDTrackData))
    {
      d = (SHDTrackData*)data;
      if(d->Magic == HDTRACKDATA_MAGIC)
      {
        Track->SetFileName(d->Name);
      }
    }
  }
}

void DARKCALL CHDTrackMachine::WriteProperties(char **data, int *length, bool *isInner)
{
  *length = sizeof(SHDTrackData);
  *data = new char[*length]; 

  SHDTrackData *d;

  d = (SHDTrackData*)*data;
  memset(d, 0, sizeof(SHDTrackData));

  d->Magic = HDTRACKDATA_MAGIC;
  Track->GetFileName(d->Name);

  *isInner = false;
}

bool CHDTrackMachine::IsSynth()
{
  return false;
}

void CHDTrackMachine::SetName(char *name)
{
  CMachine::SetName(name);
  Track->SetName(name);
}

void CHDTrackMachine::Work()
{
  double  *f1, *f2, *f3, *f4;
  int    i;

  Track->Lock();
  if(Stereo)
    Track->Write(BlockSamples, Ports[0]->AudioBuffer->LeftData, Ports[0]->AudioBuffer->RightData);
  else
    Track->Write(BlockSamples, Ports[0]->AudioBuffer->MonoData);
  Track->Release();
  
  if(Stereo)
  {
    f1 = Ports[0]->AudioBuffer->LeftData;
    f2 = Ports[0]->AudioBuffer->RightData;
    f3 = Ports[1]->AudioBuffer->LeftData;
    f4 = Ports[1]->AudioBuffer->RightData;
    
    for(i = 0; i < BlockSamples; i++)
    {
      *(f3++) = *(f1++);
      *(f4++) = *(f2++);
    }
  }
  else
  {
    f1 = Ports[0]->AudioBuffer->MonoData;
    f2 = Ports[1]->AudioBuffer->MonoData;
    
    for(i = 0; i < BlockSamples; i++)
    {
      *(f2++) = *(f1++);
    }
  }
}

void CHDTrackMachine::SetSampleRate(int sampleRate)
{
  SampleRate = sampleRate;
}

void CHDTrackMachine::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

CHDTrackMachineInfoMono::CHDTrackMachineInfoMono()
{
  Name = "ES HD Recorder Track (Mono)";
  UniqueID = "DarkPlug::ES HD Recorder Track (Mono)";
}

CMachine* CHDTrackMachineInfoMono::CreateMachine()
{
  return new CHDTrackMachine(Core->Host, false);
}

CHDTrackMachineInfoStereo::CHDTrackMachineInfoStereo()
{
  Name = "ES HD Recorder Track (Stereo)";
  UniqueID = "DarkPlug::ES HD Recorder Track (Stereo)";
}

CMachine* CHDTrackMachineInfoStereo::CreateMachine()
{
  return new CHDTrackMachine(Core->Host, true);
}