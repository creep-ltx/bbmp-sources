/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "AntiAliasFilter.h"
#include "Core.h"

#ifdef COREMACHINES
#include "../Resource.h"
#else
#include "../../AntiAlias-VST/Resource.h"
#endif

#include "Util.h"
#include "PI.h"
#include <stdio.h>
#include <math.h>
#include "Sinc.h"
#include "MinimumPhase.h"
#include "FFT.h"
#include "Complex.h"
#include <math.h>

class CAntiAliasFilterGUI;

#define PROPERTY_FORMAT_OVERSAMPLING 0

#define PROPERTY_FORMAT_COUNT      1

#define PROPERTY_ANTIALIASFILTER_OVERSAMPLING 0

#define PROPERTY_COUNT                        1

const char* AntiAliasFilterPropertyNames[PROPERTY_COUNT] = 
{
  "Oversampling"
};

const double AntiAliasFilterPropertyDefaults[PROPERTY_COUNT] = 
{
  0.0 // Oversampling
};

const int PropertyFormat[PROPERTY_COUNT] = 
{
  PROPERTY_FORMAT_OVERSAMPLING // Oversampling
};


CAntiAliasFilter::CAntiAliasFilter(CHost *host, CAntiAliasFilterInfo *info)
: CMachine(host)
{
  int i;

  GUI = 0;
  nSamples  = 0;

  SampleRate   = host->GetSampleRate();
  BlockSamples = host->GetBlockSamples();

  GenerateFIRs();
  
  Info = info;
  
  Ports = new CPort*[2];
  Ports[0] = new CPort(host, this, PT_INPUT | PT_AUDIO | PT_STEREO, "Line In");
  Ports[1] = new CPort(host, this, PT_OUTPUT | PT_AUDIO | PT_STEREO,  "Line Out");
  PortCount = 2;

  PropertyCount = PROPERTY_COUNT;
  
  Properties = new double[PropertyCount];
  for(i = 0; i < PropertyCount; i++)
    SetProperty(i, AntiAliasFilterPropertyDefaults[i]);

  //ProgramCount = 1;
  //Program      = 0;
  //Programs     = new CProgram*[1];
  //Programs[0]  = new CProgram(1, 0, this);
  //strcpy(Programs[0]->Name, "Default");  
}

CAntiAliasFilter::~CAntiAliasFilter()
{
  if(GUI != 0)
    delete GUI;
  delete Ports[0];
  delete Ports[1];
  delete Ports;
}

void CAntiAliasFilter::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
  ResizeAudioPorts(blockSamples);
}

void CAntiAliasFilter::SetSampleRate(int sampleRate)
{
  SampleRate = sampleRate;
}

void CAntiAliasFilter::Work()
{
  int             i, os, os2, j;
  double          *leftOut, *rightOut;
  double          *leftIn, *rightIn;

  leftIn  = Ports[0]->AudioBuffer->LeftData;
  rightIn = Ports[0]->AudioBuffer->RightData;

  leftOut  = Ports[1]->AudioBuffer->LeftData;
  rightOut = Ports[1]->AudioBuffer->RightData;

  os = (int)(Properties[PROPERTY_ANTIALIASFILTER_OVERSAMPLING] * (4.0f));
  os2 = 2 << os;
  for(i = 0; i < BlockSamples; i++)
  {
    leftOut[i] = rightOut[i] = 0.0;
    Filters[os]->Process(leftIn[i],  rightIn[i], leftOut + i, rightOut + i);
    for(j = 1; j < os2; j++)
      (Filters[os])->Process(0.0, 0.0);
  }
}

void CAntiAliasFilter::GenerateFIRs()
{
  int i;

  Filters = new CStereoFIR*[5];

  for(i = 0; i < 5; i++)
  {
    Filters[i] = CreateFIR(8, 2 << i);
  }
}

CStereoFIR* CAntiAliasFilter::CreateFIR(int zc, int oversampling)
{
  const int os   = oversampling;
  const int sos  = 2;
  const int bs   = 4096;
  const int loop = 256;

  int    i, n, sn, sn2, nfft;
  double  r, a, b;
  double *sinc, *window, *windowedSinc, *realCepstrum, *minimumPhase; //, *signal, *oversampled, *fftfilter, *ifftsignal;

  n    = (os * (zc * 2)) + 1;
  sn   = (n - 1) >> sos;
  sn2  = (n - 1);
  nfft = (n - 1) * 2;

  // Generate Sinc

  sinc = new double[n];
  a = (double)-zc;
  b = (double)zc;
  for(i = 0; i < n; i++)
  {
    r = ((double)i) / ((double)(n - 1));
    sinc[i] = SINC(a + (r * (b - a)));
  }

  // Generate Window

  window = new double[n];
  BlackmanWindow(n, window);

  // Generate Windowed Sinc

  windowedSinc = new double[n];
  for(i = 0; i < n; i++)
    windowedSinc[i] = sinc[i] * window[i];

  //// Generate Real Cepstrum

  realCepstrum = new double[n];
  RealCepstrum(n, windowedSinc, realCepstrum);

  //// Generate Minimum Phase Reconstruction

  minimumPhase = new double[n];
  MinimumPhase(n, realCepstrum, minimumPhase);

  //// Generate FFT Filter Kernel

  //fftfilter = new double[nfft];
  //for(i = 0; i < sn2; i++)
  //{
  //  fftfilter[i << 1] = minimumPhase[i];
  //  fftfilter[(i << 1) + 1] = 0.0f;
  //}
  //FFT(fftfilter, sn2);
  
  CStereoFIR *filter;

  filter = new CStereoFIR(n, minimumPhase, minimumPhase, false);
  filter->Ping(os);

  //delete fftfilter;
  delete minimumPhase;
  delete realCepstrum;
  delete windowedSinc;
  delete window;
  delete sinc;

  return filter;
}

void CAntiAliasFilter::ProcessMessage(SControlMessage *message)
{
  switch(message->Type)
  {
    case CONTROL_MESSAGE_CONTROL_CHANGE:
    {
      SetPropertyAutomated(message->ControlChange.Controller,
        message->ControlChange.Value);
      break;
    }
  }
}

void CAntiAliasFilter::GetPropertyName(int index, char *text)
{
  if((index >= 0) && (index < PROPERTY_COUNT))
    strcpy(text, AntiAliasFilterPropertyNames[index]);
  else
    *text = 0;
}

void CAntiAliasFilter::GetPropertyValueDisplay(int index, double value, char *text)
{
  if((index >= 0) && (index < PROPERTY_COUNT))
    switch(PropertyFormat[index])
    {
      case PROPERTY_FORMAT_OVERSAMPLING:
        sprintf(text, "%ix", (int)pow(2.0, (double)(1 + (int)(value * 4.0))));
        break;

      default:
        *text = 0;
        break;
    }
  else
    *text = 0;
}

double CAntiAliasFilter::GetProperty(int index)
{
  if((index >= 0) && (index < PROPERTY_COUNT))
    return Properties[index];
  else
    return 0.0f;
}

void CAntiAliasFilter::SetProperty(int index, double value)
{
  if(index >= 0 && index < PROPERTY_COUNT)
  {
    Properties[index] = value;
    if(GUI != 0)
      GUI->SetProperty(index, value);
  }
}

HWND CAntiAliasFilter::CreateGUI(HWND parent)
{ 
  if(GUI != 0)
  {
    delete GUI;
    GUI = 0;
  }

  if(GUI == 0)
  {
    GUI = new CAntiAliasFilterGUI(parent, this, Info);
  }
  return GUI->Handle;
}

bool CAntiAliasFilter::IsSynth()
{
  return false;
}

CAntiAliasFilterInfo::CAntiAliasFilterInfo(CHost *host)
{
  Host     = host;
  Name     = "ES AntiAlias";
  UniqueID = "DarkPlug::ES AntiAlias";
  
  Background = new CFrameBuffer(IDR_ANTIALIAS_BACKGROUND);
  ButtonsOn  = new CFrameBuffer(IDR_ANTIALIAS_BUTTONS_ON);
  ButtonsOff = new CFrameBuffer(IDR_ANTIALIAS_BUTTONS_OFF);
}

CAntiAliasFilterInfo::~CAntiAliasFilterInfo()
{
  delete Background;
  delete ButtonsOn;
  delete ButtonsOff;
}

CMachine *CAntiAliasFilterInfo::CreateMachine()
{
  return new CAntiAliasFilter(Host, this);
}

CAntiAliasFilterGUI::CAntiAliasFilterGUI(HWND parent, CAntiAliasFilter *filter, CAntiAliasFilterInfo *info)
: CLiteContainer(parent, info->Background->GetWidth(), info->Background->GetHeight(), info->Background)
{
  int i;

  AntiAliasFilter = filter;
  Info = info;
  Button = (int)(filter->GetProperty(PROPERTY_ANTIALIASFILTER_OVERSAMPLING) * 4.0);

  for(i = 0; i < 5; i++)
  {
    ButtonArea[i].x1 = 44 + (i * 40);
    ButtonArea[i].x2 = ButtonArea[i].x1 + 27;
    ButtonArea[i].y1 = 54;
    ButtonArea[i].y2 = ButtonArea[i].y1 + 27;
  }

  Render();
  Show();
  ShowWindow(Handle, SW_SHOW);
}

CAntiAliasFilterGUI::~CAntiAliasFilterGUI()
{
}

void CAntiAliasFilterGUI::SetProperty(int index, double value)
{
  if(index == PROPERTY_ANTIALIASFILTER_OVERSAMPLING)
  {
    Button = (int)(value * 4.0f);
    Render();
  }
}

void CAntiAliasFilterGUI::OnLeftButtonDown(int x, int y)
{
  int i;

  for(i = 0; i < 5; i++)
    if((ButtonArea[i].x1 <= x) && (ButtonArea[i].x2 >= x)
      && (ButtonArea[i].y1 <= y) && (ButtonArea[i].y2 >= y))
    {
      AntiAliasFilter->Lock();
	    Lock();
      AntiAliasFilter->SetPropertyAutomated(0, i * 0.25f);
      AntiAliasFilter->Release();
	    Release();
    }
}

bool CAntiAliasFilter::GetGUIRect(short *x1, short *y1, short *x2, short *y2)
{
  *x1 = 0;
  *x2 = Info->Background->GetWidth();
  *y1 = 0;
  *y2 = Info->Background->GetHeight();
  return true;
}

void CAntiAliasFilter::OnShowGUI()
{
  if(GUI != 0)
    GUI->OnShowGUI();
}

void CAntiAliasFilterGUI::OnShowGUI()
{
  Render();
  Show();
}

void CAntiAliasFilterGUI::DrawBackground(int x1, int y1, int x2, int y2, int w, int h)
{
  int i;
  CFrameBuffer *src;
  bool on;

  Info->Background->Draw(RenderBuffer, x1, y1, x1, y1, w, h);

  for(i = 0; i < 5; i++)
  {
    on = (Button == i);
    src = on ? Info->ButtonsOn : Info->ButtonsOff;
    src->Draw(RenderBuffer, ButtonArea[i].x1 + (on ? 0 : 0), ButtonArea[i].y1 + (on ? 0 : 0), (i * 40), 0, 28, 28);
  }
}