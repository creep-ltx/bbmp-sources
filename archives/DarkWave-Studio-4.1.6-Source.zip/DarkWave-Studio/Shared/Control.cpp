/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include "Control.h"
#include "Brush.h"
#include "Font.h"
#include "BackBuffer.h"
#include "Error.h"
#include "LiteContainer.h"

#ifndef GET_X_LPARAM
#define GET_X_LPARAM(lParam)	((int)(short)LOWORD(lParam))
#endif
#ifndef GET_Y_LPARAM
#define GET_Y_LPARAM(lParam)	((int)(short)HIWORD(lParam))
#endif

#ifdef DARKPLUG_HOST
  #define CONTROL_CLASS_NAME "DarkWaveControl"
#else
  #define CONTROL_CLASS_NAME "DarkPlugControl"
#endif

ATOM ControlClass = 0;

LRESULT CALLBACK ControlProcedure(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  CControl *control;
 
  if(msg == WM_NCCREATE)
  {
    DefWindowProc(hWnd, msg, wParam, lParam);
    return (LRESULT)TRUE;
  }

  if(msg == WM_LBUTTONDOWN)
  {
    if(GetFocus() != hWnd)
      SetFocus(hWnd);
  }
  
#ifdef WIN64
  control = (CControl*)(GetWindowLongPtr(hWnd, GWLP_USERDATA));
#else
  control = (CControl*)(GetWindowLong(hWnd, GWL_USERDATA));
#endif
  if(control)
    return control->WindowProc(hWnd, msg, wParam, lParam);
  else
    return DefWindowProc(hWnd, msg, wParam, lParam);
};

static int Count = 0;
char ClassName[32];

void RegisterControlClass()
{
  WNDCLASSEXA wndClass;

  if(ControlClass != 0)
    return;

  sprintf(ClassName, "ESControl_0x%x", GetTickCount());
  memset(&wndClass, 0, sizeof(WNDCLASSEXA));

  wndClass.cbSize         = sizeof(WNDCLASSEXA);
  wndClass.style          = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW | CS_OWNDC | CS_GLOBALCLASS;
  wndClass.lpfnWndProc    = ControlProcedure;
  wndClass.hInstance      = AppInstance;
  wndClass.lpszClassName  = ClassName;
  wndClass.hCursor        = LoadCursor(0, IDC_ARROW);

  ControlClass = RegisterClassExA(&wndClass) && 0x0000FFFF;
}

void CControl::OnIconListSelectItem(int index)
{
}

void CControl::Init()
{
  SubInit = false;
  Border = false;
  BorderStyle = bs3DRaised;
  Handle = 0;
  DC = BackDC = 0;
  BackBuffer = 0;
  if(Parent != 0)
  {
    Font = Parent->Font;
    OwnFont = false;
  }
  else
  {
    Font = 0;
    OwnFont = true;
  }

  BackColor = (ColorManagerColor)ControlBack;
}

CControl::CControl(CColorManager *colorManager)
{
  X = Y = Width = Height = 0;
  Texture = 0;
  Parent = 0;
  ColorManager = colorManager;
  Init();
}

void CControl::MakeWindow(HWND parent, char *name, int x, int y, int width, int height)
{
  if(ControlClass == 0)
    RegisterControlClass();

  if(!IsWindow(parent))
    throw "MakeWindow: IsWindow == False";

  Handle = CreateWindowA(ClassName, name, WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, x, y, width, height, 
    parent, NULL, AppInstance, 0);

  if(Handle == 0)
    DisplayError("CreateWindowA Failed: 0x%x", GetLastError());

  DC = GetDC(Handle);

  X = x;
  Y = y;
  Width = width;
  Height = height;

  if(Font == 0)
    SetFont(new CFont(DC, "Verdana", 9.0f, false));

#ifdef WIN64
  SetWindowLongPtr(Handle, GWLP_USERDATA, (LONG_PTR)this);
#else
  SetWindowLong(Handle, GWL_USERDATA, (LONG)this);
#endif
}

CControl::CControl(CControl *parent, char* name, int x, int y, int width, int height, bool backBuffer)
{ 
  X = x;
  Y = y;
  Width = width;
  Height = height;
  Texture = 0;
  BackBuffer = 0;
  Parent = parent;
  if(Parent)
    Texture = parent->Texture;
  ColorManager = parent->ColorManager;
  Init();
  MakeWindow(parent->Handle, name, x, y, width, height);
  if(backBuffer)
    MakeBackBuffer();
#ifdef _DEBUG
	#ifdef WIN64
	  if(Font == (CFont*)0xCDCDCDCDCDCDCDCD)
	#else
	  if(Font == (CFont*)0xCDCDCDCD)
	#endif
		throw "Bad Font";
#endif
}

CControl::CControl(HWND parent, CColorManager *colorManager, char *name, int x, int y, int width, int height, bool backBuffer)
{
  Texture = 0;
  X = x;
  Y = y;
  Width = width;
  Height = height;
  Parent = 0;
  ColorManager = colorManager;
  Init();
  MakeWindow(parent, name, x, y, width, height);
  if(backBuffer)
    MakeBackBuffer();
}

void CControl::MakeBackBuffer()
{
  BackBuffer = new CBackBuffer(DC, Width, Height);
  BackDC = BackBuffer->DC;
}

CControl::~CControl()
{
  SetFont(0);
  if(Handle != 0)
{
#ifdef WIN64
  SetWindowLong(Handle, GWLP_USERDATA, 0);
#else
  SetWindowLong(Handle, GWL_USERDATA, 0);
#endif
  DestroyWindow(Handle);
}
}

void CControl::Show()
{
  Show(SW_SHOW);
}

void CControl::Show(int showState)
{
  ShowWindow(Handle, showState);
}

void CControl::Hide()
{
  Show(SW_HIDE);
}

void CControl::OnPaint()
{
  if(BackBuffer)
  {
    SelectClipRgn(BackDC, NULL);
#ifdef _DEBUG
    if(BackBuffer->DC != BackDC)
      DisplayError("CControl::OnPaint() - BackBuffer->DC != BackDC\n");
    if(BackBuffer->TargetDC != DC)
      DisplayError("CControl::OnPaint() - BackBuffer->TargetDC != DC\n");
#endif
    BackBuffer->Draw();
  }
  else
  {
    if(ColorManager)
    {
      ColorManager->Lock();
      ColorManager->GetBrush(BackColor)->FillRect(DC, 0, 0, Width, Height);
      ColorManager->Release();
    }
    else
    {
      RECT r;
      r.top    = 0;
      r.left   = 0;
      r.right  = Width;
      r.bottom = Height;
      ::FillRect(DC, &r, (HBRUSH)GetStockObject(BLACK_BRUSH));
    }
  }
}

void CControl::SetBackColor(ColorManagerColor color)
{
  BackColor = color;
}

void CControl::OnResize(int newWidth, int newHeight)
{
  Width = newWidth;
  Height = newHeight;
  if(BackBuffer != 0)
  {
    BackBuffer->Resize(newWidth, newHeight);
    BackDC = BackBuffer->DC;
  }
  
  if(SubInit)
    Update();
}

LRESULT CControl::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_CTLCOLORSCROLLBAR:
    {
      HDC     hDC;
      LRESULT s;

      hDC = (HDC)wParam;
      SetTextColor(hDC, RGB(0xFF, 0x00, 0x00));
      SetBkColor(hDC, RGB(0x00, 0x00, 0xFF));
      ColorManager->Lock();
      s = (LRESULT)ColorManager->GetBrush((ColorManagerColor)ControlBack)->Handle;
      ColorManager->Release();
      return s;
    }
    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORLISTBOX:
    {
      HDC    hDC;
      LRESULT s;

      hDC = (HDC)wParam;
      SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaText));
      SetBkColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaBack));
      ColorManager->Lock();
      s = (LRESULT)ColorManager->GetBrush((ColorManagerColor)TextAreaBack)->Handle;
      ColorManager->Release();
      return s;
   }
    case WM_PAINT:
    {
      PAINTSTRUCT paintStruct;

      BeginPaint(Handle, &paintStruct);
      OnPaint();
      EndPaint(Handle, &paintStruct);
      return 0;
    }
    case WM_SIZE:
    {
      OnResize(LOWORD(lParam), HIWORD(lParam));
      return 0;
    }
    case WM_NCPAINT:
    {
      HDC  hDC;
      bool bHandled;
 
      hDC = GetDCEx(hWnd, 0, DCX_WINDOW);
      
      if(hDC)
      {
        bHandled = OnNCPaint(hDC);
        ReleaseDC(hWnd, hDC);

        if(bHandled)
          return 0;
      }
      break;
    }
    case WM_RBUTTONUP:
    {
      int x, y;

      x = GET_X_LPARAM(lParam);
      y = GET_Y_LPARAM(lParam);

      OnRightButtonUp(x, y);
      return 0;
    }
	  case WM_RBUTTONDOWN:
	  {
      int x, y;

      x = GET_X_LPARAM(lParam);
      y = GET_Y_LPARAM(lParam);

      OnRightButtonDown(x, y);
      return 0;    
	  }
    case WM_LBUTTONDOWN:
    {
      int x, y;

      x = GET_X_LPARAM(lParam);
      y = GET_Y_LPARAM(lParam);

      OnLeftButtonDown(x, y);
      return 0;
    }
    case WM_LBUTTONDBLCLK:
    {
      int x, y;

      x = GET_X_LPARAM(lParam);
      y = GET_Y_LPARAM(lParam);

      OnLeftButtonDoubleClick(x, y);
      return 0;
    }
    case WM_LBUTTONUP:
    {
      int x, y;

      x = GET_X_LPARAM(lParam);
      y = GET_Y_LPARAM(lParam);

      OnLeftButtonUp(x, y);
      return 0;
    }
    case WM_MOUSEMOVE:
    {
      int x, y;

      x = GET_X_LPARAM(lParam);
      y = GET_Y_LPARAM(lParam);

      OnMouseMove(x, y);
      return 0;
    }
    case WM_CAPTURECHANGED:
    {
      OnCaptureChanged((HWND)lParam);
      return 0;
    }
  }

  if((msg >= WM_APP) && (msg <= 0xBFFF))
  {
    OnAppMessage(msg, wParam, lParam);
    return 0;
  }

  return DefWindowProc(Handle, msg, wParam, lParam);
}

void CControl::OnAppMessage(UINT message, WPARAM wParam, LPARAM lParam)
{
}

void CControl::PostMessage(UINT message, WPARAM wParam, LPARAM lParam)\
{
  ::PostMessage(Handle, message, wParam, lParam);
}

void CControl::Resize(int newWidth, int newHeight)
{
  MoveWindow(Handle, X, Y, newWidth, newHeight, TRUE);
}

bool CControl::OnNCPaint(HDC hDC)
{
  if(!Border)
    return false;

  DrawBorder(hDC, BorderStyle, 0, 0, Width + 2, Height + 2); 
  return true;
}

void CControl::OnRightButtonUp(int x, int y)
{
}

void CControl::Move(int x, int y)
{
  if(GetWindowLong(Handle, GWL_STYLE) & WS_BORDER)
    MoveWindow(Handle, x, y, Width + 2, Height + 2, TRUE);
  else
    MoveWindow(Handle, x, y, Width, Height, TRUE);
  X = x;
  Y = y;
}

void CControl::Move(int x, int y, int width, int height)
{
  MoveWindow(Handle, x, y, width, height, TRUE);
  X = x;
  Y = y;
}

void CControl::OnRightButtonDown(int x, int y)
{
}

void CControl::OnLeftButtonDown(int x, int y)
{
}

void CControl::OnLeftButtonUp(int x, int y)
{
}

void CControl::OnMouseMove(int x, int y)
{
}

void CControl::OnScrollX(int newPos)
{
}

void CControl::OnScrollY(int newPos)
{
}

void CControl::OnLeftButtonDoubleClick(int x, int y)
{
}

void CControl::SetTopMost()
{
  SetWindowLong(Handle, GWL_EXSTYLE, WS_EX_TOPMOST | GetWindowLong(Handle, GWL_EXSTYLE));
  SetWindowPos(Handle, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);
}

void CControl::OnComboSelect(CDropList *comboBox)
{
}

void CControl::OnListSelChange(CListBox *listBox)
{
}

void CControl::OnListDblClick(CListBox *listBox)
{
}

void CControl::OnSizeX(CSizeBar *sizeBar, int amount)
{
}

void CControl::OnSizeY(CSizeBar *sizeBar, int amount)
{
}

void CControl::OnToolBarButtonPress(CToolBarButton *button)
{
}

void CControl::OnSliderChange(CSlider *slider, double value)
{
}

void CControl::DrawBorder(HDC hDC, DrawBorderStyle style, int x, int y, int width, int height)
{
  ColorManager->Lock();
  DrawBorder(hDC, style, x, y, width, height, ColorManager->GetPen((ColorManagerColor)ControlLight), ColorManager->GetPen((ColorManagerColor)ControlShadow));
  ColorManager->Release();
}

void CControl::DrawBorder(HDC hDC, DrawBorderStyle style, int x, int y, int width, int height, CPen *lightPen, CPen *shadowPen)
{
  HGDIOBJ lOldPen;

  switch(style)
  {
    case bsFlat:
    {
      lOldPen = SelectObject(hDC, shadowPen->Handle);
      MoveToEx(hDC, x, y + height - 1, NULL);
      LineTo(hDC, x, y);
      LineTo(hDC, x + width - 1, y);
      LineTo(hDC, x + width - 1, y + height - 1);
      LineTo(hDC, x, y + height - 1);
      SelectObject(hDC, lOldPen);

      break;
    }
    case bs3DSunken:
    {
      lOldPen = SelectObject(hDC, shadowPen->Handle);
      MoveToEx(hDC, x, y + height - 1, NULL);
      LineTo(hDC, x, y);
      LineTo(hDC, x + width - 1, y);
      SelectObject(hDC, lightPen->Handle);
      LineTo(hDC, x + width - 1, y + height - 1);
      LineTo(hDC, x, y + height - 1);
      SelectObject(hDC, lOldPen);

      break;
    }
    case bs3DRaised:
    {
      lOldPen = SelectObject(hDC, lightPen->Handle);
      MoveToEx(hDC, x, y + height - 1, NULL);
      LineTo(hDC, x, y);
      LineTo(hDC, x + width - 1, y);
      SelectObject(hDC, shadowPen->Handle);
      LineTo(hDC, x + width - 1, y + height - 1);
      LineTo(hDC, x, y + height - 1);
      SelectObject(hDC, lOldPen);

      break;
    }
  }
}

void CControl::Enable()
{
  EnableWindow(Handle, TRUE);
}

void CControl::Disable()
{
  EnableWindow(Handle, FALSE);
}

void CControl::OnButtonPress(CButton *button)
{
}

void CControl::OnUpDownChange(CUpDown *upDown)
{
}

void CControl::SetBorder(DrawBorderStyle style)
{
  Border = true;
  BorderStyle = style;
  SetWindowLong(Handle, GWL_STYLE, GetWindowLong(Handle, GWL_STYLE) | WS_BORDER);
  SetWindowPos(Handle, HWND_TOP, X, Y, Width, Height, SWP_FRAMECHANGED);
}

void CControl::OnCaptureChanged(HWND newCapture)
{
}

void CControl::DrawBox(HDC hDC, int x, int y, int width, int height, char *text)
{
  DrawBox(hDC, x, y, width, height, text, false);
}

void CControl::DrawBox(HDC hDC, int x, int y, int width, int height, char *text, bool lit)
{
  HGDIOBJ oldPen;

  POINT p[5];

  p[0].x = x;
  p[0].y = y;
  p[1].x = x + width - 1;
  p[1].y = y;
  p[2].x = p[1].x;
  p[2].y = y + height - 1;
  p[3].x = x;
  p[3].y = p[2].y;
  p[4].x = x;
  p[4].y = y;

  if(text)
    DrawLabel(hDC, x + 1, y + 1, width - 1, height - 1, text);
  
  ColorManager->Lock();

  oldPen = SelectObject(hDC, ColorManager->GetPen(FlatText)->Handle);
  Polyline(hDC, p, 5);
  SelectObject(hDC, oldPen);

  if(lit)
    ColorManager->GetBrush(FlatText)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);

  ColorManager->Release();
};

void CControl::DrawLabel(HDC hDC, int x, int y, int width, int height, char *text)
{
  RECT    rect;
  HGDIOBJ oldFont;

  rect.left   = x;
  rect.top    = y;
  rect.right  = x + width;
  rect.bottom = y + height;

  if(!Font)
    return;
  
  if(text)
  {
    oldFont = SelectObject(hDC, Font->Handle);
    DrawTextA(hDC, text, (int)strlen(text), &rect, DT_SINGLELINE | DT_VCENTER | DT_CENTER);
    SelectObject(hDC, oldFont);
  }
}

void CControl::SetFont(CFont *font)
{
  if(OwnFont && (Font != 0))
  {
    delete Font;
    Font = 0;
  }
  Font = font;
  OwnFont = true;
}

void CControl::SetFont(char *faceName, double pointSize, bool bold)
{
  SetFont(new CFont(DC, faceName, pointSize, bold));
}

void CControl::FillTexture(CFrameBuffer *texture)
{
  texture->TextureFill(BackBuffer, X, Y);
}

void CControl::Update()
{
  DrawControl();
  OnPaint();
}

void CControl::DrawControl()
{
  if(SubInit)
  {
    if(BackBuffer)
    {
      if(Texture)
        FillTexture(Texture);
      else
      {
        ColorManager->Lock();
        ColorManager->GetBrush(BackColor)->FillRect(BackBuffer->DC, 0, 0, Width, Height);
        ColorManager->Release();
      }
    }
  }
}

CBackBuffer* CControl::GetBackBuffer()
{
  return BackBuffer;
}

void CControl::OnRenameDialogSuccess()
{
}