/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "StereoSplitter.h"

CStereoSplitter::CStereoSplitter(CHost *host)
: CMachine(host)
{
  PropertyCount = 0;

  BlockSamples = host->GetBlockSamples();
  
  PortCount = 3;
  Ports = new CPort*[3];
  Ports[0] = new CPort(host, this, PT_AUDIO | PT_INPUT  | PT_STEREO, "Stereo In");
  Ports[1] = new CPort(host, this, PT_AUDIO | PT_OUTPUT | PT_MONO, "Left Out");
  Ports[2] = new CPort(host, this, PT_AUDIO | PT_OUTPUT | PT_MONO, "Right Out");
}

void CStereoSplitter::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

void CStereoSplitter::SetSampleRate(int sampleRate)
{
}

bool CStereoSplitter::IsSynth()
{
  return false;
}

CStereoSplitter::~CStereoSplitter()
{
  delete Ports[0];
  delete Ports[1];
  delete Ports[2];
  delete Ports;
}

void CStereoSplitter::Work()
{
  int i;
  double *inLeft, *inRight;
  double *outLeft, *outRight;
  
  inLeft  = Ports[0]->AudioBuffer->LeftData;
  inRight = Ports[0]->AudioBuffer->RightData;

  outLeft  = Ports[1]->AudioBuffer->MonoData;
  outRight = Ports[2]->AudioBuffer->MonoData;
  
  for(i = 0; i < BlockSamples; i++)
  {
    *(outLeft++)  = *(inLeft++);
    *(outRight++) = *(inRight++);
  }  
}

CStereoSplitterInfo::CStereoSplitterInfo(CHost *host)
{
  Host = host;
  Name = "ES StereoSplitter";
  UniqueID = "DarkPlug::ES StereoSplitter";
}

CMachine *CStereoSplitterInfo::CreateMachine()
{
  return new CStereoSplitter(Host);
}
