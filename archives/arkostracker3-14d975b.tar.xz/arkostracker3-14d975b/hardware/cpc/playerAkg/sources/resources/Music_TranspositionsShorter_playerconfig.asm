; Configuration that can be included to Arkos Tracker 2 players.
; It indicates what parts of code are useful to the song/sound effects, to save both memory and CPU.
; The players may or may not take advantage of these flags, it is up to it.

; You can either:
; - Include this to the source that also includes the player (BEFORE the player is included) (recommended solution).
; - Include this at the beginning of the player code.
; - Copy/paste this directly in the player.
; If you use one player but several songs, don't worry, these declarations will stack up.
; If no configuration is used, the player will use default values (full code used).

	PLY_CFG_ConfigurationIsPresent = 1
	PLY_CFG_UseTranspositions = 1
	PLY_CFG_UseHardwareSounds = 1
	PLY_CFG_UseRetrig = 1
	PLY_CFG_UseInstrumentRetrig = 1
	PLY_CFG_UseInstrumentLoopTo = 1
	PLY_CFG_NoSoftNoHard = 1
	PLY_CFG_NoSoftNoHard_Noise = 1
	PLY_CFG_SoftOnly = 1
	PLY_CFG_SoftOnly_Noise = 1
	PLY_CFG_SoftOnly_SoftwareArpeggio = 1
	PLY_CFG_SoftOnly_SoftwarePitch = 1
	PLY_CFG_SoftToHard = 1
	PLY_CFG_SoftToHard_SoftwarePitch = 1
	PLY_CFG_SoftToHard_HardwarePitch = 1
	PLY_CFG_SoftToHard_Retrig = 1
	PLY_CFG_SoftAndHard = 1
	PLY_CFG_SoftAndHard_HardwareArpeggio = 1
