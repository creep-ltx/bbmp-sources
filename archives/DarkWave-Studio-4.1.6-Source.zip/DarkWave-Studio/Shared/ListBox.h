/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef LIST_BOX_H
#define LIST_BOX_H

#include "Control.h"
#include "BackBuffer.h"
#include "Font.h"
#include "Array.h"

class CListBoxItem
{
public:
       CListBoxItem(char *text, int itemData);
      ~CListBoxItem();
  void SetText(char *text);

  char *Text;
  int   TextLength;
  int   ItemData;
};

class CListBox : public CControl
{
public:
               CListBox(CControl *parent, CFont *font, int x, int y, int width, int height, int itemHeight);
              ~CListBox();
  void         DrawControl();
  int          AddItem(char *text);
  int          AddItem(char *text, int itemData);
  void         Clear();
  void         DrawItem(HDC hDC, int index, int y);
  int          InItem(int x, int y);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonDoubleClick(int x, int y);
  int          GetSelection();
  void         SetHeader(char *text);
  void         DrawHeader(HDC hDC);
  int          GetItemData(int index);
  void         SetDrawTextFlags(int flags);
  void         RemoveItem(int index);

private:
  CArray<CListBoxItem*> *Items;
  int                    ItemHeight;
  int                    Selection;
  char                  *Header;
  int                    DrawTextFlags;
};

#endif