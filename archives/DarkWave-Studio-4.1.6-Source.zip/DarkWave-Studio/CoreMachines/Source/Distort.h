/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DISTORT_H
#define	DISTORT_H

#include "DarkPlug.h"
#include "FrameBuffer.h"
#include "LiteContainer.h"
#include "LiteKnob.h"

struct SDistortGraphics
{
  CFrameBuffer *Background;
  CFrameBuffer *Knob;
};

class CDistort;
class CDistortGUI;

class COverDriveDisplay : public CLiteControl
{
public:
               COverDriveDisplay(CDistortGUI *distortGUI, CDistort *distort, int x, int y, int width, int height);
              ~COverDriveDisplay();
  virtual void Draw(CFrameBuffer *frameBuffer);
  void         Update();
  void         Render();
  
private:
  CDistortGUI  *DistortGUI;
  CDistort     *Distort;
  double       *Values;
  int           NumValues;
  CFrameBuffer *RenderBuffer;
};

class CDistortGUI : public CLiteContainer
{
public:
      CDistortGUI(HWND parent, CColorManager *colorManager, CDistort *machine, SDistortGraphics *graphics);
     ~CDistortGUI();
 void SetProperty(int index, double value);
 
private:
  SDistortGraphics  *Graphics;
  CLiteKnob        **Knobs;
  CDistort          *Distort;
  COverDriveDisplay *OverDriveDisplay;
};

class CDistort : public CMachine
{
public:
                          CDistort(CHost *host, SDistortGraphics *graphics);
  virtual                ~CDistort();
  virtual void   DARKCALL Work();
  void                    ProcessBlock(int start, int samples);
  void                    ProcessMessage(SControlMessage *message);
  virtual HWND   DARKCALL CreateGUI(HWND parent);
  virtual double DARKCALL GetProperty(int index);
  virtual void   DARKCALL SetProperty(int index, double value);
  virtual void   DARKCALL GetPropertyName(int index, char *text);
  virtual void   DARKCALL GetPropertyValueDisplay(int index, double value, char *text);
  virtual void   DARKCALL SetSampleRate(int sampleRate);
  virtual void   DARKCALL SetBlockSamples(int blockSamples);
  virtual bool   DARKCALL GetGUIRect(short *x1, short *y1, short *x2, short *y2);
  virtual bool   DARKCALL IsSynth();
  double                  OverDrive(double in);
  double                  OverDrive(double in, double amp, double drive);

private:
  CHost            *Host;
  SDistortGraphics *Graphics;
  CDistortGUI      *GUI;
  double           *Properties;
  int               BlockSamples;
  double            AmpFollow, DriveFollow, WetFollow, DryFollow;
};

class CDistortInfo : public CMachineInfo
{
public:
                    CDistortInfo(CHost *host);
  virtual          ~CDistortInfo();
  virtual CMachine* DARKCALL CreateMachine();
  
private:
  CHost           *Host;
  SDistortGraphics Graphics;
  bool             Loaded;
};

#endif

