/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <malloc.h>

#include "VSTAdapter.h"
#include "Mutex.h"
#include "Error.h"
#include "Core.h"
#include "Thread.h"
#include <stdio.h>
#include "ConvertBlock.h"
#include "Util.h"

#ifdef _DEBUG
  #define DEBUGPRINT
#endif

// DarkWave VST Adapter
// Sends Null MIDI Events So CreakBox Doesn't Crash
// Persists MIDI Events Between Calls So SynthEdit Plugs Don't Crash

CVSTAdapter *FirstAdapter = 0;
CHostMutex  *AdapterMutex = 0;

class CVSTIdleThread : public CThread
{
public:
  CVSTIdleThread()
  {
    SetPriority(THREAD_PRIORITY_BELOW_NORMAL);
  }

  virtual void Work()
  {
    CVSTAdapter *adapter;

    AdapterMutex->Lock();
    adapter = FirstAdapter;
    while(adapter != 0)
    {
      adapter->Lock();
      adapter->Idle();
      adapter->Release();
      adapter = adapter->GetNext();
    }
    AdapterMutex->Release();
    Sleep(10);
  }
} *VSTIdleThread;

// CVSTAdapter

VstIntPtr VSTCALLBACK AudioMasterCallback(AEffect* effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt)
{
  CVSTAdapter *adapter;
  VstIntPtr    s;

  if(opcode == audioMasterGetSampleRate)
  {
    return Core->Host->GetSampleRate();
  }

  if(opcode == audioMasterGetBlockSize)
  {
    return Core->Host->GetBlockSamples();
  }

  if(opcode == audioMasterVersion)
  {
    return 2400;
  }

  if(opcode == audioMasterGetVendorString)
  {
    strcpy((char*)ptr, "ExperimentalScene");
    return 0;
  }

  if(effect == 0)
    return 0;
  
  if(effect->resvd1 != 0)
  {
    CVSTAdapter *adapter;

    adapter = (CVSTAdapter*)(*((void**)&(effect->resvd1)));
    adapter->Lock();
    s = adapter->Invoke(opcode, index, value, ptr, opt);
    adapter->Release();
    return s;
  }
  

  if(!AdapterMutex)
    return 0;

  AdapterMutex->Lock();
  adapter = FirstAdapter;
  while(adapter != 0)
  {
    if(adapter->Effect == effect)
    {
      adapter->Lock();
      s = adapter->Invoke(opcode, index, value, ptr, opt);
      adapter->Release();
      AdapterMutex->Release();
      return s;
    }
    adapter = adapter->GetNext();
  }
  
  AdapterMutex->Release();
  return 0;
}

CVSTAdapter::CVSTAdapter(CHost *host, vstMain main, char *directory, CVSTAdapterInfo *adapterInfo)
: CMachine(host)
{
  AdapterInfo  = adapterInfo;
  Events       = 0;
  Inputs32     = 0;
  Outputs32    = 0;
  Inputs64     = 0;
  Outputs64    = 0;
  GUI          = 0;
  MIDIIn       = 0;
  Effect       = 0;
  WantIdle     = false;
  Directory    = directory;
  WantMIDI     = false;
  WantEditIdle = false;

  BlockSamples = host->GetBlockSamples();
  SampleRate   = host->GetSampleRate();

  if(AdapterMutex == 0)
    AdapterMutex = new CHostMutex();
  if(VSTIdleThread == 0)
  {
    VSTIdleThread = new CVSTIdleThread();
    VSTIdleThread->Run();
  }
  
  AdapterMutex->Lock();
  Attach(&FirstAdapter);
  AdapterMutex->Release();
  
  Effect = main(AudioMasterCallback);
  *(void**)(&Effect->resvd1) = this;
  PropertyCount = Effect->numParams;
  ProgramCount = Effect->numPrograms;
  UniqueID = Effect->uniqueID;

  Dispatch(effSetSampleRate, 0, 0, 0, (float)SampleRate);
  Dispatch(effSetBlockSize,  0, BlockSamples, 0, 0.0f);
  Dispatch(effOpen);
  Dispatch(effSetPanLaw, 0, 0, 0, 0.707107f);
  Dispatch(effMainsChanged,  0, 1, 0, 0.0f);
  Dispatch(effStartProcess);
  
  InitPorts();
}

CVSTAdapter::~CVSTAdapter()
{
  WantIdle = false;
  WantEditIdle = false;
  if(Events)
  {
    while(--Events->numEvents >= 0)
      delete Events->events[Events->numEvents];
    delete Events;
    Events = 0;
  }
  Dispatch(effStopProcess);
  Dispatch(effMainsChanged,  0, 0, 0, 0.0f);
  if(GUI)
  {
    Dispatch(effEditClose, 0, 0, 0, 0.0f); 
    delete GUI;
  }
  Dispatch(effClose, 0, 0, 0, 0.0f);
  AdapterMutex->Lock();
  Detach();
  AdapterMutex->Release();
  FreePorts();
  AdapterInfo->OnDestroyMachine();
}

void CVSTAdapter::SetSampleRate(int sampleRate)
{
  SampleRate = sampleRate;
  Dispatch(effSetSampleRate, 0, 0, 0, (float)SampleRate);
}

void CVSTAdapter::SetBlockSamples(int blockSamples)
{
  if(!CanProcess64)
  {
    int i;

    for(i = 0; i < NumInputs; i++)
    {
      _mm_free(Inputs32[i]);
      Inputs32[i] = (float*)_mm_malloc(sizeof(float) * blockSamples, AUDIO_BUFFER_ALIGN);
    }

    for(i = 0; i < NumOutputs; i++)
    {
      _mm_free(Outputs32[i]);
      Outputs32[i] = (float*)_mm_malloc(sizeof(float) * blockSamples, AUDIO_BUFFER_ALIGN);
    }
  }

  int i;
  int port;

  port = WantMIDI ? 1 : 0;

  if(NumInputs == 2)
  {
    Inputs64[0] = Ports[port]->AudioBuffer->LeftData;
    Inputs64[1] = Ports[port++]->AudioBuffer->RightData;
  }
  else
  {
    for(i = 0; i < NumInputs; i++)
      Inputs64[i] = Ports[port++]->AudioBuffer->MonoData;
  }
  
  if(NumOutputs == 2)
  {
    Outputs64[0] = Ports[port]->AudioBuffer->LeftData;
    Outputs64[1] = Ports[port++]->AudioBuffer->RightData;
  }
  else
  {
    for(i = 0; i < NumOutputs; i++)
      Outputs64[i] = Ports[port++]->AudioBuffer->MonoData;
  }

  BlockSamples = blockSamples;
  Dispatch(effSetBlockSize, 0, BlockSamples, 0, 0.0f);
}

void CVSTAdapter::InitPorts()
{
  int  i, port;
  bool midiIn;
  char portName[32];

  if(Effect)
  {
    if(Dispatch(effCanDo, 0, 0, (void*)"receiveVstMIDIEvent", 0.0f) != 0)
      midiIn = true;
    else
    {
      if(IsSynth())
        midiIn = true;
      else
        midiIn = false;
    }

    WantMIDI = midiIn;

    NumInputs    = Effect->numInputs;
    NumOutputs   = Effect->numOutputs;
    CanProcess64 = (Effect->flags & effFlagsCanDoubleReplacing) == effFlagsCanDoubleReplacing;

    port       = 0;

    Inputs32  = 0;
    Outputs32 = 0;
    Inputs64  = 0;
    Outputs64 = 0;

    if((NumInputs != 0) || (NumOutputs != 0))
    {
      if(NumInputs == 0)
        PortCount = 0;
      else if(NumInputs == 2)
        PortCount = NumInputs >> 1;
      else PortCount = NumInputs;

      if(NumOutputs != 0)
      {
        if(NumOutputs == 2)
          PortCount += NumOutputs >> 1;
        else
          PortCount += NumOutputs;
      }

      if(midiIn)
        PortCount++;

      Ports = new CPort*[PortCount];
      for(i = 0; i < PortCount; i++)
        Ports[i] = 0;

      if(midiIn)
      {
        Ports[port] = new CPort(Host, this, PT_CONTROL | PT_INPUT, "Control In");
        MIDIIn = Ports[port++];
      }

      if(NumInputs == 0)
      {
        Inputs32 = 0;
        Inputs64 = 0;
      }
      else
      {
        if(NumInputs == 2)
        {
          Inputs64 = new double*[NumInputs];
          if(!CanProcess64)
            Inputs32 = new float*[NumInputs];

          for(i = 0; i < NumInputs; i += 2)
          {
            sprintf(portName, "Line In %i", (i >> 1) + 1);
            Ports[port] = new CPort(Host, this, PT_AUDIO | PT_INPUT | PT_STEREO, portName);
            Inputs64[i]   = Ports[port]->AudioBuffer->LeftData;
            Inputs64[i+1] = Ports[port]->AudioBuffer->RightData;

            if(!CanProcess64)
            {
              Inputs32[i]   = (float*)_mm_malloc(sizeof(float) * BlockSamples, AUDIO_BUFFER_ALIGN);
              Inputs32[i+1] = (float*)_mm_malloc(sizeof(float) * BlockSamples, AUDIO_BUFFER_ALIGN);
            }
            port++;
          }
        }
        else
        {
          Inputs64 = new double*[NumInputs];
          if(!CanProcess64)
            Inputs32 = new float*[NumInputs];

          for(i = 0; i < NumInputs; i++)
          {
            sprintf(portName, "Line In %i", i + 1);
            Ports[port] = new CPort(Host, this, PT_AUDIO | PT_INPUT | PT_MONO, portName);
            Inputs64[i] = Ports[port]->AudioBuffer->MonoData;
            if(!CanProcess64)
              Inputs32[i] = new float[Host->GetBlockSamples()];
            port++;
          }
        }
      }

      if(NumOutputs == 0)
      {
        Outputs32 = 0;
        Outputs64 = 0;
      }
      else
      {
        if(NumOutputs == 2)
        {
          Outputs64 = new double*[NumOutputs];
          if(!CanProcess64)
            Outputs32 = new float*[NumOutputs];

          for(i = 0; i < NumOutputs; i += 2)
          {
            sprintf(portName, "Line Out %i", (i >> 1) + 1);
            Ports[port] = new CPort(Host, this, PT_AUDIO | PT_OUTPUT | PT_STEREO, portName);
            
            Outputs64[i]   = Ports[port]->AudioBuffer->LeftData;
            Outputs64[i+1] = Ports[port]->AudioBuffer->RightData;

            if(!CanProcess64)
            {
              Outputs32[i]   = (float*)_mm_malloc(sizeof(float) * BlockSamples, AUDIO_BUFFER_ALIGN);
              Outputs32[i+1] = (float*)_mm_malloc(sizeof(float) * BlockSamples, AUDIO_BUFFER_ALIGN);
            }

            port++;
          }
        }
        else
        {
          Outputs64 = new double*[NumOutputs];
          if(!CanProcess64)
            Outputs32 = new float*[NumOutputs];

          for(i = 0; i < NumOutputs; i++)
          {
            sprintf(portName, "Line Out %i", i + 1);
            Ports[port] = new CPort(Host, this, PT_AUDIO | PT_OUTPUT | PT_MONO, portName);
            Outputs64[i]  = Ports[port]->AudioBuffer->MonoData;
            if(!CanProcess64)
              Outputs32[i]  = (float*)_mm_malloc(sizeof(float) * BlockSamples, AUDIO_BUFFER_ALIGN);
            port++;
          }
        }
      }
    }
  }
}

void CVSTAdapter::FreePorts()
{
  int i;

  if(Inputs32)
  {
    for(i = 0; i < NumInputs; i++)
      _mm_free(Inputs32[i]);
    delete Inputs32;
  }

  if(Outputs32)
  {
    for(i = 0; i < NumOutputs; i++)
      _mm_free(Outputs32[i]);
    delete Outputs32;
  }

  if(Inputs64)
    delete Inputs64;
  if(Outputs64)
    delete Outputs64;
  
  if(PortCount != 0)
  {
    for(i = 0; i < PortCount; i++)
      if(Ports[i] != 0)
        delete Ports[i];
    delete Ports;
    PortCount = 0;
  }
}

void CVSTAdapter::ProcessMIDIIn()
{
  CControlBuffer  *buffer;
  SControlMessage  message;
  int              n, count;
  VstIntPtr        s;
  VstEvents       *events;
  VstMidiEvent    *event;

  if(Events)
  {
    while(--Events->numEvents >= 0)
      delete Events->events[Events->numEvents];
    delete Events;
    Events = 0;
  }

  buffer   = MIDIIn->ControlBuffer;
  count    = buffer->Count();

  if(!WantMIDI)
  {
    buffer->Clear();
    return;
  }

  //if(count == 0)
  //  return;

  events = (VstEvents*)new char[sizeof(VstEvents) + ((count - 2) * 4)];
  Events = events;
  n = 0;

  while(buffer->Read(&message))
  {
    if(message.Type == CONTROL_MESSAGE_NOTE_ON)
    {
      event = new VstMidiEvent;
      memset(event, 0, sizeof(VstMidiEvent));

      event->type        = kVstMidiType;
      event->byteSize    = 24;
      event->deltaFrames = message.BlockSample;
      event->midiData[0] = (unsigned char)0x90;
      event->midiData[1] = (unsigned char)message.NoteOn.Note;
      event->midiData[2] = (unsigned char)(message.NoteOn.Velocity * 127.0f);

      events->events[n++] = (VstEvent*)event;
    }

    if(message.Type == CONTROL_MESSAGE_NOTE_OFF)
    {
      event = new VstMidiEvent;
      memset(event, 0, sizeof(VstMidiEvent));

      event->type        = kVstMidiType;
      event->byteSize    = 24;
      event->deltaFrames = message.BlockSample;
      event->midiData[0] = (unsigned char)0x80;
      event->midiData[1] = (unsigned char)message.NoteOff.Note;

      events->events[n++] = (VstEvent*)event;
    }
  }

  events->numEvents = n;
  events->reserved = 0;
  s = Dispatch(effProcessEvents, 0, 0, events, 0.0f);
  if(s == 0)
    WantMIDI = false;
}

void CVSTAdapter::Work()
{
  int i, s;

  if(MIDIIn)
    ProcessMIDIIn();
  
  if(CanProcess64)
  {
    Effect->processDoubleReplacing(Effect, Inputs64, Outputs64, BlockSamples);
  }
  else
  {
    for(i = 0; i < NumInputs; i++)
    {
      ConvertMonoDoubleToMonoFloat(Inputs64[i], Inputs32[i], BlockSamples);
    }

    if((Effect->flags & effFlagsCanReplacing) != effFlagsCanReplacing)
    {
      for(i = 0; i < NumOutputs; i++)
        for(s = 0; s < BlockSamples; s++)
          Outputs32[i][s] = 0.0f;

      Effect->process(Effect, Inputs32, Outputs32, BlockSamples);
    }
    else
      Effect->processReplacing(Effect, Inputs32, Outputs32, BlockSamples);

    for(i = 0; i < NumOutputs; i++)
    {
      ConvertMonoFloatToMonoDouble(Outputs32[i], Outputs64[i], BlockSamples);
    }
  }
}

void CVSTAdapter::Idle()
{
  VstIntPtr s;

  if(WantIdle)
  {
    s = Dispatch(effIdle);
    if(s == 0)
      WantIdle = false;
  }

  if(WantEditIdle)
  {
    Dispatch(effEditIdle);
  }
}

void CVSTAdapter::OnShowGUI()
{
  if(GUI)
  {
    GUI->Show();
    WantEditIdle = true;
  }
}

void CVSTAdapter::OnHideGUI()
{
  WantEditIdle = false;
  if(GUI)
    GUI->Hide();
}

VstTimeInfo *CVSTAdapter::GetTime(VstIntPtr flags)
{
  memset(&TimeInfo, 0, sizeof(VstTimeInfo));

  TimeInfo.samplePos  = Host->GetSamplePosition();
  TimeInfo.sampleRate = SampleRate;

  // Groove Agent Needs:
  //   kVstPpqPosValid 
  //   kVstTempoValid
  //   kVstBarsValid
  //   kVstTimeSigValid

  if(flags & kVstTempoValid)
  {
    TimeInfo.tempo  = Host->GetBPM();
    TimeInfo.flags |= kVstTempoValid;
  }

  if(flags & kVstTimeSigValid)
  {
    TimeInfo.timeSigNumerator   = 1;
    TimeInfo.timeSigDenominator = 4;
    TimeInfo.flags |= kVstTimeSigValid;
  }

  return &TimeInfo;
}

#define CAN_DO_COUNT 7

const char* CanDoStrings[CAN_DO_COUNT] =
{
	"sendVstEvents",
	"sendVstMIDIEvent",
	"sendVstTimeInfo",
	"receiveVstEvents",
	"receiveVstMIDIEvent",
	"receiveVstTimeInfo",
	"supplyIdle"
};

VstIntPtr CVSTAdapter::Invoke(VstInt32 opcode, VstInt32 index, VstIntPtr value, void *ptr, float opt)
{
  switch(opcode)
  {
    case audioMasterAutomate:
      Host->SetPropertyAutomated(this, index, opt);
      return (VstIntPtr)0;

    case audioMasterVersion:
      return (VstIntPtr)kVstVersion; // = 2400

    case audioMasterGetSampleRate:
      return (VstIntPtr)SampleRate;

    case audioMasterNeedIdle:
      WantIdle = true;
      return (VstIntPtr)0;

    case audioMasterGetDirectory:
      return (VstIntPtr)Directory;

    case audioMasterGetTime:
      return (VstIntPtr)GetTime(value);

    case audioMasterWantMidi:
      WantMIDI = true;
      return (VstIntPtr)1;

    case audioMasterCanDo:
    {
      int i;

      for(i = 0; i < CAN_DO_COUNT; i++)
        if(!strcmp(CanDoStrings[i], (char*)ptr))
          return (VstIntPtr)1;
      return (VstIntPtr)0;
    }

    case audioMasterIdle:
    {
      WantIdle = true;
      return (VstIntPtr)0;
    }

    case audioMasterTempoAt:
    {
      return (VstIntPtr)(Host->GetBPM() * 10000);
    };
    
    case audioMasterGetOutputLatency:
    case audioMasterGetInputLatency:
    {
      return (VstIntPtr)(0);
    }
    
    default:
#ifdef DEBUGPRINT
      DebugPrint("Unsupported Opcode 0x%x\n", opcode);
#endif
      return (VstIntPtr)0;
  }
}

VstIntPtr CVSTAdapter::Dispatch(long opcode, long index, long value, void *ptr, float opt)
{
  if(Effect)
	  return Effect->dispatcher(Effect, opcode, index, value, ptr, opt);
  else
    return 0;
}

VstIntPtr CVSTAdapter::Dispatch(long opcode)
{
  return Dispatch(opcode, 0, 0, 0, 0.0f);
}

void CVSTAdapter::GetPropertyName(int index, char *text)
{
  Dispatch(effGetParamName, index, 0, text, 0.0f); 
}

void CVSTAdapter::GetPropertyDisplay(int index, char *text)
{
  char display[64], label[64];

  display[0] = 0;
  label[0] = 0;
  
  Dispatch(effGetParamDisplay, index, 0, display, 0.0f);
  Dispatch(effGetParamLabel, index, 0, label, 0.0f);
  
  display[kVstMaxParamStrLen] = 0;
  label[kVstMaxParamStrLen]   = 0;

  sprintf(text, "%s%s", display, label);
}

double CVSTAdapter::GetProperty(int index)
{
  if(Effect)
    return (double)Effect->getParameter(Effect, index);
  else
    return 0.0;
}

void CVSTAdapter::SetProperty(int index, double value)
{
  if(Effect)
    Effect->setParameter(Effect, index, (float)value);
}

HWND CVSTAdapter::CreateGUI(HWND parent)
{
  if(!Effect)
    return 0;

  if(GUI == 0)
  {
    if((Effect->flags & effFlagsHasEditor) == effFlagsHasEditor)
    {
      ERect *rect = 0;

      Dispatch(effEditGetRect, 0, 0, &rect, 0.0f);
      if(rect == 0)
        return 0;
      GUI = new CControl(parent, Core->ColorManager, "VST", 0, 0, rect->right - rect->left, rect->bottom - rect->top, false);
      Dispatch(effEditOpen, 0, 0, (void*)GUI->Handle, 0.0f);
      GUI->Show();
      return GUI->Handle;
    }
    return 0;
  }
  else
    return GUI->Handle;
}

// CVSTAdapterInfo

CVSTAdapterInfo::CVSTAdapterInfo(CHost *host, HMODULE module, vstMain main, bool newMainFormat, char *dllName, char *directory, char *vstPath, char *menuPath)
{
  int n, i, len;

  IconLarge = Core->VSTIcon;
  
  RefCount = 0;

  VSTPath = CopyString(vstPath);

  if(menuPath == 0)
    MenuPath = CopyString("VST");
  else
    MenuPath = CopyString(menuPath);
  
  NewMainFormat = newMainFormat;

  n = (int)strlen(dllName);
  n -= 4;
  
  len = (int)strlen(directory) + 2;
  Directory = new char[len];
  strcpy(Directory, directory);
  strcat(Directory, "\\");

  Name = new char[n + 1];
  for(i = 0; i < n; i++)
    Name[i] = dllName[i];
  Name[n] = 0;


  Module = module;
  Host   = host;
  Main   = main;

  CMachine *machine;

  machine = CreateMachine();

  char a, b, c, d;
  
  UniqueID = new char[16];
  
  a = (machine->UniqueID >> 24) & 0x7F;
  b = (machine->UniqueID >> 16) & 0x7F;
  c = (machine->UniqueID >> 8)  & 0x7F;
  d = (machine->UniqueID)       & 0x7F;
  
  sprintf(UniqueID, "VST::%02x%02x%02x%02x", a, b, c, d);
  
  OldUniqueID = new char[16];
  
  strcpy(OldUniqueID, "VST::");
  OldUniqueID[5] = (machine->UniqueID)       & 0xF;
  OldUniqueID[6] = (machine->UniqueID >> 8)  & 0xF;
  OldUniqueID[7] = (machine->UniqueID >> 16) & 0xF;
  OldUniqueID[8] = (machine->UniqueID >> 24) & 0xF;
  OldUniqueID[9] = 0;
  
  
#ifdef _DEBUG
  DebugPrint("Scanned VST With UniqueID %4x\n", machine->UniqueID);
#endif

  delete machine;

  FreeLibrary(Module);
  Module = 0;
  Main = 0;
  RefCount = 0;
}

CVSTAdapterInfo::~CVSTAdapterInfo()
{
  delete Name;
  delete UniqueID;
  delete Directory;
  delete MenuPath;
  if(RefCount > 0)
    FreeLibrary(Module);
}

CMachine *CVSTAdapterInfo::CreateMachine()
{
  CMachine *machine;
#ifdef DEBUGPRINT
  DebugPrint("CVSTAdapterInfo::CreateMachine(%s)\n", Name);
#endif

  if(RefCount == 0)
  {
    Module = LoadLibrary(VSTPath);
    if(NewMainFormat)
      Main = (vstMain)GetProcAddress(Module, "VSTPluginMain");
    else
      Main = (vstMain)GetProcAddress(Module, "main");
  }

  RefCount++;

  machine = new CVSTAdapter(Host, Main, Directory, this);
  if(!strcmp("sfz", Name))
  {
#ifdef DEBUGPRINT
    DebugPrint("Setting SFZ To PR32 Mode\n");
#endif
    machine->SetProperty(3, 0.5);
  }
  return machine;
}

void CVSTAdapterInfo::OnDestroyMachine()
{
  RefCount--;
  if(RefCount == 0)
  {
    FreeLibrary(Module);
    Module = 0;
    Main = 0;
  }
}

void CVSTAdapter::WriteProperties(char **data, int *length, bool *isInner)
{
  *length = (int)Dispatch(effGetChunk, 1, 0, data, 0.0f);
  if(*length == 0)
    CMachine::WriteProperties(data, length, isInner);
  else
    *isInner = false;
}

void CVSTAdapter::ReadProperties(char *data, int length, bool isInner)
{
  if(isInner)
    CMachine::ReadProperties(data, length, true);
  else
    Dispatch(effSetChunk, 1, (VstIntPtr)length, data, 0.0f);
}

void CVSTAdapter::GetProgramNameIndexed(int index, char *text)
{
  text[0] = 0;
  Dispatch(effGetProgramNameIndexed, index, 0, text, 0.0f);
}

void CVSTAdapter::SetProgram(int index)
{
  Dispatch(effSetProgram, 0, index, 0, 0.0f);
}

bool CVSTAdapter::IsSynth()
{
  if(Effect->flags & effFlagsIsSynth)
    return true;
  else
    return false;
}

void CVSTAdapter::GetNoteLabel(int index, char *text)
{
  MidiKeyName midiKeyName;
  
  memset(&midiKeyName, 0, sizeof(midiKeyName));

  midiKeyName.thisKeyNumber = index;
  
  Dispatch(effGetMidiKeyName, index, 0, &midiKeyName, 0.0f);

  if(midiKeyName.keyName[0] != 0)
    strcpy(text, midiKeyName.keyName);
}