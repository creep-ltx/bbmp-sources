/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef OPTIONS_DIALOG_H
#define OPTIONS_DIALOG_H

#include "Dialog.h"

class CIconList;
class CFont;
class COptionsFrame;
class CButton;

class COptionsDialog : public CDialog
{
public:
               COptionsDialog(CControl *parent);
              ~COptionsDialog();
  virtual void OnClose();
  void         ShowFrame(int index);
  virtual void OnButtonPress(CButton *button);
  void         ApplyChanges();
  void         OnChange();
  virtual void OnIconListSelectItem(int index);
  virtual void OnResize(int newWidth, int newHeight);

private:
  CIconList      *IconList;
  COptionsFrame **Frames;
  COptionsFrame  *CurrentFrame;
  CButton        *ApplyButton;
  bool            Changed;
};

#endif