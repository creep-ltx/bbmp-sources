assert BANK(@) == 1
