/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "NullDriver.h"
#include "Error.h"
#include "Core.h"
#include "ConvertBlock.h"
#include <math.h>
#include <stdio.h>

#define POSSIBLE_SAMPLE_RATE_COUNT 5
extern double PossibleSampleRates[POSSIBLE_SAMPLE_RATE_COUNT];


bool CNullDriver::CanOpen()
{
  return true;
}



void DefaultNullCallback(int nChannels, double **channels, int samples)
{
  int channel, sample;

  for(channel = 0; channel < nChannels; channel++)
  {
    for(sample = 0; sample < samples; sample++)
      channels[channel][sample] = 0.0;
  }
}

CNullDriver::CNullDriver()
{
  if(Core->Options->Audio.Driver == OUTPUT_DRIVER_NULL)
  {
    if(Core->Options->Audio.NullLatency < NULL_MIN_LATENCY)
      SetLatency(NULL_DEFAULT_LATENCY);
    else
      SetLatency(Core->Options->Audio.NullLatency);
  }
  else
  {
    SetLatency(NULL_DEFAULT_LATENCY);
  }

	Format = ChooseFormat(Core->Options->Audio.NullFormat);
	FormatProperties(Format, &SampleRate, &Bits, &Stereo);

  WriteCallback = &DefaultNullCallback;
  BlockSamples = CalcBlockSamples(Latency, SampleRate);
  PlayBlocks = false;
}

CNullDriver::~CNullDriver()
{
  Stop();
}

char* CNullDriver::GetName()
{
  return "Null (Silent)";
}

int CNullDriver::GetBlockSamples()
{
  return BlockSamples;
}

int CNullDriver::GetSampleRate()
{
  return SampleRate;
}

void CNullDriver::SetWriteCallback(AudioOutputWriteCallback *funcPtr)
{
  WriteCallback = funcPtr;
}

void CNullDriver::Open()
{
  WAVEFORMATEX format;
  int          block;
  int          bps;

  Lock();

  bps  = Stereo ? 2 : 1;
  bps *= Bits == 16 ? 2 : 1;

  format.wFormatTag      = WAVE_FORMAT_PCM;
  format.nChannels       = Stereo ? 2 : 1;
  format.nSamplesPerSec  = SampleRate;
  format.wBitsPerSample  = Bits;
  format.nBlockAlign     = (format.nChannels * format.wBitsPerSample) / 8;
  format.nAvgBytesPerSec = format.nSamplesPerSec * format.nBlockAlign;
  format.cbSize          = 0;

  for(block = 0; block < 2; block++)
  {
    MixBuffer[block] = new double[BlockSamples];
  }

  PlayBlocks = true;
  LastTick = GetTickCount();

  Release();

  Run();
}

void CNullDriver::Close()
{
  Lock();
  PlayBlocks = false;  
  Release();

  FormatProperties(Format, &SampleRate, &Bits, &Stereo);
  BlockSamples = CalcBlockSamples(Latency, SampleRate);
}

void CNullDriver::Work()
{
  DWORD nBlockMS;
  DWORD nTicks;

  if(PlayBlocks)
  {
    nBlockMS = ((Latency * 1000) / SampleRate);
    WriteBlock();
    nTicks = GetTickCount() - LastTick;
    LastTick = GetTickCount();
    
    if(nTicks < nBlockMS)
      Sleep(nBlockMS - nTicks);
    else LastTick -= (nTicks - nBlockMS);

  }
  else
    Sleep(100);
}

int CNullDriver::GetNumChannels()
{
  return Stereo ? 2 : 1;
}

void CNullDriver::WriteBlock()
{
  WriteCallback(Stereo ? 2 : 1, MixBuffer, BlockSamples);
}

int CNullDriver::GetDeviceCount()
{
  return 1;
}

char *CNullDriver::GetDeviceName(int index)
{
  return "Null";
}

int CNullDriver::GetDeviceFormats(int index)
{
  return 0xFFFFF;
}

int CNullDriver::GetDevice()
{
  return 0;
}

char *CNullDriver::DescribeFormat(int format)
{
  int   sampleRate, bits;
  bool  stereo;
  char *text;

  FormatProperties(format, &sampleRate, &bits, &stereo);
  text = new char[128];
  sprintf(text, "%0.1fkHz, %ibit, %s", ((float)sampleRate) / 1000.0f, bits, stereo ? "Stereo" : "Mono");
  return text;
}

void CNullDriver::FormatProperties(int format, int *sampleRate, int *bits, bool *stereo)
{
  int steps = 0;

  while((format & 0xF) == 0)
  {
    format >>= 4;
    steps++;
    if(steps >= POSSIBLE_SAMPLE_RATE_COUNT)
      throw "Invalid Format";
  }

  format = format & 0xF;

  *sampleRate = (int)PossibleSampleRates[steps];
  *bits       = format >= 4 ? 16 : 8;
  *stereo     = format == 2 || format == 8 ? true : false;
}

int CNullDriver::GetFormat()
{
  return Format;
}

int MakeFormat(int sampleRate, int bits, bool stereo);

int CNullDriver::ChooseFormat(int preferredFormat)
{
  int df;

  df = GetDeviceFormats(0);
 
  if(df & preferredFormat)
    return preferredFormat;
  else
  {
    int  i, j;
    int  bits;
    bool stereo;
    const int sr[5] = {11025, 22050, 44100, 48000, 96000};
    int sampleRate;

    FormatProperties(preferredFormat, &sampleRate, &bits, &stereo);

    for(i = 0; i < 5; i++)
      if(sr[i] == sampleRate)
      {
        // closest sample rate with same bits and stereo

        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], bits, stereo) & df)
            return MakeFormat(sr[j], bits, stereo);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], bits, stereo) & df)
            return MakeFormat(sr[j], bits, stereo);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 16, true) & df)
            return MakeFormat(sr[j], 16, true);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 16, true) & df)
            return MakeFormat(sr[j], 16, true);
        

        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 16, false) & df)
            return MakeFormat(sr[j], 16, false);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 16, false) & df)
            return MakeFormat(sr[j], 16, false);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 8, true) & df)
            return MakeFormat(sr[j], 8, true);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 8, true) & df)
            return MakeFormat(sr[j], 8, true);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 8, false) & df)
            return MakeFormat(sr[j], 8, false);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 8, false) & df)
            return MakeFormat(sr[j], 8, false);
      }    
  }

  return 0;
}

void CNullDriver::SetDevice(int device)
{
}

void CNullDriver::SetFormat(int format)
{
  Format = format;
  Core->Options->Audio.NullFormat = format;
}

int CNullDriver::CalcBlockSamples(int latency, int sampleRate)
{
  return latency;
}

int CNullDriver::GetLatency()
{
  return Latency;
}

void CNullDriver::SetLatency(int latency)
{
  if(latency < NULL_MIN_LATENCY)
    latency = NULL_MIN_LATENCY;
  if(latency > NULL_MAX_LATENCY)
    latency = NULL_MAX_LATENCY;
  latency = latency - (latency % NULL_GRANULARITY);

  Latency = latency;
  Core->Options->Audio.NullLatency = latency;
}