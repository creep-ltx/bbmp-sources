/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "Core.h"
#include "Master.h"
#include "MIDIInput.h"
#include "MIDIOutput.h"
#include "HDTrackMachine.h"
#include "ControlChangeMapper.h"
#include "VSTLoader.h"
#include "Error.h"
#include "Util.h"
#include "FrameBuffer.h"
#include "../Resource.h"
#include "DetectCPU.h"
#include "BitFont.h"
#include "SaveAsDialog.h"
#include "UpDown.h"
#include <commctrl.h>
#include "Arpeggiator.h"

CCore *Core = 0;
HINSTANCE AppInstance = 0;

#define DARKWAVE_VERSION "4.1.6"

#ifdef WIN64
  #define DARKWAVE_PLATFORM "x86-64"
#else
  #define DARKWAVE_PLATFORM "x86-32"
#endif

void AudioOutputWriteProc(int nChannels, double **channels, int samples)
{
  if(Core != 0)
    if(Core->MainWindow != 0)
      if(Core->MainWindow->Studio != 0)
      {
        Core->MainWindow->Studio->Lock();
        Core->MainWindow->Studio->Work(nChannels, channels, samples);
        Core->MainWindow->Studio->Release();
      }
}

CCore::CCore()
{
  ProjectFileName   = 0;
  GraphicsThread    = 0;
  MainWindow        = 0;
  ColorManager      = 0;
  MachineLoader     = 0;
  MIDIManager       = 0;
  AudioManager      = 0;
  Host              = 0;
  AppIconSmall      = 0;
  AppIconLarge      = 0;
  AboutBox          = 0;
  CPUFeatures       = 0;

  Volume = 1.0;
}

CCore::~CCore()
{
}

bool CCore::Init(HINSTANCE appInstance)
{
  AppInstance = appInstance;
   
  Options = new COptions();
  
  Volume = Options->Audio.MasterVolume;

  CAudioOutputDriver *outputDriver;
  SYSTEM_INFO systemInfo;

  InitCommonControls();
  CoInitialize(NULL);

  InitBitmaps();

  ColorManager = new CColorManager();
  
  AboutBoxBackground = new CFrameBuffer(IDR_ABOUT_BOX_BACKGROUND);
  AboutBox = new CAboutBox(0, ColorManager, AboutBoxBackground);
  AboutBox->SetLabelText("Initializing...");
  
  AboutBox->Show(SW_SHOW);

  AboutBox->SetLabelText("Detecting Processor Features...");
  CPUFeatures = DetectProcessorFeatures();

  AboutBox->SetLabelText("Obtaining System Information...");

  GetSystemInfo(&systemInfo);
  ProcessorCount = systemInfo.dwNumberOfProcessors;
  if(ProcessorCount < 1)
    ProcessorCount = 1;

  AppIconSmall = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(IDI_APP), IMAGE_ICON,
    16, 16, LR_DEFAULTCOLOR);
  AppIconLarge = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(IDI_APP), IMAGE_ICON,
    32, 32, LR_DEFAULTCOLOR);
 
  VSTIcon = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(IDI_VST), IMAGE_ICON,
    32, 32, LR_DEFAULTCOLOR);
 

  AboutBox->SetLabelText("Initializing Audio...");

  MIDIManager = new CMIDIManager();
  AudioManager = new CAudioManager();

  outputDriver = AudioManager->GetOutputDriver();
  Host = new CDarkHost(outputDriver->GetBlockSamples(), outputDriver->GetSampleRate(), CPUFeatures);

  MachineLoader = new CMachineLoader();
  MachineLoader->AddEntry(new CMasterInfo);
  MachineLoader->AddEntry(new CArpeggiatorInfo);
  MachineLoader->AddEntry(new CControlChangeMapperInfo);
  MachineLoader->AddEntry(new CHDTrackMachineInfoMono);
  MachineLoader->AddEntry(new CHDTrackMachineInfoStereo);
  MachineLoader->AddEntry(new CMIDIInputInfo);
  MachineLoader->AddEntry(new CMIDIOutputInfo);

  char fileName[1024];
  char searchPath[1024];
  int i, j;
  GetModuleFileName(AppInstance, fileName, 1024);
  for(i = j = 0; fileName[i] != 0; i++)
    if(fileName[i] == '\\')
      j = i;
  fileName[j] = 0;

  sprintf(searchPath, "%s\\%s", fileName, "PlugIns");
  MachineLoader->SearchPath(searchPath);
 
  for(i = 0; i < Options->VSTPaths.Count; i++)
    LoadVSTMachines(Host, Options->VSTPaths.Items[i], MachineLoader, Options->VSTPaths.Items[i]);

  MainWindow = new CMainWindow();
  
  MainWindow->::CWindow::Show(SW_MAXIMIZE);

  SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
  
  AudioManager->OpenOutput(AudioOutputWriteProc);

  GraphicsThread = new CGraphicsThread();
  GraphicsThread->Run();

  AboutBox->Hide();
  delete AboutBox;
  AboutBox = new CAboutBox((CWindow*)MainWindow, ColorManager, AboutBoxBackground);
  
  char text[1024];
  sprintf(text, "Version: %s\nPlatform: %s (Visual C++ 2010 Express)\nVST PlugIn Technology by Steinberg\nASIO Technology by Steinberg", DARKWAVE_VERSION, DARKWAVE_PLATFORM);
  AboutBox->SetLabelText(text);

  return true;
}

void CCore::Free()
{
  if(GraphicsThread != 0)
  {
    GraphicsThread->Stop();
    delete GraphicsThread;
  }

  if(AudioManager != 0)
  {
    AudioManager->CloseOutput();
    delete AudioManager;
    AudioManager = 0;
  }

  if(MainWindow != 0)
  {
    delete MainWindow;
    MainWindow = 0;
  }

  if(MIDIManager != 0)
  {
    delete MIDIManager;
    MIDIManager = 0;
  }

  if(ColorManager != 0)
  {
    delete ColorManager;
    ColorManager = 0;
  }

  if(MachineLoader != 0)
  {
    delete MachineLoader;
    MachineLoader = 0;
  }

  if(Host != 0)
  {
    delete Host;
    Host = 0;
  }

  DestroyIcon(AppIconSmall);
  DestroyIcon(AppIconLarge);

  if(AboutBox != 0)
  {
    delete AboutBox;
    delete AboutBoxBackground;
  }

  FreeBitmaps();

  delete Options;
}

void CCore::ShowHelp()
{
  char fileName[1024];
  int i, j, k;
  GetModuleFileName(AppInstance, fileName, 1024);
  for(i = j = k = 0; fileName[i] != 0; i++)
    if(fileName[i] == '\\')
    {
      k = j;
      j = i;
    }
  fileName[k] = 0;
  
  strcat(fileName, "\\DarkWave.chm");
  ShellExecuteA(Core->MainWindow->Handle, "open", fileName, "", "", SW_MAXIMIZE);
}

void CCore::InitBitmaps()
{
  FrameBuffers.Knob = new CFrameBuffer(IDR_KNOB);
  FrameBuffers.Digits = new CFrameBuffer(IDR_DIGITS);
  FrameBuffers.DigitsFont = new CBitFont(FrameBuffers.Digits, 7, 2, 16, 19, 12, 46, 59); 
  FrameBuffers.ToolBarTexture = new CFrameBuffer(IDR_TOOLBARTEXTURE);
}

void CCore::FreeBitmaps()
{
  delete FrameBuffers.Knob;
  delete FrameBuffers.DigitsFont;
  delete FrameBuffers.Digits;
  delete FrameBuffers.ToolBarTexture;
}

void CCore::Run()
{
  BOOL s;
  MSG  msg;

  while((s = GetMessage(&msg, NULL, 0, 0 )) != 0)
  { 
    if(s == -1)
    {
      throw "Error Retrieving Messages From Queue";
    }
    else
    {
      TranslateMessage(&msg); 
      DispatchMessage(&msg);
    }
  }
}

void CCore::Quit()
{
  PostQuitMessage(0);
}

void CCore::ClearProject()
{
  if(ProjectFileName)
  {
    delete ProjectFileName;
    ProjectFileName = 0;
  }
  MainWindow->Studio->Lock();
  MainWindow->Studio->Master = 0;
  MainWindow->SequenceEditor->ClearTracks();
  MainWindow->PatternEditor->Lock();
  MainWindow->PatternEditor->ClearPatterns();
  MainWindow->PatternEditor->Release();
  while(MainWindow->Studio->FirstContainer)
    MainWindow->Studio->RemoveMachine(MainWindow->Studio->FirstContainer);
  MainWindow->Studio->ResetScrolling();
  MainWindow->Studio->Release();
}

void CCore::DisplayProjectTitle()
{
  if(ProjectFileName)
  {
    char *p1, *p2, buffer[2048];
    
    p1 = ProjectFileName;
    p2 = ProjectFileName;
    while(*p2)
    {
      if(*p2 == '\\')
        p1 = p2 + 1;
      p2++;
    }
    sprintf(buffer, "DarkWave Studio - %s", p1);
    MainWindow->SetText(buffer);
  }
  else
    MainWindow->SetText("DarkWave Studio");
}

#pragma pack(push)
#pragma pack(1)

#define DWP_HEADER_MAGIC 'DWP '
#define DWP_MAJOR_VERSION 6
#define DWP_MINOR_VERSION 0
#define DWP_MAJOR_VERSION_SUPPORTED_BY "3.8.4"

typedef struct
{
  int       Magic;
  char      MajorVersion;
  char      MinorVersion;
  float     BPM;
} DWP_HEADER;

typedef struct
{
  float     TPB;
} DWP_HEADER_2;

typedef struct
{
  int MachineCount;
} DWP_MACHINE_HEADER;

typedef struct
{
  char Name[1024];
  char UniqueID[1024];
  int  X, Y, VisibleControl;
  int  PropertyBytes;
  bool IsInner;
} DWP_MACHINE;

typedef struct
{
  char MachineName[1024];
} DWP_MACHINE_2;

#pragma pack(pop)

void CCore::WriteProject(char *fileName)
{
  FILE *f;

  f = fopen(fileName, "wb");
  if(f)
  {
    DWP_HEADER h;
    DWP_HEADER_2 h2;

    memset(&h, 0, sizeof(h));
    h.Magic        = DWP_HEADER_MAGIC;
    h.MajorVersion = DWP_MAJOR_VERSION;
    h.MinorVersion = DWP_MINOR_VERSION;
    h.BPM = (float)Host->GetBPM();

    fwrite(&h, sizeof(h), 1, f);

    memset(&h2, 0, sizeof(h2));
    h2.TPB = (float)Host->GetTPB();
    fwrite(&h2, sizeof(h2), 1, f);

    DWP_MACHINE_HEADER mh;

    memset(&mh, 0, sizeof(mh));
    mh.MachineCount = MainWindow->Studio->GetMachineCount();

    fwrite(&mh, sizeof(mh), 1, f);

    int machine, port;

    CMachineContainer *mc = MainWindow->Studio->FirstContainer;
    for(machine = 0; (machine < mh.MachineCount) && (mc != 0); machine++)
    {
      mc->Machine->Index = machine;
      for(port = 0; port < mc->Machine->PortCount; port++)
        mc->Machine->Ports[port]->Index = port;

      mc = mc->GetNext();
    }

    mc = MainWindow->Studio->FirstContainer;

    for(machine = 0; (machine < mh.MachineCount) && (mc != 0); machine++)
    {
      DWP_MACHINE m;
      DWP_MACHINE_2 m2;
      
      char       *data = 0;
      
      memset(&m, 0, sizeof(m));
      strcpy(m.Name, mc->Name);
      strcpy(m.UniqueID, mc->UniqueID);
      m.X = mc->OffsetX;
      m.Y = mc->OffsetY;
      m.VisibleControl = mc->VisibleControl;
      data = 0;
      mc->WriteProperties(&data, &m.PropertyBytes, &m.IsInner);
      fwrite(&m, sizeof(m), 1, f);
      
      memset(&m2, 0, sizeof(m2));
      strcpy(m2.MachineName, mc->MachineInfo->Name);
      fwrite(&m2, sizeof(m2), 1, f);
      
      fwrite(data, m.PropertyBytes, 1, f);
      mc = mc->GetNext();
    }

    mc = MainWindow->Studio->FirstContainer;
    char *data;

    for(machine = 0; (machine < mh.MachineCount) && (mc != 0); machine++)
    {
      int b = 0;
      data = 0;

      mc->WriteConnections(&data, &b);
      fwrite(&b, sizeof(b), 1, f);
      fwrite(data, b, 1, f);
      mc = mc->GetNext();

      delete data;
      
      {
        int b = 0;
        data = 0;
        MainWindow->PatternEditor->WritePatterns(&data, &b, machine);
        fwrite(&b, sizeof(b), 1, f);
        fwrite(data, b, 1, f);
        delete data;
      }




    }

      {
        int b = 0;
        data = 0;
        MainWindow->SequenceEditor->WriteSequence(&data, &b);
        fwrite(&b, sizeof(b), 1, f);
        fwrite(data, b, 1, f);
        delete data;
      }
  
      {
        int length;
        char *text;
        text = MainWindow->ProjectInfo->EditBox->GetText();
        length = (int)strlen(text) + 1;
        fwrite(&length, sizeof(length), 1, f);
        fwrite(text, length, 1, f);
      }


    fclose(f);
  }
  else
    ThrowString("Failed To Open File '%s' For Writing", fileName);
}

#define ERROR_CORRUPT "File '%s' Is Corrupt", fileName

void CCore::ReadProject(char *fileName)
{
  FILE *f;

  f = fopen(fileName, "rb");
  if(f)
  {
    DWP_HEADER   h;
    DWP_HEADER_2 h2;

    if(fread(&h, sizeof(h), 1, f) != 1)
      ThrowString(ERROR_CORRUPT);

    if(h.Magic != DWP_HEADER_MAGIC)
      ThrowString(ERROR_CORRUPT);

    if(h.MajorVersion > DWP_MAJOR_VERSION)
      ThrowString("File '%s' Has A Greater Version Number Than Supported By This Version Of DarkWave Studio.", fileName);
   
    Host->SetBPM(h.BPM);
    MainWindow->MainToolBar->BPMUpDown->SetValue(Host->GetBPM());

    if(h.MajorVersion > 3)
    {
      if(fread(&h2, sizeof(h2), 1, f) != 1)
        ThrowString(ERROR_CORRUPT);
    }
    else
      h2.TPB = 16;

    Host->SetTPB(h2.TPB);
    MainWindow->MainToolBar->TPBUpDown->SetValue(Host->GetTPB());

    DWP_MACHINE_HEADER mh;

    if(fread(&mh, sizeof(mh), 1, f) != 1)
      ThrowString(ERROR_CORRUPT);

    int i, j;
    CMachineContainer **mc;
    int p = 0;
    
    mc = new CMachineContainer*[mh.MachineCount];
    
    for(i = 0; i < mh.MachineCount; i++)
    {
      DWP_MACHINE m;
      DWP_MACHINE_2 m2;
      
      char *properties;

      if(fread(&m, sizeof(m), 1, f) != 1)
        ThrowString(ERROR_CORRUPT);
  
      if(h.MajorVersion > 4)
        if(fread(&m2, sizeof(m2), 1, f) != 1)
          ThrowString(ERROR_CORRUPT);
      
      if(m.PropertyBytes != 0)
      {
        properties = new char[m.PropertyBytes];

        if(fread(properties, m.PropertyBytes, 1, f) != 1)
          ThrowString(ERROR_CORRUPT);
      }
      else
        properties = 0;

      if(!strcmp(m.Name, "DarkPlug::ES BrainSynth"))
        strcpy(m.Name, "DarkPlug::ES BassHead");
      
      mc[i] = MainWindow->Studio->AddMachine(m.Name, h.MajorVersion > 4 ? m2.MachineName : m.Name, m.UniqueID, m.X >= 0 ? m.X : 0, m.Y >= 0 ? m.Y : 0, m.VisibleControl, properties, m.PropertyBytes, m.IsInner, h.MajorVersion < 6);
      if((mc[i]) == 0)
      {
        DisplayError("Machine of name \"%s\" could not be loaded.\r\nIf you save the project the machine's settings, connections, and patterns (if any) will be lost.", m.Name);
 
      }
      else
      {
        mc[i]->Machine->Index = i;
        for(j = 0; j < mc[i]->Machine->PortCount; j++)
          mc[i]->Machine->Ports[j]->Index = j;
      }
      if(properties != 0)
      {
        delete properties;
        properties = 0;
      }
    }

    int machine = 0;
    char *data;

    for(i = 0; i < mh.MachineCount; i++)
    {
      int b;
      data = 0;

      if(fread(&b, sizeof(b), 1, f) != 1)
        ThrowString(ERROR_CORRUPT);

      data = new char[b];
      if(fread(data, b, 1, f) != 1)
        ThrowString(ERROR_CORRUPT);

      if(mc[i] != 0)
        mc[i]->ReadConnections(data, b, h.MajorVersion > 1, h.MajorVersion < 3);
        
      if(fread(&b, sizeof(b), 1, f) != 1)
        ThrowString(ERROR_CORRUPT);

      data = new char[b];
      if(fread(data, b, 1, f) != 1)
        ThrowString(ERROR_CORRUPT);

      if(mc[i])
        MainWindow->PatternEditor->ReadPatterns(data, b, machine++);

      delete data;
    }

    int b = 0;
   
      
    if(fread(&b, sizeof(b), 1, f) != 1)
      ThrowString(ERROR_CORRUPT);

    data = new char[b];
    if(fread(data, b, 1, f) != 1)
      ThrowString(ERROR_CORRUPT);

    MainWindow->SequenceEditor->ReadSequence(data, b);
    delete data;

    if((h.MajorVersion == 2 && h.MinorVersion == 1) || (h.MajorVersion > 2))
    {
      int   length;
      char *text;

      if(fread(&length, sizeof(length), 1, f) != 1)
        ThrowString(ERROR_CORRUPT);
  
      if(length > 0)
      {
        text = new char[length];
        if(fread(text, length, 1, f) != 1)
          ThrowString(ERROR_CORRUPT);

        MainWindow->ProjectInfo->EditBox->SetText(text);
        delete text;
      }
      else
        MainWindow->ProjectInfo->EditBox->SetText("");
    }
    else
      MainWindow->ProjectInfo->EditBox->SetText("");

    fclose(f);
    
    if(h.MajorVersion < DWP_MAJOR_VERSION)
      DisplayError("This project was saved with version %i project file format. If you save the project it will use project format version %i and will be require at least DarkWave Studio v%s.", h.MajorVersion, DWP_MAJOR_VERSION, DWP_MAJOR_VERSION_SUPPORTED_BY);
  }
  else
    ThrowString("Failed To Open File '%s' For Reading", fileName);
}

void CCore::NewProject()
{
  CMachine          *machine;
  CMachineInfo      *machineInfo;
  CMachineContainer *masterContainer;

  try
  {
    ClearProject();
    MachineLoader->CreateMachine("Master", &machine, &machineInfo);
    masterContainer = MainWindow->Studio->AddMachine("Master", 32, 32, machine, machineInfo, MachineLoader->Entries->Items[0]);
    MainWindow->Studio->SetMaster(masterContainer);
    MainWindow->ProjectInfo->EditBox->SetText("");
  }
  catch(char *theError)
  {
    DisplayError(theError);
  }
}

void CCore::OpenProject()
{
  try
  {
    char fileName[1024];
    char *filter = "DarkWave Project (*.dwp)\0*.dwp\0\0";
    char *defExt = "dwp";
    bool ok;
    int  nFilterIndex = 1;

    fileName[0] = 0;
    ok = OpenDialog(filter, defExt, fileName, &nFilterIndex);
    if(ok)
    {
      ClearProject();
      ProjectFileName = CopyString(fileName);
      ReadProject(ProjectFileName);
      DisplayProjectTitle();
    }
   
  }
  catch(char *theError)
  {
    DisplayError(theError);
  }
}

void CCore::SaveProject()
{
  try
  {
    if(ProjectFileName == 0)
      SaveProjectAs();
    else
      WriteProject(ProjectFileName);
  }
  catch(char *theError)
  {
    DisplayError(theError);
  }
}

void CCore::SaveProjectAs()
{
  try
  {
    char fileName[1024];
    char *filter = "DarkWave Project (*.dwp)\0*.dwp\0\0";
    char *defExt = "dwp";
    bool ok;
    int  nFilterIndex = 1;

    fileName[0] = 0;
    ok = SaveAsDialog(filter, defExt, fileName, &nFilterIndex);
    if(ok)
    {
      if(ProjectFileName)
        delete ProjectFileName;
      ProjectFileName = CopyString(fileName);
      WriteProject(ProjectFileName);
      DisplayProjectTitle();
    }
  }
  catch(char *theError)
  {
    DisplayError(theError);
  }
}

void CCore::ResetAudioOutput(int driverNum)
{
  int oldSampleRate, oldBlockSamples, sampleRate, blockSamples;
  CAudioOutputDriver *driver;

  AudioManager->CloseOutput();

  oldSampleRate   = Host->GetSampleRate();
  oldBlockSamples = Host->GetBlockSamples();
  AudioManager->OutputDriver = driverNum;
  driver = AudioManager->GetOutputDriver();

  AudioManager->OpenOutput(AudioOutputWriteProc);
  
  sampleRate   = driver->GetSampleRate();
  blockSamples = driver->GetBlockSamples();

  MainWindow->Studio->Lock();
  Host->SetSampleRateAndBlockSamples(sampleRate, blockSamples);
  if(sampleRate != oldSampleRate)
    MainWindow->Studio->SetSampleRate(sampleRate);
  if(blockSamples != oldBlockSamples)
    MainWindow->Studio->SetBlockSamples(blockSamples);
  MainWindow->Studio->Release();
 
}

void CCore::SetBPM(double value)
{
  MainWindow->Studio->Lock();
  Host->SetBPM(value);
  MainWindow->Studio->Release();
}

void CCore::SetTPB(double value)
{
  MainWindow->Studio->Lock();
  Host->SetTPB(value);
  MainWindow->Studio->Release();
}

