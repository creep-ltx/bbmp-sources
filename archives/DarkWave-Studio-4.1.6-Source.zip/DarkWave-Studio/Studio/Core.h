/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CORE_H
#define CORE_H

#include "MainWindow.h"
#include "ColorManager.h"
#include "MachineLoader.h"
#include "MIDIManager.h"
#include "AudioManager.h"
#include "Host.h"
#include "GraphicsThread.h"
#include "AboutBox.h"
#include "Semaphore.h"
#include "FileDialog.h"
#include "Options.h"

class CFrameBuffer;
class CBitFont;

struct SGlobalData
{
  CFrameBuffer *Knob;
  CFrameBuffer *Digits;
  CBitFont     *DigitsFont;
  CFrameBuffer *ToolBarTexture;
};

class CCore
{
public:
         CCore();
        ~CCore();
   void  InitBitmaps();
   void  FreeBitmaps();
   bool  Init(HINSTANCE appInstance);
   void  Free();
   void  Run();
   void  Quit();
   void  ResetAudioOutput(int driver);
   void  SetBPM(double value);
   void  SetTPB(double value);
   void  ClearProject();
   void  NewProject();
   void  OpenProject();
   void  SaveProject();
   void  SaveProjectAs();
   void  DisplayProjectTitle();
   void  WriteProject(char *fileName);
   void  ReadProject(char *fileName);
   void  ShowHelp();

  HICON               AppIconSmall, AppIconLarge, VSTIcon;
  CMainWindow        *MainWindow;
  CColorManager      *ColorManager;
  CMachineLoader     *MachineLoader;
  CMIDIManager       *MIDIManager;
  CAudioManager      *AudioManager;
  CDarkHost          *Host;
  double              Volume;
  CGraphicsThread    *GraphicsThread;
  CAboutBox          *AboutBox;
  CFrameBuffer       *AboutBoxBackground;
  int                 CPUFeatures, ProcessorCount;
  SGlobalData         FrameBuffers;
  char               *ProjectFileName;
  COptions           *Options;
};

extern CCore *Core;

#endif