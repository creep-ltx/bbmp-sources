/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MAINTOOLBAR_H
#define MAINTOOLBAR_H

#include "../Shared/ToolBar.h"
#include "../Shared/ToolTip.h"
#include "../Shared/Slider.h"
#include "../Shared/ToolBarButton.h"
#include "PeakMeter.h"

class CUpDown;
class CLabel;
class CFont;
class CPeakMeter;

class CVolumeSlider : public CSlider
{
public:
               CVolumeSlider(CControl *parent);
  virtual void OnChange(double newValue);
  virtual void BeforeChange();
  virtual void AfterChange();

private:
  CToolTip    *ToolTip;
};

class CMainToolBar : public CToolBar
{
public:
                  CMainToolBar(CControl *parent, int x, int y, int width, int height);
                 ~CMainToolBar();
  virtual void    OnToolBarButtonPress(CToolBarButton *button);
  virtual void    OnUpDownChange(CUpDown *upDown);
  void            Idle();
  CUpDown        *BPMUpDown, *TPBUpDown;

  CPeakMeter     *PeakMeter;
  CToolBarButton *NewButton, *OpenButton, *SaveButton;

private:
  CVolumeSlider  *VolumeSlider;
  CLabel         *BPMLabel, *TPBLabel;
};

#endif
