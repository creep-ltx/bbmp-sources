/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "DetectCPU.h"
#include <intrin.h>

#define mycpuid(info, level) __cpuid(info, level)

#ifdef DISABLE_CPU_FEATURES
int DetectProcessorFeatures()
{
  return 0;
}
#else
int DetectProcessorFeatures()
{
  int cpuInfo[4];
  int nMaxInfoType;
  int processorFeatures;

  processorFeatures = 0;

  mycpuid(cpuInfo, 0);
  nMaxInfoType = cpuInfo[0];

  if(nMaxInfoType >= 1)
  {
    mycpuid(cpuInfo, 1);
    if((cpuInfo[3] & (1 << 23)) != 0)
      processorFeatures |= CPU_FEATURE_MMX;
    if((cpuInfo[3] & (1 << 25)) != 0)
      processorFeatures |= CPU_FEATURE_SSE;
    if((cpuInfo[3] & (1 << 26)) != 0)
      processorFeatures |= CPU_FEATURE_SSE2;
  }

  mycpuid(cpuInfo, 0x80000000);
  nMaxInfoType = cpuInfo[0];

  if(nMaxInfoType >= 0x80000001)
  {
    mycpuid(cpuInfo, 0x80000001);
    if((cpuInfo[3] & (1 << 31)) != 0)
      processorFeatures |= CPU_FEATURE_3DNOW;
  }

  return processorFeatures;
}
#endif