/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "PatternEditor.h"
#include "Pattern.h"
#include "Core.h"
#include "UpDown.h"
#include "../Resource.h"
#include <stdio.h>
#include "Util.h"

#define TOOLBAR_HEIGHT                   30
#define SIZEBAR_HEIGHT                   6
#define SCROLLBAR_SIZE                   16
#define COMBO_ITEMHEIGHT                 18
#define COMBO_HEIGHT                     18
#define MACHINE_COMBO_WIDTH              180
#define PATTERN_COMBO_WIDTH              120
#define PORT_COMBO_WIDTH                 120
#define LENGTH_COMBO_WIDTH               60
#define NOTE_COMBO_WIDTH                 60
#define PROPERTY_COMBO_WIDTH             180

#define BUTTON_ADDPATTERN                0
#define BUTTON_REMOVEPATTERN             1
#define BUTTON_ADDNOTE                   2
#define BUTTON_PLAY                      3
#define BUTTON_STOP                      4
#define BUTTON_LOOP                      5
#define BUTTON_EDIT_MODE                 6
#define BUTTON_SELECT_MODE               7
#define BUTTON_RENAME_PATTERN            8
#define BUTTON_DUPLICATE                 9
#define BUTTON_TRANSPOSE_UP              10
#define BUTTON_TRANSPOSE_DOWN            11

#define PATTERN_LENGTH_COUNT   17
#define DEFAULT_PATTERN_LENGTH 16

#define MIN_NOTE_LENGTH     1
#define MAX_NOTE_LENGTH     64
#define DEFAULT_NOTE_LENGTH 1

#define LABEL_HEIGHT                14
#define NOTE_LENGTH_LABEL_WIDTH     82
#define NOTE_LENGTH_UPDOWN_WIDTH    48
#define PATTERN_LENGTH_LABEL_WIDTH  102
#define PATTERN_LENGTH_UPDOWN_WIDTH 56
#define UPDOWN_HEIGHT               18

CPatternEditor::CPatternEditor(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "PatternEditor", x, y, width, height, false)
{
  CurrentMachine = 0;
  CurrentPattern = 0;

  RenameDialog = new CRenameDialog(this, "Rename Pattern", "Name:");

  NoteViewPercent = 0.65f;
  PatternToolBar  = new CToolBar(this, 0, 0, Width, TOOLBAR_HEIGHT);
  NoteToolBar     = new CToolBar(this, 0, TOOLBAR_HEIGHT, Width, TOOLBAR_HEIGHT);
  ControlToolBar  = new CToolBar(this, 0, (TOOLBAR_HEIGHT * 2) + NoteViewHeight + SIZEBAR_HEIGHT, Width, TOOLBAR_HEIGHT);
  ScrollBarH      = new CScrollBar(this, SCROLLBAR_HORIZONTAL, 0, Height - SCROLLBAR_SIZE, Width, SCROLLBAR_SIZE, 0, 16);
  ControlView     = new CControlView(this, 0, (TOOLBAR_HEIGHT * 3) + NoteViewHeight + SIZEBAR_HEIGHT, Width, Height - SCROLLBAR_SIZE - ((TOOLBAR_HEIGHT * 3) + NoteViewHeight + (SIZEBAR_HEIGHT * 2)), ScrollBarH);
  NoteView        = new CNoteView(this, 0, TOOLBAR_HEIGHT * 2, Width, NoteViewHeight, ScrollBarH, ControlView);
  SizeBar         = new CSizeBar(this, SIZEBAR_STYLE_HORIZONTAL, 0, (TOOLBAR_HEIGHT * 2) + NoteViewHeight, Width, SIZEBAR_HEIGHT); 
  
  MachineCombo = new CDropList(PatternToolBar, "MachineCombo", 0, 0, MACHINE_COMBO_WIDTH, COMBO_HEIGHT);
  PatternToolBar->AddControl(MachineCombo, "Select Machine", MachineCombo->Handle);

  PatternCombo = new CDropList(PatternToolBar, "PatternCombo", 0, 0, PATTERN_COMBO_WIDTH, COMBO_HEIGHT);
  PatternToolBar->AddControl(PatternCombo, "Select Pattern", PatternCombo->Handle);

  RenamePatternButton = PatternToolBar->AddButton(IDI_EDIT, BUTTON_RENAME_PATTERN, 20, 20, "Rename Pattern", false);

  PortCombo = new CDropList(PatternToolBar, "PortCombo", 0, 0, PORT_COMBO_WIDTH, COMBO_HEIGHT);
  PatternToolBar->AddControl(PortCombo, "Select Port", PortCombo->Handle);

  NoteLengthLabel = new CLabel(NoteToolBar, "Note Length:", 0, 0, NOTE_LENGTH_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  NoteLengthUpDown = new CUpDown(NoteToolBar, 0, 0, NOTE_LENGTH_UPDOWN_WIDTH, UPDOWN_HEIGHT, 1.0, 1024.0, 1.0, DEFAULT_NOTE_LENGTH, false);
  NoteToolBar->AddControl(NoteLengthLabel, "");
  NoteToolBar->AddControl(NoteLengthUpDown, "Note Length");

  EditModeButton = NoteToolBar->AddButton(IDI_PENCIL, BUTTON_EDIT_MODE, 20, 20, "Edit Mode", true);
  EditModeButton->SetPressed(true);
  SelectModeButton = NoteToolBar->AddButton(IDI_SELECT, BUTTON_SELECT_MODE, 20, 20, "Select Mode", true);
  TransposeUpButton = NoteToolBar->AddButton(IDI_TRANSPOSE_UP, BUTTON_TRANSPOSE_UP, 20, 20, "Transpose Up", false);
  TransposeDownButton = NoteToolBar->AddButton(IDI_TRANSPOSE_DOWN, BUTTON_TRANSPOSE_DOWN, 20, 20, "Transpose Down", false);

  AddPatternButton = PatternToolBar->AddButton(IDI_ADD, BUTTON_ADDPATTERN, 20, 20, "Add Pattern", false);
  RemovePatternButton = PatternToolBar->AddButton(IDI_REMOVE, BUTTON_REMOVEPATTERN, 20, 20, "Remove Pattern", false);
  DuplicatePatternButton = PatternToolBar->AddButton(IDI_DUPLICATE, BUTTON_DUPLICATE, 20, 20, "Duplicate Pattern", false);

  PatternLengthLabel = new CLabel(PatternToolBar, "Pattern Length:", 0, 0, PATTERN_LENGTH_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  PatternLengthUpDown = new CUpDown(PatternToolBar, 0, 0, PATTERN_LENGTH_UPDOWN_WIDTH, UPDOWN_HEIGHT, 1.0, 1024.0, 1.0, 16.0, false);
  PatternToolBar->AddControl(PatternLengthLabel, "");
  PatternToolBar->AddControl(PatternLengthUpDown, "Pattern Length");


  PlayButton = PatternToolBar->AddButton(IDI_PLAY, BUTTON_PLAY, 20, 20, "Play Pattern", true);
  StopButton = PatternToolBar->AddButton(IDI_STOP, BUTTON_STOP, 20, 20, "Stop Pattern", false);
  LoopButton = PatternToolBar->AddButton(IDI_LOOP, BUTTON_LOOP, 20, 20, "Loop Pattern", true);

  PropertyCombo = new CDropList(ControlToolBar, "PropertyCombo", 0, 0, PROPERTY_COMBO_WIDTH, COMBO_HEIGHT);
  ControlToolBar->AddControl(PropertyCombo, "Select Property", PropertyCombo->Handle);

  AddControlTrackButton = ControlToolBar->AddButton(IDI_ADD, 0, 20, 20, "Add Control Track", false);
  RemoveControlTrackButton = ControlToolBar->AddButton(IDI_REMOVE, 0, 20, 20, "Remove Control Track", false);

  InitStaticCombos();

  PatternToolBar->Show();
  NoteToolBar->Show();
  ControlToolBar->Show();
  ScrollBarH->Show();
  NoteView->Show();
  ControlView->Show();
  SizeBar->Show();

  Machines        = new CArray<CMachineContainer*>();
  Ports           = new CArray<CConnector*>();
  Patterns        = new CArray<CPattern*>();
  MachinePatterns = new CArray<CPattern*>();
  Properties      = new CArray<int>();

  SubInit = true;
}

CPatternEditor::~CPatternEditor()
{
  ClearPatterns();

  delete TransposeUpButton;
  delete TransposeDownButton;
  delete DuplicatePatternButton;
  delete RenameDialog;
  delete RenamePatternButton;
  delete EditModeButton;
  delete SelectModeButton;
  delete PatternToolBar;
  delete NoteToolBar;
  delete ControlToolBar;
  delete ScrollBarH;
  delete NoteView;
  delete ControlView;
  delete MachineCombo;
  delete PatternCombo;
  delete PortCombo;
  delete PatternLengthLabel;
  delete PatternLengthUpDown;
  delete AddPatternButton;
  delete RemovePatternButton;
  delete Machines;
  delete SizeBar;
  delete Ports;
  delete Patterns;
  delete MachinePatterns;
  delete NoteLengthLabel;
  delete NoteLengthUpDown;
  delete PlayButton;
  delete StopButton;
  delete LoopButton;
  delete PropertyCombo;
  delete AddControlTrackButton;
  delete RemoveControlTrackButton;
}

void CPatternEditor::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
    PerformLayout();
}

void CPatternEditor::PerformLayout()
{
  NoteViewHeight = (Height - ((3 * TOOLBAR_HEIGHT) + SIZEBAR_HEIGHT + SCROLLBAR_SIZE));
  NoteViewHeight = (int)(NoteViewHeight * NoteViewPercent);

  PatternToolBar->Move(0, 0, Width, TOOLBAR_HEIGHT);
  NoteToolBar->Move(0, TOOLBAR_HEIGHT, Width, TOOLBAR_HEIGHT);
  ControlToolBar->Move(0, (TOOLBAR_HEIGHT * 2) + NoteViewHeight + SIZEBAR_HEIGHT, Width, TOOLBAR_HEIGHT);
  ScrollBarH->Move(0, Height - SCROLLBAR_SIZE, Width, SCROLLBAR_SIZE);
  NoteView->Move(0, TOOLBAR_HEIGHT * 2, Width, NoteViewHeight);
  ControlView->Move(0, (TOOLBAR_HEIGHT * 3) + NoteViewHeight + SIZEBAR_HEIGHT, Width, Height - SCROLLBAR_SIZE - ((TOOLBAR_HEIGHT * 3) + NoteViewHeight + (SIZEBAR_HEIGHT * 2)));
  SizeBar->Move(0, (TOOLBAR_HEIGHT * 2) + NoteViewHeight, Width, SIZEBAR_HEIGHT);
}

void CPatternEditor::OnSizeY(CSizeBar *sizeBar, int amount)
{
  int MaxNoteViewHeight;

  MaxNoteViewHeight = (Height - ((3 * TOOLBAR_HEIGHT) + SIZEBAR_HEIGHT + SCROLLBAR_SIZE));
  NoteViewPercent += (float)(amount) / (float)MaxNoteViewHeight;
  if(NoteViewPercent < 0.1f)
    NoteViewPercent = 0.1f;
  else if(NoteViewPercent > 0.9f)
    NoteViewPercent = 0.9f;
  PerformLayout();
}

void CPatternEditor::AddMachine(CMachineContainer *machine)
{
  int i;

  if(MachineHasValidPorts(machine))
  {
    Machines->AddItem(machine);
    MachineCombo->AddItem(machine->Name);
   
    for(i = 0; i < machine->Machine->PortCount; i++)
      if(IsValidPort(machine->Machine->Ports[i]))
        AddPort(machine->Connectors[i]);
  }
}

void CPatternEditor::UpdateMachineNames()
{
  int i, mi;

  mi = MachineCombo->GetSelection();
  MachineCombo->Clear();

  for(i = 0; i < Machines->Count; i++)
  {
    MachineCombo->AddItem(Machines->Items[i]->Name);
  }

  MachineCombo->SetSelection(mi);
}

void CPatternEditor::RemoveMachine(CMachineContainer *machine)
{
  int i;

  for(i = 0; i < Patterns->Count; i++)
    if(Patterns->Items[i]->Port->Container == machine)
    {
      delete Patterns->Items[i];
      Patterns->Items[i] = 0;
      Patterns->RemoveItem(i);
      i--;
    }

  for(i = 0; i < Machines->Count; i++)
    if(Machines->Items[i] == machine)
    {
      Machines->RemoveItem(i);
      MachineCombo->RemoveItem(i);
      i--;
    }

  if(CurrentMachine == machine)
    LoadMachine(0);
}

void CPatternEditor::OnComboSelect(CDropList *comboBox)
{
  int i;

  if(comboBox == MachineCombo)
  {
    i = comboBox->GetSelection();
    if(i >= 0 && i < Machines->Count)
      if(CurrentMachine != Machines->Items[i])
      {
        LoadMachine(Machines->Items[i]);
      }
 /*   else
    {
      if(CurrentMachine != 0)
      {
        LoadMachine(0);
      }
    }*/
  }

  if(comboBox == PortCombo)
  {
    if(CurrentMachine != 0)
    {
      i = comboBox->GetSelection();
      if(i >= 0 && i < Ports->Count)
      {
        LoadPort(Ports->Items[i]);
        if(CurrentPattern != 0)
          CurrentPattern->Port = CurrentPort;
      }
      else
        LoadPort(0);
    }
  }

  if(comboBox == PatternCombo)
  {
    i = PatternCombo->GetSelection();
    if(i >= 0 && i < MachinePatterns->Count)
      LoadPattern(MachinePatterns->Items[i]);
    else
      LoadPattern(0);
  }
}

void CPatternEditor::OnUpDownChange(CUpDown *upDown)
{
  int i;

  if(upDown == NoteLengthUpDown)
  {
    i = (int)NoteLengthUpDown->GetValue();
    NoteView->SetNoteLength(i);
  }

  if(upDown == PatternLengthUpDown)
  {
    if(CurrentPattern)
    {
      i = (int)PatternLengthUpDown->GetValue();
      CurrentPattern->Resize(i);
      LoadPattern(CurrentPattern);

      Core->MainWindow->SequenceEditor->Lock();
      Core->MainWindow->SequenceEditor->OnResizePattern(CurrentPattern);
      Core->MainWindow->SequenceEditor->SequenceView->Update();
      Core->MainWindow->SequenceEditor->Release();

    }
  }
}

void CPatternEditor::LoadPorts()
{
  CConnector *port;
  int         i;

  Ports->Clear();
  PortCombo->Clear();
  CurrentPort = 0;

  if(CurrentMachine != 0)
  {
    for(i = 0; i < CurrentMachine->ConnectorCount; i++)
    {
      port = CurrentMachine->Connectors[i];
      AddPort(port);
    }
  }

  if(Ports->Count > 0)
  {
    PortCombo->SetSelection(0);
    LoadPort(Ports->Items[0]);
  }
  else
    LoadPort(0);
}

void CPatternEditor::AddPort(CConnector *port)
{
  if(IsValidPort(port->Port))
  {
    Ports->AddItem(port);
    PortCombo->AddItem(port->Port->Name);
    Core->MainWindow->SequenceEditor->AddTrack(port);
  }
}

bool CPatternEditor::IsValidPort(CPort *port)
{
  if((port->Type & (PT_CONTROL | PT_OUTPUT)) == PT_CONTROL)
    return true;
  else
    return false;
}

bool CPatternEditor::MachineHasValidPorts(CMachineContainer *machine)
{
  int i;

  for(i = 0; i < machine->ConnectorCount; i++)
    if(IsValidPort(machine->Connectors[i]->Port))
      return true;
  return false;
}

void CPatternEditor::InitStaticCombos()
{
  NoteView->SetNoteLength(DEFAULT_NOTE_LENGTH);
}

void CPatternEditor::ClearPatterns()
{
  while(Patterns->Count)
  {
    delete Patterns->Items[0];
    Patterns->RemoveItem(0);
  }
  Patterns->Clear();
}

void CPatternEditor::LoadMachine(CMachineContainer *machine)
{
  CurrentMachine = machine;
  CurrentPort    = 0;
  LoadPorts();
  LoadMachinePatterns(true);
}

void CPatternEditor::LoadMachinePatterns(bool clear)
{
  int       i;
  CPattern *pattern;

  MachinePatterns->Clear();
  PatternCombo->Clear();
  if(clear)
    CurrentPattern = 0;
  
  if(CurrentMachine != 0)
  {
    for(i = 0; i < Patterns->Count; i++)
    {
      pattern = Patterns->Items[i];
      if(pattern->Port)
        if(pattern->Port->Container == CurrentMachine)
        {
          MachinePatterns->AddItem(pattern);
          PatternCombo->AddItem(pattern->Name);
        }
    }
  }

  for(i = 0; i < MachinePatterns->Count; i++)
  {
    if(MachinePatterns->Items[i] == CurrentPattern)
    {
      PatternCombo->SetSelection(i);
      return;
    }
  }

  if(MachinePatterns->Count > 0)
  {
    PatternCombo->SetSelection(0);
    LoadPattern(MachinePatterns->Items[0]);
  }
  else
    LoadPattern(0);
}

#pragma pack(push)
#pragma pack(2)

typedef struct 
{
  int PatternCount;
} PatternsHeader;

typedef struct
{
  int  Index;
  int  Length;
  char Name[1024];
  int  NoteCount;
  int  ControlTrackCount;
  int  Machine;
  int  Connector;
} Pattern;

typedef struct
{
  int Start;
  int Length;
  int Note;
} Note;

typedef struct
{
  int Index;
  int EventCount;
} ControlTrack;

typedef struct
{
  float  Value;
  bool   Used;
} ControlEvent;

#pragma pack(pop)

void CPatternEditor::WritePatterns(char **buffer, int *size, int machine)
{
  PatternsHeader *ph;
  Pattern *p;
  int i, j, k, patternSpace = 0;
  Note *n;
  char *x;
  ControlTrack *t;
  ControlEvent *e;
  CControlTrack *track;

  for(i = 0; i < Patterns->Count; i++)
  {
    Patterns->Items[i]->Index = i;
    if(Patterns->Items[i]->Port)
    {
      if(Patterns->Items[i]->Port->Container)
        if(Patterns->Items[i]->Port->Container->Machine->Index == machine)
        {
          patternSpace += sizeof(Pattern) + (Patterns->Items[i]->GetNoteCount() * sizeof(Note));
          for(j = 0; j < Patterns->Items[i]->ControlTracks->Count; j++)
          {
            patternSpace += sizeof(ControlTrack);
            patternSpace += sizeof(ControlEvent) * Patterns->Items[i]->ControlTracks->Items[j]->Entries->Count;
          }
        }
    }
  }

  *size = patternSpace + sizeof(PatternsHeader);
  *buffer = new char[*size];
  ph = (PatternsHeader*)*buffer;
  ph->PatternCount = 0;

  x = *buffer + sizeof(PatternsHeader);  

  for(i = 0; i < Patterns->Count; i++)
  {
    if(Patterns->Items[i]->Port->Container->Machine->Index == machine)
    {
      ph->PatternCount++;
      
      p = (Pattern*)(x);
      p->Machine = machine;
      p->Connector = Patterns->Items[i]->Port->Port->Index;
      p->Length = Patterns->Items[i]->Length;
      strcpy(p->Name, Patterns->Items[i]->Name);
      p->NoteCount = Patterns->Items[i]->GetNoteCount();
      p->ControlTrackCount = Patterns->Items[i]->ControlTracks->Count;
      p->Index = Patterns->Items[i]->Index;

      x += sizeof(Pattern);

      CNote *note = Patterns->Items[i]->FirstNote;
      while(note)
      {
        n = (Note*)(char*)x;
        n->Note = note->Note;
        n->Start = note->Start;
        n->Length = note->Length;
        n++;
        note = note->GetNext();

        x += sizeof(Note);
      }

      for(j = 0; j < Patterns->Items[i]->ControlTracks->Count; j++)
      {
        track = Patterns->Items[i]->ControlTracks->Items[j];
        t = (ControlTrack*)x;
        t->Index = track->Property;
        t->EventCount = track->Entries->Count;
      
        x += sizeof(ControlTrack);

        for(k = 0; k < track->Entries->Count; k++)
        {
          e = (ControlEvent*)x;
          e->Value  = (float)track->Entries->Items[k]->Value;
          e->Used   = track->Entries->Items[k]->Used;
          
          x += sizeof(ControlEvent);
        }
      }
    }
  }
}

void CPatternEditor::ReadPatterns(char *buffer, int size, int machine)
{
  PatternsHeader *ph;
  Pattern *p;
  int i, j, k;
  Note *n;
  ControlTrack  *t;
  ControlEvent  *e;
  CControlTrack *track;

  ph = (PatternsHeader*)buffer;
  buffer += sizeof(PatternsHeader); 

  for(i = 0; i < ph->PatternCount; i++)
  {
    p = (Pattern*)(buffer); 
    CPattern *pattern;
   CConnector* c;
   c = Core->MainWindow->Studio->GetConnector(p->Machine, p->Connector);

   Patterns->AddItem(new CPattern(p->Length, p->Name, c)); 
    pattern = Patterns->Items[Patterns->Count - 1];
pattern->Index = p->Index;
    buffer += sizeof(Pattern);
    
    for(j = 0; j < p->NoteCount; j++)
    {
      n = (Note*)buffer;
      pattern->AddNote(n->Start, n->Length, n->Note);
      buffer += sizeof(Note);
    }
    
    for(j = 0; j < p->ControlTrackCount; j++)
    {
      int ti;
      
      t = (ControlTrack*)buffer;
      ti = pattern->AddControlTrack(t->Index);
      track = pattern->ControlTracks->Items[ti];
      
      buffer += sizeof(ControlTrack);

      for(k = 0; k < t->EventCount; k++)
      {
        e = (ControlEvent*)buffer;
        track->Entries->Items[k]->Value = (double)e->Value;
        track->Entries->Items[k]->Used  = e->Used;

        buffer += sizeof(ControlEvent);
      }
    }
  }
}

void CPatternEditor::OnRenameDialogSuccess()
{
  if(CurrentPattern != 0)
  {
    char text[1024];

    RenameDialog->GetEditText(text);
    
    if(strcmp(CurrentPattern->Name, text))
    {
      delete CurrentPattern->Name;
      CurrentPattern->Name = CopyString(text);
      LoadMachinePatterns(false);
      Core->MainWindow->SequenceEditor->Lock();
      Core->MainWindow->SequenceEditor->UpdatePatternCombo(Core->MainWindow->SequenceEditor->SequenceView->GetTrack());
      Core->MainWindow->SequenceEditor->SequenceView->Update();
      Core->MainWindow->SequenceEditor->Release();
    }
  }
}

void CPatternEditor::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == RenamePatternButton)
  {
    if(CurrentPattern != 0)
    {
      RenameDialog->SetEditText(CurrentPattern->Name);
      RenameDialog->Show();
    }
  }

  if(button == AddPatternButton)
  {
    AddPattern();
  }

  if(button == RemovePatternButton)
  {
    RemovePattern();
  }

  if(button == DuplicatePatternButton)
  {
    DuplicatePattern();
  }

  if(button == TransposeUpButton)
  {
    Transpose(1);
  }

  if(button == TransposeDownButton)
  {
    Transpose(-1);
  }

  if(button == PlayButton)
  {
    if(CurrentPattern != 0)
    {
      if(button->GetPressed())
      {
        CurrentPattern->SetLoop(LoopButton->GetPressed());
        CurrentPattern->Play(false);
        NoteView->UpdatePlayBar();
      }
      else
      {
        CurrentPattern->SetLoop(false);
        CurrentPattern->Stop(false);
        NoteView->UpdatePlayBar();
      }
    }
  }

  if(button == LoopButton)
  {
    if(CurrentPattern != 0)
      CurrentPattern->SetLoop(button->GetPressed());
  }

  if(button == StopButton)
  {
    if(PlayButton->GetPressed())
    {
      if(CurrentPattern != 0)
      {
        CurrentPattern->SetLoop(false);
        CurrentPattern->Stop(true);
        NoteView->UpdatePlayBar();
        PlayButton->SetPressed(false);
      }
    }
    else
    {
      if(CurrentPattern != 0)
      {
        CurrentPattern->Stop(true);
        NoteView->UpdatePlayBar();
      }
    }
  }

  if(button == AddControlTrackButton)
  {
    int i;

    i = PropertyCombo->GetSelection();
    if(i >= 0 && i < Properties->Count)
      ControlView->AddTrack(Properties->Items[i]);
  }

  if(button == RemoveControlTrackButton)
  {
    int i;

    i = PropertyCombo->GetSelection();
    if(i >= 0 && i < Properties->Count)
      ControlView->RemoveTrack(Properties->Items[i]);
  }

  if(button == SelectModeButton)
  {
    if(SelectModeButton->GetPressed())
    {
      EditModeButton->SetPressed(false);
      NoteView->SetMode(NOTEVIEW_MODE_SELECT_IDLE);
    }
    else
    {
      SelectModeButton->SetPressed(true);
    }
  }

  if(button == EditModeButton)
  {
    if(EditModeButton->GetPressed())
    {
      SelectModeButton->SetPressed(false);
      NoteView->SetMode(NOTEVIEW_MODE_DRAW_IDLE);
      NoteView->Update();
    }
    else
    {
      EditModeButton->SetPressed(true);
    }
  }
}

void CPatternEditor::AddPattern()
{
  CPattern *pattern;
  char     *name;
  int       length;

  if(CurrentMachine != 0 && CurrentPort != 0)
  {
    name    = GeneratePatternName();
    length  = (int)PatternLengthUpDown->GetValue();
    pattern = new CPattern(length, name, CurrentPort); 
    
    delete name;
    Patterns->AddItem(pattern);
    MachinePatterns->AddItem(pattern);
    PatternCombo->AddItem(pattern->Name);
    PatternCombo->SetSelection(MachinePatterns->Count - 1);
    LoadPattern(pattern);
    Core->MainWindow->SequenceEditor->OnAddPattern(pattern);
  }
}

void CPatternEditor::DuplicatePattern()
{
  CPattern *oldPattern, *newPattern;
  char     *name;

  if((CurrentMachine != 0) && (CurrentPattern != 0) && (CurrentPort != 0))
  {
    oldPattern = CurrentPattern;
    name = GeneratePatternName();
    newPattern = new CPattern(oldPattern->Length, name, oldPattern->Port);
    delete name;
    newPattern->CopyPattern(oldPattern);

    Patterns->AddItem(newPattern);
    MachinePatterns->AddItem(newPattern);
    PatternCombo->AddItem(newPattern->Name);
    PatternCombo->SetSelection(MachinePatterns->Count - 1);
    LoadPattern(newPattern);
    Core->MainWindow->SequenceEditor->OnAddPattern(newPattern);
  }
}

void CPatternEditor::Transpose(int amount)
{
  if(CurrentPattern != 0)
  {
    CurrentPattern->Transpose(amount);
    NoteView->Update();
  }
}

void CPatternEditor::RemovePattern()
{
  int       i;
  CPattern *pattern;

  if(CurrentPattern != 0)
  {
    pattern = CurrentPattern;
    CurrentPattern = 0;
    i = PatternIndex(pattern);
    if(i != -1)
      Patterns->RemoveItem(i);
    Core->MainWindow->SequenceEditor->OnRemovePattern(pattern);
    i = MachinePatternIndex(pattern);
    if(i != -1)
    {
      MachinePatterns->RemoveItem(i);
      PatternCombo->RemoveItem(i);
    }
    if(MachinePatterns->Count > 0)
    {
      if(i < 0)
        i = 0;
      else if(i >= MachinePatterns->Count)
        i = MachinePatterns->Count - 1;
      PatternCombo->SetSelection(i);
      LoadPattern(MachinePatterns->Items[i]);
    }
    else
    {
      PatternCombo->Clear();
      LoadPattern(0);
    }
  }
}

CPattern *CPatternEditor::GetPattern(int index)
{
  int i;

  for(i = 0; i < Patterns->Count; i++)
    if(Patterns->Items[i]->Index == index)
      return Patterns->Items[i];
  return 0;
}

CPattern *CPatternEditor::FindPattern(char *name)
{
  int i;

  for(i = 0; i < MachinePatterns->Count; i++)
    if(strcmp(name, MachinePatterns->Items[i]->Name) == 0)
      return MachinePatterns->Items[i];
  return 0;
}

char *CPatternEditor::GeneratePatternName()
{
  int   i;
  char *name;

  for(i = 1; ; i++)
  {
    name = new char[16];
    sprintf(name, "Pattern %i", i);
    if(FindPattern(name) == 0)
      return name;
    else
      delete name;
  }
}

int CPatternEditor::PatternIndex(CPattern *pattern)
{
  int i;

  for(i = 0; i < Patterns->Count; i++)
    if(Patterns->Items[i] == pattern)
      return i;
  return -1;
}

int CPatternEditor::MachinePatternIndex(CPattern *pattern)
{
  int i;

  for(i = 0; i < MachinePatterns->Count; i++)
    if(MachinePatterns->Items[i] == pattern)
      return i;
  return -1;
}

void CPatternEditor::LoadPattern(CPattern *pattern)
{
  if(CurrentPattern != 0 && PlayButton->GetPressed())
    CurrentPattern->Stop(true);
  CurrentPattern = pattern;
  NoteView->LoadPattern(pattern);
  ControlView->LoadPattern(pattern);
  if(CurrentPattern != 0 && PlayButton->GetPressed())
  {
    CurrentPattern->SetLoop(LoopButton->GetPressed());
    CurrentPattern->Play(true);
  }
  if(CurrentPattern != 0)
    PatternLengthUpDown->SetValue((double)CurrentPattern->Length);
}

void CPatternEditor::OnScrollX(int newPos)
{
  NoteView->OnScrollX(newPos);
  ControlView->OnScrollX(newPos);
}

void CPatternEditor::Work()
{
  CPattern *pattern;
  int       i;

  if(PlayButton->GetPressed())
  {
    for(i = 0; i < Patterns->Count; i++)
    {
      pattern = Patterns->Items[i];
      if(pattern == CurrentPattern)
      {
        if(pattern->Playing)
          pattern->Work();
        else  
          PlayButton->SetPressed(false);
      }
    }
  }
}

void CPatternEditor::Animate()
{
  Lock();
  if(CurrentMachine != 0 && CurrentPattern != 0)
  {
      NoteView->UpdatePlayBar();
      NoteView->UpdatePlayBar2();
  }
  Release();
}

void CPatternEditor::LoadPort(CConnector *port)
{
  int       i;
  CMachine *machine;
  char      name[256];

  CurrentPort = port;
  Properties->Clear();
  PropertyCombo->Clear();

  if(port != 0)
  {
    Properties->AddItem(PROPERTY_VELOCITY);
    PropertyCombo->AddItem("Velocity");
    machine = port->Container->Machine;

    for(i = 0; i < machine->PropertyCount; i++)
    {
      *name = 0;
      machine->GetPropertyName(i, name);
      if(*name == 0)
        sprintf(name, "Property %i", i);
      Properties->AddItem(i);
      PropertyCombo->AddItem(name);
    }
  }
}

void CPatternEditor::SetBlockSamples(int blockSamples)
{
  int i;

  for(i = 0; i < Patterns->Count; i++)
    Patterns->Items[i]->SetBlockSamples(blockSamples);
}

void CPatternEditor::SetSampleRate(int sampleRate)
{  
  int i;

  for(i = 0; i < Patterns->Count; i++)
    Patterns->Items[i]->SetSampleRate(sampleRate);
}