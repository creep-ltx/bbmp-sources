/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "VST.h"

#ifdef _DEBUG

const char* EffectCodeStrings[VST_EFFECT_OPCODE_COUNT] =
{
	"effOpen",		// initialise
	"effClose",			// exit, release all memory and other resources!

	"effSetProgram",		// program no in <value>
	"effGetProgram",		// return current program no.
	"effSetProgramName",	// user changed program name (max 24 char + 0) to as passed in string 
	"effGetProgramName",	// stuff program name (max 24 char + 0) into string 

	"effGetParamLabel",	// stuff parameter <index> label (max 8 char + 0) into string
						// (examples: sec, dB, type)
	"effGetParamDisplay",	// stuff parameter <index> textual representation into string
						// (examples: 0.5, -3, PLATE)
	"effGetParamName",	// stuff parameter <index> label (max 8 char + 0) into string
						// (examples: Time, Gain, RoomType) 
	"effGetVu",			// called if (flags & (effFlagsHasClip | effFlagsHasVu))

	// system
	"effSetSampleRate",	// in opt (float value in Hz; for example 44100.0Hz)
	"effSetBlockSize",	// in value (this is the maximun size of an audio block,
						// pls check sampleframes in process call)
	"effMainsChanged",	// the user has switched the 'power on' button to
						// value (0 off, else on). This only switches audio
						// processing; you should flush delay buffers etc.
	
	// editor
	"effEditGetRect",		// stuff rect (top, left, bottom, right) into ptr
	"effEditOpen",		// system dependant Window pointer in ptr
	"effEditClose",		// no arguments
	"effEditDraw",		// draw method, ptr points to rect (MAC Only)
	"effEditMouse",		// index: x, value: y (MAC Only)
	"effEditKey",			// system keycode in value
	"effEditIdle",		// no arguments. Be gentle!
	"effEditTop",			// window has topped, no arguments
	"effEditSleep",		// window goes to background
	
	"effIdentify",		// returns 'NvEf'
	"effGetChunk",		// host requests pointer to chunk into (void**)ptr, byteSize returned
	"effSetChunk",		// plug-in receives saved chunk, byteSize passed
 


	"effProcessEvents",		// VstEvents* in <ptr>

	// parameters and programs
	"effCanBeAutomated",						// parameter index in <index>
	"effString2Parameter",					// parameter index in <index>, string in <ptr>
	"effGetNumProgramCategories",				// no arguments. this is for dividing programs into groups (like GM)
	"effGetProgramNameIndexed",				// get program name of category <value>, program <index> into <ptr>.
											// category (that is, <value>) may be -1, in which case program indices
											// are enumerated linearily (as usual); otherwise, each category starts
											// over with index 0.
	"effCopyProgram",							// copy current program to destination <index>
											// note: implies setParameter	
	// connections, configuration
	"effConnectInput",						// input at <index> has been (dis-)connected;
											// <value> == 0: disconnected, else connected
	"effConnectOutput",						// same as input
	"effGetInputProperties",					// <index>, VstPinProperties* in ptr, return != 0 => true
	"effGetOutputProperties",					// dto
	"effGetPlugCategory",						// no parameter, return value is category

	// realtime
	"effGetCurrentPosition",					// for external dsp, see flag bits below
	"effGetDestinationBuffer",				// for external dsp, see flag bits below. returns float*

	// offline
	"effOfflineNotify",						// ptr = VstAudioFile array, value = count, index = start flag
	"effOfflinePrepare",						// ptr = VstOfflineTask array, value = count
	"effOfflineRun",							// dto

	// other
	"effProcessVarIo",						// VstVariableIo* in <ptr>
	"effSetSpeakerArrangement",				// VstSpeakerArrangement* pluginInput in <value>
											// VstSpeakerArrangement* pluginOutput in <ptr>
	"effSetBlockSizeAndSampleRate",			// block size in <value>, sampleRate in <opt>
	"effSetBypass",							// onOff in <value> (0 = off)
	"effGetEffectName",						// char* name (max 32 bytes) in <ptr> 
	"effGetErrorText",						// char* text (max 256 bytes) in <ptr> 
	"effGetVendorString",						// fills <ptr> with a string identifying the vendor (max 64 char)
	"effGetProductString",					// fills <ptr> with a string with product name (max 64 char)
	"effGetVendorVersion",					// returns vendor-specific version
	"effVendorSpecific",						// no definition, vendor specific handling
	"effCanDo",								// <ptr>
	"effGetTailSize",							// returns tail size; 0 is default (return 1 for 'no tail')
	"effIdle",								// idle call in response to audioMasterneedIdle. must
											// return 1 to keep idle calls beeing issued

	// gui
	"effGetIcon",								// void* in <ptr>, not yet defined
	"effSetViewPosition",						// set view position (in window) to x <index> y <value>

	// and...
	"effGetParameterProperties",				// of param <index>, VstParameterProperties* in <ptr>
	"effKeysRequired",						// returns 0: needs keys (default for 1.0 plugs), 1: don't need
	"effGetVstVersion",						// returns 2 for VST 2; older versions return 0; 2100 for VST 2.1

	// note that effNumOpcodes doesn't apply anymore


	//---from here VST 2.1 extension opcodes---------------------------------------------------------
	"effEditKeyDown",       // Character in <index>, virtual in <value>, modifiers in <opt>,
	                                        // return -1 if not used, return 1 if used
	"effEditKeyUp",                           // Character in <index>, virtual in <value>, modifiers in <opt>
	                                        // return -1 if not used, return 1 if used
	"effSetEditKnobMode",                     // Mode in <value>: 0: circular, 1:circular relativ, 2:linear

	// midi plugins channeldependent programs
	"effGetMIDIProgramName",					// Passed <ptr> points to MIDIProgramName struct. 
											// struct will be filled with information for 'thisProgramIndex'.
											// returns number of used programIndexes.
											// if 0 is returned, no MIDIProgramNames supported.

	"effGetCurrentMIDIProgram",				// Returns the programIndex of the current program.
											// passed <ptr> points to MIDIProgramName struct. 
											// struct will be filled with information for the current program.

	"effGetMIDIProgramCategory",				// Passed <ptr> points to MIDIProgramCategory struct.
											// struct will be filled with information for 'thisCategoryIndex'.
											// returns number of used categoryIndexes. 
											// if 0 is returned, no MIDIProgramCategories supported.

	"effHasMIDIProgramsChanged",				// Returns 1 if the MIDIProgramNames or MIDIKeyNames
											// had changed on this channel, 0 otherwise. <ptr> ignored.

	"effGetMIDIKeyName",						// Passed <ptr> points to MIDIKeyName struct.
											// struct will be filled with information for 'thisProgramIndex' and 
											// 'thisKeyNumber'. If keyName is "" the standard name of the key 
											// will be displayed. If 0 is returned, no MIDIKeyNames are
											// defined for 'thisProgramIndex'.

	"effBeginSetProgram",						// Called before a new program is loaded
	"effEndSetProgram",						// Called when the program is loaded


	//---from here VST 2.3 extension opcodes---------------------------------------------------------
	"effGetSpeakerArrangement", // VstSpeakerArrangement** pluginInput in <value>
											      // VstSpeakerArrangement** pluginOutput in <ptr>

	"effShellGetNextPlugin",					// This opcode is only called, if plugin is of type kPlugCategShell.
 											// returns the next plugin's uniqueID.
 											// <ptr> points to a char buffer of size 64, which is to be filled 
 											// with the name of the plugin including the terminating zero.

	"effStartProcess",						// Called before the start of process call
	"effStopProcess",							// Called after the stop of process call
	"effSetTotalSampleToProcess",			    // Called in offline (non RealTime) Process before process is called, indicates how many sample will be processed

	"effSetPanLaw",							// PanLaw : Type (Linear, Equal Power,.. see enum PanLaw Type) in <value>,
											// Gain in <opt>: for Linear : [1.0 => 0dB PanLaw], [~0.58 => -4.5dB], [0.5 => -6.02dB]	
	"effBeginLoadBank",						// Called before a Bank is loaded, <ptr> points to VstPatchChunkInfo structure
											// return -1 if the Bank can not be loaded, return 1 if it can be loaded else 0 (for compatibility)
	"effBeginLoadProgram",					// Called before a Program is loaded, <ptr> points to VstPatchChunkInfo structure
											// return -1 if the Program can not be loaded, return 1 if it can be loaded else 0 (for compatibility)

	"effSetProcessPrecision",				///< [value]: @see VstProcessPrecision  @see AudioEffectX::setProcessPrecision
	"effGetNumMIDIInputChannels",			///< [return value]: number of used MIDI input channels (1-15)  @see AudioEffectX::getNumMIDIInputChannels
	"effGetNumMIDIOutputChannels"			///< [return value]: number of used MIDI output channels (1-15)  @see AudioEffectX::getNumMIDIOutputChannels

};

const char* AudioMasterCodeStrings[VST_AUDIO_MASTER_OPCODE_COUNT] =
{
	"audioMasterAutomate",		// index, value, returns 0
	"audioMasterVersion",				// VST Version supported (for example 2200 for VST 2.2)
	"audioMasterCurrentId",			// Returns the unique id of a plug that's currently
									// loading
	"audioMasterIdle",				// Call application idle routine (this will
									// call effEditIdle for all open editors too) 
	"audioMasterPinConnected",			// Inquire if an input or output is beeing connected;
									// index enumerates input or output counting from zero,
									// value is 0 for input and != 0 otherwise. note: the
									// return value is 0 for <true> such that older versions
									// will always return true.	
  "audioMasterPinConnected+1",
	//---from here VST 2.0 extension opcodes------------------------------------------------------
	// VstEvents + VstTimeInfo
	"audioMasterWantMIDI" ,	// <value> is a filter which is currently ignored
	"audioMasterGetTime",				// returns const VstTimeInfo* (or 0 if not supported)
									// <value> should contain a mask indicating which fields are required
									// (see valid masks above), as some items may require extensive
									// conversions
	"audioMasterProcessEvents",		// VstEvents* in <ptr>
	"audioMasterSetTime",				// VstTimenfo* in <ptr>, filter in <value>, not supported
	"audioMasterTempoAt",				// returns tempo (in bpm * 10000) at sample frame location passed in <value>

	// parameters
	"audioMasterGetNumAutomatableParameters",
	"audioMasterGetParameterQuantization",	// returns the integer value for +1.0 representation,
											// or 1 if full single float precision is maintained
											// in automation. parameter index in <value> (-1: all, any)
	// connections, configuration
	"audioMasterIOChanged",				// numInputs and/or numOutputs has changed
	"audioMasterNeedIdle",				// plug needs idle calls (outside its editor window)
	"audioMasterSizeWindow",				// index: width, value: height
	"audioMasterGetSampleRate",
	"audioMasterGetBlockSize",
	"audioMasterGetInputLatency",
	"audioMasterGetOutputLatency",
	"audioMasterGetPreviousPlug",			// input pin in <value> (-1: first to come), returns cEffect*
	"audioMasterGetNextPlug",				// output pin in <value> (-1: first to come), returns cEffect*

	// realtime info
	"audioMasterWillReplaceOrAccumulate",	// returns: 0: not supported, 1: replace, 2: accumulate
	"audioMasterGetCurrentProcessLevel",	// returns: 0: not supported,
										// 1: currently in user thread (gui)
										// 2: currently in audio thread (where process is called)
										// 3: currently in 'sequencer' thread (midi, timer etc)
										// 4: currently offline processing and thus in user thread
										// other: not defined, but probably pre-empting user thread.
	"audioMasterGetAutomationState",		// returns 0: not supported, 1: off, 2:read, 3:write, 4:read/write

	// offline
	"audioMasterOfflineStart",
	"audioMasterOfflineRead",				// ptr points to offline structure, see below. return 0: error, 1 ok
	"audioMasterOfflineWrite",			// same as read
	"audioMasterOfflineGetCurrentPass",
	"audioMasterOfflineGetCurrentMetaPass",

	// other
	"audioMasterSetOutputSampleRate",		// for variable i/o, sample rate in <opt>
	"audioMasterGetSpeakerArrangement",	// result in ret
	"audioMasterGetVendorString",			// fills <ptr> with a string identifying the vendor (max 64 char)
	"audioMasterGetProductString",		// fills <ptr> with a string with product name (max 64 char)
	"audioMasterGetVendorVersion",		// returns vendor-specific version
	"audioMasterVendorSpecific",			// no definition, vendor specific handling
	"audioMasterSetIcon",					// void* in <ptr>, format not defined yet
	"audioMasterCanDo",					// string in ptr, see below
	"audioMasterGetLanguage",				// see enum
	"audioMasterOpenWindow",				// returns platform specific ptr
	"audioMasterCloseWindow",				// close window, platform specific handle in <ptr>
	"audioMasterGetDirectory",			// get plug directory, FSSpec on MAC, else char*
	"audioMasterUpdateDisplay",			// something has changed, update 'multi-fx' display

	//---from here VST 2.1 extension opcodes------------------------------------------------------
	"audioMasterBeginEdit",               // begin of automation session (when mouse down), parameter index in <index>
	"audioMasterEndEdit",                 // end of automation session (when mouse up),     parameter index in <index>
	"audioMasterOpenFileSelector",		// open a fileselector window with VstFileSelect* in <ptr>
	
	//---from here VST 2.2 extension opcodes------------------------------------------------------
	"audioMasterCloseFileSelector",		// close a fileselector operation with VstFileSelect* in <ptr>: Must be always called after an open !
	"audioMasterEditFile",				// open an editor for audio (defined by XML text in ptr)
	"audioMasterGetChunkFile",			// get the native path of currently loading bank or project
										// (called from writeChunk) void* in <ptr> (char[2048], or sizeof(FSSpec))

	//---from here VST 2.3 extension opcodes------------------------------------------------------
	"audioMasterGetInputSpeakerArrangement"	// result a VstSpeakerArrangement in ret
};


#endif