#ifndef CONTROL_CHANGE_MAPPER_H
#define CONTROL_CHANGE_MAPPER_H

#include "DarkPlug.h"
#include "Control.h"
#include "UpDown.h"
#include "Font.h"
#include "ToolBar.h"
#include "Array.h"
#include "ScrollBar.h"
#include "Label.h"
#include "UpDown.h"

class CControlChangeMapper;
class CControlChangeMapperGUI;
class CMapping;
class CMappingGUIList;

class CMappingGUI : public CToolBar
{
public:
               CMappingGUI(CMappingGUIList *mapperGUIList, CMapping *mapping);
  virtual     ~CMappingGUI();
  CMapping    *GetMapping();
  void         OnSetMapping();
  virtual void OnUpDownChange(CUpDown *upDown);
  virtual void OnToolBarButtonPress(CToolBarButton *button);
  void         Train(int mapIn);

private:
  CMappingGUIList *MappingGUIList;
  CMapping        *Mapping;
  CLabel          *MapInLabel,  *MapOutLabel;
  CUpDown         *MapInUpDown, *MapOutUpDown;
  CToolBarButton  *TrainButton, *RemoveButton;
};

class CMappingGUIList : public CControl
{
public:
  CMappingGUIList(CControlChangeMapperGUI *parent);
 ~CMappingGUIList();

  void                     AddMapping(CMapping *newMapping);
  void                     RemoveMapping(CMapping *oldMapping);
  void                     OnSetMapping(CMapping *mapping);
  void                     SizeScrollBar();
  virtual void             OnScrollY(int newPos);
  CControlChangeMapperGUI *GetMappingGUI();
  void                     Train(int mapIn);

private:
  CControlChangeMapperGUI *MappingGUI;
  CArray<CMappingGUI*>    *MappingGUIs;
  CScrollBar              *ScrollBarV;
};

class CControlChangeMapperGUI : public CControl
{
public:
                        CControlChangeMapperGUI(HWND parent, CControlChangeMapper *mapper);
  virtual              ~CControlChangeMapperGUI();
  virtual void          OnToolBarButtonPress(CToolBarButton *button);
  void                  OnAddMapping(CMapping *newMapping);
  void                  OnRemoveMapping(CMapping *oldMapping);
  void                  OnSetMapping(CMapping *mapping);
  CControlChangeMapper *GetMapper();
  virtual void          OnAppMessage(UINT message, WPARAM wParam, LPARAM lParam);
  void                  Train(int mapIn);

private:
  CControlChangeMapper *Mapper;
  CToolBar             *ToolBar;
  CToolBarButton       *AddButton;
  CMappingGUIList      *MappingGUIList;
};

class CMapping
{
public:
  CMapping();
  CMapping(int mapIn, int mapOut);

  void SetMapping(int mapIn, int mapOut);
  void GetMapping(int &mapIn, int &mapOut);

private:
  int MapIn, MapOut;
};

class CControlChangeMapper : public CMachine
{
public:
                     CControlChangeMapper(CHost *host);
  virtual           ~CControlChangeMapper();

  int                GetMappingCount();
  void               GetMapping(int index, int &mapIndexIn, int &mapIndexOut);
  CMapping          *GetMapping(int index);
  void               SetMappingCount(int newCount);
  void               SetMapping(int index, int mapIndexIn, int mapIndexOut);
  void               SetMapping(CMapping *mapping, int mapIn, int mapOut);
  void               AddMapping();
  void               AddMapping(int mapIn, int mapOut);
  void               RemoveMapping();
  void               RemoveMapping(CMapping *mapping);

  virtual void  DARKCALL  Work();
  virtual bool  DARKCALL  IsSynth();
  virtual void  DARKCALL  SetSampleRate(int sampleRate);
  virtual void  DARKCALL  SetBlockSamples(int blockSamples);
  virtual void  DARKCALL  ReadProperties(char *data, int length, bool isInner);
  virtual void  DARKCALL  WriteProperties(char **data, int *length, bool *isInner);
  virtual HWND  DARKCALL  CreateGUI(HWND parent);

private:
  CControlChangeMapperGUI *GUI;
  CArray<CMapping*>       *Mappings;  
};

class CControlChangeMapperInfo : public CMachineInfo
{
public:
                             CControlChangeMapperInfo();
  virtual CMachine* DARKCALL CreateMachine();
};

#endif