/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ToolBar.h"
#include "Font.h"
#include "../Studio/Core.h"

#define CONTROL_SPACING 4

CToolBar::CToolBar(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "ToolBar", x, y, width, height, true)
{
  Texture = Core->FrameBuffers.ToolBarTexture;
  SetFont(new CFont(DC, "Verdana", 10.0f, true));
  SetBorder(bs3DRaised);
  Parent = parent;
  ToolTip = new CToolTip(Handle);
  ControlCount = 0;
  Controls = 0;
  SubInit = true;
  DrawControl();
}

CToolBar::~CToolBar()
{
  if(Controls != 0)
    delete Controls;
  delete ToolTip;
}

void CToolBar::DrawControl()
{
  if(Texture)
    Texture->TextureFill(GetBackBuffer(), 0, 0);
  else
    CControl::DrawControl();
}

void CToolBar::AddControl(CControl *control, char *toolTip)
{
  AddControl(control, toolTip, control->Handle);
}

void CToolBar::AddControl(CControl *control, char *toolTip, HWND hwndTool)
{
  AddControl(control, toolTip, hwndTool, 0);
}

void CToolBar::AddControl(CControl *control, char *toolTip, HWND hwndTool, int offsetY)
{
  CControl **newControls;
  int        i;

  if(ControlCount == 0)
  {
    Controls = new CControl*[1];
    Controls[0] = control;
       
    ControlCount = 1;
    control->Move(CONTROL_SPACING, offsetY + (Height - (control->Height + 2)) / 2);
  }
  else
  {
    newControls = new CControl*[ControlCount + 1];
    for(i = 0; i < ControlCount; i++)
      newControls[i] = Controls[i];
    newControls[ControlCount] = control;
    delete Controls;
    Controls = newControls;

    ControlCount += 1;
    control->Move(Controls[ControlCount - 2]->X + Controls[ControlCount - 2]->Width + CONTROL_SPACING, (Height - (control->Height + 2)) / 2);
  }

  control->Show();
  control->Update();
  ToolTip->AddTool(hwndTool, toolTip, false);
}

void CToolBar::OnToolBarButtonPress(CToolBarButton *button)
{
  Parent->OnToolBarButtonPress(button);
}

CToolBarButton *CToolBar::AddButton(int iconID, int id, int iconWidth, int iconHeight, char *toolTip, bool toggle)
{
  CToolBarButton *button;

  button = new CToolBarButton(this, 0, 0, 32, 24, iconID, iconWidth, iconHeight, id, toggle ? TOOLBARBUTTON_STYLE_TOGGLE : TOOLBARBUTTON_STYLE_DEFAULT);
  AddControl(button, toolTip);
  return button;
}

void CToolBar::OnComboSelect(CDropList *comboBox)
{
  Parent->OnComboSelect(comboBox);
}

void CToolBar::OnUpDownChange(CUpDown *upDown)
{
  Parent->OnUpDownChange(upDown);
}

void CToolBar::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  RedrawWindow(Handle, NULL, NULL, RDW_FRAME | RDW_INVALIDATE | RDW_UPDATENOW);
}