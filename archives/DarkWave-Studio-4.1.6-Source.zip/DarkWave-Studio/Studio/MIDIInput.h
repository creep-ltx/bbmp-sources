/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MIDI_INPUT_H
#define MIDI_INPUT_H

#include "DarkPlug.h"
#include "Control.h"
#include "DropList.h"
#include "Font.h"
#include "MIDIManager.h"

class CMIDIInput;
class CMIDIInputGUI;

class CMIDIInputGUI : public CControl
{
public:
               CMIDIInputGUI(HWND parent, CMIDIInput *midiInput);
              ~CMIDIInputGUI();
  void         OpenDevice(int index);
  virtual void OnComboSelect(CDropList *comboBox);
  CDropList    *ChannelCombo;

private:
  CMIDIInput   *MIDIInput;
  CDropList    *DeviceCombo;
};

class CMIDIInput : public CMachine
{
public:
                CMIDIInput(CHost *host);
  virtual      ~CMIDIInput();
  virtual void  DARKCALL Work();
  virtual HWND  DARKCALL CreateGUI(HWND parent);
  void          OpenDevice(int index);
  void          CloseDevice();
  void          MIDIMessage(unsigned char status, unsigned char data1, unsigned char data2);
  virtual void  DARKCALL SetSampleRate(int sampleRate);
  virtual void  DARKCALL SetBlockSamples(int blockSamples);
  virtual bool  DARKCALL IsSynth();
  void          SetChannel(int channel);
  virtual void  DARKCALL ReadProperties(char *data, int length, bool isInner);
  virtual void  DARKCALL WriteProperties(char **data, int *length, bool *isInner);

  CMIDIInputDevice *Device;
  int Channel;
private:
  CMIDIInputGUI    *GUI;
  CControlBuffer   *ControlBuffer, *FutureBuffer;
  LARGE_INTEGER     PerformanceFrequency;
  int               SampleRate, BlockSamples;
};

class CMIDIInputInfo : public CMachineInfo
{
public:
                             CMIDIInputInfo();
  virtual CMachine* DARKCALL CreateMachine();
};

#endif