/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SEQUENCEVIEW_H
#define SEQUENCEVIEW_H

#include "Control.h"
#include "ScrollBar.h"
#include "Sequence.h"
#include "DropList.h"

#define SEQUENCEVIEW_STATE_NONE      0
#define SEQUENCEVIEW_STATE_HIGHLIGHT 1
#define SEQUENCEVIEW_STATE_DRAG      2

class CSequenceView : public CControl, CMutex
{
public:
                  CSequenceView(CControl *parent, int x, int y, int width, int height);
                 ~CSequenceView();
  void            ScrollVertical(int offsetY);
  void            ScrollHorizontal(int offsetX);
  void            SizeControl();
  virtual void    OnPaint();
  virtual void    DrawControl();
  void            DrawTitles(HDC hDC);
  void            DrawGrid(HDC hDC);
  void            DrawEvents(HDC hDC);
  void            DrawTitle(HDC hDC, int x, int y, int track);
  void            TrackLabel(int track, char *label);
  void            SetSequence(CSequence *sequence);
  virtual void    OnResize(int newWidth, int newHeight);
  virtual void    OnScrollY(int newPos);
  virtual void    OnScrollX(int newPos);
  virtual void    OnLeftButtonDown(int x, int y);
  virtual void    OnLeftButtonUp(int x, int y);
  virtual void    OnRightButtonDown(int x, int y);
  void            SetTrack(int track);
  int             TrackAt(int y);
  int             PosAt(int x);
  void            AddEvent(int x, int y);
  void            RemoveEvent(int x, int y);
  bool            EventFits(int start, int length, int ntrack);
  CSequenceTrack* GetTrack(int ntrack);
  int             GetTrack();
  void            DrawEvent(HDC hDC, int y, CSequenceEvent *ev);
  int             PlayBarX(double playBarPos);
  void            DrawPlayBar(double pos, bool clear);
  void            UpdatePlayBar(double newPos);
  void            RemoveTrack(int track);
  virtual void    OnMouseMove(int x, int y);
  bool            EventFits(int start, int length, CSequenceTrack *track, CSequenceEvent *ignore);
  CSequenceEvent* EventAt(int x, int y);

private:  
  int            CurrentTrack;
  CScrollBar    *ScrollBarV, *ScrollBarH;
  int            OffsetX, OffsetY;
  int            Rows, TopRow, TopRowY, BottomRow, MaxTopRow;
  int            Cols, LeftCol, LeftColX, RightCol, MaxLeftCol;
  CFont         *TrackFont;
  CSequence      *Sequence;
  double          PlayBarPos;
  int             State, DragStart, DragX;
  CSequenceEvent *DragEvent;
  CSequenceTrack *DragTrack;
};

#endif