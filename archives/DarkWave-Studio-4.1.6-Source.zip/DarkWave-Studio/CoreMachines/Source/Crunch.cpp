/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "Crunch.h"
#include "Resource.h"
#include "Util.h"

#include <stdio.h>
#include <math.h>

#define PROPERTY_AMP   0
#define PROPERTY_CRUNCH 1
#define PROPERTY_WET   2
#define PROPERTY_DRY   3

#define PROPERTY_COUNT 4

const double CrunchPropertyDefaults[PROPERTY_COUNT] =
{
  0.0, // Amp
  0.5, // Crunch
  1.0, // Wet
  0.0  // Dry
};

const char* CrunchPropertyNames[PROPERTY_COUNT] =
{
  "Amp",
  "Crunch",
  "Wet",
  "Dry"
};

#define PROPERTY_FORMAT_PERCENT 0

#define PROPERTY_FORMAT_COUNT   1

const int CrunchPropertyFormats[PROPERTY_COUNT] =
{
  PROPERTY_FORMAT_PERCENT, // Amp
  PROPERTY_FORMAT_PERCENT, // Crunch
  PROPERTY_FORMAT_PERCENT, // Wet
  PROPERTY_FORMAT_PERCENT  // Dry
};

#define KNOB_COUNT   4
#define KNOB_Y       40
#define KNOB_HEIGHT  38

#define CRUNCH_DISPLAY_BORDER  4
#define CRUNCH_DISPLAY_X       (82 + CRUNCH_DISPLAY_BORDER)
#define CRUNCH_DISPLAY_Y       (43 + CRUNCH_DISPLAY_BORDER)
#define CRUNCH_DISPLAY_WIDTH   (96 - (2 * CRUNCH_DISPLAY_BORDER))
#define CRUNCH_DISPLAY_HEIGHT  (40 - (2 * CRUNCH_DISPLAY_BORDER))

const int CrunchKnobX[KNOB_COUNT] =
{
  8,
  44,
  188,
  224
};

const int CrunchKnobProperties[KNOB_COUNT] =
{
  PROPERTY_AMP,
  PROPERTY_CRUNCH,
  PROPERTY_WET,
  PROPERTY_DRY
};

// CrunchDisplay

CCrunchDisplay::CCrunchDisplay(CCrunchGUI *crunchGUI, CCrunch *crunch, int x, int y, int width, int height)
: CLiteControl(crunchGUI, x, y, width, height)
{
  CrunchGUI = crunchGUI;
  Crunch = crunch;
  NumValues = width - 2;
  Values = new double[NumValues];
  RenderBuffer = new CFrameBuffer(Width, Height, true);
  Update();
}

CCrunchDisplay::~CCrunchDisplay()
{
  delete RenderBuffer;
}

void CCrunchDisplay::Update()
{
  int    i;
  double v, f;
  
  f = 1.0 / (double)(NumValues - 1);
  
  for(i = 0; i < NumValues; i++)
  {
    v = f * (double)i;
    Values[i] = Crunch->Crunch(v);
  }
  
  Render();
}

void CCrunchDisplay::Render()
{
  int x, y, y1, y2, i;
  double v;
  
  const unsigned char alpha  = (unsigned char)(0.6 * 0xFF);
  const unsigned char alpha2 = alpha >> 1;
  
  RenderBuffer->Fill(0);
  
  RenderBuffer->DrawRect(0, 0, Width, Height, 0, alpha);

  v = (double)(Height - 3);
  
  for(i = 0; i < NumValues; i++)
  {
    x  = 1 + i;
    y1 = 1 + (int)((1.0 - Values[i]) * v);
    y2 = 1 + (int)v;
    y  = y1;
    
    RenderBuffer->SetPixel(x, y++, 0, alpha);
    while(y <= y2)
      RenderBuffer->SetPixel(x, y++, 0, alpha2);
  }
  
  Parent->Render(X, Y, Width, Height);
}

void CCrunchDisplay::Draw(CFrameBuffer *frameBuffer)
{
  RenderBuffer->Draw(frameBuffer, X, Y, 0, 0, Width, Height);
}

// CCrunchGUI

CCrunchGUI::CCrunchGUI(HWND parent, CColorManager *colorManager, CCrunch *machine, SCrunchGraphics *graphics)
: CLiteContainer(parent, graphics->Background->GetWidth(), graphics->Background->GetHeight(), graphics->Background)
{
  int i;
  
  Graphics = graphics; 

  Knobs = new CLiteKnob*[KNOB_COUNT];
  for(i = 0; i < KNOB_COUNT; i++)
    Knobs[i] = new CLiteKnob(this, machine, CrunchKnobProperties[i], Graphics->Knob, CrunchKnobX[i], KNOB_Y, KNOB_HEIGHT);

  Crunch = machine;

  CrunchDisplay = new CCrunchDisplay(this, machine, CRUNCH_DISPLAY_X, CRUNCH_DISPLAY_Y, CRUNCH_DISPLAY_WIDTH, CRUNCH_DISPLAY_HEIGHT);
  
  Render();
  Show();
}

CCrunchGUI::~CCrunchGUI()
{
  int i;

  for(i = 0; i < KNOB_COUNT; i++)
    delete Knobs[i];
  delete Knobs;
}

void CCrunchGUI::SetProperty(int index, double value)
{
  int i;

  for(i = 0; i < KNOB_COUNT; i++)
    if(CrunchKnobProperties[i] == index)
      Knobs[i]->SetValue(value);
  
  if((index == PROPERTY_CRUNCH) || (index == PROPERTY_AMP))
    CrunchDisplay->Update();
}

// CCrunch

CCrunch::CCrunch(CHost *host, SCrunchGraphics *graphics)
: CMachine(host)
{
  int i;
  
  Host     = host;
  Graphics = graphics;
  
  GUI = 0;
  
  PropertyCount = PROPERTY_COUNT;
  Properties = new double[PROPERTY_COUNT];

  for(i = 0; i < PROPERTY_COUNT; i++)
    Properties[i] = CrunchPropertyDefaults[i];
  
  AmpFollow    = Properties[PROPERTY_AMP];
  CrunchFollow = Properties[PROPERTY_CRUNCH];
  WetFollow    = Properties[PROPERTY_WET];
  DryFollow    = Properties[PROPERTY_DRY];
  
  Ports = new CPort*[3];
  Ports[0] = new CPort(host, this, PT_INPUT | PT_CONTROL, "Control In");
  Ports[1] = new CPort(host, this, PT_INPUT | PT_AUDIO | PT_STEREO, "Line In");
  Ports[2] = new CPort(host, this, PT_OUTPUT | PT_AUDIO | PT_STEREO, "Line Out");
  PortCount = 3;
  
  BlockSamples = host->GetBlockSamples();
}

CCrunch::~CCrunch()
{
  delete Ports[0];
  delete Ports[1];
  delete Ports[2];
  delete Ports;
  if(GUI != 0)
    delete GUI;
  delete Properties;
}

double CCrunch::Crunch(double in)
{
  return Crunch(in, Properties[PROPERTY_AMP], Properties[PROPERTY_CRUNCH]);
}

double CCrunch::Crunch(double in, double amp, double crunch)
{
  double out, sign;
  int    bits, x;

  if(in < -1.0)
    in = -1.0;
  else
    if(in > 1.0)
      in = 1.0;
  
  
  bits = (int)(1.0 + ((1.0 - crunch) * 15.0));
  sign = in >= 0.0 ? 1.0 : -1.0;
  
  x = (int)((fabs(in) * (double)(1 << bits)));
  out   = (1.0 + (amp * 4.0)) * ((double)x * sign) / ((double)(1 << bits));
  
  if(out < -1.0)
    out = -1.0;
  else
    if(out > 1.0)
      out = 1.0;
  
  return out;
}

bool CCrunch::IsSynth()
{
  return false;
}

bool CCrunch::GetGUIRect(short *x1, short *y1, short *x2, short *y2)
{
  *x1 = 0;
  *x2 = Graphics->Background->GetWidth();
  *y1 = 0;
  *y2 = Graphics->Background->GetHeight();
  return true;
}

void CCrunch::SetSampleRate(int sampleRate)
{
}

void CCrunch::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

HWND CCrunch::CreateGUI(HWND parent)
{
  if(GUI != 0)
  {
    delete GUI;
	  GUI = 0;
  }
  if(GUI == 0)
  {
    GUI = new CCrunchGUI(parent, 0, this, Graphics);
  }
  return GUI->Handle;
}

void CCrunch::Work()
{
  SControlMessage message;
  bool            gotMessage;
  int             firstSample, lastSample;

  gotMessage = Ports[0]->ControlBuffer->Read(&message);
  if(!gotMessage) // no messages, just generate signal
    ProcessBlock(0, BlockSamples);
  else // got one or more messages
  {
    if(message.BlockSample > 0) // process data before first block
      ProcessBlock(0, message.BlockSample);

    while(gotMessage) // process message and data until no more messages
    {
      ProcessMessage(&message);
      firstSample = message.BlockSample;
      gotMessage = Ports[0]->ControlBuffer->Read(&message);
      if(gotMessage)
        lastSample = message.BlockSample - 1;
      else
        lastSample = BlockSamples - 1;
      ProcessBlock(firstSample, lastSample - firstSample + 1);
    }
  }
}

void CCrunch::ProcessMessage(SControlMessage *message)
{
  if(message->Type == CONTROL_MESSAGE_CONTROL_CHANGE)
  {
    SetProperty(message->ControlChange.Controller, message->ControlChange.Value);
  }
}

void CCrunch::ProcessBlock(int start, int samples)
{
  int     i;
  double *pInLeft, *pInRight, *pOutLeft, *pOutRight;
  double  inLeft, inRight, outLeft, outRight;

  pInLeft   = Ports[1]->AudioBuffer->LeftData;
  pInRight  = Ports[1]->AudioBuffer->RightData;
  pOutLeft  = Ports[2]->AudioBuffer->LeftData;
  pOutRight = Ports[2]->AudioBuffer->RightData;

  for(i = start; i < samples; i++)
  {
    inLeft  = *(pInLeft++);
    inRight = *(pInRight++);
    
    AmpFollow   = AdjustVolume(Properties[PROPERTY_AMP],   AmpFollow);
    CrunchFollow = AdjustVolume(Properties[PROPERTY_CRUNCH], CrunchFollow);
    WetFollow   = AdjustVolume(Properties[PROPERTY_WET],   WetFollow);
    DryFollow   = AdjustVolume(Properties[PROPERTY_DRY],   DryFollow);

	  outLeft  = 0.5 * ((DryFollow * inLeft)  + (WetFollow * Crunch(inLeft, AmpFollow, CrunchFollow)));
    outRight = 0.5 * ((DryFollow * inRight) + (WetFollow * Crunch(inRight, AmpFollow, CrunchFollow)));

    *(pOutLeft++)  = outLeft;
    *(pOutRight++) = outRight;
  }
}

double CCrunch::GetProperty(int index)
{
  if(index >= 0 && index < PROPERTY_COUNT)
    return Properties[index];
  else
    return 0.0;
}

void CCrunch::SetProperty(int index, double value)
{
  if(index >= 0 && index < PROPERTY_COUNT)
  {
    Properties[index] = value;

    if(GUI)
      GUI->SetProperty(index, value);

  }
}

void CCrunch::GetPropertyName(int index, char *text)
{
  if(index >= 0 && index < PROPERTY_COUNT)
    strcpy(text, CrunchPropertyNames[index]);
  else
    *text = 0;
}

void CCrunch::GetPropertyValueDisplay(int index, double value, char *text)
{
  if(index >= 0 && index < PROPERTY_COUNT)
  {
    switch(CrunchPropertyFormats[index])
    {
      case PROPERTY_FORMAT_PERCENT:
      default:
        sprintf(text, "%i%%", (int)(value * 100));
        break;
    }
  }
  else
    *text = 0;
}

// CCrunchInfo

CCrunchInfo::CCrunchInfo(CHost* host)
{
  Host     = host;
  Name     = "ES Crunch";
  UniqueID = "DarkPlug::ES Crunch";
  Loaded   = false;
}

CCrunchInfo::~CCrunchInfo()
{
  if(Loaded)
  {
    delete Graphics.Background;
    delete Graphics.Knob;
  }
}

CMachine *CCrunchInfo::CreateMachine()
{
  if(!Loaded)
  {
    Graphics.Background = new CFrameBuffer(IDR_CRUNCH_BACKGROUND);
    Graphics.Knob       = new CFrameBuffer(IDR_CRUNCH_KNOB);

    Loaded              = true;
  }
  return new CCrunch(Host, &Graphics);
}