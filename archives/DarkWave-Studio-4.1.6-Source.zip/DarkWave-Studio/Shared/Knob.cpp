/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "Knob.h"
#include <stdio.h>

CKnob::CKnob(CControl *parent, CToolTip *toolTip, CFont *font, CBitmap *bitmap, int imageWidth, int imageHeight, int x, int y, int width, int height)
: CControl(parent, "Knob", x, y, width, height, true)
{
  ToolTip = toolTip;
  if(ToolTip != 0)
    ToolTip->AddTool(Handle, "", true);
  Moving = false;
  Font = font;
  Bitmap = bitmap;
  ImageWidth = imageWidth;
  ImageHeight = imageHeight;
  ImageCount = bitmap->Width / ImageWidth;
  Value = 0.0f;
  Property = 0;
  Machine = 0;
  Label = 0;
  DrawControl();
}

CKnob::~CKnob()
{
}

void CKnob::DrawControl()
{
  HDC hDC;
  int index, x, y;
  HGDIOBJ oldFont;

  index = (int)(Value * ImageCount);
  if(index < 0)
    index = 0;
  else if(index >= ImageCount)
    index = ImageCount - 1;

  hDC = GetBackBuffer()->DC;
  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, 0, 0, Width, Height);
  x = (Width  - ImageWidth)  >> 1;
  y = 0; 
  Bitmap->Draw(hDC, index * ImageWidth, 0, ImageWidth, ImageHeight, x, y);
  if(Label != 0)
  {
    RECT rect;
    SetBkColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlBack));
    SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlText));

    rect.left = 0;
    rect.right = Width - 1;
    rect.top = y + ImageHeight;
    rect.bottom = Height - 1;

    oldFont = SelectObject(hDC, Font->Handle);
    DrawTextA(hDC, Label, (int)strlen(Label), &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    SelectObject(hDC, oldFont);
  }
}

void CKnob::OnPaint()
{
  GetBackBuffer()->Draw();
}

void CKnob::BindToMachine(CMachine *machine, int parameter)
{
  char temp[1024];
  int  c;

  Machine = machine;
  Property = parameter;
  if(Label != 0)
    delete Label;
  *temp = 0;
  Machine->GetPropertyName(Property, temp);
  Value = Machine->GetProperty(Property);
  c = (int)strlen(temp);
  Label = new char[c + 1];
  strcpy(Label, temp);
  DrawControl();
  InvalidateRect(Handle, NULL, FALSE);
  UpdateWindow(Handle);
}

void CKnob::OnLeftButtonDown(int x, int y)
{
  StartY = y;
  StartValue = Value;
  SetCapture(Handle);
  Moving = true;
  if(ToolTip != 0)
  {
    POINT p;

    UpdateToolTipText();

    p.x = Width + 2;
    p.y = (Height / 2) - 8;
    ClientToScreen(Handle, &p);
    ToolTip->TrackPosition(p.x, p.y);

    ToolTip->TrackActivate(Handle, true);
  }
}

void CKnob::OnMouseMove(int x, int y)
{
  int   step, numSteps;
  double newValue;

  if(!Moving)
    return;

  numSteps = ((StartY - y) * ImageCount) / 100;
  step = (int)(StartValue * (ImageCount - 1)) + numSteps;
  if(step < 0)
    step = 0;
  else if(step >= ImageCount)
    step = ImageCount - 1;
  newValue = (double)step / (double)(ImageCount - 1);
  if(newValue != Value)
  {
    Value = newValue;
    DrawControl();
    InvalidateRect(Handle, NULL, FALSE);
    UpdateWindow(Handle);
    if(Machine != 0)
    {
      Machine->Lock();
      Machine->SetPropertyAutomated(Property, Value);
      Machine->Release();
    }
    if(ToolTip != 0)
      UpdateToolTipText();
  }
}

void CKnob::UpdateToolTipText()
{
  char display[MAX_PROPERTY_DISPLAY_STRING];

  if(Machine != 0 && ToolTip != 0)
  {
    display[0] = 0;
    Machine->Lock();
    Machine->GetPropertyDisplay(Property, display);
    Machine->Release();
    ToolTip->UpdateText(Handle, display, true);
  }
}

void CKnob::SetValue(double value)
{
  Value = value;
  DrawControl();
  InvalidateRect(Handle, NULL, FALSE);
  UpdateWindow(Handle);
}

void CKnob::OnLeftButtonUp(int x, int y)
{
  if(ToolTip != 0)
    ToolTip->TrackActivate(Handle, false);
  Moving = false;
  ReleaseCapture();
}