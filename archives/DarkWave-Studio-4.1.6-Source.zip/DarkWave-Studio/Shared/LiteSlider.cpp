/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "LiteSlider.h"
#include <stdio.h>

CLiteSlider::CLiteSlider(CLiteContainer *parent, int x, int y, int size, int knobY, CFrameBuffer *knob, CFrameBuffer *back, CMachine *machine, int property)
: CLiteControl(parent, x, y + knobY, size, knob->GetHeight())
{
  Vertical    = false;
  Knob        = knob;
  KnobY       = knobY;
  Back        = back;
  MaxDistance = size - Knob->GetWidth();
  Machine     = machine;
  Property    = property;
  Moving      = false;

  if(Machine)
    Value = Machine->GetProperty(Property);
  else
    Value = 0.0f;
}

CLiteSlider::CLiteSlider(CLiteContainer *parent, int x, int y, int size, bool vertical, CFrameBuffer *knob, CMachine *machine, int property)
: CLiteControl(parent, x, y, vertical ? knob->GetWidth() : size, vertical ? size : knob->GetHeight())
{
  Vertical    = vertical;
  Knob        = knob;
  KnobY       = 0;
  Back        = 0;
  MaxDistance = vertical ? size - knob->GetHeight() : size - knob->GetWidth();
  Machine     = machine;
  Property    = property;
  Moving      = false;

  if(Machine)
    Value = Machine->GetProperty(Property);
  else
    Value = 0.0f;
}

CLiteSlider::~CLiteSlider()
{
}

void CLiteSlider::Draw(CFrameBuffer *frameBuffer)
{
  int distance;
  
  if(Back)
    Back->Draw(frameBuffer, X, Y - KnobY, 0, 0, Back->GetWidth(), Back->GetHeight());

  distance = (int)(Value * MaxDistance);
  if(Vertical)
    Knob->Draw(frameBuffer, X, Y + (MaxDistance - distance), 0, 0, Width, Knob->GetHeight());
  else
    Knob->Draw(frameBuffer, X + distance, Y, 0, 0, Knob->GetWidth(), Height); 
}

void CLiteSlider::OnLeftButtonDown(int x, int y)
{
  int  distance;
  bool onHandle;

  distance = (int)(Value * MaxDistance);
  if(Vertical)
    onHandle = (y >= Y + (MaxDistance - distance) && y < Y + (MaxDistance - distance) + Knob->GetHeight());
  else
    onHandle = (x >= X + distance && x < X + distance + Knob->GetWidth());

  if(onHandle)
  {
    StartValue = Value;
    StartPos = Vertical ? y : x;
    SetCapture();
    Moving = true;
    if(Machine)
    {
      Machine->Lock();
      ShowToolTip(Value);
      Machine->Release();
    }
    else
    {
      Parent->Lock();
      Parent->OnLiteSliderDown(this, Value);
      Parent->Release();
    }
  }
}

void CLiteSlider::OnMouseMove(int x, int y)
{
  double newValue;
  int   distance;

  if(!Moving)
    return;

  distance = Vertical ? StartPos - y : x - StartPos;
  newValue = StartValue + ((double)distance / (double)MaxDistance);
  if(newValue < 0.0f)
    newValue = 0.0f;
  else if(newValue > 1.0f)
    newValue = 1.0f;
  if(newValue != Value)
  {
    if(Machine)
    {
      Machine->Lock();
      ShowToolTip(newValue);
      Machine->SetPropertyAutomated(Property, newValue);
      Machine->Release();
    }
    else
    {
      Parent->Lock();
      Value = newValue;
      Parent->Render(X, Y, Width, Height);
      Parent->OnLiteSliderChange(this, newValue);
      Parent->Release();
    }
  } 
}

void CLiteSlider::OnLeftButtonUp(int x, int y)
{
  if(Moving)
  {
    ReleaseCapture();
    Moving = false;
  }
}

void CLiteSlider::SetValue(double value)
{
  Value = value;
  Parent->Render(X, Y, Width, Height);
}

void CLiteSlider::ShowToolTip(double value)
{
  char name[MAX_PROPERTY_NAME_STRING], display[MAX_PROPERTY_DISPLAY_STRING], text[MAX_PROPERTY_NAME_STRING + MAX_PROPERTY_DISPLAY_STRING];

  Machine->GetPropertyName(Property, name);
  Machine->GetPropertyValueDisplay(Property, value, display);
  sprintf(text, "%s %s", name, display);
  Parent->ShowToolTip(this, text);
}