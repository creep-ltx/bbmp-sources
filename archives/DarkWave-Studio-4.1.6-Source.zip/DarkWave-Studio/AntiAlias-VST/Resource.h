#define IDR_MINBLEP                     101
#define IDR_ANTIALIAS_BUTTONS_OFF       102
#define IDR_ANTIALIAS_BUTTONS_ON        103
#define IDR_ANTIALIAS_BACKGROUND        120

