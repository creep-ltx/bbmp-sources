/*  organya.h v1.04-dev
    Author: Strultz

# organya.h

## Description

organya.h is a simple C89 library for reading and decoding Organya music (.org files).

Organya is a sequenced music format created in 1999 by Studio Pixel. It is the predecessor to PxTone
and was used in games such as Cave Story, Azarashi (2001 version), STARGAZER, and more.

## Usage

To use this library, just `#include "organya.h"` in your project. Define `ORGANYA_IMPLEMENTATION`
before including the header in one .c file to create the implementation.
You should also link with `-lm` on Linux/BSD systems.

## Example

```c
#define ORGANYA_IMPLEMENTATION
#include "organya.h"

int main()
{
    // Create the context:
    organya_context ctx;
    if (organya_context_init(&ctx) != ORG_RESULT_SUCCESS)
    {
        // Handle the error here
        return -1;
    }

    // Set everything up (these are the default settings):
    organya_context_set_sample_rate(&ctx, 44100);
    organya_context_set_volume(&ctx, 1);
    organya_context_set_interpolation(&ctx, ORG_INTERPOLATION_CUBIC);
    organya_context_set_output_format(&ctx, ORG_OUTPUT_FORMAT_F32, ORG_FALSE);
    // Note: Using Cubic interpolation produces output that sounds (almost)
    // identical to original Organya playback (on Windows Vista and later)

    // Load a soundbank from a file path:
    if (organya_context_load_soundbank_file(&ctx, "path/to/file.wdb") != ORG_RESULT_SUCCESS)
    {
        // Handle the error here
        organya_context_deinit(&ctx);
        return -1;
    }
    // Then load a song from a file path:
    if (organya_context_load_song_file(&ctx, "path/to/file.org") != ORG_RESULT_SUCCESS)
    {
        // Handle the error here
        organya_context_deinit(&ctx);
        return -1;
    }
    // Alternatively, you can load both of these directly from some pointer using
    // organya_context_read_soundbank() and organya_context_read_song().

    // Generate samples (which would then be output to an audio player, or a
    // .wav file, or etc.). This will output interleaved stereo PCM samples in
    // the format set with organya_context_set_output_format to output_buffer.
    // output_buffer should be at least num_samples * sizeof(output_format) * 2
    // long.
    organya_context_generate_samples(&ctx, (void *)output_buffer, num_samples);

    // When you're done, deinitialize and free everything.
    organya_context_deinit(&ctx);
    return 0;
}
```

See bottom of file for license information.
*/

#ifndef ORGANYA_H_
#define ORGANYA_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>

#ifdef ORG_USE_STDINT
    #include <stdint.h>
    typedef int8_t   org_int8;
    typedef uint8_t  org_uint8;
    typedef int16_t  org_int16;
    typedef uint16_t org_uint16;
    typedef int32_t  org_int32;
    typedef uint32_t org_uint32;
#else
    typedef signed   char  org_int8;
    typedef unsigned char  org_uint8;
    typedef signed   short org_int16;
    typedef unsigned short org_uint16;
    typedef signed   long  org_int32;
    typedef unsigned long  org_uint32;
#endif

typedef org_uint8 org_bool;
#define ORG_TRUE 1
#define ORG_FALSE 0

#ifndef ORG_API
    #define ORG_API extern
#endif

#ifndef ORG_PRIVATE
    #define ORG_PRIVATE static
#endif

#define ORG_WAVETABLE_COUNT             100             /* Total number of sounds for melody channels */
#define ORG_PERCUSSION_COUNT            42              /* Total number of sounds for percussion channels */

#define ORG_MELODY_CHANNEL_COUNT        8               /* Number of melody channels */
#define ORG_PERCUSSION_CHANNEL_COUNT    8               /* Number of percussion channels */

#define ORG_CHANNEL_COUNT               (ORG_MELODY_CHANNEL_COUNT + ORG_PERCUSSION_CHANNEL_COUNT)

#define ORG_PROPERTY_NOT_USED           0xFF            /* Value for event properties that aren't used */
#define ORG_DEFAULT_VOLUME              200             /* Default volume of notes */
#define ORG_DEFAULT_PAN                 6               /* Default pan of notes */

#define ORG_COMMENT_STRING_LENGTH       0x20

#ifndef ORG_SCRATCH_BUFFER_LENGTH
    #define ORG_SCRATCH_BUFFER_LENGTH   0x400 /* Results in 4 * 1024 = 4 KB */
#endif

/* --- */

typedef enum organya_result
{
    ORG_RESULT_SUCCESS = 0,  /* Successful */
    ORG_RESULT_ERROR,        /* Generic error status */
    ORG_RESULT_INVALID_ARGS, /* Passed in arguments were invalid */
    ORG_RESULT_FILE_ERROR,   /* Unable to open file or hit EOF while reading */
    ORG_RESULT_MEMORY_ERROR  /* Memory allocation failed */
} organya_result;

/* --- Song Handling --- */

typedef struct organya_event
{
    org_int32 position; /* X position of the event */
    org_uint8 pitch;    /* Pitch of the note (0 to 95 or ORG_PROPERTY_NOT_USED if none) */
    org_uint8 length;   /* Length of the note (should never be 0) */
    org_uint8 volume;   /* Volume of the note (0 to 254 or ORG_PROPERTY_NOT_USED if none) */
    org_uint8 pan;      /* Panning of the note (0 to 12 or ORG_PROPERTY_NOT_USED if none) */
} organya_event;

typedef struct organya_channel
{
    org_uint8 instrument; /* Channel instrument index */
    org_uint16 finetune;  /* Channel finetune, only used for melody channels (default is 1000) */
    org_bool pizzicato;   /* Notes will not sustain, only used for melody channels */
    size_t event_count;
    organya_event *event_list;
} organya_channel;

typedef struct organya_comments
{
    char name[ORG_COMMENT_STRING_LENGTH + 1];
    char artist[ORG_COMMENT_STRING_LENGTH + 1];
    char version[ORG_COMMENT_STRING_LENGTH + 1];
    char *text;
    org_bool open_comments;
    /* TODO: Extra metadata segments */
} organya_comments;

typedef struct organya_song
{
    org_uint16 tempo_ms;    /* How long one tick takes in milliseconds */
    org_uint8 beats;        /* Number of beats per bar. Does not affect playback */
    org_uint8 steps;        /* Number of steps per beat. Does not affect playback */
    org_int32 repeat_start; /* Repeat range start X position */
    org_int32 repeat_end;   /* Repeat range end X position */
    organya_channel channels[ORG_CHANNEL_COUNT];
    organya_comments comments;
} organya_song;

/**
 * Initializes a default song structure.
 *
 * @param song Pointer to the organya_song structure
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_song_init(organya_song *song);

/**
 * Frees any existing event data.
 *
 * @param song Pointer to the organya_song structure
**/
ORG_API void organya_song_deinit(organya_song *song);

/**
 * Frees any existing event data and sets properties to their defaults.
 *
 * @param song Pointer to the organya_song structure
 * @param file_path Path of file to load
**/
ORG_API void organya_song_clean(organya_song *song);

/**
 * Copies song data from src to dst. This is a deep copy, meaning all note data is reallocated.
 *
 * @param dst Pointer of the destination
 * @param src Pointer of the source to copy
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_song_copy(organya_song *dst, organya_song *src);

/**
 * Reads Organya data.
 *
 * @param song Pointer to the organya_song structure
 * @param song_data Song data bytes - this would be the contents of an org file
 * @param data_length Length of song_data
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_song_read(organya_song *song, const org_uint8 *song_data, size_t data_length);

#ifndef ORG_NO_STDIO

/**
 * Loads and reads Organya data from a file.
 *
 * @param song Pointer to the organya_song structure
 * @param file_path Path of file to load
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_song_load_file(organya_song *song, const char *file_path);

#endif

/* --- Context Handling --- */

#define ORG_MIN(a, b)   ((a) < (b) ? (a) : (b))
#define ORG_MAX(a, b)   ((a) > (b) ? (a) : (b))
#define ORG_ABS(a)      ((a) > 0 ? (a) : -(a))

#ifndef ORG_LANCZOS_WINDOW
    #define ORG_LANCZOS_WINDOW 3
#endif

#define ORG_MAX_MARGIN  ORG_MAX(ORG_LANCZOS_WINDOW, 2)
#define ORG_MAX_TAPS    (ORG_MAX_MARGIN * 2)

/* Cubic interpolation is the default setting for accuracy's sake. */
typedef enum organya_interpolation
{
    ORG_INTERPOLATION_NONE = 0, /* Zero order hold (1 point) */
    ORG_INTERPOLATION_LINEAR,   /* Linear interpolation (2 point) */
    ORG_INTERPOLATION_CUBIC,    /* Lagrange interpolation (4 point) */
    ORG_INTERPOLATION_SINC      /* Lanczos interpolation (6 point) */
} organya_interpolation;

typedef enum organya_output_format
{
    ORG_OUTPUT_FORMAT_F32 = 0, /* 32 bit floating point */
    ORG_OUTPUT_FORMAT_S32,     /* 32 bit signed integer */
    ORG_OUTPUT_FORMAT_S16,     /* 16 bit signed integer */
    ORG_OUTPUT_FORMAT_U8       /* 8 bit unsigned integer */
} organya_output_format;

/* Compatibility with specific Organya players, such as old OrgMaker versions, OrgView, Cave Story, etc. */
enum organya_compat_flags
{
    ORG_COMPAT_LEGACY_VOLUME    = 1 << 0, /* From OrgMaker only: Volume was calculated differently and was much louder. */
    ORG_COMPAT_ALTERNATE_TUNING = 1 << 1, /* From OrgMaker 2.x only: Note tuning values were altered. */
    ORG_COMPAT_1_0_NOTE_CHANGE  = 1 << 2, /* From OrgMaker 1.0, 1.1: Note changes had different logic. */
    ORG_COMPAT_1_0_VOLUME_BUG   = 1 << 3, /* From OrgMaker 1.0, 1.1: Volume events while no note was playing could affect the volume of other channels. */
    ORG_COMPAT_CS_PIZZICATO_BUG = 1 << 4, /* From Cave Story: Pizzicato functionality was broken. */
    ORG_COMPAT_CS_VOLUME_BUG    = 1 << 5, /* From Cave Story, OrgView: Volume events at the end of a song would sometimes not work. */
    ORG_COMPAT_CS_PERCUSSION    = 1 << 6, /* From Cave Story: The percussion instruments were hard-coded. */
    ORG_COMPAT_NO_VOLUME_RAMP   = 1 << 7, /* Disable volume ramping, resulting in a click when volumes are changed. */
    ORG_COMPAT_LEGACY_PAUSING   = 1 << 8  /* Use old method for pausing and resuming music. */
};

/* Internal sample data. Not intended to be used directly */
typedef struct organya_internal_sound
{
    size_t sample_count;
    org_int8 *data;
    org_uint32 position;
    float samples[ORG_MAX_TAPS];
    org_uint32 ring;
    float sub_position;
    org_uint32 frequency;
    float position_increment;
    org_bool playing;
    org_bool looping;
    org_uint32 out_sample_rate;
    org_uint32 out_volume_ramp;
    organya_interpolation interpolation;
    float volume;
    float pan_left;
    float pan_right;
    float volume_left;
    float volume_right;
    float target_volume_left;
    float target_volume_right;
    org_uint32 volume_ticks;
    org_uint32 total_samples;
    org_uint8 silence_timer;
} organya_internal_sound;

/* Channel playback data */
typedef struct organya_melody
{
    org_uint8 pitch;                     /* Current pitch, or ORG_PROPERTY_NOT_USED if nothing is playing */
    org_uint8 volume;                    /* Current volume */
    org_uint8 pan;                       /* Current pan */

    size_t index;                        /* Next note index */
    org_uint32 ticks;                    /* Ticks left for current note */
    org_uint8 alt;                       /* Alternate key index */
    org_bool muted;                      /* Channel mute */

    organya_internal_sound sounds[8][2]; /* Internal sounds */
} organya_melody;

typedef struct organya_percussion
{
    org_uint8 pitch;              /* Current pitch, or ORG_PROPERTY_NOT_USED if nothing is playing */
    org_uint8 volume;             /* Current volume */
    org_uint8 pan;                /* Current pan */

    size_t index;                 /* Next note index */
    org_bool muted;               /* Channel mute */

    organya_internal_sound sound; /* Internal sound */
} organya_percussion;

/* The main context */
typedef struct organya_context
{
    /* Song playback data */
    organya_song song;
    org_int32 position;
    org_int32 last_position;
    double samples_to_next_tick;
    org_uint32 volume_ramp;

    organya_melody melody_index[ORG_MELODY_CHANNEL_COUNT];
    organya_percussion percussion_index[ORG_PERCUSSION_CHANNEL_COUNT];

    /* User settings */
    float volume;
    org_uint32 sample_rate;
    organya_interpolation interpolation;
    organya_output_format output_format;
    org_bool paused;
    org_bool dither_output;
    org_uint32 dither_rng;
    org_uint32 compat_flags;
    org_int16 org_volume;
    org_bool org_fadeout;

    /* For soundbanks */
    org_bool has_sounds;
    org_uint8 melody_wave_data[ORG_WAVETABLE_COUNT * 0x100];
    struct
    {
        org_uint32 length;
        org_uint8 *data;
    } percussion_wave_data[ORG_PERCUSSION_COUNT];
} organya_context;

/**
 * Initializes an Organya context.
 *
 * @param context Pointer to the organya_context structure
 *
 * @returns Success/failure status; see organya_result enum for possible values
 *
 * @see organya_context_init_ex
**/
ORG_API organya_result organya_context_init(organya_context *context);

/**
 * Initializes an Organya context.
 *
 * @param context Pointer to the organya_context structure
 * @param flags Compatibility flags, ORed together
 *
 * @returns Success/failure status; see organya_result enum for possible values
 *
 * @see organya_compat_flags
**/
ORG_API organya_result organya_context_init_ex(organya_context *context, org_uint32 flags);

/**
 * Deinitializes an Organya context.
 *
 * @param context Pointer to the organya_context structure
**/
ORG_API void organya_context_deinit(organya_context *context);

/**
 * Reads soundbank data.
 *
 * @param context Pointer to the organya_context structure
 * @param bank_data Soundbank data bytes - this would be the contents of a wdb file
 * @param data_length Length of bank_data
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_context_read_soundbank(organya_context *context, const org_uint8 *bank_data, size_t data_length);

#ifndef ORG_NO_STDIO

/**
 * Loads and reads soundbank data from a file.
 *
 * @param context Pointer to the organya_context structure
 * @param file_path Path of .wdb file to load
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_context_load_soundbank_file(organya_context *context, const char *file_path);

#endif

/**
 * Sets the playback sample rate.
 *
 * @param context Pointer to the organya_context structure
 * @param sample_rate Samples per second
**/
ORG_API void organya_context_set_sample_rate(organya_context *context, org_uint32 sample_rate);

/**
 * Sets the playback volume.
 *
 * @param context Pointer to the organya_context structure
 * @param volume Playback volume (1 is full volume)
**/
ORG_API void organya_context_set_volume(organya_context *context, float volume);

/**
 * Sets the interpolation mode. Affects quality of pitch changes.
 *
 * @param context Pointer to the organya_context structure
 * @param interpolation Interpolation mode to use
 *
 * @see organya_interpolation
**/
ORG_API void organya_context_set_interpolation(organya_context *context, organya_interpolation interpolation);

/**
 * Sets the format to output samples in.
 *
 * @param context Pointer to the organya_context structure
 * @param output_format Output format to use
 * @param dither_output Enable dithering for integer formats
 *
 * @see organya_output_format
**/
ORG_API void organya_context_set_output_format(organya_context *context, organya_output_format output_format, org_bool dither_output);

/**
 * Sets the song data this structure should play back.
 *
 * @param context Pointer to the organya_context structure
 * @param song Pointer to the organya_song structure. This will be deep-copied, so modifying it after will not affect the context.
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_context_set_song(organya_context *context, organya_song *song);

/**
 * Reads Organya data.
 *
 * @param context Pointer to the organya_context structure
 * @param song_data Song data bytes - this would be the contents of an org file
 * @param data_length Length of song_data
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_context_read_song(organya_context *context, const org_uint8 *song_data, size_t data_length);

#ifndef ORG_NO_STDIO

/**
 * Loads and reads Organya data from a file.
 *
 * @param context Pointer to the organya_context structure
 * @param file_path Path of file to load
 *
 * @returns Success/failure status; see organya_result enum for possible values
**/
ORG_API organya_result organya_context_load_song_file(organya_context *context, const char *file_path);

#endif

/**
 * Unloads the currently loaded song.
 *
 * @param context Pointer to the organya_context structure
**/
ORG_API void organya_context_unload_song(organya_context *context);

/**
 * Sets the current song position.
 *
 * @param context Pointer to the organya_context structure
 * @param position Position to seek to
**/
ORG_API void organya_context_seek(organya_context *context, org_int32 position);

/**
 * Sets if a channel is muted.
 *
 * @param context Pointer to the organya_context structure
 * @param channel Index of channel to mute
 * @param mute If the channel should be muted
**/
ORG_API void organya_context_set_mute(organya_context *context, size_t channel, org_bool mute);

/**
 * Toggles Organya fadeout, which will decrease the song's volume over time.
 * This setting will reset when a new song is loaded.
 *
 * @param context Pointer to the organya_context structure
 * @param fadeout If fadeout should be enabled or disabled
**/
ORG_API void organya_context_set_fadeout(organya_context *context, org_bool fadeout);

/**
 * Pauses the active song playback.
 *
 * @param context Pointer to the organya_context structure
**/
ORG_API void organya_context_pause(organya_context *context);

/**
 * Resumes the active song playback.
 *
 * @param context Pointer to the organya_context structure
**/
ORG_API void organya_context_resume(organya_context *context);

/**
 * Renders samples of Organya playback.
 * This function will write interleaved stereo samples to output in 32-bit floating point PCM format.
 *
 * @param context Pointer to the organya_context structure
 * @param output Buffer, with sample_count * 2 elements
 * @param sample_count Number of samples to generate
 *
 * @returns Number of samples generated
**/
ORG_API size_t organya_context_generate_samples(organya_context *context, void *output, size_t sample_count);

/**
 * Ticks the internal Organya player.
 *
 * @param context Pointer to the organya_context structure
**/
ORG_API void organya_context_tick(organya_context *context);

#ifdef __cplusplus
}
#endif

#endif /* ORGANYA_H_ */

/* Implementation */
#ifdef ORGANYA_IMPLEMENTATION

#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifndef ORG_NO_STDIO
#include <stdio.h>
#endif

#ifndef ORG_MALLOC
    #define ORG_MALLOC(s) malloc(s)
#endif
#ifndef ORG_FREE
    #define ORG_FREE(p) free(p)
#endif

#define ORG_PI 3.14159265358979323846

#define ORG_CLAMP(a, n, x) ((a) > (x) ? (x) : ((a) < (n) ? (n) : (a)))
#define ORG_MOD_CLAMP(a, x, y) ((a) >= (x) ? (a) - (x) : ((a) < (y) ? ((a) - (y)) + (x) : (a)))

#define ORG_SINC(x) (sin(x) / (x))

#define ORG_READ_8_LE(p)    ((p)[0])
#define ORG_READ_16_LE(p)   (((p)[1] << 8) | (p)[0])
#define ORG_READ_32_LE(p)   (((p)[3] << 24) | ((p)[2] << 16) | ((p)[1] << 8) | (p)[0])

#define ORG_MIN_SONG_SIZE       (6 + 12 + (ORG_CHANNEL_COUNT * 6))
#define ORG_MIN_SOUNDBANK_SIZE  ((ORG_WAVETABLE_COUNT * 0x100) + (ORG_PERCUSSION_COUNT * 4))

#ifdef __GNUC__
    #define ORG_HOT __attribute__((hot))
#else
    #define ORG_HOT
#endif

/* --- Playback Handling --- */

ORG_PRIVATE organya_result organya_internal_sound_init(organya_internal_sound *sound, organya_context *context, size_t sample_count);
ORG_PRIVATE void organya_internal_sound_deinit(organya_internal_sound *sound);
ORG_PRIVATE void organya_internal_sound_set_frequency(organya_internal_sound *sound, org_uint32 freq);
ORG_PRIVATE void organya_internal_sound_set_volume(organya_internal_sound *sound, org_int16 volume_db);
ORG_PRIVATE void organya_internal_sound_set_pan(organya_internal_sound *sound, org_int16 pan_db);
ORG_PRIVATE void organya_internal_sound_play(organya_internal_sound *sound, org_bool loop);
ORG_PRIVATE void organya_internal_sound_stop(organya_internal_sound *sound);
ORG_PRIVATE void organya_internal_sound_generate_samples(organya_internal_sound *sound, float *output, size_t samples);

/* --- Context Handling --- */

/* Constant tables */
static const org_int16 organya_wave_size_table[8] = {256, 256, 128, 128, 64, 32, 16, 8};

static const org_int16 organya_frequency_table[12] = {262, 277, 294, 311, 330, 349, 370, 392, 415, 440, 466, 494};
static const double organya_frequency_table_alternate[12] = {
        261.6255653006,  277.18263097687, 293.66476791741, 311.12698372208,
        329.62755691287, 349.228231433,   369.99442271163, 391.99543598175,
        415.30469757995, 440,             466.16376151809, 493.88330125612
};

static const org_int16 organya_panning_table[13] = {0, 43, 86, 129, 172, 215, 256, 297, 340, 383, 426, 469, 512};

static const org_uint8 organya_default_percussion[ORG_PERCUSSION_CHANNEL_COUNT] = {0, 2, 5, 6, 4, 8};

/* organya_song */

ORG_API organya_result organya_song_init(organya_song *song)
{
    size_t i;

    if (song == NULL)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    /* song_clean tries to free event_list, so make sure it's NULL */
    for (i = 0; i < ORG_CHANNEL_COUNT; ++i)
    {
        song->channels[i].event_list = NULL;
    }

    /* It tries to free the comments text too */
    song->comments.text = NULL;

    /* Initialize song data */
    organya_song_clean(song);

    return ORG_RESULT_SUCCESS;
}

ORG_API void organya_song_deinit(organya_song *song)
{
    size_t i;

    if (song == NULL)
    {
        return;
    }

    /* Free channels */
    for (i = 0; i < ORG_CHANNEL_COUNT; ++i)
    {
        if (song->channels[i].event_list != NULL)
        {
            ORG_FREE(song->channels[i].event_list);
            song->channels[i].event_list = NULL;
        }
    }

    /* Free comments text */
    if (song->comments.text != NULL)
    {
        ORG_FREE(song->comments.text);
        song->comments.text = NULL;
    }
}

ORG_API void organya_song_clean(organya_song *song)
{
    size_t i;

    if (song == NULL)
    {
        return;
    }

    /* These are the default song properties in OrgMaker 3.1.0 */
    song->tempo_ms = 125; /* 125 ms = 120 bpm (with the default settings) */
    song->beats = 4;
    song->steps = 4;
    song->repeat_start = 0;
    song->repeat_end = 100 * (song->beats * song->steps);

    /* Reset melody channel */
    for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
    {
        song->channels[i].instrument = (org_uint8)(i * 11);
        song->channels[i].finetune = 1000;
        song->channels[i].pizzicato = ORG_FALSE;

        song->channels[i].event_count = 0;
        if (song->channels[i].event_list != NULL)
        {
            ORG_FREE(song->channels[i].event_list);
            song->channels[i].event_list = NULL;
        }
    }

    /* Reset percussion channel */
    for (i = ORG_MELODY_CHANNEL_COUNT; i < ORG_CHANNEL_COUNT; ++i)
    {
        song->channels[i].instrument = organya_default_percussion[i - ORG_MELODY_CHANNEL_COUNT];
        song->channels[i].finetune = 1000;
        song->channels[i].pizzicato = ORG_FALSE;

        song->channels[i].event_count = 0;
        if (song->channels[i].event_list != NULL)
        {
            ORG_FREE(song->channels[i].event_list);
            song->channels[i].event_list = NULL;
        }
    }

    /* Clear comments */
    memset(song->comments.name, '\0', ORG_COMMENT_STRING_LENGTH + 1);
    memset(song->comments.artist, '\0', ORG_COMMENT_STRING_LENGTH + 1);
    memset(song->comments.version, '\0', ORG_COMMENT_STRING_LENGTH + 1);

    if (song->comments.text != NULL)
    {
        ORG_FREE(song->comments.text);
        song->comments.text = NULL;
    }
    song->comments.open_comments = ORG_FALSE;
}

ORG_API organya_result organya_song_copy(organya_song *dst, organya_song *src)
{
    size_t i;

    if (dst == NULL || src == NULL)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    *dst = *src;

    for (i = 0; i < ORG_CHANNEL_COUNT; ++i)
    {
        if (src->channels[i].event_list != NULL)
        {
            dst->channels[i].event_list = (organya_event *)ORG_MALLOC(src->channels[i].event_count * sizeof(organya_event));
            if (dst->channels[i].event_list == NULL)
            {
                organya_song_clean(dst);
                return ORG_RESULT_MEMORY_ERROR;
            }

            memcpy(dst->channels[i].event_list, src->channels[i].event_list, src->channels[i].event_count * sizeof(organya_event));
        }
    }

    if (src->comments.text != NULL)
    {
        size_t len = strlen(src->comments.text);

        dst->comments.text = (char *)ORG_MALLOC(len + 1);
        if (dst->comments.text == NULL)
        {
            return ORG_RESULT_MEMORY_ERROR; /* XXX: Should we fail here? Comment data is low priority. */
        }

        memcpy(dst->comments.text, src->comments.text, len + 1);
    }

    return ORG_RESULT_SUCCESS;
}

ORG_API organya_result organya_song_read(organya_song *song, const org_uint8 *song_data, size_t data_length)
{
    size_t i, j;
    size_t offset;
    org_uint16 version;

    if (song == NULL || song_data == NULL)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    /* Sanity check */
    if (data_length < ORG_MIN_SONG_SIZE)
    {
        return ORG_RESULT_FILE_ERROR;
    }

    offset = 0;

    /* .org files always start with "Org-" */
    if (ORG_READ_32_LE(&song_data[offset]) != 0x2D67724F) /* "Org-" */
    {
        return ORG_RESULT_FILE_ERROR;
    }

    offset += 4;

    /* Read and check version (read done manually here as it's in ASCII) */
    version = (song_data[offset] - 48) * 10 + (song_data[offset + 1] - 48); offset += 2;
    if (version < 1 || version > 3) /* Org-01, Org-02, Org-03 */
    {
        return ORG_RESULT_FILE_ERROR;
    }

    /* Clear the previous song data */
    organya_song_clean(song);

    /* Read song header */
    song->tempo_ms = ORG_READ_16_LE(&song_data[offset]); offset += 2;
    song->beats = ORG_READ_8_LE(&song_data[offset]); ++offset;
    song->steps = ORG_READ_8_LE(&song_data[offset]); ++offset;
    song->repeat_start = ORG_READ_32_LE(&song_data[offset]); offset += 4;
    song->repeat_end = ORG_READ_32_LE(&song_data[offset]); offset += 4;

    if (song->tempo_ms == 0)
    {
        /* Tempo of 0 is invalid */
        song->tempo_ms = 1;
    }

    /* Read channel headers */
    for (i = 0; i < ORG_CHANNEL_COUNT; ++i)
    {
        song->channels[i].finetune = ORG_READ_16_LE(&song_data[offset]); offset += 2;
        song->channels[i].instrument = ORG_READ_8_LE(&song_data[offset]); ++offset;

        /* Org-01 doesn't have this option, but there's still a byte here in the file structure */
        song->channels[i].pizzicato = (version > 1 ? ORG_READ_8_LE(&song_data[offset]) : 0); ++offset;

        /* Check for invalid instrument */
        if ((i < ORG_MELODY_CHANNEL_COUNT && song->channels[i].instrument >= ORG_WAVETABLE_COUNT)
        || (i >= ORG_MELODY_CHANNEL_COUNT && song->channels[i].instrument >= ORG_PERCUSSION_COUNT))
        {
            song->channels[i].instrument = 0;
        }

        song->channels[i].event_count = ORG_READ_16_LE(&song_data[offset]); offset += 2;
    }

    /* Read event data */
    for (i = 0; i < ORG_CHANNEL_COUNT; ++i)
    {
        if (song->channels[i].event_count == 0)
        {
            /* No events here */
            continue;
        }

        /* Check file size. Each event is worth 8 bytes */
        if (offset + (song->channels[i].event_count * 8) > data_length)
        {
            organya_song_clean(song);
            return ORG_RESULT_FILE_ERROR;
        }

        /* Allocate event list */
        song->channels[i].event_list = (organya_event *)ORG_MALLOC(song->channels[i].event_count * sizeof(organya_event));
        if (song->channels[i].event_list == NULL)
        {
            organya_song_clean(song);
            return ORG_RESULT_MEMORY_ERROR;
        }

        /* Read events */
        for (j = 0; j < song->channels[i].event_count; j++)
        {
            song->channels[i].event_list[j].position = ORG_READ_32_LE(&song_data[offset + j * 4]);
            song->channels[i].event_list[j].pitch = ORG_READ_8_LE(&song_data[offset + song->channels[i].event_count * 4 + j]);
            song->channels[i].event_list[j].length = ORG_READ_8_LE(&song_data[offset + song->channels[i].event_count * 5 + j]);
            song->channels[i].event_list[j].volume = ORG_READ_8_LE(&song_data[offset + song->channels[i].event_count * 6 + j]);
            song->channels[i].event_list[j].pan = ORG_READ_8_LE(&song_data[offset + song->channels[i].event_count * 7 + j]);

            /* Note pitch goes from 0-95, or 255 if there is no note there */
            if (song->channels[i].event_list[j].pitch >= (12 * 8) && song->channels[i].event_list[j].pitch != ORG_PROPERTY_NOT_USED)
            {
                song->channels[i].event_list[j].pitch = ORG_PROPERTY_NOT_USED;
            }

            /* Note volume goes from 0-254, or 255 if there is no volume there */
            if (song->channels[i].event_list[j].length == 0)
            {
                song->channels[i].event_list[j].length = 1;
            }

            /* Note panning goes from 0-12, or 255 if there is no panning there */
            if (song->channels[i].event_list[j].pan > 12 && song->channels[i].event_list[j].pan != ORG_PROPERTY_NOT_USED)
            {
                song->channels[i].event_list[j].pan = ORG_DEFAULT_PAN;
            }
        }

        offset += song->channels[i].event_count * 8;
    }

    /* Check if we have a metadata segment */
    if (offset + 6 > data_length)
    {
        return ORG_RESULT_SUCCESS;
    }

    /* Read the OM3MD segment. This is OrgMaker 3's custom metadata block */
    if (memcmp(&song_data[offset], "OM3MD", 5) == 0)
    {
        org_uint8 md_version;
        char *comments;
        size_t comments_length;

        /* Read ascii version number */
        md_version = song_data[offset + 5] - '0';
        offset += 6;

        if (md_version < 1 || md_version > 2) /* OM3MD1, OM3MD2 */
        {
            /* We don't need to fail, just ignore the metadata */
            return ORG_RESULT_SUCCESS;
        }

        if (offset + ORG_COMMENT_STRING_LENGTH * 3 > data_length)
        {
            return ORG_RESULT_SUCCESS;
        }

        memcpy(song->comments.name, &song_data[offset], ORG_COMMENT_STRING_LENGTH); offset += ORG_COMMENT_STRING_LENGTH;
        memcpy(song->comments.artist, &song_data[offset], ORG_COMMENT_STRING_LENGTH); offset += ORG_COMMENT_STRING_LENGTH;
        memcpy(song->comments.version, &song_data[offset], ORG_COMMENT_STRING_LENGTH); offset += ORG_COMMENT_STRING_LENGTH;
        song->comments.name[ORG_COMMENT_STRING_LENGTH] = '\0';
        song->comments.artist[ORG_COMMENT_STRING_LENGTH] = '\0';
        song->comments.version[ORG_COMMENT_STRING_LENGTH] = '\0';

        /* The comments text is a zero-terminated string.
         * We're going to count it manually, to not create a possible overread if the file is invalid */
        for (i = offset; i < data_length && song_data[i] != '\0'; ++i);

        if (i == data_length)
        {
            /* We hit the end, so the string was invalid */
            return ORG_RESULT_SUCCESS;
        }

        comments_length = i - offset;

        /* If the length is 0, the string is empty, so it just stays NULL */
        if (comments_length > 0)
        {
            /* Allocate the string copy */
            comments = (char *)ORG_MALLOC(comments_length + 1);
            if (comments == NULL)
            {
                /* This failed. Loading the comments doesn't need to be as strict, so just stop reading */
                return ORG_RESULT_SUCCESS;
            }

            memcpy(comments, &song_data[offset], comments_length + 1); offset = i + 1;

            song->comments.text = comments;
        }

        if (md_version < 2 || offset + 1 > data_length)
        {
            return ORG_RESULT_SUCCESS;
        }

        song->comments.open_comments = ORG_READ_8_LE(&song_data[offset]); ++offset;

        /* TODO: We don't read any additional chunks, such as DEFS or TCOL */
    }

    return ORG_RESULT_SUCCESS;
}

#ifndef ORG_NO_STDIO

ORG_API organya_result organya_song_load_file(organya_song *song, const char *file_path)
{
    organya_result result;
    size_t file_size;
    org_uint8 *buffer;
    FILE *file;
#if defined(_MSC_VER) && _MSC_VER >= 1400
    errno_t err;

    /* Open file */
    err = fopen_s(&file, file_path, "rb");
    if (err != 0)
    {
        return ORG_RESULT_FILE_ERROR;
    }
#elif !defined(_WIN32) && !defined(__APPLE__) && defined(_FILE_OFFSET_BITS) && _FILE_OFFSET_BITS == 64 && defined(_LARGEFILE64_SOURCE)
    file = fopen64(file_path, "rb");
#else
    file = fopen(file_path, "rb");
#endif

    if (file == NULL)
    {
        return ORG_RESULT_FILE_ERROR;
    }

    /* Seek to end */
    if (fseek(file, 0, SEEK_END))
    {
        fclose(file);
        return ORG_RESULT_FILE_ERROR;
    }

    /* Get file size */
    file_size = ftell(file);

    if (file_size == 0)
    {
        fclose(file);
        return ORG_RESULT_FILE_ERROR;
    }

    /* Return to start */
    rewind(file);

    /* Create buffer to store file contents in */
    buffer = (org_uint8 *)ORG_MALLOC(file_size);

    if (buffer == NULL)
    {
        fclose(file);
        return ORG_RESULT_MEMORY_ERROR;
    }

    /* Load file to buffer */
    if (fread(buffer, 1, file_size, file) < file_size)
    {
        ORG_FREE(buffer);
        fclose(file);
        return ORG_RESULT_FILE_ERROR;
    }

    /* Close file */
    fclose(file);

    /* Read file data */
    result = organya_song_read(song, buffer, file_size);
    ORG_FREE(buffer);
    return result;
}

#endif

/* organya_context */

ORG_PRIVATE organya_result organya_internal_context_load_instruments(organya_context *context, org_bool force_percussion)
{
    organya_result result;
    size_t i, j, k;
    size_t sample_count;
    size_t wave_index;

    const org_uint8 *percussion_data;

    if (!context->has_sounds)
    {
        return ORG_RESULT_ERROR;
    }

    for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
    {
        for (j = 0; j < 8; ++j)
        {
            sample_count = organya_wave_size_table[j];

            /* Increase the sound length if pizzicato is enabled.
             * Otherwise it will just sound like a pop. */
            if (context->song.channels[i].pizzicato)
            {
                sample_count *= (4 + j * 4);
            }

            for (k = 0; k < 2; ++k)
            {
                /* Delete old sound if there is one */
                organya_internal_sound_deinit(&context->melody_index[i].sounds[j][k]);

                /* Create sound object */
                result = organya_internal_sound_init(&context->melody_index[i].sounds[j][k], context, sample_count);
                if (result != ORG_RESULT_SUCCESS)
                {
                    return result;
                }
            }

            /* Load waveform into sound */
            wave_index = 0;

            for (k = 0; k < sample_count; ++k)
            {
                /* Set both sound's samples */
                context->melody_index[i].sounds[j][0].data[k] = context->melody_index[i].sounds[j][1].data[k] =
                        context->melody_wave_data[context->song.channels[i].instrument * 0x100 + wave_index];

                wave_index = (wave_index + (0x100 / organya_wave_size_table[j])) & 0xFF;
            }
        }
    }

    for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
    {
        org_uint8 instrument;

        if (context->compat_flags & ORG_COMPAT_CS_PERCUSSION && !force_percussion && context->percussion_index[i].sound.data != NULL)
        {
            continue;
        }

        if (context->compat_flags & ORG_COMPAT_CS_PERCUSSION)
        {
            instrument = organya_default_percussion[i];
        }
        else
        {
            instrument = context->song.channels[ORG_MELODY_CHANNEL_COUNT + i].instrument;
        }

        percussion_data = context->percussion_wave_data[instrument].data;

        if (percussion_data == NULL)
        {
            continue;
        }

        /* Read sound length */
        sample_count = context->percussion_wave_data[instrument].length;

        /* Delete old sound if there is one */
        organya_internal_sound_deinit(&context->percussion_index[i].sound);

        /* Create sound object */
        result = organya_internal_sound_init(&context->percussion_index[i].sound, context, sample_count);
        if (result != ORG_RESULT_SUCCESS)
        {
            return result;
        }

        /* Read percussion samples */
        for (j = 0; j < sample_count; ++j)
        {
            context->percussion_index[i].sound.data[j] = percussion_data[j] + 0x80;
        }
    }

    return ORG_RESULT_SUCCESS;
}

ORG_PRIVATE void organya_internal_context_set_sound_settings(organya_context *context)
{
    size_t i, j, k;

    if (context == NULL)
    {
        return;
    }

    /* Update volume ramp (should be 4ms) */
    /* If ORG_COMPAT_NO_VOLUME_RAMP is enabled, just set this to 1, which will update it immediately */
    context->volume_ramp = (context->compat_flags & ORG_COMPAT_NO_VOLUME_RAMP) ? 1 : (org_uint32)(context->sample_rate * 0.004F);

    /* Update all melody sounds data */
    for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
    {
        for (j = 0; j < 8; ++j)
        {
            for (k = 0; k < 2; ++k)
            {
                context->melody_index[i].sounds[j][k].out_sample_rate = context->sample_rate;
                context->melody_index[i].sounds[j][k].out_volume_ramp = context->volume_ramp;
                context->melody_index[i].sounds[j][k].interpolation = context->interpolation;

                organya_internal_sound_set_frequency(&context->melody_index[i].sounds[j][k], context->melody_index[i].sounds[j][k].frequency);
            }
        }
    }

    /* Update all percussion sounds data */
    for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
    {
        context->percussion_index[i].sound.out_sample_rate = context->sample_rate;
        context->percussion_index[i].sound.out_volume_ramp = context->volume_ramp;
        context->percussion_index[i].sound.interpolation = context->interpolation;

        organya_internal_sound_set_frequency(&context->percussion_index[i].sound, context->percussion_index[i].sound.frequency);
    }
}

ORG_PRIVATE float organya_internal_context_dither_rng(organya_context *context)
{
    org_uint32 x;

    context->dither_rng = (context->dither_rng * 214013U) + 2531011U;
    x = (context->dither_rng >> 16) & 0x7FFFU;

    return x / 32767.0f - 0.5f;
}

ORG_PRIVATE size_t organya_internal_context_format_samples(organya_context *context, organya_output_format output_format, float *buffer, void *output, size_t samples)
{
    size_t i;
    size_t write_length = 0;

    for (i = 0; i < samples; ++i)
    {
        size_t index = i * 2;
        float l = buffer[index + 0];
        float r = buffer[index + 1];

        /* Clear the old buffer */
        buffer[index + 0] = 0;
        buffer[index + 1] = 0;

        /* Apply context volume */
        l *= context->volume;
        r *= context->volume;

        /* Convert to selected output format */
        switch (output_format)
        {
            case ORG_OUTPUT_FORMAT_F32:
            {
                write_length += 4 * 2;
                ((float *)output)[index + 0] = l;
                ((float *)output)[index + 1] = r;
                break;
            }
            case ORG_OUTPUT_FORMAT_S32: /* It's really just a 24 bit conversion */
            {
                write_length += 4 * 2;
                l *= 8388607.0F;
                r *= 8388607.0F;
                if (context->dither_output)
                {
                    l += (organya_internal_context_dither_rng(context) + organya_internal_context_dither_rng(context));
                    r += (organya_internal_context_dither_rng(context) + organya_internal_context_dither_rng(context));
                }
                ((org_int32 *)output)[index + 0] = (org_int32)((org_uint32)ORG_CLAMP(l + (l < 0.0F ? -0.5F : 0.5F), -0x800000, 0x7FFFFF) << 8);
                ((org_int32 *)output)[index + 1] = (org_int32)((org_uint32)ORG_CLAMP(r + (r < 0.0F ? -0.5F : 0.5F), -0x800000, 0x7FFFFF) << 8);
                break;
            }
            case ORG_OUTPUT_FORMAT_S16:
            {
                write_length += 2 * 2;
                l *= 32767.0F;
                r *= 32767.0F;
                if (context->dither_output)
                {
                    l += (organya_internal_context_dither_rng(context) + organya_internal_context_dither_rng(context));
                    r += (organya_internal_context_dither_rng(context) + organya_internal_context_dither_rng(context));
                }
                ((org_int16 *)output)[index + 0] = (org_int16)ORG_CLAMP(l + (l < 0.0F ? -0.5F : 0.5F), -0x8000, 0x7FFF);
                ((org_int16 *)output)[index + 1] = (org_int16)ORG_CLAMP(r + (r < 0.0F ? -0.5F : 0.5F), -0x8000, 0x7FFF);
                break;
            }
            case ORG_OUTPUT_FORMAT_U8:
            {
                write_length += 1 * 2;
                l = (l * 127.5F) + 128.0F;
                r = (r * 127.5F) + 128.0F;
                if (context->dither_output)
                {
                    l += (organya_internal_context_dither_rng(context) + organya_internal_context_dither_rng(context));
                    r += (organya_internal_context_dither_rng(context) + organya_internal_context_dither_rng(context));
                }
                ((org_uint8 *)output)[index + 0] = (org_uint8)ORG_CLAMP(l + (l < 0.0F ? -0.5F : 0.5F), 0, 0xFF);
                ((org_uint8 *)output)[index + 1] = (org_uint8)ORG_CLAMP(r + (r < 0.0F ? -0.5F : 0.5F), 0, 0xFF);
                break;
            }
            default:
            {
                break;
            }
        }
    }

    return write_length;
}

/* API functions */

ORG_API organya_result organya_context_init(organya_context *context)
{
    return organya_context_init_ex(context, 0);
}

ORG_API organya_result organya_context_init_ex(organya_context *context, org_uint32 flags)
{
    organya_result result;
    size_t i;

    if (context == NULL)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    /* Create song */
    result = organya_song_init(&context->song);
    if (result != ORG_RESULT_SUCCESS)
    {
        return result;
    }

    context->paused = ORG_TRUE;
    context->position = 0;
    context->last_position = 0;
    context->samples_to_next_tick = 0.0;
    context->org_volume = (flags & ORG_COMPAT_LEGACY_VOLUME) ? 0x7F : 100;

    context->sample_rate = 44100;
    context->volume = 1;
    /* Cubic interpolation (4 point Lagrange) is the same as original Organya playback on Windows Vista and later. */
    context->interpolation = ORG_INTERPOLATION_CUBIC;
    context->output_format = ORG_OUTPUT_FORMAT_F32;
    context->dither_output = ORG_FALSE;
    context->dither_rng = 1;
    context->compat_flags = flags;

    /* Should be 4ms */
    context->volume_ramp = (flags & ORG_COMPAT_NO_VOLUME_RAMP) ? 1 : (org_uint32)(context->sample_rate * 0.004F);

    /* Initialize melody channel status */
    for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
    {
        context->melody_index[i].pitch = ORG_PROPERTY_NOT_USED;
        context->melody_index[i].volume = (flags & ORG_COMPAT_CS_VOLUME_BUG) ? 0 : ORG_DEFAULT_VOLUME;
        context->melody_index[i].pan = ORG_DEFAULT_PAN;

        context->melody_index[i].index = 0;
        context->melody_index[i].ticks = 0;
        context->melody_index[i].alt = 0;
        context->melody_index[i].muted = ORG_FALSE;
    }

    /* Initialize percussion channel status */
    for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
    {
        context->percussion_index[i].pitch = ORG_PROPERTY_NOT_USED;
        context->percussion_index[i].volume = (flags & ORG_COMPAT_CS_VOLUME_BUG) ? 0 : ORG_DEFAULT_VOLUME;
        context->percussion_index[i].pan = ORG_DEFAULT_PAN;

        context->percussion_index[i].index = 0;
        context->percussion_index[i].muted = ORG_FALSE;
    }

    memset(context->melody_wave_data, 0, sizeof(context->melody_wave_data));
    memset(context->percussion_wave_data, 0, sizeof(context->percussion_wave_data));

    context->has_sounds = ORG_FALSE;
    return ORG_RESULT_SUCCESS;
}

ORG_API void organya_context_deinit(organya_context *context)
{
    size_t i;

    if (context == NULL)
    {
        return;
    }

    /* Unload song from context and destroy it */
    organya_context_unload_song(context);
    organya_song_deinit(&context->song);

    /* Delete percussion samples */
    for (i = 0; i < ORG_PERCUSSION_COUNT; ++i)
    {
        if (context->percussion_wave_data[i].data != NULL)
        {
            ORG_FREE(context->percussion_wave_data[i].data);
        }
    }
}

ORG_API organya_result organya_context_read_soundbank(organya_context *context, const org_uint8 *bank_data, size_t data_length)
{
    size_t i;
    size_t offset;

    if (bank_data == NULL || data_length < ORG_MIN_SOUNDBANK_SIZE)
    {
        return ORG_RESULT_FILE_ERROR;
    }

    /* Copy wavetable data */
    memcpy(context->melody_wave_data, bank_data, ORG_WAVETABLE_COUNT * 0x100);

    /* Read percussion samples */
    offset = ORG_WAVETABLE_COUNT * 0x100;

    for (i = 0; i < ORG_PERCUSSION_COUNT; ++i)
    {
        /* Free old data */
        if (context->percussion_wave_data[i].data != NULL)
        {
            ORG_FREE(context->percussion_wave_data[i].data);
            context->percussion_wave_data[i].data = NULL;
        }

        if (offset + 4 > data_length)
        {
            return ORG_RESULT_FILE_ERROR;
        }

        context->percussion_wave_data[i].length = ORG_READ_32_LE(&bank_data[offset]);
        offset += 4;

        if (context->percussion_wave_data[i].length == 0)
        {
            /* Invalid sample */
            continue;
        }

        if (offset + context->percussion_wave_data[i].length > data_length)
        {
            return ORG_RESULT_FILE_ERROR;
        }

        context->percussion_wave_data[i].data = (org_uint8 *)ORG_MALLOC(context->percussion_wave_data[i].length);
        if (context->percussion_wave_data[i].data == NULL)
        {
            return ORG_RESULT_MEMORY_ERROR;
        }

        memcpy(context->percussion_wave_data[i].data, &bank_data[offset], context->percussion_wave_data[i].length);
        offset += context->percussion_wave_data[i].length;
    }

    context->has_sounds = ORG_TRUE;
    return organya_internal_context_load_instruments(context, ORG_TRUE);
}

#ifndef ORG_NO_STDIO

ORG_API organya_result organya_context_load_soundbank_file(organya_context *context, const char *file_path)
{
    organya_result result;
    size_t file_size;
    org_uint8 *buffer;
    FILE *file;
#if defined(_MSC_VER) && _MSC_VER >= 1400
    errno_t err;

    /* Open file */
    err = fopen_s(&file, file_path, "rb");
    if (err != 0)
    {
        return ORG_RESULT_FILE_ERROR;
    }
#elif !defined(_WIN32) && !defined(__APPLE__) && defined(_FILE_OFFSET_BITS) && _FILE_OFFSET_BITS == 64 && defined(_LARGEFILE64_SOURCE)
    file = fopen64(file_path, "rb");
#else
    file = fopen(file_path, "rb");
#endif

    if (file == NULL)
    {
        return ORG_RESULT_FILE_ERROR;
    }

    /* Seek to end */
    if (fseek(file, 0, SEEK_END))
    {
        fclose(file);
        return ORG_RESULT_FILE_ERROR;
    }

    /* Get file size */
    file_size = ftell(file);

    if (file_size == 0)
    {
        fclose(file);
        return ORG_RESULT_FILE_ERROR;
    }

    /* Return to start */
    rewind(file);

    /* Create buffer to store file contents in */
    buffer = (org_uint8 *)ORG_MALLOC(file_size);

    if (buffer == NULL)
    {
        fclose(file);
        return ORG_RESULT_MEMORY_ERROR;
    }

    /* Load file to buffer */
    if (fread(buffer, 1, file_size, file) < file_size)
    {
        ORG_FREE(buffer);
        fclose(file);
        return ORG_RESULT_FILE_ERROR;
    }

    /* Close file */
    fclose(file);

    /* Read file data */
    result = organya_context_read_soundbank(context, buffer, file_size);
    ORG_FREE(buffer);
    return result;
}

#endif

ORG_API void organya_context_set_sample_rate(organya_context *context, org_uint32 sample_rate)
{
    if (context == NULL)
    {
        return;
    }

    context->sample_rate = sample_rate;

    /* Update all sounds data */
    organya_internal_context_set_sound_settings(context);
}

ORG_API void organya_context_set_volume(organya_context *context, float volume)
{
    if (context == NULL)
    {
        return;
    }

    context->volume = volume;
}

ORG_API void organya_context_set_interpolation(organya_context *context, organya_interpolation interpolation)
{
    if (context == NULL)
    {
        return;
    }

    context->interpolation = interpolation;

    /* Update all sounds data */
    organya_internal_context_set_sound_settings(context);
}

ORG_API void organya_context_set_output_format(organya_context *context, organya_output_format output_format, org_bool dither_output)
{
    if (context == NULL)
    {
        return;
    }

    context->output_format = output_format;
    context->dither_output = dither_output;
}

ORG_API organya_result organya_context_set_song(organya_context *context, organya_song *song)
{
    organya_result result;

    if (context == NULL || song == NULL)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    result = organya_song_copy(&context->song, song);
    if (result != ORG_RESULT_SUCCESS)
    {
        return result;
    }

    /* Seek to start */
    organya_context_seek(context, 0);
    context->paused = ORG_FALSE;

    if (context->compat_flags & ORG_COMPAT_LEGACY_PAUSING)
    {
        context->samples_to_next_tick = (double)context->sample_rate * (double)context->song.tempo_ms / 1000.0;
    }
    else
    {
        context->samples_to_next_tick = 0.0;
    }

    context->org_volume = (context->compat_flags & ORG_COMPAT_LEGACY_VOLUME) ? 0x7F : 100;
    context->org_fadeout = ORG_FALSE;

    /* Create and load instrument data */
    return organya_internal_context_load_instruments(context, ORG_FALSE);
}

ORG_API organya_result organya_context_read_song(organya_context *context, const org_uint8 *song_data, size_t data_length)
{
    organya_result result;

    if (context == NULL || song_data == NULL)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    result = organya_song_read(&context->song, song_data, data_length);
    if (result != ORG_RESULT_SUCCESS)
    {
        return result;
    }

    /* Seek to start */
    organya_context_seek(context, 0);
    context->paused = ORG_FALSE;

    if (context->compat_flags & ORG_COMPAT_LEGACY_PAUSING)
    {
        context->samples_to_next_tick = (double)context->sample_rate * (double)context->song.tempo_ms / 1000.0;
    }
    else
    {
        context->samples_to_next_tick = 0.0;
    }

    context->org_volume = (context->compat_flags & ORG_COMPAT_LEGACY_VOLUME) ? 0x7F : 100;
    context->org_fadeout = ORG_FALSE;

    /* Create and load instrument data */
    return organya_internal_context_load_instruments(context, ORG_FALSE);
}

#ifndef ORG_NO_STDIO

ORG_API organya_result organya_context_load_song_file(organya_context *context, const char *file_path)
{
    organya_result result;

    if (context == NULL || file_path == NULL)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    result = organya_song_load_file(&context->song, file_path);
    if (result != ORG_RESULT_SUCCESS)
    {
        return result;
    }

    /* Seek to start */
    organya_context_seek(context, 0);
    context->paused = ORG_FALSE;

    if (context->compat_flags & ORG_COMPAT_LEGACY_PAUSING)
    {
        context->samples_to_next_tick = (double)context->sample_rate * (double)context->song.tempo_ms / 1000.0;
    }
    else
    {
        context->samples_to_next_tick = 0.0;
    }

    context->org_volume = (context->compat_flags & ORG_COMPAT_LEGACY_VOLUME) ? 0x7F : 100;
    context->org_fadeout = ORG_FALSE;

    /* Create and load instrument data */
    return organya_internal_context_load_instruments(context, ORG_FALSE);
}

#endif

ORG_API void organya_context_unload_song(organya_context *context)
{
    size_t i, j;

    if (context == NULL)
    {
        return;
    }

    /* Destroy all melody sounds */
    for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
    {
        for (j = 0; j < 8; ++j)
        {
            organya_internal_sound_deinit(&context->melody_index[i].sounds[j][0]);
            organya_internal_sound_deinit(&context->melody_index[i].sounds[j][1]);
        }

        context->melody_index[i].pitch = ORG_PROPERTY_NOT_USED;
    }

    /* Destroy all percussion sounds */
    for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
    {
        organya_internal_sound_deinit(&context->percussion_index[i].sound);

        context->percussion_index[i].pitch = ORG_PROPERTY_NOT_USED;
    }

    /* Clear song info */
    organya_song_clean(&context->song);
}

ORG_API void organya_context_seek(organya_context *context, org_int32 position)
{
    size_t i, j;
    organya_event *event;

    if (context == NULL)
    {
        return;
    }

    context->last_position = position;
    context->position = position;

    /* Get melody indexes */
    for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
    {
        context->melody_index[i].index = 0;

        for (j = 0; j < context->song.channels[i].event_count; ++j)
        {
            event = &context->song.channels[i].event_list[j];

            if (event != NULL && context->position <= event->position)
            {
                context->melody_index[i].index = j;
                break;
            }
        }
    }

    /* Get percussion indexes */
    for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
    {
        context->percussion_index[i].index = 0;

        for (j = 0; j < context->song.channels[ORG_MELODY_CHANNEL_COUNT + i].event_count; ++j)
        {
            event = &context->song.channels[ORG_MELODY_CHANNEL_COUNT + i].event_list[j];

            if (event != NULL && context->position <= event->position)
            {
                context->percussion_index[i].index = j;
                break;
            }
        }
    }
}

ORG_API void organya_context_set_mute(organya_context *context, size_t channel, org_bool mute)
{
    if (context == NULL || channel >= ORG_CHANNEL_COUNT)
    {
        return;
    }

    if (channel < ORG_MELODY_CHANNEL_COUNT)
    {
        context->melody_index[channel].muted = mute;
    }
    else
    {
        context->percussion_index[channel - ORG_MELODY_CHANNEL_COUNT].muted = mute;
    }
}

ORG_API void organya_context_set_fadeout(organya_context *context, org_bool fadeout)
{
    if (context == NULL)
    {
        return;
    }

    context->org_fadeout = fadeout;

    if (!fadeout)
    {
        context->org_volume = (context->compat_flags & ORG_COMPAT_LEGACY_VOLUME) ? 0x7F : 100;
    }
}

ORG_PRIVATE size_t organya_internal_context_find_last_note(organya_context *context, size_t channel, org_bool ignore_length, org_uint8 *out_volume, org_uint8 *out_pan)
{
    size_t i;
    org_uint8 volume = ORG_DEFAULT_VOLUME;
    org_uint8 pan = ORG_DEFAULT_PAN;
    size_t event_count = context->song.channels[channel].event_count;
    size_t play_index = -1;

    for (i = 0; i < event_count; ++i)
    {
        organya_event *event = &context->song.channels[channel].event_list[i];

        if (event->position >= context->position)
        {
            break;
        }

        if (event->volume != ORG_PROPERTY_NOT_USED)
        {
            volume = event->volume;
        }

        if (event->pan != ORG_PROPERTY_NOT_USED)
        {
            pan = event->pan;
        }

        if (event->pitch != ORG_PROPERTY_NOT_USED && (ignore_length || event->position + event->length >= context->position))
        {
            play_index = i;
        }
    }

    *out_volume = volume;
    *out_pan = pan;
    return play_index;
}

ORG_PRIVATE void organya_internal_context_set_melody_volume(organya_context *context, size_t channel)
{
    if (context->melody_index[channel].pitch != ORG_PROPERTY_NOT_USED)
    {
        organya_internal_sound_set_volume(
            &context->melody_index[channel].sounds[context->melody_index[channel].pitch / 12][context->melody_index[channel].alt],
            ((context->melody_index[channel].volume * context->org_volume / 0x7F) - 0xFF) * 8
        );
    }
    else if (context->compat_flags & ORG_COMPAT_1_0_VOLUME_BUG)
    {
        org_uint8 index = context->melody_index[channel].pitch / 12;

        org_uint8 channel_index = channel + index / 8;
        org_uint8 sound_index = index % 8;

        if (channel_index < ORG_MELODY_CHANNEL_COUNT)
        {
            organya_internal_sound_set_volume(
                &context->melody_index[channel_index].sounds[sound_index][context->melody_index[channel].alt],
                ((context->melody_index[channel].volume * context->org_volume / 0x7F) - 0xFF) * 8
            );
        }
    }
}

ORG_PRIVATE void organya_internal_context_play_event(organya_context *context, size_t channel, organya_event *event, org_bool no_play)
{
    size_t i, j;

    if (channel < ORG_MELODY_CHANNEL_COUNT)
    {
        if (event->pitch != ORG_PROPERTY_NOT_USED)
        {
            /* Stop old sound */
            if (context->melody_index[channel].pitch != ORG_PROPERTY_NOT_USED && !no_play)
            {
                if (!context->song.channels[channel].pizzicato || context->compat_flags & ORG_COMPAT_CS_PIZZICATO_BUG)
                {
                    organya_internal_sound_play(
                        &context->melody_index[channel].sounds[context->melody_index[channel].pitch / 12][context->melody_index[channel].alt],
                        ORG_FALSE
                    );
                }

                if (!(context->compat_flags & ORG_COMPAT_1_0_NOTE_CHANGE) || context->melody_index[channel].pitch == event->pitch)
                {
                    context->melody_index[channel].alt ^= 1;
                }
            }

            /* Update channel status */
            context->melody_index[channel].pitch = event->pitch;
            context->melody_index[channel].ticks = event->length;

            /* Set frequency */
            for (i = 0; i < 8; ++i)
            {
                for (j = 0; j < 2; ++j)
                {
                    if (context->compat_flags & ORG_COMPAT_ALTERNATE_TUNING)
                    {
                        organya_internal_sound_set_frequency(
                            &context->melody_index[channel].sounds[i][j],
                            (organya_wave_size_table[i]
                                    * organya_frequency_table_alternate[context->melody_index[channel].pitch % 12]
                                    * (1 << i))
                                    / 8
                                    + (context->song.channels[channel].finetune - 1000)
                        );
                    }
                    else
                    {
                        organya_internal_sound_set_frequency(
                            &context->melody_index[channel].sounds[i][j],
                            (organya_wave_size_table[i]
                                    * organya_frequency_table[context->melody_index[channel].pitch % 12]
                                    * (1 << i))
                                    / 8
                                    + (context->song.channels[channel].finetune - 1000)
                        );
                    }
                }
            }

            /* Play sound */
            if (!no_play)
            {
                organya_internal_sound_play(
                    &context->melody_index[channel].sounds[context->melody_index[channel].pitch / 12][context->melody_index[channel].alt],
                    !context->song.channels[channel].pizzicato || context->compat_flags & ORG_COMPAT_CS_PIZZICATO_BUG
                );
            }
        }

        if (event->volume != ORG_PROPERTY_NOT_USED)
        {
            /* Update channel status */
            context->melody_index[channel].volume = event->volume;

            /* Set playing volume */
            if (!(context->compat_flags & ORG_COMPAT_CS_VOLUME_BUG) || no_play)
            {
                organya_internal_context_set_melody_volume(context, channel);
            }
        }

        if (event->pan != ORG_PROPERTY_NOT_USED)
        {
            /* Update channel status */
            context->melody_index[channel].pan = event->pan;

            /* Set playing pan */
            if (context->melody_index[channel].pitch != ORG_PROPERTY_NOT_USED)
            {
                organya_internal_sound_set_pan(
                    &context->melody_index[channel].sounds[context->melody_index[channel].pitch / 12][context->melody_index[channel].alt],
                    (organya_panning_table[context->melody_index[channel].pan] - 0x100) * 10
                );
            }
        }
    }
    else
    {
        size_t i = channel - ORG_MELODY_CHANNEL_COUNT;

        if (event->pitch != ORG_PROPERTY_NOT_USED)
        {
            /* Stop old sound */
            if (!no_play)
            {
                organya_internal_sound_stop(&context->percussion_index[i].sound);
            }

            /* Update channel status */
            context->percussion_index[i].pitch = event->pitch;

            /* Set frequency */
            organya_internal_sound_set_frequency(
                &context->percussion_index[i].sound,
                (context->percussion_index[i].pitch * 800) + 100
            );

            /* Play new sound */
            if (!no_play)
            {
                organya_internal_sound_play(&context->percussion_index[i].sound, ORG_FALSE);
            }
        }

        if (event->volume != ORG_PROPERTY_NOT_USED)
        {
            /* Update channel status */
            context->percussion_index[i].volume = event->volume;

            /* Set playing volume */
            if (!(context->compat_flags & ORG_COMPAT_CS_VOLUME_BUG) || no_play)
            {
                organya_internal_sound_set_volume(
                    &context->percussion_index[i].sound,
                    ((context->percussion_index[i].volume * context->org_volume / 0x7F) - 0xFF) * 8
                );
            }
        }

        if (event->pan != ORG_PROPERTY_NOT_USED)
        {
            /* Update channel status */
            context->percussion_index[i].pan = event->pan;

            /* Set playing pan */
            organya_internal_sound_set_pan(
                &context->percussion_index[i].sound,
                (organya_panning_table[context->percussion_index[i].pan] - 0x100) * 10
            );
        }
    }
}

ORG_API void organya_context_pause(organya_context *context)
{
    size_t i, j;

    if (context == NULL)
    {
        return;
    }

    context->paused = ORG_TRUE;

    organya_context_seek(context, context->last_position);

    if (!(context->compat_flags & ORG_COMPAT_LEGACY_PAUSING))
    {
        for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
        {
            for (j = 0; j < 8; ++j)
            {
                organya_internal_sound_stop(&context->melody_index[i].sounds[j][0]);
                organya_internal_sound_stop(&context->melody_index[i].sounds[j][1]);
            }

            context->melody_index[i].pitch = ORG_PROPERTY_NOT_USED;
        }

        for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
        {
            organya_internal_sound_stop(&context->percussion_index[i].sound);

            context->percussion_index[i].pitch = ORG_PROPERTY_NOT_USED;
        }
    }
    else
    {
        for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
        {
            if (context->melody_index[i].pitch != ORG_PROPERTY_NOT_USED)
            {
                if (!context->song.channels[i].pizzicato || context->compat_flags & ORG_COMPAT_CS_PIZZICATO_BUG)
                {
                    organya_internal_sound_play(
                        &context->melody_index[i].sounds[context->melody_index[i].pitch / 12][context->melody_index[i].alt],
                        ORG_FALSE
                    );
                }

                context->melody_index[i].pitch = ORG_PROPERTY_NOT_USED;
            }
        }

        if (context->compat_flags & ORG_COMPAT_CS_PERCUSSION)
        {
            return;
        }

        for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
        {
            organya_internal_sound_stop(&context->percussion_index[i].sound);

            context->percussion_index[i].pitch = ORG_PROPERTY_NOT_USED;
        }
    }
}

ORG_API void organya_context_resume(organya_context *context)
{
    size_t i;

    if (context == NULL)
    {
        return;
    }

    context->paused = ORG_FALSE;

    organya_context_seek(context, context->position);

    if (!(context->compat_flags & ORG_COMPAT_LEGACY_PAUSING))
    {
        context->samples_to_next_tick = 0.0;

        for (i = 0; i < ORG_CHANNEL_COUNT; ++i)
        {
            organya_event temp_event;
            org_uint8 volume = ORG_DEFAULT_VOLUME;
            org_uint8 pan = ORG_DEFAULT_PAN;
            organya_event *event;
            size_t played_ms;
            double resume_pos;
            organya_internal_sound *sound;
            org_bool looping = i < ORG_MELODY_CHANNEL_COUNT && (!context->song.channels[i].pizzicato || context->compat_flags & ORG_COMPAT_CS_PIZZICATO_BUG);
            size_t event_index = organya_internal_context_find_last_note(context, i, !looping, &volume, &pan);

            if (event_index >= context->song.channels[i].event_count)
            {
                continue;
            }

            event = &context->song.channels[i].event_list[event_index];

            /* Create a temporary event so it will use the volume/pan values we found */
            temp_event = *event;
            temp_event.volume = volume;
            temp_event.pan = pan;

            organya_internal_context_play_event(context, i, &temp_event, ORG_TRUE);

            if (i < ORG_MELODY_CHANNEL_COUNT)
            {
                context->melody_index[i].pitch = event->pitch;
                context->melody_index[i].ticks = event->length - (context->position - event->position);
                context->melody_index[i].volume = event->volume;
                context->melody_index[i].pan = event->pan;
                sound = &context->melody_index[i].sounds[event->pitch / 12][context->melody_index[i].alt];
            }
            else
            {
                context->percussion_index[i - ORG_MELODY_CHANNEL_COUNT].pitch = event->pitch;
                context->percussion_index[i - ORG_MELODY_CHANNEL_COUNT].volume = event->volume;
                context->percussion_index[i - ORG_MELODY_CHANNEL_COUNT].pan = event->pan;
                sound = &context->percussion_index[i - ORG_MELODY_CHANNEL_COUNT].sound;
            }

            played_ms = (context->position - event->position) * context->song.tempo_ms;
            resume_pos = sound->position_increment * ((double)(played_ms * context->sample_rate) / 1000);

            sound->playing = ORG_TRUE;
            sound->looping = looping;
            sound->silence_timer = 0;

            sound->position = (org_uint32)resume_pos;
            sound->sub_position = resume_pos - sound->position;

            if (!looping && sound->position >= sound->sample_count)
            {
                sound->playing = ORG_FALSE;
            }
            else if (looping)
            {
                sound->position = sound->position % sound->sample_count;
            }
        }
    }
    else
    {
        context->samples_to_next_tick = (double)context->sample_rate * (double)context->song.tempo_ms / 1000.0;
    }
}

ORG_API void organya_context_tick(organya_context *context)
{
    size_t i;
    org_uint32 lp;
    organya_event *event;

    if (context->org_fadeout && context->org_volume > 0)
    {
        context->org_volume -= 2;
        if (context->org_volume < 0)
        {
            context->org_volume = 0;
        }
    }

    if (context == NULL)
    {
        return;
    }

    /* Tick melody channels */
    for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
    {
        /* Is there another event to handle? */
        if (context->melody_index[i].index < context->song.channels[i].event_count && !(context->compat_flags & ORG_COMPAT_LEGACY_PAUSING && context->melody_index[i].muted))
        {
            event = &context->song.channels[i].event_list[context->melody_index[i].index];

            if (context->position == event->position)
            {
                organya_internal_context_play_event(context, i, event, ORG_FALSE);

                ++context->melody_index[i].index;
            }
        }

        /* Tick note length */
        if (context->melody_index[i].ticks == 0)
        {
            if (context->melody_index[i].pitch != ORG_PROPERTY_NOT_USED && (!context->song.channels[i].pizzicato || context->compat_flags & ORG_COMPAT_CS_PIZZICATO_BUG))
            {
                /* Stop old sound */
                organya_internal_sound_play(
                    &context->melody_index[i].sounds[context->melody_index[i].pitch / 12][context->melody_index[i].alt],
                    ORG_FALSE
                );

                context->melody_index[i].pitch = ORG_PROPERTY_NOT_USED;
            }
        }
        else
        {
            --context->melody_index[i].ticks;
        }

        if ((context->compat_flags & ORG_COMPAT_CS_VOLUME_BUG && context->melody_index[i].index < context->song.channels[i].event_count)
                || (!(context->compat_flags & ORG_COMPAT_CS_VOLUME_BUG) && context->org_fadeout))
        {
            organya_internal_context_set_melody_volume(context, i);
        }
    }

    /* Tick percussion channels */
    for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
    {
        /* Is there another event to handle? */
        if (context->percussion_index[i].index < context->song.channels[ORG_MELODY_CHANNEL_COUNT + i].event_count
                && !(context->compat_flags & ORG_COMPAT_LEGACY_PAUSING && context->percussion_index[i].muted))
        {
            event = &context->song.channels[ORG_MELODY_CHANNEL_COUNT + i].event_list[context->percussion_index[i].index];

            if (context->position == event->position)
            {
                organya_internal_context_play_event(context, ORG_MELODY_CHANNEL_COUNT + i, event, ORG_FALSE);

                ++context->percussion_index[i].index;
            }
        }

        if ((context->compat_flags & ORG_COMPAT_CS_VOLUME_BUG && context->percussion_index[i].index < context->song.channels[ORG_MELODY_CHANNEL_COUNT + i].event_count)
                || (!(context->compat_flags & ORG_COMPAT_CS_VOLUME_BUG) && context->org_fadeout))
        {
            organya_internal_sound_set_volume(
                &context->percussion_index[i].sound,
                ((context->percussion_index[i].volume * context->org_volume / 0x7F) - 0xFF) * 8
            );
        }
    }

    context->last_position = context->position;
    ++context->position;

    /* Check for repeat */
    if (context->position >= context->song.repeat_end)
    {
        lp = context->last_position;
        organya_context_seek(context, context->song.repeat_start);
        context->last_position = lp;
    }

    context->samples_to_next_tick += (double)context->sample_rate * (double)context->song.tempo_ms / 1000.0;
}

ORG_API size_t organya_context_generate_samples(organya_context *context, void *output, size_t sample_count)
{
    size_t i, j;
    size_t samples_done = 0;
    float buffer[ORG_SCRATCH_BUFFER_LENGTH] = {0};
    org_uint8 *p;

    if (context == NULL || output == NULL || sample_count == 0)
    {
        return 0;
    }

    p = (org_uint8 *)output;

    /* Generate samples */
    while (samples_done < sample_count)
    {
        size_t tick_time = context->paused ? ORG_SCRATCH_BUFFER_LENGTH / 2 : (size_t)ceil(context->samples_to_next_tick);
        size_t next_samples = ORG_MIN(sample_count - samples_done, ORG_MIN(tick_time, ORG_SCRATCH_BUFFER_LENGTH / 2));

        if (!context->paused)
        {
            if (context->samples_to_next_tick <= 0)
            {
                organya_context_tick(context);
            }
            context->samples_to_next_tick -= next_samples;
        }

        /* Generate melody samples */
        for (i = 0; i < ORG_MELODY_CHANNEL_COUNT; ++i)
        {
            if (!(context->compat_flags & ORG_COMPAT_LEGACY_PAUSING) && context->melody_index[i].muted)
            {
                continue;
            }

            for (j = 0; j < 8; ++j)
            {
                if (context->melody_index[i].sounds[j][0].playing || context->melody_index[i].sounds[j][0].silence_timer > 0)
                {
                    organya_internal_sound_generate_samples(&context->melody_index[i].sounds[j][0], buffer, next_samples);
                }
                if (context->melody_index[i].sounds[j][1].playing || context->melody_index[i].sounds[j][1].silence_timer > 0)
                {
                    organya_internal_sound_generate_samples(&context->melody_index[i].sounds[j][1], buffer, next_samples);
                }
            }
        }

        /* Generate percussion samples */
        for (i = 0; i < ORG_PERCUSSION_CHANNEL_COUNT; ++i)
        {
            if (context->compat_flags & ORG_COMPAT_CS_PERCUSSION && i >= 6)
            {
                break;
            }

            if (!(context->compat_flags & ORG_COMPAT_LEGACY_PAUSING) && context->percussion_index[i].muted)
            {
                continue;
            }

            if (context->percussion_index[i].sound.playing || context->percussion_index[i].sound.silence_timer > 0)
            {
                organya_internal_sound_generate_samples(&context->percussion_index[i].sound, buffer, next_samples);
            }
        }

        /* Output the final samples */
        p += organya_internal_context_format_samples(context, context->output_format, buffer, p, next_samples);
        samples_done += next_samples;
    }

    return samples_done;
}

/* Sound buffers */
ORG_PRIVATE organya_result organya_internal_sound_init(organya_internal_sound *sound, organya_context *context, size_t sample_count)
{
    if (sound == NULL || context == NULL || sample_count < 1)
    {
        return ORG_RESULT_INVALID_ARGS;
    }

    sound->sample_count = sample_count;

    /* Allocate sample buffer */
    sound->data = (org_int8 *)ORG_MALLOC(sound->sample_count);

    if (sound->data == NULL)
    {
        return ORG_RESULT_MEMORY_ERROR;
    }

    /* Initialize sample buffer */
    memset(sound->data, 0, sound->sample_count);
    memset(sound->samples, 0, ORG_MAX_TAPS * sizeof(float));

    sound->position = 0;
    sound->sub_position = 0;
    sound->silence_timer = 0;

    sound->total_samples = 0;

    sound->frequency = 22050;

    sound->volume = 1.0F;
    sound->pan_left = 1.0F;
    sound->pan_right = 1.0F;

    organya_internal_sound_set_frequency(sound, 22050);
    organya_internal_sound_set_volume(sound, 0);
    organya_internal_sound_set_pan(sound, 0);

    sound->volume_left = sound->target_volume_left;
    sound->volume_right = sound->target_volume_right;

    sound->playing = ORG_FALSE;
    sound->looping = ORG_FALSE;

    sound->volume_ticks = 0;
    sound->ring = 0;

    sound->out_sample_rate = context->sample_rate;
    sound->out_volume_ramp = context->volume_ramp;
    sound->interpolation = context->interpolation;

    return ORG_RESULT_SUCCESS;
}

ORG_PRIVATE void organya_internal_sound_deinit(organya_internal_sound *sound)
{
    if (sound == NULL)
    {
        return;
    }

    if (sound->data != NULL)
    {
        ORG_FREE(sound->data);
    }
}

ORG_PRIVATE void organya_internal_sound_set_frequency(organya_internal_sound *sound, org_uint32 frequency)
{
    if (sound == NULL)
    {
        return;
    }

    sound->frequency = frequency;
    sound->position_increment = (float)sound->frequency / sound->out_sample_rate;
}

ORG_PRIVATE void organya_internal_sound_set_volume(organya_internal_sound *sound, org_int16 volume_db)
{
    if (sound == NULL)
    {
        return;
    }

    if (volume_db < -10000)
    {
        volume_db = -10000;
    }
    else if (volume_db > 0)
    {
        volume_db = 0;
    }

    sound->volume = (float)pow(10.0F, volume_db / 2000.0F);

    sound->target_volume_left = sound->volume * sound->pan_left;
    sound->target_volume_right = sound->volume * sound->pan_right;

    if (sound->total_samples == 0)
    {
        sound->volume_left = sound->target_volume_left;
        sound->volume_right = sound->target_volume_right;
        sound->volume_ticks = 0;
    }
    else
    {
        sound->volume_ticks = sound->out_volume_ramp;
    }
}

ORG_PRIVATE void organya_internal_sound_set_pan(organya_internal_sound *sound, org_int16 pan_db)
{
    if (sound == NULL)
    {
        return;
    }

    if (pan_db < 0)
    {
        if (pan_db < -10000)
        {
            pan_db = -10000;
        }

        sound->pan_left = 1.0F;
        sound->pan_right = (float)pow(10.0F, pan_db / 2000.0F);
    }
    else
    {
        pan_db *= -1;
        if (pan_db < -10000)
        {
            pan_db = -10000;
        }

        sound->pan_left = (float)pow(10.0F, pan_db / 2000.0F);
        sound->pan_right = 1.0F;
    }

    sound->target_volume_left = sound->volume * sound->pan_left;
    sound->target_volume_right = sound->volume * sound->pan_right;

    if (sound->total_samples == 0)
    {
        sound->volume_left = sound->target_volume_left;
        sound->volume_right = sound->target_volume_right;
        sound->volume_ticks = 0;
    }
    else
    {
        sound->volume_ticks = sound->out_volume_ramp;
    }
}

ORG_PRIVATE void organya_internal_sound_play(organya_internal_sound *sound, org_bool loop)
{
    if (sound == NULL || sound->data == NULL)
    {
        return;
    }

    if (!sound->playing)
    {
        sound->position = 0;

        if (sound->silence_timer == 0)
        {
            sound->sub_position = 0;
        }
    }

    sound->playing = ORG_TRUE;
    sound->looping = loop;
}

ORG_PRIVATE void organya_internal_sound_stop(organya_internal_sound *sound)
{
    if (sound == NULL)
    {
        return;
    }

    sound->playing = ORG_FALSE;
    sound->silence_timer = ORG_MAX_TAPS;
}

ORG_HOT ORG_PRIVATE void organya_internal_sound_generate_samples(organya_internal_sound *sound, float *output, size_t samples)
{
    size_t i;
    org_uint32 j;
    org_int32 margin;
    org_uint32 last_position;
    float sample_mixed;

    if (sound == NULL || output == NULL)
    {
        return;
    }

    for (i = 0; i < samples; ++i)
    {
        if (!sound->playing && sound->silence_timer == 0)
        {
            break;
        }

        if (sound->volume_ticks > 0)
        {
            sound->volume_left += (sound->target_volume_left - sound->volume_left) / (float)sound->volume_ticks;
            sound->volume_right += (sound->target_volume_right - sound->volume_right) / (float)sound->volume_ticks;

            --sound->volume_ticks;
        }

        /* Interpolate sample with chosen algorithm */
        switch (sound->interpolation)
        {
            case ORG_INTERPOLATION_NONE:
            {
                /* Zero order hold. */
                margin = sound->ring;

                sample_mixed = sound->samples[margin];
                break;
            }
            case ORG_INTERPOLATION_LINEAR:
            {
                /* Linear interpolation. */
                float sample_a;
                float sample_b;

                margin = sound->ring - 1;

                sample_a = sound->samples[ORG_MOD_CLAMP(margin,     ORG_MAX_TAPS, 0)];
                sample_b = sound->samples[ORG_MOD_CLAMP(margin + 1, ORG_MAX_TAPS, 0)];

                sample_mixed = sample_a + (sample_b - sample_a) * sound->sub_position;
                break;
            }
            case ORG_INTERPOLATION_CUBIC:
            {
                /* 4-point, 3rd-order Lagrange interpolation. */
                /* It should be noted that this specific algorithm produces nearly identical results to DirectSound output, on Windows Vista onwards. */
                float sample_a, sample_b, sample_c, sample_d;
                float c0, c1, c2, c3;

                margin = sound->ring - 2;

                sample_a = sound->samples[ORG_MOD_CLAMP(margin - 1, ORG_MAX_TAPS, 0)];
                sample_b = sound->samples[ORG_MOD_CLAMP(margin,     ORG_MAX_TAPS, 0)];
                sample_c = sound->samples[ORG_MOD_CLAMP(margin + 1, ORG_MAX_TAPS, 0)];
                sample_d = sound->samples[ORG_MOD_CLAMP(margin + 2, ORG_MAX_TAPS, 0)];

                c0 = sample_b;
                c1 = sample_c - 1 / 3.0F * sample_a - 1 / 2.0F * sample_b - 1 / 6.0F * sample_d;
                c2 = 1 / 2.0F * (sample_a + sample_c) - sample_b;
                c3 = 1 / 6.0F * (sample_d - sample_a) + 1 / 2.0F * (sample_b - sample_c);

                sample_mixed = ((c3 * sound->sub_position + c2) * sound->sub_position + c1) * sound->sub_position + c0;
                break;
            }
            case ORG_INTERPOLATION_SINC:
            {
                /* Sinc interpolation with a Lanczos window. */
                /* ORG_LANCZOS_WINDOW can be re-defined before this file is included, to change how many points the algorithm uses. */
                org_int32 k;
                float sample_in;
                float t;
                float sample_out;

                margin = sound->ring - ORG_LANCZOS_WINDOW;
                sample_out = 0;

                for (k = -ORG_LANCZOS_WINDOW + 1; k <= ORG_LANCZOS_WINDOW; ++k)
                {
                    sample_in = sound->samples[ORG_MOD_CLAMP(margin + k, ORG_MAX_TAPS, 0)];

                    t = ORG_PI * (sound->sub_position - k);
                    sample_out += sample_in * (t == 0.0F ? 1.0F : (ORG_SINC(t) * ORG_SINC(t / ORG_LANCZOS_WINDOW)));
                }

                sample_mixed = sample_out;
                break;
            }
            default:
            {
                /* ??? */
                sample_mixed = 0;
                break;
            }
        }

        /* Write sample */
        output[i * 2 + 0] += (sample_mixed * sound->volume_left);
        output[i * 2 + 1] += (sample_mixed * sound->volume_right);

        /* Increment position */
        last_position = sound->position;

        sound->sub_position += sound->position_increment;
        sound->position += (org_uint32)sound->sub_position;
        sound->sub_position = (float)fmod(sound->sub_position, 1.0F);

        if (sound->position > last_position)
        {
            /* Update ring buffer position and write new sample(s) */
            for (j = 0; j < sound->position - last_position; ++j)
            {
                sound->ring = (sound->ring + 1) % (ORG_MAX_TAPS);

                if (sound->playing)
                {
                    if (sound->looping)
                    {
                        sound->samples[sound->ring] = (float)sound->data[(last_position + j) % sound->sample_count] / (float)(1 << 7);
                    }
                    else
                    {
                        sound->samples[sound->ring] = ((last_position + j) >= sound->sample_count ? 0 : (float)sound->data[(last_position + j)] / (float)(1 << 7));
                    }
                }
                else
                {
                    sound->samples[sound->ring] = 0;
                    --sound->silence_timer;
                }
            }
        }

        ++sound->total_samples;

        if (sound->playing)
        {
            /* Check if sound reached the end */
            if (sound->position >= sound->sample_count)
            {
                if (sound->looping)
                {
                    /* Make sure position is in range */
                    sound->position %= sound->sample_count;
                }
                else
                {
                    /* Stop playing */
                    sound->playing = ORG_FALSE;
                    sound->silence_timer = ORG_MAX_TAPS;
                }
            }
        }
        else
        {
            sound->position = 0;
        }
    }
}

#endif /* ORGANYA_IMPLEMENTATION */

/*
Copyright (c) 2026 Strultz

This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/
