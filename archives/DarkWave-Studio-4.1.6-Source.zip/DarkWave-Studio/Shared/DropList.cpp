/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include <windows.h>
#include <commctrl.h>
#include "DropList.h"
#include "Font.h"
#include "Util.h"

CDropListItem::CDropListItem(char *text, int id)
{
  Text = CopyString(text);
  ID   = id;
}

CDropListItem::~CDropListItem()
{
  delete Text;
  Text = 0;
}

CDropList::CDropList(CControl *parent, char *name, int x, int y, int width, int height)
: CControl(parent, "DropList", x, y, width, height, true)
{
  Menu    = 0;
  Items   = 0;
  Parent  = parent;
  Dropped = false;
  CurrentSelection = -1;

  Menu = new CMenu(this, true);

  Items = new CArray<CDropListItem*>();

  Font = new CFont(GetBackBuffer()->DC, "Verdana", 9.0, true);

  Update();
}

CDropList::~CDropList()
{
  int i;

  delete Menu;
  Menu = 0;

  for(i = 0; i < Items->Count; i++)
  {
    delete Items->Items[i];
    Items->Items[i] = 0;
  }

  Items->Clear();

  delete Items;
  Items = 0;

  delete Font;
  Font = 0;
}

int CDropList::AddItem(char *text)
{
  int n, id;
  CDropListItem *item;

  id = NextID++;

  item = new CDropListItem(text, id);

  n = Items->AddItem(item);
  Menu->Append(id, text, 0);

  return n;
}
void CDropList::RemoveItem(int index)
{
  Menu->RemoveItem(Items->Items[index]->ID);
  Items->RemoveItem(index);

  if(CurrentSelection == index)
  {
    CurrentSelection -= 1;
    Update();
  }
}

void CDropList::Clear()
{
  int i;

  for(i = 0; i < Items->Count; i++)
  {
    Menu->RemoveItem(Items->Items[i]->ID);
    delete Items->Items[i];
    Items->Items[i] = 0;
  }
  
  Items->Clear();

  CurrentSelection = -1;
  Update();
}

void CDropList::DrawControl()
{
  HDC  hDC;
  RECT r;

  hDC = GetBackBuffer()->DC;

  ColorManager->Lock();

  r.top    = 0;
  r.left   = 0;
  r.bottom = Height - 1;
  r.right  = Width - 1;
  FillRect(hDC, &r, ColorManager->GetBrush(ControlBack)->Handle);
  
  if((CurrentSelection >= 0) && (CurrentSelection < Items->Count))
  {
    HGDIOBJ oldFont;

    r.top    = 2;
    r.left   = 4;
    r.right  = Width - Height;
    r.bottom = Height - 3;

    oldFont = SelectObject(hDC, Font->Handle);
    SetTextColor(hDC, ColorManager->GetColor(TextAreaText));
    SetBkColor(hDC, ColorManager->GetColor(ControlBack));
    
    DrawText(hDC, Items->Items[CurrentSelection]->Text, (int)strlen(Items->Items[CurrentSelection]->Text), &r, DT_VCENTER | DT_LEFT); 
    
    SelectObject(hDC, oldFont);
  }

  DrawBorder(hDC, bs3DRaised, 0, 0, Width - Height, Height, ColorManager->GetPen(ControlLight), ColorManager->GetPen(ControlShadow));

  DrawButton(hDC, Width - Height, 0, Height, Height, false, Dropped);

  ColorManager->Release();
}

void CDropList::DrawButton(HDC hDC, int x, int y, int width, int height, bool up, bool pressed)
{
  HGDIOBJ oldPen, oldBrush;
  POINT   p[3];

  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)ControlLight)->Handle);
  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)ControlLight)->Handle);

  if(up)
  {
    p[0].x = x + (width / 2) - 3;
    p[0].y = y + (height / 2) + 1;
    p[1].x = p[0].x + 3;
    p[1].y = p[0].y - 3;
    p[2].x = p[0].x + 6;
    p[2].y = p[0].y;
  }
  else
  {
    p[0].x = x + (width / 2)  - 3;
    p[0].y = y + (height / 2) - 2;
    p[1].x = p[0].x + 3;
    p[1].y = p[0].y + 3;
    p[2].x = p[0].x + 6;
    p[2].y = p[0].y;
  }

  Polygon(hDC, p, 3);

  SelectObject(hDC, oldPen);
  SelectObject(hDC, oldBrush);

  ColorManager->Release();

  DrawBorder(hDC, pressed ? bs3DSunken : bs3DRaised, x, y, width, height);
}

void CDropList::OnSelChange()
{
  Parent->OnComboSelect(this);
}

int CDropList::GetSelection()
{
  return CurrentSelection;
}

void CDropList::SetSelection(int selection)
{
  if((CurrentSelection >= 0) && (CurrentSelection < Items->Count))
  {
    CheckMenuItem(Menu->GetHandle(), Items->Items[CurrentSelection]->ID, MF_UNCHECKED);
  }

  if((selection < 0) || (selection >= Items->Count))
    CurrentSelection = -1;
  else
  {
    CurrentSelection = selection;
    CheckMenuItem(Menu->GetHandle(), Items->Items[CurrentSelection]->ID, MF_CHECKED);
  } 
  
  Update();
}

void CDropList::OnLeftButtonDown(int x, int y)
{
  int  i, id;
  RECT r;

  if(x >= (Width - Height) && (x < Width))
  {
    Dropped = true;
    Update();
    GetWindowRect(Handle, &r);

    id = Menu->ShowPopup(r.left, r.bottom);
    Dropped = false;
    
    for(i = 0; i < Items->Count; i++)
    {
      if(Items->Items[i]->ID == id)
      {
        SetSelection(i);
        OnSelChange();
      }
    }
    
   
    Update();
  }
}
