/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MINBLEPDESIGNER_H
#define MINBLEPDESIGNER_H

#include "DarkPlug.h"
#include "Control.h"
#include "SampleView.h"
#include "ComboBox.h"
#include "Font.h"
#include "ToolBar.h"
#include "ToolBarButton.h"

#define SAMPLE_SINC              0
#define SAMPLE_WINDOW            1
#define SAMPLE_WINDOWEDSINC      2
#define SAMPLE_FREQUENCYRESPONSE 3
#define SAMPLE_REALCEPSTRUM      4
#define SAMPLE_MINIMUMPHASE      5
#define SAMPLE_MINBLEP           6
#define SAMPLE_MINBLAR           7

#define SAMPLE_COUNT             8
#define SAMPLE_BUFFER_COUNT      7

class CMinBLEPDesignerGUI : public CControl
{
public:
               CMinBLEPDesignerGUI(HWND parent);
              ~CMinBLEPDesignerGUI();
  virtual void Generate();
  virtual void OnComboSelChange(CComboBox *comboBox);
  void         ShowSample(int sample);

private:
  CSampleView    *View;
  CComboBox      *ViewCombo;
  CSample        *Samples[SAMPLE_COUNT];
  CToolBar       *ToolBar;
};

class CMinBLEPDesigner : public CMachine
{
public:
               CMinBLEPDesigner(CHost *host);
  virtual     ~CMinBLEPDesigner();
  virtual HWND CreateGUI(HWND parent);
  virtual void Work();
  virtual void SetSampleRate(int sampleRate);
  virtual void SetBlockSamples(int blockSamples);

private:
  CMinBLEPDesignerGUI *GUI;
};

class CMinBLEPDesignerInfo : public CMachineInfo
{
public:
                    CMinBLEPDesignerInfo(CHost *host);
  virtual CMachine *CreateMachine();

private:
  CHost *Host;
};

#endif