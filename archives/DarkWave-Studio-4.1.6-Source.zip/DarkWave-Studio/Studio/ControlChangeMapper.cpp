#include "ControlChangeMapper.h"
#include "Core.h"
#include "..\Resource.h"

#define IDI_TRAIN IDI_RECORD

#define CCMG_WIDTH                 348
#define CCMG_TOOLBAR_HEIGHT        30
#define CCMG_HEIGHT                ((CCMG_TOOLBAR_HEIGHT * 6) + 16)

#define CCMG_LIST_X                8
#define CCMG_LIST_Y                (CCMG_TOOLBAR_HEIGHT + 8)
#define CCMG_LIST_WIDTH            (CCMG_WIDTH - 16)
#define CCMG_LIST_HEIGHT           (CCMG_HEIGHT - (CCMG_TOOLBAR_HEIGHT + 16))

#define CCMG_TOOLBAR_BUTTON_ADD    0
#define CCMG_TOOLBAR_BUTTON_REMOVE 1
#define CCMG_TOOLBAR_BUTTON_TRAIN  2

#define SCROLLBAR_SIZE             16

#define LABEL_HEIGHT               14
#define UPDOWN_HEIGHT              18

#define MAP_IN_LABEL_WIDTH         52
#define MAP_IN_UPDOWN_WIDTH        64
#define MAP_OUT_LABEL_WIDTH        60
#define MAP_OUT_UPDOWN_WIDTH       64

#define WM_APP_REMOVE_MAPPING      WM_APP + 0

CMappingGUI::CMappingGUI(CMappingGUIList *mappingGUIList, CMapping *mapping)
: CToolBar(mappingGUIList, 0, 0, CCMG_LIST_WIDTH, CCMG_TOOLBAR_HEIGHT)
{
  int mapIn, mapOut;

  MappingGUIList = mappingGUIList;
  Mapping = mapping;

  Mapping->GetMapping(mapIn, mapOut);

  TrainButton = AddButton(IDI_TRAIN, CCMG_TOOLBAR_BUTTON_TRAIN, 20, 20, "Train (Set Map In To Next Received Control Change)", true);

  MapInLabel = new CLabel(this, "Map In:", 0, 0, MAP_IN_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  MapInUpDown = new CUpDown(this, 0, 0, MAP_IN_UPDOWN_WIDTH, UPDOWN_HEIGHT, 0.0, 1024.0, 1.0, (double)mapIn, false);
  
  MapOutLabel = new CLabel(this, "Map Out:", 0, 0, MAP_OUT_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  MapOutUpDown = new CUpDown(this, 0, 0, MAP_OUT_UPDOWN_WIDTH, UPDOWN_HEIGHT, 0.0, 1024.0, 1.0, (double)mapOut, false);

  AddControl(MapInLabel, "");
  AddControl(MapInUpDown, "Map In");

  AddControl(MapOutLabel, "");
  AddControl(MapOutUpDown, "Map Out");

  RemoveButton = AddButton(IDI_REMOVE, CCMG_TOOLBAR_BUTTON_REMOVE, 20, 20, "Remove ControlChange Mapping", false);
}

CMappingGUI::~CMappingGUI()
{
  delete TrainButton;
  delete MapInLabel;
  delete MapInUpDown;
  delete MapOutLabel;
  delete MapOutUpDown;
  delete RemoveButton;

  MappingGUIList = 0;
  Mapping = 0;
}

void CMappingGUI::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == RemoveButton)
  {
    MappingGUIList->GetMappingGUI()->PostMessage(WM_APP_REMOVE_MAPPING, (WPARAM)Mapping, 0);
  }
}

void CMappingGUI::OnSetMapping()
{
  int mapIn, mapOut;

  Mapping->GetMapping(mapIn, mapOut);

  MapInUpDown->SetValue((double)mapIn);
  MapOutUpDown->SetValue((double)mapOut);
}

CMapping* CMappingGUI::GetMapping()
{
  return Mapping;
}

void CMappingGUI::OnUpDownChange(CUpDown *upDown)
{
  int mapNew, mapIn, mapOut;
  CControlChangeMapper *mapper;
  bool bChanged = false;

  Mapping->GetMapping(mapIn, mapOut);
  mapper = MappingGUIList->GetMappingGUI()->GetMapper();

  if(upDown == MapInUpDown)
  {
    mapNew = (int)(MapInUpDown->GetValue());
    if(mapNew != mapIn)
    {
      mapIn = mapNew;
      bChanged = true;
    }
  }

  if(upDown == MapOutUpDown)
  {
    mapNew = (int)(MapOutUpDown->GetValue());
    if(mapNew != mapOut)
    {
      mapOut = mapNew;
      bChanged = true;
    }
  }

  mapper->Lock();
  mapper->SetMapping(Mapping, mapIn, mapOut);
  mapper->Release();
}

void CMappingGUI::Train(int mapIn)
{
  int mapInOld, mapOut;
  CControlChangeMapper *mapper;
  bool bChanged = false;

  if(TrainButton->GetPressed())
  {
    TrainButton->SetPressed(false);

    Mapping->GetMapping(mapInOld, mapOut);
    mapper = MappingGUIList->GetMappingGUI()->GetMapper();

    mapper->SetMapping(Mapping, mapIn, mapOut);
  }
}

CMappingGUIList::CMappingGUIList(CControlChangeMapperGUI *parent)
: CControl(parent, "Mapping GUI List", CCMG_LIST_X, CCMG_LIST_Y, CCMG_LIST_WIDTH, CCMG_LIST_HEIGHT, false)
{
  MappingGUI = parent;
  SetBackColor((ColorManagerColor)WindowWorkspace);
  MappingGUIs = new CArray<CMappingGUI*>;
  ScrollBarV = new CScrollBar(this, SCROLLBAR_VERTICAL, CCMG_LIST_WIDTH - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, CCMG_LIST_HEIGHT, 0, 0);
}

CMappingGUIList::~CMappingGUIList()
{
  int i;

  for(i = 0; i < MappingGUIs->Count; i++)
  {
    delete MappingGUIs->Items[i];
    MappingGUIs->Items[i] = 0;
  }
  delete MappingGUIs;
  MappingGUIs = 0;

  delete ScrollBarV;
  ScrollBarV = 0;
}

void CMappingGUIList::AddMapping(CMapping *newMapping)
{
  CMappingGUI *mappingGUI;
  int          i;

  mappingGUI = new CMappingGUI(this, newMapping);
  i = MappingGUIs->AddItem(mappingGUI);
  mappingGUI->Move(0, i * CCMG_TOOLBAR_HEIGHT); 
  mappingGUI->Show();

  SizeScrollBar();
}

void CMappingGUIList::RemoveMapping(CMapping *oldMapping)
{
  int          i, j, pos;
  CMappingGUI *mappingGUI;

  for(i = 0; i < MappingGUIs->Count; i++)
  {
    mappingGUI = MappingGUIs->Items[i];

    if(mappingGUI->GetMapping() == oldMapping)
    {
      MappingGUIs->RemoveItem(i);
      delete mappingGUI;

      pos = ScrollBarV->GetPos();

      for(j = i; j < MappingGUIs->Count; j++)
      {
        mappingGUI = MappingGUIs->Items[j];
        mappingGUI->Move(0, (j * CCMG_TOOLBAR_HEIGHT) - pos);
      }

      SizeScrollBar();
    }
  }
}

void CMappingGUIList::OnSetMapping(CMapping *mapping)
{
  int i;
  CMappingGUI *mappingGUI;

  for(i = 0; i < MappingGUIs->Count; i++)
  {
    mappingGUI = MappingGUIs->Items[i];

    if(mappingGUI->GetMapping() == mapping)
    {
      mappingGUI->OnSetMapping();
      break;
    }
  }
}

CControlChangeMapperGUI* CMappingGUIList::GetMappingGUI()
{
  return MappingGUI;
}


void CMappingGUIList::SizeScrollBar()
{
  ScrollBarV->SetMaxPos((MappingGUIs->Count * CCMG_TOOLBAR_HEIGHT) - Height);
  ScrollBarV->SetPageSize(Height - CCMG_TOOLBAR_HEIGHT);
  if((MappingGUIs->Count * CCMG_TOOLBAR_HEIGHT) > Height)
  {
    ScrollBarV->Show();
    ScrollBarV->SetTopMost();
  }
  else
    ScrollBarV->Hide();
}

void CMappingGUIList::Train(int mapIn)
{
  int i;

  for(i = 0; i < MappingGUIs->Count; i++)
    MappingGUIs->Items[i]->Train(mapIn);
}

void CMappingGUIList::OnScrollY(int newPos)
{
  int i;

  for(i = 0; i < MappingGUIs->Count; i++)
    MappingGUIs->Items[i]->Move(0, (i * CCMG_TOOLBAR_HEIGHT) - newPos);
}

CControlChangeMapperGUI::CControlChangeMapperGUI(HWND parent, CControlChangeMapper *mapper)
: CControl(parent, Core->ColorManager, "ControlChange Mapper", 0, 0, CCMG_WIDTH, CCMG_HEIGHT, false)
{
  int i;

  Mapper = mapper;
 
  ToolBar = new CToolBar(this, 0, 0, CCMG_WIDTH, CCMG_TOOLBAR_HEIGHT);
  AddButton = ToolBar->AddButton(IDI_ADD,    CCMG_TOOLBAR_BUTTON_ADD, 20, 20, "Add ControlChange Mapping", false);

  ToolBar->Show();

  MappingGUIList = new CMappingGUIList(this);

  for(i = 0; i < mapper->GetMappingCount(); i++)
  {
    MappingGUIList->AddMapping(mapper->GetMapping(i));
  }

  MappingGUIList->Show();
}

CControlChangeMapperGUI::~CControlChangeMapperGUI()
{
  delete MappingGUIList;
  MappingGUIList = 0;

  delete ToolBar;
  ToolBar = 0;

  delete AddButton;
  AddButton = 0;
}

void CControlChangeMapperGUI::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == AddButton)
  {
    Mapper->Lock();
    Mapper->AddMapping();
    Mapper->Release();
  }
}

void CControlChangeMapperGUI::Train(int mapIn)
{
  MappingGUIList->Train(mapIn);
}

void CControlChangeMapperGUI::OnAppMessage(UINT message, WPARAM wParam, LPARAM lParam)
{
  if(message == WM_APP_REMOVE_MAPPING)
  {
    Mapper->Lock();
    Mapper->RemoveMapping((CMapping*)wParam);
    Mapper->Release();
  }
}

void CControlChangeMapperGUI::OnAddMapping(CMapping *newMapping)
{
  MappingGUIList->AddMapping(newMapping);
}

void CControlChangeMapperGUI::OnRemoveMapping(CMapping *oldMapping)
{
  MappingGUIList->RemoveMapping(oldMapping);
}

void CControlChangeMapperGUI::OnSetMapping(CMapping *mapping)
{
  MappingGUIList->OnSetMapping(mapping);
}

CControlChangeMapper* CControlChangeMapperGUI::GetMapper()
{
  return Mapper;
}

CMapping::CMapping()
{
  SetMapping(0, 0);
}

CMapping::CMapping(int mapIn, int mapOut)
{
  SetMapping(mapIn, mapOut);
}

void CMapping::GetMapping(int &mapIn, int &mapOut)
{
  mapIn  = MapIn;
  mapOut = MapOut;
}

void CMapping::SetMapping(int mapIn, int mapOut)
{
  MapIn  = mapIn;
  MapOut = mapOut;
}

CControlChangeMapper::CControlChangeMapper(CHost *host)
: CMachine(host)
{
  GUI = 0;

  Mappings = new CArray<CMapping*>;

  Ports     = new CPort*[2];
  Ports[0]  = new CPort(host, this, PT_CONTROL | PT_INPUT,  "Control In");
  Ports[1]  = new CPort(host, this, PT_CONTROL | PT_OUTPUT, "Control Out");
  PortCount = 2;
}

CControlChangeMapper::~CControlChangeMapper()
{
  int i;

  delete Ports[0];
  Ports[0] = 0;
  delete Ports[1];
  Ports[1] = 0;
  delete Ports;
  Ports = 0;

  while(Mappings->Count > 0)
    RemoveMapping();

  for(i = 0; i < Mappings->Count; i++)
  {
    delete Mappings->Items[i];
    Mappings->Items[i] = 0;
  }
  Mappings->Clear();

  if(GUI != 0)
  {
    delete GUI;
    GUI = 0;
  }


  delete Mappings;
  Mappings = 0;
}

void CControlChangeMapper::GetMapping(int index, int &mapIndexIn, int &mapIndexOut)
{
  CMapping *mapping;

  mapping = GetMapping(index);
  if(mapping)
    mapping->GetMapping(mapIndexIn, mapIndexOut);
}

CMapping* CControlChangeMapper::GetMapping(int index)
{
  if((index >= 0) && (index < Mappings->Count))
    return Mappings->Items[index];
  else
    return 0;
}

void CControlChangeMapper::SetMapping(int index, int mapIndexIn, int mapIndexOut)
{
  CMapping *mapping;

  mapping = GetMapping(index);
  if(mapping)
  {
    mapping->SetMapping(mapIndexIn, mapIndexOut);
    if(GUI)
      GUI->OnSetMapping(mapping);
  }
}

void CControlChangeMapper::SetMapping(CMapping *mapping, int mapIndexIn, int mapIndexOut)
{
  mapping->SetMapping(mapIndexIn, mapIndexOut);
  if(GUI)
    GUI->OnSetMapping(mapping);
}

int CControlChangeMapper::GetMappingCount()
{
  return Mappings->Count;
}

bool CControlChangeMapper::IsSynth()
{
  return false;
}

void CControlChangeMapper::SetSampleRate(int sampleRate)
{
}

void CControlChangeMapper::SetBlockSamples(int blockSamples)
{
}

void CControlChangeMapper::Work()
{
  SControlMessage message;

  while(Ports[0]->ControlBuffer->Read(&message))
  {
    if(message.Type == CONTROL_MESSAGE_CONTROL_CHANGE)
    {
      int i;

      if(GUI)
        GUI->Train(message.ControlChange.Controller);

      for(i = 0; i < Mappings->Count; i++)
      {
        int mapIn, mapOut;

        Mappings->Items[i]->GetMapping(mapIn, mapOut);

        if(mapIn == message.ControlChange.Controller)
        {
          message.ControlChange.Controller = mapOut;
          break;
        }
      }
    }

    Ports[1]->ControlBuffer->Write(&message);
  }
}

void CControlChangeMapper::ReadProperties(char *data, int length, bool isInner)
{
  int *iData, i, mapIn, mapOut, n;

  if(length >= 4)
  {
    iData = (int*)data;
  
    if(*iData > 0)
    {
      n = *(iData++);

      if((sizeof(int) * ((n * 2) + 1)) == length)
      {
        for(i = 0; i < n; i++)
        {
          mapIn  = *(iData++);
          mapOut = *(iData++);

          AddMapping(mapIn, mapOut);
        }
      }
    }
  }
}

void CControlChangeMapper::WriteProperties(char **data, int *length, bool *isInner)
{
  int *iData, i, mapIn, mapOut;

  *isInner = false;
  *length  = sizeof(int) * ((Mappings->Count * 2) + 1);
  *data = new char[*length];
  iData = (int*)*data;

  *(iData++) = Mappings->Count;

  for(i = 0; i < Mappings->Count; i++)
  {
    Mappings->Items[i]->GetMapping(mapIn, mapOut);
      
    *(iData++) = mapIn;
    *(iData++) = mapOut;
  }
}

HWND CControlChangeMapper::CreateGUI(HWND parent)
{
  if(GUI == 0)
  {
    GUI = new CControlChangeMapperGUI(parent, this);
  }
  return GUI->Handle;
}

void CControlChangeMapper::AddMapping()
{
  AddMapping(0, 0);
}

void CControlChangeMapper::AddMapping(int mapIn, int mapOut)
{
  CMapping *mapping;

  mapping = new CMapping(mapIn, mapOut);
  Mappings->AddItem(mapping);
  if(GUI)
    GUI->OnAddMapping(Mappings->Items[Mappings->Count - 1]);
}

void CControlChangeMapper::RemoveMapping()
{
  if(Mappings->Count > 0)
  {
    CMapping *oldMapping;

    oldMapping = Mappings->Items[Mappings->Count - 1];
    Mappings->RemoveItem(Mappings->Count - 1);

    if(GUI)
      GUI->OnRemoveMapping(oldMapping);

    delete oldMapping;
  }
}

void CControlChangeMapper::RemoveMapping(CMapping *mapping)
{
  int i;

  for(i = 0; i < Mappings->Count; i++)
  {
    if(Mappings->Items[i] == mapping)
    {
      Mappings->RemoveItem(i);

      if(GUI)
        GUI->OnRemoveMapping(mapping);

      delete mapping;
    }
  }
}

CControlChangeMapperInfo::CControlChangeMapperInfo()
{
  Name = "ES ControlChange Mapper";
  UniqueID = "DarkPlug::ES ControlChange Mapper";
}

CMachine *CControlChangeMapperInfo::CreateMachine()
{
  return new CControlChangeMapper(Core->Host);
}