/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "LiteLCDText.h"

#define TIMER_DELAY_1 4000
#define TIMER_DELAY_2 100

CLiteLCDText::CLiteLCDText(CLiteContainer *parent, int x, int y, int width, int height, CBitFont *font, double alpha)
: CLiteControl(parent, x, y, width, height)
{
  RenderBuffer = new CFrameBuffer(width, height, true);
  Font         = font;
  Text         = 0;
  Alpha        = alpha;
  Timer        = new CTimer(this, Parent->Handle);
  TextOffset   = 0;

  Render();
};

CLiteLCDText::~CLiteLCDText()
{
  delete Timer;
  delete RenderBuffer;
  if(Text)
    delete Text;
}

void CLiteLCDText::Draw(CFrameBuffer *frameBuffer)
{
  RenderBuffer->Draw(frameBuffer, X, Y, 0, 0, Width, Height);
}

void CLiteLCDText::Render()
{
  int            x, y;
  unsigned char *pixel, a;

  RenderBuffer->Fill(RGB(0xFF, 0xFF, 0xFF));
  if(Text != 0)
    Font->DrawText(RenderBuffer, Text, -TextOffset, 0, Width + TextOffset, Height);
  for(x = 0; x < Width; x++)
    for(y = 0; y < Height; y++)
    {
      pixel = RenderBuffer->GetPixel4(x, y);
      a = (unsigned char)((0xFF - ((pixel[0] + pixel[1] + pixel[2]) / 3)) * Alpha);
      pixel[0] = 0;
      pixel[1] = 0;
      pixel[2] = 0;
      pixel[3] = a;
    }
}

void CLiteLCDText::SetText(char *text)
{
  int len;
  TextOffset = 0;
  if(Text)
    delete Text;
  len = (int)(strlen(text) + 1);
  Text = new char[len];
  strcpy(Text, text);
  _strupr(Text);
  Render();
  Parent->Render(X, Y, Width, Height);
  Timer->Set(TIMER_DELAY_1);
}

void CLiteLCDText::OnTimer(CTimer *timer)
{
  Parent->Lock();
  Timer->Set(TIMER_DELAY_2);
  TextOffset = TextOffset + 1;
  if(TextOffset > Width)
  {
    Timer->Kill();
    TextOffset = Width;
  }
  Render();
  Parent->Render(X, Y, Width, Height);
  Parent->Release();
  
}