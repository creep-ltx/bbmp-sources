/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "Core.h"
#include "DarkPlugAdapter.h"
#include "AntiAliasFilter.h"
#include "Resource.h"
#include "DetectCPU.h"
#include "DSP.h"

CCore     *Core = 0;
HINSTANCE AppInstance = 0;
CDSP      *DSP = 0;

CAntiAliasFilterInfo *Info = 0;

CCore::CCore(int cpuFeatures, audioMasterCallback audioMaster)
{
  CPUFeatures  = cpuFeatures;
  DSP = new CDSP(true);
  Host = new CHostAdapter(audioMaster);
  Info = new CAntiAliasFilterInfo(Host);
}

CCore::~CCore()
{
  delete Host;
}

AudioEffect* createEffectInstance(audioMasterCallback audioMaster, HINSTANCE hInstance)
{
  AppInstance = hInstance;
  if(Core == 0)
    Core = new CCore(DetectProcessorFeatures(), audioMaster);
  return new CDarkPlugAdapter(new CAntiAliasFilter(Core->Host, Info), audioMaster, 'ESAA');
}

