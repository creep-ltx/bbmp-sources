/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "SampleAnalyzer.h"
#include "Core.h"
#include "Sample.h"
#include "Error.h"
#include "../Resource.h"
#include <stdio.h>

#define WINDOW_WIDTH  640
#define WINDOW_HEIGHT 480

#define SPACING_X 8
#define SPACING_Y 8

#define COMBO_X      SPACING_X
#define COMBO_Y      SPACING_Y
#define COMBO_WIDTH  256
#define COMBO_HEIGHT 16

#define SAMPLE_VIEW_X              SPACING_X
#define SAMPLE_VIEW_Y_1            (COMBO_Y + 16 + (SPACING_Y * 2))
#define SAMPLE_VIEW_WIDTH(w)       ((w) - (SPACING_X * 2))
#define SAMPLE_VIEW_HEIGHT(h)      (((h) - (SAMPLE_VIEW_Y_1 + (SPACING_X * 2))) / 2)
#define SAMPLE_VIEW_Y_2(h)         (SAMPLE_VIEW_Y_1 + SAMPLE_VIEW_HEIGHT(h) + SPACING_Y)

void CSampleAnalyzer::OnComboSelect(CDropList *comboBox)
{
  SelectSample(comboBox->GetSelection());
}

CSampleAnalyzer::CSampleAnalyzer()
: CWindow("Sample Analyzer", WINDOW_WIDTH, WINDOW_HEIGHT, Core->ColorManager)
{
  HICON iconSmall, iconBig;

  SetFont(new CFont(DC, "Verdana", 10.0f, false));

  SampleCombo = new CDropList(this, "SampleCombo", COMBO_X, COMBO_Y, COMBO_WIDTH, COMBO_HEIGHT);
  SampleCombo->Show();

  SampleView[0] = new CSampleView(this, SAMPLE_VIEW_X, SAMPLE_VIEW_Y_1,
    SAMPLE_VIEW_WIDTH(Width), SAMPLE_VIEW_HEIGHT(Height));
  SampleView[0]->Show();

  SampleView[1] = new CSampleView(this, SAMPLE_VIEW_X, SAMPLE_VIEW_Y_2(Height),
    SAMPLE_VIEW_WIDTH(Width), SAMPLE_VIEW_HEIGHT(Height));
  SampleView[1]->SetMode(SAMPLE_VIEW_MODE_SPECTRUM);
  SampleView[1]->Show();

  iconSmall = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(IDI_APP), IMAGE_ICON,
    16, 16, LR_DEFAULTCOLOR);
  iconBig   = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(IDI_APP), IMAGE_ICON,
    32, 32, LR_DEFAULTCOLOR);

  SendMessage(Handle, WM_SETICON, ICON_SMALL, (LPARAM)iconSmall);
  SendMessage(Handle, WM_SETICON, ICON_BIG,   (LPARAM)iconBig);

  Samples = 0;
  SamplePaths = 0;

  LoadSamples("Samples");
}

CSampleAnalyzer::~CSampleAnalyzer()
{
  FreeSamples();
  delete SampleCombo;
  delete SampleView[0];
  delete SampleView[1];
}

void CSampleAnalyzer::OnClose()
{
  Hide();
}

void CSampleAnalyzer::SelectSample(int index)
{
  CSample *sample;

  try
  {
    sample = new CSample;
    sample->LoadWAV(SamplePaths[index]);
    SampleView[0]->SetSample(sample);
    SampleView[1]->SetSample(sample);
  }
  catch(char *theError)
  {
    DisplayError(theError);
  }
  if(sample != 0)
    delete sample;
}

void CSampleAnalyzer::LoadSamples(char *path)
{
  HANDLE          findHandle;
  WIN32_FIND_DATA findData;
  char           *findPath;
  int             c;
  bool            moreFiles;
  int             sample = 0, samples = 0;

  // generate find string

  c = (int)strlen(path) + 6;
  findPath = new char[c + 1];
  sprintf(findPath, "%s\\*.wav", path);
  
  // find how many samples exist in directory
  
  findHandle = FindFirstFile(findPath, &findData);
  moreFiles = (findHandle != INVALID_HANDLE_VALUE);

  while(moreFiles)
  {
    samples++;
    moreFiles = (FindNextFile(findHandle, &findData) == TRUE);
  }

  FindClose(findHandle);
  
  // load samples

  Samples = 0;
  SamplePaths = new char*[samples];

  findHandle = FindFirstFile(findPath, &findData);
  delete findPath;

  moreFiles = (findHandle != INVALID_HANDLE_VALUE);

  while(moreFiles && (sample < samples))
  {
    SampleCombo->AddItem(findData.cFileName);
    c = (int)strlen(path) + 1 + (int)strlen(findData.cFileName);
    SamplePaths[sample] = new char[c + 1];
    sprintf(SamplePaths[sample], "%s\\%s", path, findData.cFileName);
    Samples++;
    sample++;
    moreFiles = (FindNextFile(findHandle, &findData) == TRUE);
  }

  FindClose(findHandle);
}

void CSampleAnalyzer::FreeSamples()
{
  if(SamplePaths != 0)
  {
    delete SamplePaths;
    SamplePaths = 0;
  }
  Samples = 0;
}

void CSampleAnalyzer::OnResize(int newWidth, int newHeight)
{
  CWindow::OnResize(newWidth, newHeight);
  SampleView[0]->Resize(SAMPLE_VIEW_WIDTH(Width), SAMPLE_VIEW_HEIGHT(Height));
  SampleView[1]->Move(SAMPLE_VIEW_X, SAMPLE_VIEW_Y_2(Height));
  SampleView[1]->Resize(SAMPLE_VIEW_WIDTH(Width), SAMPLE_VIEW_HEIGHT(Height));
}