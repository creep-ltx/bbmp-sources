/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "Core.h"
#include "DarkPlugAdapter.h"
#include "Resource.h"
#include "DrumKit.h"
#include "DetectCPU.h"

CCore    *Core = 0;
HINSTANCE AppInstance = 0;

CCore::CCore(int cpuFeatures, audioMasterCallback audioMaster)
{
  CPUFeatures  = cpuFeatures;
  Host = new CHostAdapter(audioMaster);
  DSP = new CDSP(false);
  DrumKitInfo = new CDrumKitInfo(Host);
}

AudioEffect* createEffectInstance(audioMasterCallback audioMaster, HINSTANCE hInstance)
{
  AppInstance = hInstance;
  if(Core == 0)
    Core = new CCore(DetectProcessorFeatures(), audioMaster);
  return new CDarkPlugAdapter(new CDrumKit(Core->Host, Core->DrumKitInfo), audioMaster, 'DGR8');
}
