/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "Studio.h"
#include "Core.h"
#include "Util.h"
#include "Button.h"
#include <math.h>
#include <stdio.h>


#define STATE_IDLE          0
#define STATE_USERCONNECT   1
#define STATE_USERMOVE      2
#define VOLUME_VELOCITY     0.0004
#define PI                  3.14159265358979
#define CABLE_VOLUME_WIDTH  24
#define CABLE_VOLUME_HEIGHT 120
#define VOLUME_RANGE_DB     90.0
#define SCROLLBAR_SIZE      16

CStudio::CStudio(CControl *parent, CPatternEditor *patternEditor, CHDRecorder *hdRecorder, int x, int y, int width, int height)
  : CControl(parent, "Studio", x, y, width, height, true)
{
  RenameDialog = new CRenameDialog(this, "Rename Machine", "Name:");
  PatternEditor = patternEditor;
  OffsetX = OffsetY = 0;
  FirstContainer = 0;
  BackColor = (ColorManagerColor)WindowWorkspace;
  
  Master = 0;
  InitContextMenus();
  State = STATE_IDLE;
  SubInit = true;

  DrawControl();
  
  ScrollBarH = new CScrollBar(this, SCROLLBAR_HORIZONTAL, 0, Height - SCROLLBAR_SIZE, Width - SCROLLBAR_SIZE, SCROLLBAR_SIZE, 0, 0);
  ScrollBarV = new CScrollBar(this, SCROLLBAR_VERTICAL, Width - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, Height - SCROLLBAR_SIZE, 0, 0);
  ScrollBox = new CControl(this, "ScrollBox", Width - SCROLLBAR_SIZE, Height - SCROLLBAR_SIZE, SCROLLBAR_SIZE, SCROLLBAR_SIZE, false);
  ScrollBox->SetBackColor((ColorManagerColor)ControlLight);
  ScrollBarH->SetLineSize(16);
  ScrollBarV->SetLineSize(16);
  ScrollBarH->Show();
  ScrollBarV->Show();
  ScrollBox->Show();

  WorkingVolume = 0.0f;
  CableVolumeSlider = new CCableVolumeSlider(this, 0, 0, CABLE_VOLUME_WIDTH, CABLE_VOLUME_HEIGHT);
  
  HDRecorder = hdRecorder;
}

CStudio::~CStudio()
{
  CMachineContainer *container;

  while(FirstContainer != 0)
  {
    container = FirstContainer;
    container->Detach();
    delete container;
  }

  delete AddMachineMenu;
  delete CableMenu;
  delete CableVolumeSlider;
  delete ScrollBarH;
  delete ScrollBarV;
  delete ScrollBox;
  delete RenameDialog;
}

void CStudio::Idle()
{
  CMachineContainer *container;

  Lock();  
  container = FirstContainer;
  while(container)
  {
    container->Machine->OnIdle();
    container = container->GetNext();
  }
  Release();
}

CMachineContainer *CStudio::AddMachine(char *name, int x, int y, CMachine *machine, CMachineInfo *machineInfo, CMachineLoaderEntry *entry)
{
  CMachineContainer *container;

  container = new CMachineContainer(name, machineInfo->UniqueID, x, y, x + OffsetX, y + OffsetY, machine, machineInfo, entry, this, 0, 0, false);
  container->Attach(&FirstContainer);
  container->Show();
  SizeScrollBars();
  PatternEditor->AddMachine(container);
  if(!strcmp("Master", name))
    SetMaster(container);
  return container;
}

CMachineContainer *CStudio::AddMachine(char *name, int x, int y, CMachine *machine, CMachineInfo *machineInfo, CMachineLoaderEntry *entry, char *properties, int propertyBytes, bool isInner)
{
  CMachineContainer *container;

  container = new CMachineContainer(name, machineInfo->UniqueID, x, y, x + OffsetX, y + OffsetY, machine, machineInfo, entry, this, properties, propertyBytes, isInner);
  container->Attach(&FirstContainer);
  container->Show();
  SizeScrollBars();
  PatternEditor->AddMachine(container);
  if(!strcmp("Master", name))
    SetMaster(container);
  return container;
}

void CStudio::RemoveMachine(CMachineContainer *container)
{
  CMachineContainer *container2;
  CConnector        *connector;
  int                i, j;

  container2 = FirstContainer;
  while(container2 != 0)
  {
    for(i = 0; i < container2->ConnectorCount; i++)
    {
      connector = container2->Connectors[i];
      for(j = 0; j < connector->ConnectionCount; j++)
        if(connector->Connections[j]->Input->Container == container)
          connector->Disconnect(j--);
    }
    container2 = container2->GetNext();
  }

  for(i = 0; i < container->ConnectorCount; i++)
  {
    connector = container->Connectors[i];
    connector->ClearConnections();
  }

  Update();

  container->Hide();
  SizeScrollBars();
  container->Detach();
  PatternEditor->RemoveMachine(container);
  Core->MainWindow->SequenceEditor->RemoveMachine(container);
  delete container;
}

void CStudio::SetMaster(CMachineContainer *master)
{
  Master = master;
}

void CStudio::Work(const int nChannels, double **channels, const int samples)
{
  CMachineContainer *container;
  int                i, j, channel;
  double             volume, workingVolume, temp, *val, *peak;
  CPeakMeter        *peakMeter;

  val = new double[nChannels];
  peak = new double[nChannels];

  Lock();
  PatternEditor->Lock();

  for(i = 0; i < nChannels; i++)
    peak[i] = 0.0f;

  volume = Core->Volume;
  workingVolume = WorkingVolume;

  container = FirstContainer;
  while(container != 0)
  {
    container->PrepareToWork();
    container = container->GetNext();
  }

  Core->MainWindow->PatternEditor->Work();
  Core->MainWindow->SequenceEditor->Work();

  if(Master != 0)
  {
    Master->Lock();
    Master->Work(false);
    
    Core->Host->UpdateSamplePosition(samples);
    
    for(i = 0; i < samples; i++)
    {
      if(nChannels == 2)
      {
        val[0] = Master->Machine->Ports[0]->AudioBuffer->LeftData[i]  * workingVolume;
        val[1] = Master->Machine->Ports[0]->AudioBuffer->RightData[i] * workingVolume;
        channels[0][i] = val[0];
        channels[1][i] = val[1];

        temp = val[0] * val[0];
        if(temp > peak[0])
          peak[0] = temp;

        temp = val[1] * val[1];
        if(temp > peak[1])
          peak[1] = temp;
      }
      else
      {
        for(channel = 0; channel < nChannels; channel++)
        {
          val[channel] = Master->Machine->Ports[channel]->AudioBuffer->MonoData[i] * workingVolume;
          channels[channel][i] = val[channel];
          temp = val[channel] * val[channel];
          if(temp > peak[channel])
            peak[channel] = temp;
        }
      }

      if(workingVolume != volume)
      {
        if(workingVolume < volume)
        {
          workingVolume += (0.1f + (volume - workingVolume)) * VOLUME_VELOCITY;
          if(workingVolume > volume)
            workingVolume = volume;
        }
        else 
        {
          workingVolume -= (0.1f + (workingVolume - volume)) * VOLUME_VELOCITY;
          if(workingVolume < volume)
            workingVolume = volume;
        }
      }
    }
    Master->Release();
  }
  else
  {
    for(i = 0; i < nChannels; i++)
      for(j = 0; j < samples; j++)
        channels[i][j] = 0.0f;
  }


  CMachineContainer *machine;
  machine = FirstContainer;
  while(machine)
  {
    if(!(machine->WorkDone))
      machine->Work(false);
	machine = machine->GetNext();
  }

  WorkingVolume = workingVolume;
  PatternEditor->Release();
  peakMeter = Core->MainWindow->MainToolBar->PeakMeter;
  peakMeter->Lock();
  if(nChannels < 2)
    peakMeter->SetPeak(fabs(peak[0]), fabs(peak[0]));
  else
    peakMeter->SetPeak(fabs(peak[0]), fabs(peak[1]));
  peakMeter->Release();

  delete val;
  delete peak;

  Release();
}

int CStudio::MenuPathDepth(char *machinePath)
{
  return Core->MachineLoader->MenuPathDepth(machinePath);
}

void CStudio::MenuPathItem(char *machinePath, int depth, char *pathItem)
{
  Core->MachineLoader->MenuPathItem(machinePath, depth, pathItem);
}

int CStudio::AppendMachineMenu(HMENU parentMenu, int loaderItem, int depth)
{
  int                  i, entryDepth, firstItem;
  CMachineLoader      *loader;
  CMachineLoaderEntry *entry;
   
  loader = Core->MachineLoader;
  firstItem = loaderItem;
  
  while(loaderItem < loader->Entries->Count)
  {
    entry = loader->Entries->Items[loaderItem];
    entryDepth = MenuPathDepth(entry->MachineInfo->MenuPath);
    
    if(entryDepth < depth)
      return loaderItem;
  
    for(i = 0; i < depth; i++)
    {
      char pathItem[1024];
      char pathItem2[1024];
      
      MenuPathItem(entry->MachineInfo->MenuPath, i, pathItem);
      MenuPathItem(loader->Entries->Items[firstItem]->MachineInfo->MenuPath, i, pathItem2);
      
      if(strcmp(pathItem, pathItem2) != 0)
        return loaderItem;
    }
    
    if(entryDepth > depth)
    {
      char pathItem[1024];
      
      HMENU subMenu;
      
      MenuPathItem(entry->MachineInfo->MenuPath, depth, pathItem);
      
      subMenu = CreatePopupMenu();
      
      AppendMenuA(parentMenu, MF_POPUP | MF_STRING, (UINT_PTR)subMenu, pathItem);
      loaderItem = AppendMachineMenu(subMenu, loaderItem, depth + 1);
    }
    else
    {
      if(strcmp("Master", entry->MachineInfo->Name) != 0)
      {
        AppendMenuA(parentMenu, MF_ENABLED | MF_STRING, ++loaderItem, entry->MachineInfo->Name);
      }
      else
        loaderItem++;
    }
  }
  
  return loaderItem;
}

void CStudio::InitContextMenus()
{  
  Core->MachineLoader->Sort();
  
  AddMachineMenu = new CMenu(this, true);
  AppendMachineMenu(AddMachineMenu->GetHandle(), 0, 0);

  CableMenu = new CMenu(this, true);
  CableMenu->Append(1, "Disconnect", 0);
}

void CStudio::OnRightButtonUp(int x, int y)
{
  CConnector *connector1, *connector2;

  if(PointInCable(x, y, &connector1, &connector2))
    ShowCableMenu(x, y, connector1, connector2);
  else
    ShowAddMachineMenu(x, y);
}

void CStudio::ShowAddMachineMenu(int x, int y)
{
  POINT                point;
  int                  id;
  CMachineLoaderEntry *entry;
  char                *name;

  point.x = x;
  point.y = y;

  ClientToScreen(Handle, &point);

  id = AddMachineMenu->ShowPopup(point.x, point.y);
  if((id > 0) && (id <= Core->MachineLoader->Entries->Count))
  {
    entry = Core->MachineLoader->Entries->Items[id - 1];
    name = GenerateMachineName(entry->MachineInfo->Name);
    AddMachine(name, x, y, entry->MachineInfo->CreateMachine(), entry->MachineInfo, entry);
    delete name;
  }
}

void CStudio::ResetScrolling()
{
  OffsetX = 0;
  OffsetY = 0;
  SizeScrollBars();
}

CMachineContainer* CStudio::AddMachine(char *instanceName, char *uniqueID, int x, int y, int visibleControl, char *properties, int propertyBytes, bool isInner)
{
  return AddMachine(instanceName, instanceName, uniqueID, x, y, visibleControl, properties, propertyBytes, isInner, false);
}
CMachineContainer* CStudio::AddMachine(char *instanceName, char *machineName, char *uniqueID, int x, int y, int visibleControl, char *properties, int propertyBytes, bool isInner, bool oldUniqueID)
{
  CMachineLoader      *loader;
  CMachineLoaderEntry *entry;
  CMachineContainer   *container;
  int                  i, n, matches, bestMatch;;
  
  loader = Core->MachineLoader;
  
  matches    = 0;
  bestMatch  = -1;
 
  if(oldUniqueID)
  {
    if((uniqueID[0] == 'V') && (uniqueID[1] == 'S') && (uniqueID[2] == 'T') && (uniqueID[3] == ':') && (uniqueID[4] == ':'))
    {  
      for(i = 0; i < loader->Entries->Count; i++)
      {
        entry = loader->Entries->Items[i];

        if(!strcmp((oldUniqueID ? (entry->MachineInfo->OldUniqueID != 0 ? entry->MachineInfo->OldUniqueID : entry->MachineInfo->UniqueID) : entry->MachineInfo->UniqueID), uniqueID))
        {
          matches++;
          for(n = 0; machineName[n] == entry->MachineInfo->Name[n]; n++)
            if(entry->MachineInfo->Name[n + 1] == 0)
              bestMatch = i;
        }       
      }
    }

    if(matches > 1)
      if(bestMatch != -1)
      {
        entry = loader->Entries->Items[bestMatch];

        container = AddMachine(instanceName, x, y, entry->MachineInfo->CreateMachine(), entry->MachineInfo, entry, properties, propertyBytes, isInner);
        container->SetVisibleControl(visibleControl);
        return container;
      }
  }
  
  for(i = 0; i < Core->MachineLoader->Entries->Count; i++)
  {
    entry = loader->Entries->Items[i];
    
    if(!strcmp((oldUniqueID ? (entry->MachineInfo->OldUniqueID != 0 ? entry->MachineInfo->OldUniqueID : entry->MachineInfo->UniqueID) : entry->MachineInfo->UniqueID), uniqueID))
    {
      container = AddMachine(instanceName, x, y, entry->MachineInfo->CreateMachine(), entry->MachineInfo, entry, properties, propertyBytes, isInner);
      container->SetVisibleControl(visibleControl);
      return container;
    }
  }
  
  return 0;
}

void CStudio::BeginUserConnect(CConnector *connector)
{
  POINT point;

  GetCursorPos(&point);
  ScreenToClient(Handle, &point);

  State = STATE_USERCONNECT;
  MouseX = point.x;
  MouseY = point.y;
  SetCapture(Handle);
  CurrentConnector = connector;
  CurrentConnector2 = 0;
}

void CStudio::BeginUserMove(CMachineContainer *container)
{
  POINT point;

  GetCursorPos(&point);
  ScreenToClient(Handle, &point);

  State = STATE_USERMOVE;
  MouseX = point.x;
  MouseY = point.y;
  SetCapture(Handle);
  CurrentContainer = container;
}

LRESULT CStudio::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  Lock();

  switch(msg)
  {
    case WM_LBUTTONUP:
    {
      if(State == STATE_USERMOVE)
      {
        State = STATE_IDLE;
        CurrentContainer = 0;
        ReleaseCapture();
        SizeScrollBars();
      }
      if(State == STATE_USERCONNECT)
      {
        if(CurrentConnector2 != 0)
          ConnectConnectors(CurrentConnector, CurrentConnector2, 1.0f);
        State = STATE_IDLE;
        CurrentConnector = 0;
        ReleaseCapture();
        Update();
      }
      break;
    }
    case WM_MOUSEMOVE:
    {
      if(State == STATE_USERMOVE)
      {
        int x, y, movex, movey;

        x = LOWORD(lParam);
        y = HIWORD(lParam);

        if(x >= 0 && x < Width)
        {
          movex = x - MouseX;
          MouseX = x;
        }
        else
          movex = 0;
        if(y >= 0 && y < Height)
        {
          movey = y - MouseY;
          MouseY = y;
        }
        else
          movey = 0;

        if((CurrentContainer->X + movex) < 0)
            movex = 0;

        if((CurrentContainer->Y + movey) < 0)
            movey = 0;

        if((movex != 0) || (movey != 0))
        {
          CurrentContainer->Move(CurrentContainer->X + movex, CurrentContainer->Y + movey);
          CurrentContainer->OffsetX += movex;
          CurrentContainer->OffsetY += movey;
          DrawControl();
          OnPaint();
          SizeScrollBars();
        }

        Release();
        return 0;
      }
      if(State == STATE_USERCONNECT)
      {
        int x, y, movex, movey;

        x = LOWORD(lParam);
        y = HIWORD(lParam);

        if(x < 0 || x >= Width || y < 0 || y >= Height)
          ConnectorCentre(CurrentConnector, &x, &y);

        movex = x - MouseX;
        movey = y - MouseY;

        MouseX = x;
        MouseY = y;

        if((movex != 0) || (movey != 0))
        {
          CurrentConnector2 = ConnectorAt(x, y);
          DrawControl();
          OnPaint();
        }
      }
      break;
    }
  }
  Release();
  return CControl::WindowProc(hWnd, msg, wParam, lParam);
}

void CStudio::DrawControl()
{
  HDC hDC;

  hDC = BackDC;

  ColorManager->Lock();
  ColorManager->GetBrush(BackColor)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();

  DrawConnections(hDC);

  if(State == STATE_USERCONNECT)
    DrawUserConnect(hDC);
}

void CStudio::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
  {
    SizeScrollBars();
    Update();
  }
}

void CStudio::ConnectorCentre(CConnector *connector, int *x, int *y)
{
  POINT point;

  point.x = connector->Width / 2;
  point.y = connector->Height / 2;

  ClientToScreen(connector->Handle, &point);
  ScreenToClient(Handle, &point);
  *x = point.x;
  *y = point.y;
}

void CStudio::DrawUserConnect(HDC hDC)
{
  int x1, y1, x2, y2;
  ConnectorCentre(CurrentConnector, &x1, &y1);
  if(CurrentConnector2 == 0)
  {  
    x2 = MouseX;
    y2 = MouseY;
  }
  else
    ConnectorCentre(CurrentConnector2, &x2, &y2);

  DrawCable(hDC, x1, y1, x2, y2);
}

void CStudio::DrawConnections(HDC hDC)
{
  CMachineContainer *container;
  CConnection       *connection;
  CConnector        *connector;
  int                i, j;

  container = FirstContainer;
  while(container != 0)
  {
    for(i = 0; i < container->ConnectorCount; i++)
    {
      connector = container->Connectors[i];
      for(j = 0; j < connector->ConnectionCount; j++)
      {
        connection = connector->Connections[j];
        DrawConnection(hDC, connection);
      }
    }
    container = container->GetNext();
  }
}

CConnector *CStudio::ConnectorFromPort(CPort *port)
{
  CMachineContainer *container;
  int                i;

  container = ((CMachineContainer*)(port->Machine->HostData));
  for(i = 0; i < container->ConnectorCount; i++)
    if(container->Connectors[i]->Port == port)
      return container->Connectors[i];
  return 0;
}

void CStudio::AdjustCable(CConnection *connection, int *x1, int *y1, int *x2, int *y2)
{
  CMachineContainer *c;

  c = connection->Input->Container;
  LineInRect(c->X, c->Y, c->X + c->Width - 1, c->Y + c->Height - 1, *x1, *y1, *x2, *y2, x1, y1); 

  c = connection->Output->Container;
  LineInRect(c->X, c->Y, c->X + c->Width - 1, c->Y + c->Height - 1, *x2, *y2, *x1, *y1, x2, y2); 
}

void CStudio::DrawConnection(HDC hDC, CConnection *connection)
{
  int         x1, y1, x2, y2;
  CConnector *connector1, *connector2;

  connector1 = connection->Input;
  connector2 = connection->Output;
  ConnectorCentre(connector1, &x1, &y1);
  ConnectorCentre(connector2, &x2, &y2);
  
  AdjustCable(connection, &x1, &y1, &x2, &y2);
  
  DrawCable(hDC, x1, y1, x2, y2);
  if((connection->Input->Port->Type && PT_AUDIO) == PT_AUDIO)
    DrawVolumeKnob(hDC, x1, y1, x2, y2);
}

void CStudio::DrawCableBorderLine(HDC hDC, POINT &p1, POINT &p2)
{
  int f;
  HGDIOBJ oldPen;
  ColorManagerColor lineColor;
  
  f = ((p1.x - p2.x) + (p2.y - p1.y));

  if(f >= 0)
    lineColor = (ColorManagerColor)CableLight;
  else
    lineColor = (ColorManagerColor)CableShadow;

  ColorManager->Lock();
  oldPen = SelectObject(hDC, Core->ColorManager->GetPen(lineColor)->Handle);
  MoveToEx(hDC, p1.x, p1.y, NULL);
  LineTo(hDC, p2.x, p2.y);
  SelectObject(hDC, oldPen);
  ColorManager->Release();
}

void CStudio::DrawCable(HDC hDC, int x1, int y1, int x2, int y2)
{
#define CABLE_RADIUS 2

  double  a;
  POINT   p[6];
  HGDIOBJ oldPen, oldBrush;
  
  a = LineAngle(x1, y1, x2, y2);
  a = a + (2.0 * (PI / 4.0));

  RotatePoint(a + (-2.0 * (PI / 4.0)), x1, y1, CABLE_RADIUS, &(p[0]));
  RotatePoint(a + ( 0.0 * (PI / 4.0)), x1, y1, 0, &(p[1]));
  RotatePoint(a + ( 2.0 * (PI / 4.0)), x1, y1, CABLE_RADIUS, &(p[2]));

  RotatePoint(a + (+2.0 * (PI / 4.0)), x2, y2, CABLE_RADIUS, &(p[3]));
  RotatePoint(a + ( 0.0 * (PI / 4.0)), x2, y2, 0, &(p[4]));
  RotatePoint(a + (-2.0 * (PI / 4.0)), x2, y2, CABLE_RADIUS, &(p[5]));

  ColorManager->Lock();

  oldBrush = SelectObject(hDC, Core->ColorManager->GetBrush((ColorManagerColor)CableBack)->Handle);
  oldPen = SelectObject(hDC, Core->ColorManager->GetPen((ColorManagerColor)CableBack)->Handle);
  
  Polygon(hDC, p, 6);

  SelectObject(hDC, oldBrush);
  SelectObject(hDC, oldPen);

  ColorManager->Release();

  //SelectObject(hDC, Core->ColorManager->GetPen((ColorManagerColor)CableBorder)->Handle);
  //MoveToEx(hDC, p[0].x, p[0].y, NULL);
  //LineTo(hDC, p[5].x, p[5].y);

  DrawCableBorderLine(hDC, p[5], p[0]);

  //SelectObject(hDC, Core->ColorManager->GetPen((ColorManagerColor)CableBorder)->Handle);
  //MoveToEx(hDC, p[2].x, p[2].y, NULL);
  //LineTo(hDC, p[3].x, p[3].y);

  DrawCableBorderLine(hDC, p[2], p[3]);
}

CConnector *CStudio::ConnectorAt(int x, int y)
{
  HWND               handle;
  POINT              point;
  CMachineContainer *currentContainer;
  int                i;
  CConnector        *connector;

  point.x = x;
  point.y = y;
  ClientToScreen(Handle, &point);
  handle = WindowFromPoint(point);
  if(handle == 0)
    return 0;
  currentContainer = FirstContainer;
  while(currentContainer)
  {
    for(i = 0; i < currentContainer->ConnectorCount; i++)
    {
      connector = currentContainer->Connectors[i];
      if(connector->Handle == handle)
        return connector;
    }
    currentContainer = currentContainer->GetNext();
  }
  return 0;
}

void CStudio::ConnectConnectors(CConnector *connector1, CConnector *connector2, double volume)
{
  if(CanConnect(connector1, connector2))
  {
    connector1->Container->Machine->Lock();
    connector2->Container->Machine->Lock();

    if((connector1->Port->Type & PT_OUTPUT) == PT_OUTPUT)
      connector2->Connect(connector1, volume);
    else
      connector1->Connect(connector2, volume);

    connector1->Container->Machine->Release();
    connector2->Container->Machine->Release();
  }
}

void CStudio::ConnectConnectors(int m1, int c1, int m2, int c2, double volume)
{
  CConnector *connector1, *connector2;

  connector1 = GetConnector(m1, c1);
  connector2 = GetConnector(m2, c2);

  if((connector1 != 0) && (connector2 != 0))
    ConnectConnectors(connector1, connector2, volume);
  
  Update();
}

CConnector* CStudio::GetConnector(int index)
{
  CMachineContainer *m;
  int i;

  m = FirstContainer;
  while(m)
  {
    for(i = 0; i < m->ConnectorCount; i++)
      if(m->Connectors[i]->Port->Index == index)
        return m->Connectors[i];
    m = m->GetNext();
  }
  return 0;
}

CConnector* CStudio::GetConnector(int mi, int ci)
{
  CMachineContainer *m;

  m = FirstContainer;
  while(m)
  {
    if(m->Machine->Index == mi)
    {
      if(m->ConnectorCount > ci)
        return m->Connectors[ci];
      break;
    }
    m = m->GetNext();
  }
  return 0;
}

bool CStudio::CanConnect(CConnector *connector1, CConnector *connector2)
{
  CPort *port1, *port2;
  int    i;

  if((connector1 == 0) || (connector2 == 0))
    return false;

  port1 = connector1->Port;
  port2 = connector2->Port;

  if(port1->Machine == port2->Machine)
    return false;

  if((port1->Type & (PT_AUDIO | PT_CONTROL)) == (port2->Type & (PT_AUDIO | PT_CONTROL)))
  {
    if((port1->Type & PT_OUTPUT) != (port2->Type & PT_OUTPUT))
    {
      if((port1->Type & PT_OUTPUT) == PT_OUTPUT)
      {
        for(i = 0; i < connector2->ConnectionCount; i++)
          if(connector2->Connections[i]->Input == connector1)
            return false;
        return true;
      }
      else
      {
        for(i = 0; i < connector1->ConnectionCount; i++)
          if(connector1->Connections[i]->Input == connector2)
            return false;
        return true;
      }
    }
  }
  return false;
}

bool CStudio::PointInCable(int x, int y, CConnector **connector1, CConnector **connector2)
{
  CMachineContainer *container;
  int                i, j, x1, y1, x2, y2;
  CConnector        *checkConnector1, *checkConnector2;

  container = FirstContainer;
  while(container)
  {
    for(i = 0; i < container->ConnectorCount; i++)
    {
      checkConnector1 = container->Connectors[i];
      if(checkConnector1->ConnectionCount > 0)
      {
        ConnectorCentre(checkConnector1, &x1, &y1);

        for(j = 0; j < checkConnector1->ConnectionCount; j++)
        {
          checkConnector2 = checkConnector1->Connections[j]->Input;
          ConnectorCentre(checkConnector2, &x2, &y2);

          if(PointInLine(x, y, x1, y1, x2, y2, 4))
          {
            *connector1 = checkConnector1;
            *connector2 = checkConnector2;
            return true;
          }
        }
      }
    }
    container = container->GetNext();
  }
  return false;
}

bool CStudio::PointInLine(int pointX, int pointY, int x1, int y1, int x2, int y2, int gap)
{
  int   temp, lineX, lineY, lineHeight, lineWidth, minX, maxX;
  float fract;

  if(y1 > y2)
  {
    temp = y1;
    y1 = y2;
    y2 = temp;

    temp = x1;
    x1 = x2;
    x2 = temp;
  }

  if(x1 > x2)
  {
    maxX = x1;
    minX = x2;
  }
  else
  {
    maxX = x2;
    minX = x1;
  }

  if((pointY >= y1 - gap) && (pointY <= y2 + gap) && (pointX >= minX - gap) && (pointX <= maxX + gap))
  {
    lineWidth = abs(x2 - x1);
    lineHeight = abs(y2 - y1);

    if(lineWidth > lineHeight)
    {
      if(x1 < x2)
        lineX = (pointX - x1);
      else
        lineX = (x1 - pointX);

      fract = lineX / (float)lineWidth;
      lineY = y1 + (int)(fract * lineHeight);

      if((pointY >= lineY - gap) && (pointY <= lineY + gap))
        return true;
    }
    else
    {
      lineY = (pointY - y1);
      fract = lineY / (float)lineHeight;
      lineX = x1 + (int)(fract * (x2 - x1));

      if((pointX >= lineX - gap) && (pointX <= lineX + gap))
        return true;
    }
  }
  
  return false;
}

void CStudio::ShowCableMenu(int x, int y, CConnector *connector1, CConnector *connector2)
{
  POINT        point;
  int          id, i;

  point.x = x;
  point.y = y;

  ClientToScreen(Handle, &point);
  id = CableMenu->ShowPopup(point.x, point.y);
  if(id == 1)
  {
    for(i = 0; i < connector1->ConnectionCount; i++)
    {
      if(connector1->Connections[i]->Input == connector2)
      {
        connector1->Disconnect(i);
        Update();
      }
    }

    for(i = 0; i < connector2->ConnectionCount; i++)
    {
      if(connector2->Connections[i]->Input == connector1)
      {
        connector2->Disconnect(i);
        Update();
      }
    }
  }
}

double CStudio::LineAngle(int x1, int y1, int x2, int y2)
{
  double x, y, h;

  x = (double)(x2 - x1);
  y = (double)(y2 - y1);
  h = sqrt((double)((x * x) + (y * y)));
  return(-atan2(x, y));
}

void CStudio::RotatePoint(double angle, int xcentre, int ycentre, int radius, POINT *point)
{
  point->x = (int)((double)xcentre + ((double)radius * cos(angle)));
  point->y = (int)((double)ycentre + ((double)radius * sin(angle)));
}

double CStudio::VolumeKnobPoints(int x1, int y1, int x2, int y2, POINT *p)
{
  double  a, a1;
  int     x, y;

  x = (x1 + x2) / 2;
  y = (y1 + y2) / 2;

  a = a1 = LineAngle(x1, y1, x2, y2);
  a = a + (2.0 * (PI / 4.0));
  RotatePoint(a + ( 0.0 * (PI / 4.0)), x, y, 12, &(p[0]));
  RotatePoint(a + (-2.0 * (PI / 3.0)), x, y, 12, &(p[1]));
  RotatePoint(a + ( 2.0 * (PI / 3.0)), x, y, 12, &(p[2]));

  return a1;
}

void CStudio::DrawVolumeKnob(HDC hDC, int x1, int y1, int x2, int y2)
{
  HGDIOBJ oldPen, oldBrush;
  POINT   p[3];

  VolumeKnobPoints(x1, y1, x2, y2, p);

  ColorManager->Lock();

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)CableBack)->Handle);
  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)CableBack)->Handle);

  Polygon(hDC, p, 3);

  SelectObject(hDC, oldPen);
  SelectObject(hDC, oldBrush);

  ColorManager->Release();

  //SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)CableBorder)->Handle);
  //MoveToEx(hDC, p[0].x, p[0].y, NULL);
  //LineTo(hDC, p[1].x, p[1].y);

  //MoveToEx(hDC, p[1].x, p[1].y, NULL);
  //LineTo(hDC, p[2].x, p[2].y);

  //MoveToEx(hDC, p[2].x, p[2].y, NULL);
  //LineTo(hDC, p[0].x, p[0].y);

  DrawCableBorderLine(hDC, p[0], p[1]);
  DrawCableBorderLine(hDC, p[1], p[2]);
  DrawCableBorderLine(hDC, p[2], p[0]);

}

bool CStudio::PointInRect(int x1, int y1, int x2, int y2, int x, int y)
{
  if(x >= x1 && x <= x2 && y >= y1 && y <= y2)
    return true;
  else
    return false;
}

void CStudio::LineInRect(int rectX1, int rectY1, int rectX2, int rectY2, int lineX1, int lineY1, int lineX2, int lineY2, int *pointX, int *pointY)
{
  int   x, y;
  int   lineWidth, lineHeight;
  float ratio;

  if(PointInRect(rectX1, rectY1, rectX2, rectY2, lineX1, lineY1))
  {
    lineWidth  = (lineX2 - lineX1);
    lineHeight = (lineY2 - lineY1);

    // left edge
    if(lineX2 < rectX1)
    {
      ratio = (float)(lineX1 - rectX1) / (float)(lineWidth);
      y = lineY1 - (int)(ratio * (float)(lineHeight));       
      if(y >= rectY1 && y <= rectY2)
      {
        *pointX = rectX1;
        *pointY = y;
        return;
      }
    }

    // right edge
    if(lineX2 > rectX2)
    {
      ratio = (float)(rectX2 - lineX1) / (float)(lineWidth);
      y = lineY1 + (int)(ratio * (float)(lineHeight));       
      if(y >= rectY1 && y <= rectY2)
      {
        *pointX = rectX2;
        *pointY = y;
        return;
      }
    }

    // top edge
    if(lineY2 < rectY1)
    {
      ratio = (float)(lineY1 - rectY1) / (float)(lineHeight);
      x = lineX1 - (int)(ratio * (float)(lineWidth));       
      if(x >= rectX1 && x <= rectX2)
      {
        *pointY = rectY1;
        *pointX = x;
        return;
      }
    }

    // bottom edge
    if(lineY2 > rectY2)
    {
      ratio = (float)(rectY2 - lineY1) / (float)(lineHeight);
      x = lineX1 + (int)(ratio * (float)(lineWidth));       
      if(x >= rectX1 && x <= rectX2)
      {
        *pointY = rectY2;
        *pointX = x;
        return;
      }
    }

    *pointX = lineX1;
    *pointY = lineY1;
    
  }
  else
  {
    *pointX = lineX1;
    *pointY = lineY1;
  }
}

void CStudio::OnLeftButtonDown(int x, int y)
{
  CMachineContainer *container;
  CPort             *port;
  CConnection       *connection;
  CConnector        *connector;
  int                i, j, kx, ky;

  container = FirstContainer;
  while(container != 0)
  {
    for(i = 0; i < container->ConnectorCount; i++)
    {
      connector = container->Connectors[i];
      port = connector->Port;
      if(port->Type & PT_AUDIO)
        for(j = 0; j < connector->ConnectionCount; j++)
        {
          connection = connector->Connections[j];
          if(PointInVolumeKnob(x, y, connection, &kx, &ky))
          {
            CableVolumeSlider->SetConnection(connection);
            CableVolumeSlider->ShowPopup(kx, ky);
            return;
          }
        }
    }
    container = container->GetNext();
  }
}

bool CStudio::PointInVolumeKnob(int x, int y, CConnection *connection, int *kx, int *ky)
{
  int         x1, y1, x2, y2;
  CConnector *connector1, *connector2;
  POINT       p[3];
  HRGN        region;
  bool        ptInRgn;

  connector1 = connection->Input;
  connector2 = connection->Output;
  ConnectorCentre(connector1, &x1, &y1);
  ConnectorCentre(connector2, &x2, &y2);
  
  AdjustCable(connection, &x1, &y1, &x2, &y2);
  
  VolumeKnobPoints(x1, y1, x2, y2, p);
  region = CreatePolygonRgn(p, 3, ALTERNATE);
  ptInRgn = (PtInRegion(region, x, y) == TRUE);
  DeleteObject(region);
  *kx = (p[0].x + p[1].x + p[2].x) / 3;
  *ky = (p[0].y + p[1].y + p[2].y) / 3;
  return ptInRgn;
}

CCableVolumeSlider::CCableVolumeSlider(CStudio *studio, int x, int y, int width, int height)
: CSlider(studio, x, y, width, height, SLIDER_VERTICAL | SLIDER_BORDER)
{
  Connection = 0;
}

void CCableVolumeSlider::SetConnection(CConnection *connection)
{
  double dB;

  Connection = connection;
  
  if(Connection->PowerRatio == 0.0f)
    dB = -VOLUME_RANGE_DB;
  else
    dB = PowerRatioTodB(Connection->PowerRatio);
  
  if(dB > 0.0)
    dB = 0.0;
  if(dB < -VOLUME_RANGE_DB)
    dB = -VOLUME_RANGE_DB;
  SetValue(1.0 - ((0.0 - dB) / VOLUME_RANGE_DB));
}

void CCableVolumeSlider::OnChange(double newValue)
{
  double dB;
 
  dB = (-1.0 + newValue) * VOLUME_RANGE_DB;
  Connection->PowerRatio = dBToPowerRatio(dB);
  CSlider::OnChange(newValue);
}

void CStudio::BringMachineToFront(CMachineContainer *container)
{
  SetWindowPos(container->Handle, ScrollBox->Handle, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
}

void CStudio::SizeScrollBars()
{
  int                x, y, maxX, maxY, pageSizeX, pageSizeY;
  CMachineContainer *container;
  
  maxX = 0;
  maxY = 0;

  container = FirstContainer;
  while(container != 0)
  {
    x = container->OffsetX + container->Width;
    y = container->OffsetY + container->Height;
    if(x > maxX)
      maxX = x;
    if(y > maxY)
      maxY = y;
    container = container->GetNext();
  }

  pageSizeX = Width - SCROLLBAR_SIZE;
  pageSizeY = Height - SCROLLBAR_SIZE;

  maxX += pageSizeX;
  maxY += pageSizeY;

  maxX = maxX >= pageSizeX ? maxX - pageSizeX : 0;
  maxY = maxY >= pageSizeY ? maxY - pageSizeY : 0;

  if(maxX == 0)
    ScrollBarH->Hide();
  else
    ScrollBarH->Show();

  if(maxY == 0)
    ScrollBarV->Hide();
  else
    ScrollBarV->Show();
  
  if(maxX == 0 || maxY == 0)
    ScrollBox->Hide();
  else
    ScrollBox->Show();

  if((maxX > 0) && (maxY > 0))
  {
    ScrollBarH->Move(0, Height - SCROLLBAR_SIZE, Width - SCROLLBAR_SIZE, SCROLLBAR_SIZE);
    ScrollBarV->Move(Width - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, Height - SCROLLBAR_SIZE);
    ScrollBox->Move(Width - SCROLLBAR_SIZE, Height - SCROLLBAR_SIZE, SCROLLBAR_SIZE, SCROLLBAR_SIZE);
  }
  else
  {
    if(maxX > 0)
      ScrollBarH->Move(0, Height - SCROLLBAR_SIZE, Width, SCROLLBAR_SIZE);
    else if(maxY > 0)
      ScrollBarV->Move(Width - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, Height);
  }

  ScrollBarH->SetMaxPos(maxX);
  ScrollBarH->SetPageSize(pageSizeX);
  ScrollBarV->SetMaxPos(maxY);
  ScrollBarV->SetPageSize(pageSizeY);
}

void CStudio::OnScrollX(int newPos)
{
  CMachineContainer *container;

  OffsetX = newPos;
  container = FirstContainer;
  while(container != 0)
  {
    container->Move(container->OffsetX - OffsetX, container->OffsetY - OffsetY);
    container = container->GetNext();
  }
  Update();
}

void CStudio::OnScrollY(int newPos)
{
  CMachineContainer *container;

  OffsetY = newPos;
  container = FirstContainer;
  while(container != 0)
  {
    container->Move(container->OffsetX - OffsetX, container->OffsetY - OffsetY);
    container = container->GetNext();
  }
  Update();
}

char *CStudio::GenerateMachineName(char *baseName)
{
  int   i, c;
  char *name = 0;

  for(i = 1; ; i++)
  {
    if(name != 0)
      delete name;
    c = (int)strlen(baseName) + 8;
    name = new char[c + 1];
    sprintf(name, "%s %i", baseName, i);
    if(FindMachine(name) == 0)
      return name;
  }
}

CMachineContainer *CStudio::FindMachine(char *name)
{
  CMachineContainer *container;

  container = FirstContainer;
  while(container != 0)
  {
    if(strcmp(name, container->Name) == 0)
      return container;
    else
      container = container->GetNext();
  }
  return 0;
}

void CStudio::SetBlockSamples(int blockSamples)
{
  CMachineContainer *machine;

  PatternEditor->Lock();
  PatternEditor->SetBlockSamples(blockSamples);
  PatternEditor->Release();

  machine = FirstContainer;
  while(machine)
  {
    machine->Lock();
    machine->Machine->ResizeAudioPorts(blockSamples);
    machine->Machine->SetBlockSamples(blockSamples);
    machine->Release();
    machine = machine->GetNext();
  }
}

void CStudio::SetSampleRate(int sampleRate)
{
  CMachineContainer *machine;

  PatternEditor->Lock();
  PatternEditor->SetSampleRate(sampleRate);
  PatternEditor->Release();

  machine = FirstContainer;
  while(machine)
  {
    machine->Lock();
    machine->Machine->SetSampleRate(sampleRate);
	machine->Release();  
	machine = machine->GetNext();
  }
}

int CStudio::GetMachineCount()
{
  int count = 0;
  CMachineContainer *container = FirstContainer;
  while(container)
  {
    count++;
    container = container->GetNext();
  }
  return count;
}

void CStudio::ShowRenameDialog(CMachineContainer *machine)
{
  RenameMachine = machine;
  RenameDialog->SetEditText(machine->Name);
  RenameDialog->Show();
}

void CStudio::OnRenameDialogSuccess()
{
  if(RenameMachine)
  {
    char text[1024];

    RenameDialog->GetEditText(text);
    if(strcmp(RenameMachine->Machine->GetName(), text))
    {
      RenameMachine->Rename(text);
    }
    RenameMachine = 0;

    Core->MainWindow->PatternEditor->Lock();
    Core->MainWindow->PatternEditor->UpdateMachineNames();
    Core->MainWindow->PatternEditor->Release();

    Core->MainWindow->SequenceEditor->Lock();
    Core->MainWindow->SequenceEditor->SequenceView->Update();
    Core->MainWindow->SequenceEditor->Release();
  }
}

