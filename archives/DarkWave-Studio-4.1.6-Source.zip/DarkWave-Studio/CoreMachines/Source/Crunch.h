/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CRUNCH_H
#define	CRUNCH_H

#include "DarkPlug.h"
#include "FrameBuffer.h"
#include "LiteContainer.h"
#include "LiteKnob.h"

struct SCrunchGraphics
{
  CFrameBuffer *Background;
  CFrameBuffer *Knob;
};

class CCrunch;
class CCrunchGUI;

class CCrunchDisplay : public CLiteControl
{
public:
               CCrunchDisplay(CCrunchGUI *crunchGUI, CCrunch *crunch, int x, int y, int width, int height);
              ~CCrunchDisplay();
  virtual void Draw(CFrameBuffer *frameBuffer);
  void         Update();
  void         Render();
  
private:
  CCrunchGUI  *CrunchGUI;
  CCrunch     *Crunch;
  double       *Values;
  int           NumValues;
  CFrameBuffer *RenderBuffer;
};

class CCrunchGUI : public CLiteContainer
{
public:
      CCrunchGUI(HWND parent, CColorManager *colorManager, CCrunch *machine, SCrunchGraphics *graphics);
     ~CCrunchGUI();
 void SetProperty(int index, double value);
 
private:
  SCrunchGraphics  *Graphics;
  CLiteKnob        **Knobs;
  CCrunch          *Crunch;
  CCrunchDisplay *CrunchDisplay;
};

class CCrunch : public CMachine
{
public:
                          CCrunch(CHost *host, SCrunchGraphics *graphics);
  virtual                ~CCrunch();
  virtual void   DARKCALL Work();
  void                    ProcessBlock(int start, int samples);
  void                    ProcessMessage(SControlMessage *message);
  virtual HWND   DARKCALL CreateGUI(HWND parent);
  virtual double DARKCALL GetProperty(int index);
  virtual void   DARKCALL SetProperty(int index, double value);
  virtual void   DARKCALL GetPropertyName(int index, char *text);
  virtual void   DARKCALL GetPropertyValueDisplay(int index, double value, char *text);
  virtual void   DARKCALL SetSampleRate(int sampleRate);
  virtual void   DARKCALL SetBlockSamples(int blockSamples);
  virtual bool   DARKCALL GetGUIRect(short *x1, short *y1, short *x2, short *y2);
  virtual bool   DARKCALL IsSynth();
  double                  Crunch(double in);
  double                  Crunch(double in, double amp, double crunch);

private:
  CHost           *Host;
  SCrunchGraphics *Graphics;
  CCrunchGUI      *GUI;
  double          *Properties;
  int              BlockSamples;
  double           AmpFollow, CrunchFollow, WetFollow, DryFollow;
};

class CCrunchInfo : public CMachineInfo
{
public:
                    CCrunchInfo(CHost *host);
  virtual          ~CCrunchInfo();
  virtual CMachine* DARKCALL CreateMachine();
  
private:
  CHost           *Host;
  SCrunchGraphics  Graphics;
  bool             Loaded;
};

#endif

