#include <CoreFoundation/CoreFoundation.h>
#include <CoreFoundation/CFPlugInCOM.h>
#include <CoreServices/CoreServices.h>
#include "GetMetadataForFile.h"

// -----------------------------------------------------------------------------
#pragma mark constants
// -----------------------------------------------------------------------------

#define PLUGIN_ID "DF098C69-8463-40CD-BD50-A964BBCEFDFE"

//
// Below is the generic glue code for all plug-ins.
//

// -----------------------------------------------------------------------------
#pragma mark typedefs
// -----------------------------------------------------------------------------
			   
//! The layout for an instance of MetadataImporterPlugIn
typedef struct __MetadataImporterPluginType {
	MDImporterInterfaceStruct		*conduitInterface;
	MDImporterURLInterfaceStruct	*extraInterface;
	CFUUIDRef						factoryID;
	UInt32							refCount;
} MDImportPlug;

// -----------------------------------------------------------------------------
#pragma mark prototypes
// -----------------------------------------------------------------------------
//	Forward declaration for the IUnknown implementation.
//

static MDImportPlug	*AllocMetadataImporterPluginType(CFUUIDRef inFactoryID);
static void			DeallocMetadataImporterPluginType(MDImportPlug *thisInstance);
static HRESULT		MetadataImporterQueryInterface(void *thisInstance,REFIID iid,LPVOID *ppv);
extern void			*PPMetadataImporterPluginFactory(CFAllocatorRef allocator,CFUUIDRef typeID) __attribute__((visibility ("default")));
static ULONG		MetadataImporterPluginAddRef(void *thisInstance);
static ULONG		MetadataImporterPluginRelease(void *thisInstance);
static Boolean GetMetadataForFile(void* thisInterface, CFMutableDictionaryRef attributes, CFStringRef contentTypeUTI, CFStringRef pathToFile);

//! The TestInterface function table.
static MDImporterInterfaceStruct testInterfaceFtbl = {
	NULL,
	MetadataImporterQueryInterface,
	MetadataImporterPluginAddRef,
	MetadataImporterPluginRelease,
	GetMetadataForFile
};

//! The TestInterfaceURL function table.
static MDImporterURLInterfaceStruct testInterfaceURLFtbl = {
	NULL,
	MetadataImporterQueryInterface,
	MetadataImporterPluginAddRef,
	MetadataImporterPluginRelease,
	GetMetadataForURL
};

#pragma mark -

//! Utility function that allocates a new instance.
//!
//! You can do some initial setup for the importer here if you wish
//! like allocating globals etc...
static MDImportPlug *AllocMetadataImporterPluginType(CFUUIDRef inFactoryID)
{
	MDImportPlug *theNewInstance = (MDImportPlug *)calloc(sizeof(MDImportPlug), 1);
	
	/* Point to the function table */
	theNewInstance->conduitInterface = &testInterfaceFtbl;
	theNewInstance->extraInterface = &testInterfaceURLFtbl;
	
	/*  Retain and keep an open instance refcount for each factory. */
	theNewInstance->factoryID = CFRetain(inFactoryID);
	CFPlugInAddInstanceForFactory(inFactoryID);
	
	/* This function returns the IUnknown interface so set the refCount to one. */
	theNewInstance->refCount = 1;
	return theNewInstance;
}

//! Utility function that deallocates the instance when
//! the `refCount` goes to zero.
//!
//! In the current implementation importer interfaces are never deallocated
//! but implement this as this might change in the future
static void DeallocMetadataImporterPluginType(MDImportPlug *thisInstance)
{
	CFUUIDRef theFactoryID = thisInstance->factoryID;
	
	free(thisInstance);
	if (theFactoryID) {
		CFPlugInRemoveInstanceForFactory(theFactoryID);
		CFRelease(theFactoryID);
	}
}

//! Implementation of the `IUnknown` `QueryInterface` function.
static HRESULT MetadataImporterQueryInterface(void *thisInstance, REFIID iid, LPVOID *ppv)
{
	CFUUIDRef interfaceID = CFUUIDCreateFromUUIDBytes(kCFAllocatorDefault, iid);
	// First, make sure we get the proper pointer.
	// Overkill maybe, but just to be safe...
	if (((MDImportPlug*)thisInstance)->conduitInterface->ImporterImportData != GetMetadataForFile) {
		thisInstance = ((char *)thisInstance - offsetof(MDImportPlug, extraInterface));
	}
	
	if (CFEqual(interfaceID, kMDImporterInterfaceID)) {
		/* If the right interface was requested, bump the ref count,
		 * set the ppv parameter equal to the instance, and
		 * return good status.
		 */
		((MDImportPlug*)thisInstance)->conduitInterface->AddRef(thisInstance);
		*ppv = thisInstance;
		CFRelease(interfaceID);
		return S_OK;
	} else if (CFEqual(interfaceID, kMDImporterURLInterfaceID)) {
		/* If the other interface was requested, bump the ref count,
		 * set the ppv parameter equal to the other interface, and
		 * return good status.
		 */
		((MDImportPlug*)thisInstance)->conduitInterface->AddRef(thisInstance);
		*ppv = ((MDImportPlug*)thisInstance)->extraInterface;
		CFRelease(interfaceID);
		return S_OK;
	} else if (CFEqual(interfaceID, IUnknownUUID)) {
		/* If the IUnknown interface was requested, same as above. */
		((MDImportPlug*)thisInstance)->conduitInterface->AddRef(thisInstance);
		*ppv = thisInstance;
		CFRelease(interfaceID);
		return S_OK;
	} else {
		/* Requested interface unknown, bail with error. */
		*ppv = NULL;
		CFRelease(interfaceID);
		return E_NOINTERFACE;
	}
}

//! Implementation of reference counting for this type. Whenever an interface
//! is requested, bump the `refCount` for the instance. NOTE: returning the
//! `refcount` is a convention but is not required so don't rely on it.
static ULONG MetadataImporterPluginAddRef(void *thisInstance)
{
	// First, make sure we get the proper pointer.
	// Overkill maybe, but just to be safe...
	if (((MDImportPlug*)thisInstance)->conduitInterface->ImporterImportData != GetMetadataForFile) {
		thisInstance = ((char *)thisInstance - offsetof(MDImportPlug, extraInterface));
	}
	return ++((MDImportPlug*)thisInstance)->refCount;
}

//! When an interface is released, decrement the `refCount`.
//! If the `refCount` goes to zero, deallocate the instance.
static ULONG MetadataImporterPluginRelease(void *thisInstance)
{
	// First, make sure we get the proper pointer.
	// Overkill maybe, but just to be safe...
	if (((MDImportPlug*)thisInstance)->conduitInterface->ImporterImportData != GetMetadataForFile) {
		thisInstance = ((char *)thisInstance - offsetof(MDImportPlug, extraInterface));
	}
	((MDImportPlug*)thisInstance)->refCount -= 1;
	if (((MDImportPlug*)thisInstance)->refCount == 0) {
		DeallocMetadataImporterPluginType((MDImportPlug*)thisInstance);
		return 0;
	} else {
		return ((MDImportPlug*)thisInstance)->refCount;
	}
}

//! Simple function that converts a POSIX path to a CFURL and call `GetMetadataForURL`.
static Boolean GetMetadataForFile(void* thisInterface, CFMutableDictionaryRef attributes, CFStringRef contentTypeUTI, CFStringRef pathToFile)
{
	Boolean isGood = FALSE;
	CFURLRef theURL = CFURLCreateWithFileSystemPath(kCFAllocatorDefault, pathToFile, kCFURLPOSIXPathStyle, false);
	if (theURL) {
		isGood = GetMetadataForURL(thisInterface, attributes, contentTypeUTI, theURL);
		CFRelease(theURL);
	}
	return isGood;
}


//! Implementation of the factory function for this type.
void *PPMetadataImporterPluginFactory(CFAllocatorRef allocator, CFUUIDRef typeID)
{
	MDImportPlug	*result;
	CFUUIDRef		uuid;
	
	/* If correct type is being requested, allocate an
	 * instance of TestType and return the IUnknown interface.
	 */
	
	if (CFEqual(typeID, kMDImporterTypeID)) {
		uuid = CFUUIDCreateFromString(kCFAllocatorDefault, CFSTR(PLUGIN_ID));
		result = AllocMetadataImporterPluginType(uuid);
		CFRelease(uuid);
		return result;
	}
	/* If the requested type is incorrect, return NULL. */
	return NULL;
}
