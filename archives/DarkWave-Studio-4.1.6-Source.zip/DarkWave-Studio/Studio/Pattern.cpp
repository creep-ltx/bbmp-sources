/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Pattern.h"
#include "Util.h"
#include "Core.h"



CPattern::CPattern(int length, char *name, CConnector *port)
{
  Index          = 0;
  Length         = length;
  Name           = CopyString(name);
  Port           = port;
  FirstNote      = 0;
  Sample         = 0;
  Sample2        = -1;
  Loop           = false;
  Playing        = false;
  ControlTracks  = new CArray<CControlTrack*>();
  VelocityTrack  = 0;
  SampleRate     = Core->Host->GetSampleRate();
  BlockSamples   = Core->Host->GetBlockSamples();
  BPM            = Core->Host->GetBPM();
}

void CPattern::CopyPattern(CPattern *originalPattern)
{
  int    i, j;
  CNote *note;

  // Copy Notes

  note = originalPattern->FirstNote;
  while(note != 0)
  {
    AddNote(note->Start, note->Length, note->Note);
    note = note->GetNext();
  }

  // Copy Control Tracks

  for(i = 0; i < originalPattern->ControlTracks->Count; i++)
  {
    CControlTrack *oldTrack, *newTrack;

    oldTrack = originalPattern->ControlTracks->Items[i];
    newTrack = ControlTracks->Items[AddControlTrack(oldTrack->Property)];
    
    for(j = 0; j < oldTrack->Entries->Count; j++)
    {
      SControlEntry *oldEntry, *newEntry;

      oldEntry = oldTrack->Entries->Items[j];
      newEntry = newTrack->Entries->Items[j];
      memcpy(newEntry, oldEntry, sizeof(SControlEntry));
    }
  }
}

CPattern::~CPattern()
{
  CNote *note;
  int    i;

  Stop(true);

  while(FirstNote != 0)
  {
    note = FirstNote;
    note->Detach();
    delete note;
  }

  for(i = 0; i < ControlTracks->Count; i++)
    delete ControlTracks->Items[i];
  ControlTracks->Clear();

  delete Name;
}

CNote* CPattern::AddNote(int start, int length, int note)
{
  CNote         *cnote;
  SControlEntry *entry;

  cnote = new CNote(start, length, note);
  cnote->Attach(&FirstNote);

  if(VelocityTrack != 0)
  {
    entry = VelocityTrack->Entries->Items[start];
    if(!entry->Used)
    {
      entry->Used  = true;
      entry->Value = DEFAULT_VELOCITY;
    }
  }

  return cnote;
}

void CPattern::RemoveNote(CNote *note)
{
  CNote         *cnote;
  SControlEntry *entry;
  int            start;

  start = note->Start;
  note->Detach();
  delete note;

  if(VelocityTrack != 0)
  {
    cnote = FirstNote;
    while(cnote != 0)
      if(cnote->Start == start)
        return;
      else
        cnote = cnote->GetNext();

    entry = VelocityTrack->Entries->Items[start];
    if(entry->Used)
    {
      entry->Used  = false;
      entry->Value = 0.0f;
    }
  }
}

void CPattern::Stop(bool reset)
{
  if(Playing)
    Stopping = true;

  if(reset)
    Sample = 0;
}

void CPattern::Play(bool reset)
{
  Stop(reset);
  Playing = true;
  Stopping = false;
}

void CPattern::Play(bool reset, int sample)
{
  Stop(reset);
  Sample = sample;
  Playing = true;
  Stopping = false;
}

void CPattern::SetLoop(bool value)
{
  Loop = value;
}

void CPattern::SetSample2(int sample)
{
  Sample2 = sample;
}

void CPattern::Work()
{
  int              maxSample;
  double           bpm, samplesPerTick;

  Port->Container->Lock();
  BPM            = Core->Host->GetBPM();
  bpm            = BPM;
  BlockSamples   = Core->Host->GetBlockSamples();
  SampleRate     = Core->Host->GetSampleRate();
  samplesPerTick  = Core->Host->GetSamplesPerTick();
  maxSample      = (int)((double)Length * 4.0 * samplesPerTick);

  if(maxSample)
    Sample = Sample % maxSample;

  if(!Stopping)
  {
    if(Sample + BlockSamples >= maxSample)
    {
      ProcessBlock(0, Sample, maxSample - Sample, samplesPerTick);
      if(Loop)
      {
        if(Sample + BlockSamples > maxSample)
          ProcessBlock(maxSample - Sample, 0, (Sample + BlockSamples) % maxSample, samplesPerTick);
        Sample = (Sample + BlockSamples) % maxSample;
      }
      else
      {
        Playing = false;
        Sample = 0;
      }
    }
    else
    {
      ProcessBlock(0, Sample, BlockSamples, samplesPerTick);
      Sample = (Sample + BlockSamples) % maxSample;
    }
  }

  Port->Container->Release();
}

void CPattern::ProcessBlock(int offset, int startSample, int samples, double samplesPerTick)
{
  CControlBuffer  *buffer;
  SControlMessage  m;
  int              sample, pos, track;
  CNote           *note;
  SControlEntry   *entry;
  bool             voiceMode;
  double           velocity;

  voiceMode = Port->Container->Machine->VoiceCount > 0 ? true : false;
  buffer    = Port->Port->ControlBuffer;

  for(pos = 0; pos < (Length * 4); pos++)
  {
    sample = (int)((double)pos * samplesPerTick);
    if(sample >= startSample && sample < startSample + samples)
    {
      for(track = 0; track < ControlTracks->Count; track++)
      {
        if(ControlTracks->Items[track]->Property != PROPERTY_VELOCITY)
        {
          entry = ControlTracks->Items[track]->Entries->Items[pos];
          if(entry->Used)
          {
            m.BlockSample = offset + sample - startSample;
            m.Size = sizeof(m);
            m.Type = CONTROL_MESSAGE_CONTROL_CHANGE;
            m.ControlChange.Controller = ControlTracks->Items[track]->Property;
            m.ControlChange.Value = entry->Value;
            buffer->Write(&m);
          }
        }
      }
    }
  }

  note = FirstNote;
  while(note != 0)
  {
    sample = (int)((double)(note->Start) * samplesPerTick);
    if(sample >= startSample && sample < startSample + samples)
    {
      m.BlockSample = offset + sample - startSample;
      m.Size = sizeof(m);

      if(VelocityTrack != 0)
        velocity = VelocityTrack->Entries->Items[note->Start]->Value;
      else
        velocity = DEFAULT_VELOCITY;

      if(voiceMode)
      {
        m.Type = CONTROL_MESSAGE_VOICE_ON;
        m.VoiceOn.Voice = note->Note;
        m.VoiceOn.Velocity = velocity;
      }
      else
      {
        m.Type = CONTROL_MESSAGE_NOTE_ON;
        m.NoteOn.Note = note->Note;
        Core->Host->GetNoteFrequency(m.NoteOn.Note, &m.NoteOn.Frequency);
        m.NoteOn.Velocity = velocity;
      }

      buffer->Write(&m);

      sample = (int)((double)(note->Start + note->Length) * samplesPerTick);
      m.BlockSample = (offset + sample - startSample) - 1;
      m.Size = sizeof(m);

      if(voiceMode)
      {
        m.Type = CONTROL_MESSAGE_VOICE_OFF;
        m.VoiceOff.Voice = note->Note;
      }
      else
      {
        m.Type = CONTROL_MESSAGE_NOTE_OFF;
        m.NoteOff.Note = note->Note;
      }
      
      if(m.BlockSample >= BlockSamples)
      {
        Port->Future->Write(&m);
      }
      else
        buffer->Write(&m);
    }
    note = note->GetNext();
  }
}

double CPattern::GetPlayPos()
{
  if((!Playing || Stopping))
    return -1.0;

  return (double)Sample / Core->Host->GetSamplesPerTick();;
}

double CPattern::GetPlayPos2()
{
  if(Sample2 == -1)
    return -1.0;
  else
    return (double)Sample2 / Core->Host->GetSamplesPerTick();;
}

int CPattern::AddControlTrack(int parameter)
{
  CControlTrack *controlTrack;

  controlTrack = new CControlTrack(parameter, Length * 4);
  ControlTracks->AddItem(controlTrack);
  if(parameter == PROPERTY_VELOCITY)
    VelocityTrack = controlTrack;
  return ControlTracks->Count - 1;
}

void CPattern::RemoveControlTrack(int index)
{
  if(ControlTracks->Items[index]->Property == PROPERTY_VELOCITY)
    VelocityTrack = 0;
  delete ControlTracks->Items[index];
  ControlTracks->RemoveItem(index);
}

void CPattern::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

void CPattern::SetSampleRate(int sampleRate)
{
  SampleRate = sampleRate;
}

int CPattern::GetNoteCount()
{
  int noteCount = 0;
  CNote *note;

  note = FirstNote;
  while(note)
  {
    noteCount++;
    note = note->GetNext();
  }

  return noteCount;
}

void CPattern::Resize(int newLength)
{
  int i;

  if(newLength == Length)
    return;

  for(i = 0; i < ControlTracks->Count; i++)
    ControlTracks->Items[i]->Resize(newLength * 4);

  if(newLength > Length)
  {
    Length = newLength;
    return;
  }
  else
  {
    CNote *note, *next;

    note = FirstNote;
    while(note)
    {
      next = note->GetNext();

      if((note->Start + note->Length) > (newLength * 4))
        RemoveNote(note);

      note = next;
    }
    Length = newLength;
  }
}

bool CPattern::Transpose(int amount)
{
  int minNote, maxNote, voiceCount, notes, newNote;
  CNote *note;

  voiceCount = Port->Container->Machine->VoiceCount;

  minNote = 0;
  
  if(voiceCount > 0)
  {
    maxNote = voiceCount - 1;
    notes = -amount;
  }
  else
  {
    maxNote = MAX_NOTE;
    notes = amount;
  }

  note = FirstNote;
  while(note != 0)
  {
    newNote = note->Note + notes;
    if((newNote < minNote) || (newNote > maxNote))
      return false;
    note = note->GetNext();
  }

  note = FirstNote;
  while(note != 0)
  {
    newNote = note->Note + notes;
    note->Note = newNote;
    note = note->GetNext();
  }

  return true;
}

void CPattern::SendNoteOn(int note)
{
  SControlMessage message;
  bool voiceMode;
  
  Port->Container->Lock();
  
  memset(&message, 0, sizeof(message));
  message.Size = sizeof(message);
  
  voiceMode = Port->Container->Machine->VoiceCount > 0 ? true : false;
  
  if(voiceMode)
  {
    message.Type = CONTROL_MESSAGE_VOICE_ON;
    message.VoiceOn.Voice = note;
    message.VoiceOn.Velocity = DEFAULT_VELOCITY;
  }
  else
  {
    message.Type = CONTROL_MESSAGE_NOTE_ON;
    message.NoteOn.Note = note;
    message.NoteOn.Velocity = DEFAULT_VELOCITY;
    Core->Host->GetNoteFrequency(note, &message.NoteOn.Frequency);
  }
 
  Port->Future->Write(&message);
  
  Port->Container->Release();
}

void CPattern::SendNoteOff(int note)
{
  SControlMessage message;
  bool voiceMode;
 
  Port->Container->Lock();
  
  voiceMode = Port->Container->Machine->VoiceCount > 0 ? true : false;
  
  memset(&message, 0, sizeof(message));
  message.Size = sizeof(message);
  message.BlockSample = BlockSamples;
  
  if(voiceMode)
  {
    message.Type = CONTROL_MESSAGE_VOICE_OFF;
    message.VoiceOff.Voice = note;
  }
  else
  {
    message.Type = CONTROL_MESSAGE_NOTE_OFF;  
    message.NoteOff.Note = note;
  }

  Port->Future->Write(&message);
  
  Port->Container->Release();
}