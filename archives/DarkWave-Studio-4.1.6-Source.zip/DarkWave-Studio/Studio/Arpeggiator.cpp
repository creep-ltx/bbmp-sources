/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "Arpeggiator.h"
#include "Core.h"
#include "../Resource.h"

#define GUI_WIDTH  304
#define GUI_HEIGHT 200

#define TOOLBAR_X      0
#define TOOLBAR_Y      0
#define TOOLBAR_WIDTH  GUI_WIDTH
#define TOOLBAR_HEIGHT 30

#define LABEL_HEIGHT   14
#define UPDOWN_HEIGHT  18

#define TPB_LABEL_WIDTH     32
#define LENGTH_LABEL_WIDTH  56

#define TPB_UPDOWN_WIDTH    40
#define LENGTH_UPDOWN_WIDTH 40

#define GRID_X       32
#define GRID_Y       88
#define GRID_WIDTH   256
#define GRID_HEIGHT  96
#define CELL_WIDTH   8
#define CELL_HEIGHT  8

CArpeggiatorGrid::CArpeggiatorGrid(CArpeggiatorGUI *parent, CArpeggiator *arpeggiator, int x, int y, int width, int height)
: CLiteControl(parent, x, y, width, height)
{
  Arpeggiator = arpeggiator;
  Drawing = false;
}

CArpeggiatorGrid::~CArpeggiatorGrid()
{
}

void CArpeggiatorGrid::Draw(CFrameBuffer *frameBuffer)
{
  int x, y, row, col, length;
 
  length = Arpeggiator->GetLength();

  y = Y;
  for(row = 0; row < GRID_ROWS; row++)
  {
    x = X;
    for(col = 0; col < GRID_COLS; col++)
    {
      if(col >= length)
      {
        frameBuffer->FillRect(x, y, CELL_WIDTH, CELL_HEIGHT, RGB(0x00, 0x44, 0x61), 0xFF);
      }
      else
      {  
        if((col % 8) < 4)
          frameBuffer->FillRect(x, y, CELL_WIDTH, CELL_HEIGHT, RGB(0x00, 0x80, 0xA5), 0xFF);
        else
          frameBuffer->FillRect(x, y, CELL_WIDTH, CELL_HEIGHT, RGB(0x00, 0x90, 0xB5), 0xFF);

        if(Arpeggiator->GetCell(row, col))
          frameBuffer->FillRect(x, y, CELL_WIDTH - 1, CELL_HEIGHT - 1, RGB(0x00, 0xC6, 0xFF), 0xFF);
        else
          if((col % 8) < 4)
            frameBuffer->FillRect(x, y, CELL_WIDTH - 1, CELL_HEIGHT - 1, RGB(0x00, 0x64, 0x81), 0xFF);
          else
            frameBuffer->FillRect(x, y, CELL_WIDTH - 1, CELL_HEIGHT - 1, RGB(0x00, 0x74, 0x91), 0xFF);
      }
      x += CELL_WIDTH;
    }
    y += CELL_HEIGHT;
  }
}

void CArpeggiatorGrid::OnLeftButtonDown(int x, int y)
{
  int row, col;

  row = RowAt(y - Y);
  col = ColAt(x - X);

  if((row != -1) && (col != -1))
  {
    Drawing = true;
    DrawValue = !Arpeggiator->GetCell(row, col);
    Arpeggiator->SetCell(row, col, DrawValue);
    Parent->Render(X + (col * CELL_WIDTH), Y + (row * CELL_HEIGHT), CELL_WIDTH, CELL_HEIGHT);
    SetCapture();
  }
}

void CArpeggiatorGrid::OnMouseMove(int x, int y)
{
  int row, col;

  if(Drawing)
  {
    row = RowAt(y - Y);
    col = ColAt(x - X);

    if((row != -1) && (col != -1))
    {
      if(DrawValue != Arpeggiator->GetCell(row, col))
      {
        Arpeggiator->SetCell(row, col, DrawValue);
        Parent->Render(X + (col * CELL_WIDTH), Y + (row * CELL_HEIGHT), CELL_WIDTH, CELL_HEIGHT);
      }
    }
  }
}

void CArpeggiatorGrid::OnLeftButtonUp(int x, int y)
{
  Drawing = false;
  ReleaseCapture();
}


int CArpeggiatorGrid::RowAt(int y)
{
  if((y >= 0) && (y < Height))
    return y / CELL_HEIGHT;
  else
    return -1;
}

int CArpeggiatorGrid::ColAt(int x)
{
  if((x >= 0) && (x < Width))
    return x / CELL_WIDTH;
  else
    return -1; 
}

CArpeggiatorGUI::CArpeggiatorGUI(HWND parent, CArpeggiator *arpeggiator, SArpeggiatorGraphics *graphics)
: CLiteContainer(parent, GUI_WIDTH, GUI_HEIGHT, graphics->Background)
{
  ColorManager = Core->ColorManager;
  Arpeggiator = arpeggiator;

  ToolBar = new CToolBar(this, TOOLBAR_X, TOOLBAR_Y, TOOLBAR_WIDTH, TOOLBAR_HEIGHT);
  
  TPBLabel = new CLabel(ToolBar, "TPB:", 0, 0, TPB_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  ToolBar->AddControl(TPBLabel, 0);

  TPBUpDown = new CUpDown(ToolBar, 0, 0, TPB_UPDOWN_WIDTH, UPDOWN_HEIGHT, 1.0, 16.0, 1.0, arpeggiator->GetTPB(), false);
  ToolBar->AddControl(TPBUpDown, 0);

  LengthLabel = new CLabel(ToolBar, "Length:", 0, 0, LENGTH_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  ToolBar->AddControl(LengthLabel, 0);

  LengthUpDown = new CUpDown(ToolBar, 0, 0, LENGTH_UPDOWN_WIDTH, UPDOWN_HEIGHT, 1.0, 32.0, 1.0, arpeggiator->GetLength(), false);
  ToolBar->AddControl(LengthUpDown, 0);
  
  ToolBar->Show();

  Grid = new CArpeggiatorGrid(this, arpeggiator, GRID_X, GRID_Y, GRID_WIDTH, GRID_HEIGHT);
  Grid->Show();
}

CArpeggiatorGUI::~CArpeggiatorGUI()
{
  delete Grid;
  delete TPBLabel;
  delete TPBUpDown;
  delete LengthLabel;
  delete LengthUpDown;
  delete ToolBar;
}

void CArpeggiatorGUI::OnUpDownChange(CUpDown *upDown)
{
  if(upDown == TPBUpDown)
  {
    Arpeggiator->SetTPB((int)upDown->GetValue());
  }
  if(upDown == LengthUpDown)
  {
    Arpeggiator->SetLength((int)upDown->GetValue());
    Render(GRID_X, GRID_Y, GRID_WIDTH, GRID_HEIGHT);
  }
}

CArpeggiator::CArpeggiator(CHost *host, SArpeggiatorGraphics *graphics)
: CMachine(host)
{
  SampleRate = host->GetSampleRate();
  BlockSamples = host->GetBlockSamples();

  TickSamples = 0;
  
  Trigger  = false;
  BaseNote = 0;

  Host = host;
  GUI = 0;
  Graphics = graphics;

  TPB = 4;
  Length = 32;

  ClearCells();

  Ports = new CPort*[2];
  Ports[0] = new CPort(Core->Host, this, PT_CONTROL | PT_INPUT,  "Control In");
  Ports[1] = new CPort(Core->Host, this, PT_CONTROL | PT_OUTPUT, "Control Out");
  PortCount = 2;

  FutureBuffer = new CControlBuffer();
}

CArpeggiator::~CArpeggiator()
{
  if(GUI)
  {
    delete GUI;
    GUI = 0;
  }

  delete Ports[0];
  delete Ports[1];
  delete Ports;

  Ports = 0;
  PortCount = 0;

  delete FutureBuffer;
  FutureBuffer = 0;
}

struct SArpeggiatorProperties
{
  int  TPB;
  int  Length;
  bool Cell[GRID_ROWS][GRID_COLS];
};

void DARKCALL CArpeggiator::ReadProperties(char *data, int length, bool isInner)
{
  if(length == sizeof(SArpeggiatorProperties))
  {
    SArpeggiatorProperties *properties;

    properties = (SArpeggiatorProperties*)data;
    TPB = properties->TPB;
    Length = properties->Length;
    memcpy(Cell, properties->Cell, sizeof(Cell));
  }
}

void DARKCALL CArpeggiator::WriteProperties(char **data, int *length, bool *isInner)
{
  SArpeggiatorProperties *properties;
  
  properties = new SArpeggiatorProperties;
  properties->TPB = TPB;
  properties->Length = Length;
  memcpy(properties->Cell, Cell, sizeof(Cell));
  *data = (char*)properties;
  *length = sizeof(SArpeggiatorProperties);
  *isInner = false;
}

void CArpeggiator::Work()
{
  SControlMessage message;
  bool messageRead;
  int  sample, nextSample;
  CControlBuffer *tempBuffer;

  tempBuffer = new CControlBuffer();

  messageRead = FutureBuffer->Read(&message);
  while(messageRead)
  {
    if(message.BlockSample < BlockSamples)
      Ports[1]->ControlBuffer->Write(&message);
    else
    {
      message.BlockSample -= BlockSamples;
      tempBuffer->Write(&message);
    }
    messageRead = FutureBuffer->Read(&message);
  }

  tempBuffer->CopyTo(FutureBuffer);
  tempBuffer->Clear();
  delete tempBuffer;
  tempBuffer = 0;

  sample = 0;

  messageRead = Ports[0]->ControlBuffer->Read(&message);
  while(messageRead)
  {
    nextSample = message.BlockSample;
    if(nextSample > sample)
    {
      GenerateBlock(sample, nextSample - sample);
      sample = nextSample;
    }
    ProcessMessage(&message);

    messageRead = Ports[0]->ControlBuffer->Read(&message);
  }
  if(sample < BlockSamples)
    GenerateBlock(sample, BlockSamples - sample);
}

void CArpeggiator::ProcessMessage(SControlMessage *message)
{
  switch(message->Type)
  {
    case CONTROL_MESSAGE_NOTE_ON:
    {
      Trigger     = true;
      BaseNote    = message->NoteOn.Note;
      Tick        = 0;
      TickSamples = 0;
      break;
    }
    case CONTROL_MESSAGE_NOTE_OFF:
    {
      if(message->NoteOff.Note == BaseNote)
      {
        Trigger     = false;
        BaseNote    = 0;
        Tick        = 0;
        TickSamples = 0;
      }
      break;
    }
  }
}

#define DEFAULT_VELOCITY ((1.0 / 127.0) * 100.0)

void CArpeggiator::GenerateBlock(int sample, int samples)
{
  int samplesPerTick;

  if(Trigger)
  {
    samplesPerTick = SamplesPerTick();

    while(TickSamples < samples)
    {
      int row, note;

      for(row = 0; row < GRID_ROWS; row++)
      {
        if(GetCell(row, Tick))
        {
          SControlMessage message;

          note = (BaseNote + GRID_ROWS - (row + 1)); 

          memset(&message, 0, sizeof(message));

          message.Size            = sizeof(message);
          message.BlockSample     = sample;
          message.Type            = CONTROL_MESSAGE_NOTE_ON;
          message.NoteOn.Note     = note;
          message.NoteOn.Velocity = DEFAULT_VELOCITY;
          Core->Host->GetNoteFrequency(message.NoteOn.Note, &message.NoteOn.Frequency);

          Ports[1]->ControlBuffer->Write(&message);

          memset(&message, 0, sizeof(message));

          message.Size            = sizeof(message);
          message.BlockSample     = sample + samplesPerTick - 1;
          message.Type            = CONTROL_MESSAGE_NOTE_OFF;
          message.NoteOff.Note    = note;


          if(message.BlockSample < BlockSamples)
            Ports[1]->ControlBuffer->Write(&message);
          else
          {
            //message.BlockSample -= BlockSamples;
            FutureBuffer->Write(&message);
          }
        }
      }

      TickSamples = samplesPerTick;

      if(samples <= TickSamples)
      {
        sample  = samples - 1;
        samples = 0;
      }
      else
      {
        sample  += TickSamples;
        samples -= TickSamples;
      }

      Tick = (Tick + 1) % Length;
    }
  }
  
  if(TickSamples > samples)
    TickSamples -= samples;
  else
    TickSamples = 0;
}

int CArpeggiator::SamplesPerTick()
{
  return (int)((60.0 / ((double)Core->Host->GetBPM() * (double)TPB)) * (double)SampleRate);
}

void CArpeggiator::SetSampleRate(int sampleRate)
{
  SampleRate = sampleRate;
}

void CArpeggiator::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

bool CArpeggiator::IsSynth()
{
  return false;
}

HWND CArpeggiator::CreateGUI(HWND parent)
{
  if(GUI)
    return GUI->Handle;
  else
  {
    GUI = new CArpeggiatorGUI(parent, this, Graphics);
    return GUI->Handle;
  }
}

int CArpeggiator::GetTPB()
{
  return TPB;
}

int CArpeggiator::GetLength()
{
  return Length;
}

void CArpeggiator::SetTPB(int newTPB)
{
  if(newTPB != TPB)
  {
    TPB = newTPB;
  }
}

void CArpeggiator::SetLength(int newLength)
{
  if(newLength != Length)
  {
    Length = newLength;
  }
}

void CArpeggiator::ClearCells()
{
  int row, col;

  for(row = 0; row < GRID_ROWS; row++)
    for(col = 0; col < GRID_COLS; col++)
      SetCell(row, col, false);
}

bool CArpeggiator::GetCell(int row, int col)
{
  return Cell[row][col];
}

void CArpeggiator::SetCell(int row, int col, bool v)
{
  Cell[row][col] = v;
}


CArpeggiatorInfo::CArpeggiatorInfo()
{
  Name     = "ES Arpeggiator";
  UniqueID = "DarkPlug::ES Arpeggiator";
  Graphics = new SArpeggiatorGraphics;
  Graphics->Background = new CFrameBuffer(IDR_ARPEGGIATOR_BACKGROUND);
}

CMachine *CArpeggiatorInfo::CreateMachine()
{
  return new CArpeggiator(Core->Host, Graphics);
}

CArpeggiatorInfo::~CArpeggiatorInfo()
{
  if(Graphics != 0)
  {
    if(Graphics->Background != 0)
    {
      delete Graphics->Background;
      Graphics->Background = 0;
    }
    delete Graphics;
    Graphics = 0;
  }
} 