# Experimental OpenMPT SKM loader

An independent, experimental loader for Skale Tracker `.skm` modules, written
against OpenMPT's shared `soundlib` engine.

## Please read this first

**This is not an OpenMPT contribution and cannot become one unless a policy
exception is made.** OpenMPT's
[contribution policy](https://github.com/OpenMPT/openmpt/blob/master/doc/contributing.md)
states:

> We will not accept any contribution fully or partially developed by or
> assisted by the use of LLMs or other forms of AI.

This loader was developed with AI assistance. It is therefore ineligible
upstream, and **no code from this repository should be copied into OpenMPT
without approval from OpenMPT maintainers.**

It is published anyway because the format research behind it is independently
useful as a reference. The format was derived solely by observing data files
and by driving Skale's own GUI.

The current `.skm` format understanding, along with redistributable test
files, lives here: <https://github.com/lpreiner/skale-skm-format>. This
repository contains only the player-specific integration.

## Current scope

This experimental loader covers:

- the ALIM3 container and metadata
- order lists and channel-major pattern decoding
- notes, instruments, plain volume, and the verified XM-compatible effect range
- PCM8, PCM16, and embedded Ogg Vorbis samples
- sample loops, keymaps, primary envelopes, panning, and gain state
- Skale 0.70, 0.71, 0.75, and the 0.76 format family (versions up to 0.81)

A note on versions: the header stamps a *format* version, not an application
version. Every test file carries 7000, 7100, 7500, or 7600, and Skale 0.77
through 0.81 all write 7600 — so "0.76 support" covers the last several
Skale releases. The loader reports this as `Skale Tracker (format v0.76)` rather
than claiming to know which application version wrote the file.

Not covered:

- Section 4 (VST/FX chain). The OpenMPT application can host compatible VST
  plugins, but this loader does not translate Skale's plugin paths, saved plugin
  state, VSTi assignments, or mixer graph into OpenMPT plugin slots. libopenmpt
  does not host arbitrary VST DLLs at all, though it supports a narrower set of
  built-in and platform-specific DSP plugins.
- Section 5 beyond master volume (SUB1-4 bus routing and the FX-bus send matrix
  have no direct equivalent in soundlib's module graph).
- Section 6 (VSTi state and Skale-owned synth routing).
- Skale-native effects `0x10..0x13`.
- Three 0.76-family instrument records in the corpus whose 716/784-byte prefixes
  use a keymap encoding that has not been established; they fall back to their
  first playable sample.

## Trying it locally

Copy `Load_skm.cpp` into an OpenMPT checkout as `soundlib/Load_skm.cpp`, then:

1. Declare `ProbeFileHeaderSKM` and `ReadSKM` in `soundlib/Sndfile.h`.
2. Add `MPT_DECLARE_FORMAT(SKM)` to `ModuleFormatLoaders` in
   `soundlib/Sndfile.cpp`.
3. Add a `{ UL_("Skale Tracker"), "skm" }` entry to `modFormatInfo[]` in
   `soundlib/Tables.cpp`, in extension order.
4. Add the loader to the two build files that carry explicit source lists.
   They use different syntax:
   - `build/autotools/Makefile.am` —
     `MPT_FILES_SOUNDLIB += soundlib/Load_skm.cpp`
   - `build/android_ndk/Android.mk` — a `	soundlib/Load_skm.cpp \` line in the
     `LOCAL_SRC_FILES` list

   The GNU `Makefile` and the premake-generated Visual Studio projects both glob
   `soundlib/*.cpp`, so they need no edit.
5. Optionally add `skm="ALIM3"` to `contrib/fuzzing/all_formats.dict`. Note that
   this file has no trailing newline upstream, so append carefully.

No `Snd_defs.h` change and no new module type are required.

Built and render-tested against OpenMPT `master` at r25644 (libopenmpt
0.9.0-pre.13), as a C++23 translation unit with the project's standard warning
set: no errors, no warnings.

No `.skm` files are distributed here. For something to load, clone the research
repository and use its fixture corpus — every file in it is CC0 or otherwise
declared redistributable in `tests/fixtures/manifest.json`:

```
git clone https://github.com/lpreiner/skale-skm-format.git
bin/openmpt123 skale-skm-format/tests/fixtures/authentic/*.skm
```

Everything under `authentic/` is expected to load. `generated/` additionally
carries deliberately malformed and boundary cases — invalid loops, out-of-range
envelopes, broken Ogg framing — which are useful for checking that the loader
rejects or clamps rather than crashing. One of them,
`truncated-inside-ogg-stream.skm`, is expected to be rejected outright; each
file's `expected_parse` field in the manifest states which behaviour is
correct.

### Module type

The loader calls `InitializeGlobals(MOD_TYPE_XM, ...)` and identifies itself as
SKM entirely through `m_modFormat`:

```cpp
m_modFormat.formatName = UL_("Skale Tracker Module");
m_modFormat.type = UL_("skm");
m_modFormat.charset = mpt::Charset::Windows1252;
```

This matches what recent soundlib formats do — SymMOD, DSym, FTM, RTM and ETX
all take no `MODTYPE` bit of their own — and it keeps SKM on the XM-family
playback paths whose effect, envelope, tuning, and sample semantics the format
research verified as shared.

An earlier revision defined a distinct composite type,
`MOD_TYPE_SKM = 0x40000000 | MOD_TYPE_XM`. That was dropped for two reasons.

The first is cost: `MODTYPE` is a dense `uint32` bitfield whose highest assigned
value is `MOD_TYPE_SFX = 0x20000000`, so only two bits remain, and spending one
on an import-only format is a poor trade.

The second is that the composite value was quietly wrong.
`CSoundFile::GetModSpecifications()` is a `switch` on the exact type, so
`0x40000004` matched no case and fell through to `default: return
ModSpecs::mod`. The module was therefore operating under ProTracker
specifications — `instrumentMax = 0`, no envelopes, pattern rows fixed at 64,
31 samples, 128 orders — while the loader was importing instruments, envelopes,
256-row patterns, and hundreds of samples. `MOD_TYPE_XM` selects
`ModSpecs::xmEx`, which actually describes what the loader produces.

Module specifications mostly govern the OpenMPT application's editing
constraints rather than libopenmpt playback, which is why the render
comparisons in `VALIDATION.md` did not surface this.

## An upstream bug this format exposes

Independent of the loader, testing SKM's embedded Ogg samples surfaced a
zero-progress loop in OpenMPT's own stb_vorbis path
(`soundlib/SampleFormatVorbis.cpp`). This is probably the most directly useful
finding here for a maintainer, so it is written up in full.

`ReadVorbisSample` loops while

```cpp
error == VORBIS__no_error || (error == VORBIS_need_more_data && dataLeft > 0)
```

If `stb_vorbis_decode_frame_pushdata` returns `consumed == 0` and
`decodedSamples == 0` while setting `need_more_data`, nothing in that condition
changes and the loop re-enters with identical state — forever. Two trailing
bytes that are not a valid Ogg page are enough to trigger it, and it happens
*after* the audio has been fully decoded, so it is invisible in the output.

`openmpt-stb-vorbis-progress.patch` in this repository is a minimal defensive
fix: stop when a decode call consumes no bytes and produces no samples. It is
not SKM-specific — any malformed or padded Vorbis stream can reach this.

**This loader does not depend on that patch.** Skale pads every embedded stream
with a fixed four bytes, `01 00 FF FF`, counted inside the stored inner length
(1032/1032 corpus samples). The loader validates and excludes all four, so it
never hands the decoder the bytes that trigger the condition. An earlier
revision excluded only the trailing `FF FF` and did hang; the padding had been
recorded as two bytes rather than four. Excluding all four is lossless —
decoded sample counts are identical either way.

Both fixes were confirmed to resolve the hang independently.

## Validation

See `VALIDATION.md` for what was measured and how.
