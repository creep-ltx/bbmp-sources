/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef RENAMEDIALOG_H
#define RENAMEDIALOG_H

#include "Dialog.h"
#include "Label.h"
#include "EditBox.h"

class CRenameDialog : public CDialog
{
public:
	             CRenameDialog(CControl *parent, char *caption, char *label);
              ~CRenameDialog();
  void         SetEditText(char *text);
  void         GetEditText(char *text);
  virtual void OnButtonPress(CButton *button);

private:
	CLabel   *Label;
	CEditBox *EditBox;
	CButton  *CancelButton, *OKButton;
};

#endif