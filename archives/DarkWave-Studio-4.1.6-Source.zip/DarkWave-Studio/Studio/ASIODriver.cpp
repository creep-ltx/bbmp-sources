/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ASIODriver.h"
#include "Error.h"
#include "Core.h"
#include "ConvertBlock.h"
#include <math.h>
#include <stdio.h>
#include "iasiodrv.h"

extern IASIO* theAsioDriver;

#define POSSIBLE_SAMPLE_RATE_COUNT 5
extern double PossibleSampleRates[POSSIBLE_SAMPLE_RATE_COUNT];

CASIODriver *ASIODriver = 0;

bool CASIODriver::CanOpen()
{
  return (DeviceCount > 0);
}

void BufferSwitch(long doubleBufferIndex, ASIOBool directProcess)
{
	if(ASIODriver)
	{
		ASIODriver->BlockFinished(doubleBufferIndex);
	}
}

ASIOTime* BufferSwitchTimeInfo(ASIOTime* params, long doubleBufferIndex, ASIOBool directProcess)
{
  return 0;
}

void SampleRateDidChange(ASIOSampleRate sRate)
{
}

long AsioMessage(long selector, long value, void* message, double* opt)
{
  return 0;
}

void DefaultASIOCallback(int nChannels, double **channels, int samples)
{
  int channel, sample;

  for(channel = 0; channel < nChannels; channel++)
  {
    for(sample = 0; sample < samples; sample++)
      channels[channel][sample] = 0.0;
  }
}

int CASIODriver::ChooseFormat(int preferredFormat)
{
  int i;

  int df;

  df = GetDeviceFormats(Device);
 
  if(df & preferredFormat)
    return preferredFormat;

  for(i = POSSIBLE_SAMPLE_RATE_COUNT - 1; i >= 0; i--)
  {
    if(df & (1 << i))
      return (1 << i);
  }
  return 0;
}
 
CASIODriver::CASIODriver()
{
  SASIODeviceInfo *deviceInfo;
  int              i, j;
  long             minSize, maxSize, preferredSize, granularity, nInputs = 0, nOutputs = 0;
  ASIOError        s;
  
  IsOpen = false;

  Device = -1;
  
  memset(&CallBacks, 0, sizeof(ASIOCallbacks));
  CallBacks.bufferSwitch = BufferSwitch;
  CallBacks.bufferSwitchTimeInfo = BufferSwitchTimeInfo;
  CallBacks.sampleRateDidChange = SampleRateDidChange;
  CallBacks.asioMessage = AsioMessage;

  BufferInfo  = 0;
  ChannelInfo = 0;
  Channels    = 0;
  
  Drivers = new AsioDrivers();

  DeviceCount = Drivers->asioGetNumDev();

  DeviceInfo = new SASIODeviceInfo[DeviceCount];
  memset(DeviceInfo, 0, sizeof(SASIODeviceInfo) * DeviceCount);

  for(i = 0; i < DeviceCount; i++)
  {
    deviceInfo = &(DeviceInfo[i]);
    deviceInfo->DeviceFormats = 0;
    
    Drivers->asioGetDriverName(i, deviceInfo->Name, ASIO_MAX_NAME);
    if(Drivers->loadDriver(deviceInfo->Name))
    {
      ASIODriverInfo di;	

      s = ASIOInit(&di); 
	  
      theAsioDriver->getBufferSize(&minSize, &maxSize, &preferredSize, &granularity);

      deviceInfo->MinBufferSize = minSize;
      deviceInfo->MaxBufferSize = maxSize;
      deviceInfo->PreferredSize = preferredSize;
	  if(preferredSize == 0)
		preferredSize = maxSize;
      deviceInfo->Granularity   = granularity;
      

      theAsioDriver->getChannels(&nInputs, &nOutputs);
      deviceInfo->NumChannels = nOutputs;
      
      for(j = 0; j < POSSIBLE_SAMPLE_RATE_COUNT; j++)
      {
        s = theAsioDriver->canSampleRate(PossibleSampleRates[j]);

        if((s != ASE_NoClock) && (s != ASE_NotPresent))
          deviceInfo[i].DeviceFormats |= (1 << j);
      }  
    }
  }   

  if(DeviceCount < 1)
  {
    SampleRate = 44100;
    Bits = 16;
    Format = 4;
    Device = -1;
    BlockSamples = Latency = 512;
  }
  else
  {
    Device = Core->Options->Audio.ASIODevice;
    if((Device < 0) || (Device >= DeviceCount))
      Device = 0;

    Format = ChooseFormat(Core->Options->Audio.ASIOFormat);
    if(Format == 0)
    {
      ASIOSampleRate sr;

      theAsioDriver->getSampleRate(&sr);
      SampleRate = (int)sr;
    }
    else
      FormatProperties(Format, &SampleRate, &Bits, 0);
  
    Latency = Core->Options->Audio.ASIOLatency;
    if((Latency < DeviceInfo[Device].MinBufferSize) || (Latency > DeviceInfo[Device].MaxBufferSize))           
      Latency = GetPreferredSize(Device) == 0 ? DeviceInfo[Device].MaxBufferSize : GetPreferredSize(Device);
    BlockSamples = Latency;
  
    WriteCallback = &DefaultASIOCallback;
  }
  
  for(i = 0; i < DeviceCount; i++)
  {
    Drivers->asioCloseDriver(i);
  }
}

CASIODriver::~CASIODriver()
{
  Close();
  
  delete Drivers;
  delete DeviceInfo;
}

char* CASIODriver::GetName()
{
  return "Steinberg ASIO";
}

int CASIODriver::GetBlockSamples()
{
  return BlockSamples;
}

int CASIODriver::GetSampleRate()
{
  return SampleRate;
}

void CASIODriver::SetWriteCallback(AudioOutputWriteCallback *funcPtr)
{
  WriteCallback = funcPtr;
}

void CASIODriver::Open()
{
  int nChannels, i;

  BlockSamples = Latency;
  
  if(Device < 0)
    return;

  if(BufferInfo)
    delete BufferInfo;

  nChannels = GetNumChannels();

  BufferInfo = new ASIOBufferInfo[nChannels];
  memset(BufferInfo, 0, sizeof(ASIOBufferInfo) * nChannels);

  ChannelCount = nChannels;
  if(Channels)
    delete Channels;
  Channels = new void*[nChannels];

  if(ChannelInfo != 0)
    delete ChannelInfo;
  ChannelInfo = new ASIOChannelInfo[nChannels];
  memset(ChannelInfo, 0, sizeof(ASIOChannelInfo) * nChannels);
  
  MixBuffer = new double*[nChannels];
      
  for(i = 0; i < nChannels; i++)
  {
    MixBuffer[i] = new double[BlockSamples];
    BufferInfo[i].isInput = false;
    BufferInfo[i].channelNum = i;
    ChannelInfo[i].channel = i;
    ChannelInfo[i].isInput = 0;

    ASIOGetChannelInfo(&(ChannelInfo[i]));
  }
  
  ASIOError s;

  ASIODriver = this;
  Drivers->loadDriver(DeviceInfo[Device].Name);

  ASIODriverInfo di;	
  s = ASIOInit(&di);
  
  if(DeviceInfo[Device].DeviceFormats)
  {
    Format = ChooseFormat(Core->Options->Audio.ASIOFormat);
    FormatProperties(Format, &SampleRate, &Bits, 0);
  	ASIOSampleRate sr;

	if(ASIOSetSampleRate((ASIOSampleRate)SampleRate) != ASE_OK)
    {
      memset(&sr, 0, sizeof(sr));

	  ASIOGetSampleRate(&sr);
      SampleRate = (int)sr;
	}
  }
 
  s = ASIOCreateBuffers(BufferInfo, nChannels, Latency, &CallBacks);
  s = ASIOOutputReady();
  s = ASIOStart();

  IsOpen = true;
}

void CASIODriver::Close()
{
  int s;

  if(IsOpen)
  {
    IsOpen = false;

    s = ASIOStop();
    s = ASIODisposeBuffers();

    Drivers->asioCloseDriver(Device);
  }
  
  FormatProperties(Format, &SampleRate, &Bits, 0);
}

void CASIODriver::WriteBlock(int block)
{
  int i, j;

  for(i = 0; i < ChannelCount; i++)
  {
    Channels[i] = BufferInfo[i].buffers[block];
  }

  WriteCallback(ChannelCount, MixBuffer, BlockSamples); 

  for(i = 0; i < ChannelCount; i++)
  {
    switch(ChannelInfo[i].type)
    {
      case ASIOSTInt16MSB:
      {
        for(j = 0; j < BlockSamples; j++)
        {
          ((short**)Channels)[i][j] = ConvertAudioDoubleToInt(MixBuffer[i][j]);
        }
        break;
      }
      case ASIOSTInt32LSB:
      {
        for(j = 0; j < BlockSamples; j++)
        {
          ((int**)Channels)[i][j] = ConvertAudioDoubleToInt32(MixBuffer[i][j]);
        }
        break;
      }
    }
  }
}

void CASIODriver::BlockFinished(int block)
{
  WriteBlock(block);
  ASIOOutputReady();
}

int CASIODriver::GetDeviceCount()
{
  return DeviceCount;
}

char *CASIODriver::GetDeviceName(int index)
{
  char *drvName;

  drvName = new char[256];
  drvName[0] = 0;

  Drivers->asioGetDriverName(index, drvName, 256);
  return drvName;
}

int CASIODriver::GetDeviceFormats(int index)
{
   if(DeviceCount <= index)
    return 512;
  return DeviceInfo[index].DeviceFormats;
}

int CASIODriver::GetDevice()
{
  return Device;
}

char *CASIODriver::DescribeFormat(int format)
{
  int   sampleRate;
  int   bits;
  bool  stereo;
  char *text;

  if(format == 0)
  {
    ASIOSampleRate sr;

    ASIOGetSampleRate(&sr);
 
    sampleRate = (int)sr;
    bits = 16;
    stereo = true;
  }
  else
  {
    FormatProperties(format, &sampleRate, &bits, &stereo);
  }
  text = new char[128];
  sprintf(text, "%0.1fkHz", sampleRate / 1000.0f);
  return text;
}

void CASIODriver::FormatProperties(int format, int *sampleRate, int *bits, bool *stereo)
{
  int steps = 0;

  format >>= 1;
  
  while(format != 0)
  {
    format >>= 1;
    steps++;
    if(steps >= POSSIBLE_SAMPLE_RATE_COUNT)
      throw "Invalid Format";
  }

  *sampleRate = (int)PossibleSampleRates[steps];
  *bits       = 16; 
  if(stereo)
    *stereo     = true;
}

int CASIODriver::GetFormat()
{
  return Format;
}

void CASIODriver::SetDevice(int device)
{
  Core->Options->Audio.ASIODevice = device;
  Device = device;
}

void CASIODriver::SetFormat(int format)
{
  Core->Options->Audio.ASIOFormat = format;
  Format = format;
}

int CASIODriver::GetLatency()
{
  return Latency;
}

void CASIODriver::SetLatency(int latency)
{
  Core->Options->Audio.ASIOLatency = latency;
  Latency = latency;
  BlockSamples = Latency;
}

int CASIODriver::GetMaxBufferSize(int index)
{
  if(DeviceCount <= index)
    return 512;
  return DeviceInfo[Device].MaxBufferSize;
}

int CASIODriver::GetMinBufferSize(int index)
{
  if(DeviceCount <= index)
    return 512;
  return DeviceInfo[Device].MinBufferSize;
}

int CASIODriver::GetPreferredSize(int index)
{
  if(DeviceCount <= index)
    return 512;
  return DeviceInfo[Device].PreferredSize;
}

int CASIODriver::GetGranularity(int index)
{
  if(DeviceCount <= index)
    return 0;
  return DeviceInfo[Device].Granularity;
}

long CASIODriver::GetDeviceChannels(int index)
{
  if(DeviceCount <= index)
    return 0;
  return DeviceInfo[Device].NumChannels;
}

int CASIODriver::GetNumChannels()
{
  return Device == -1 ? 0 : (int)GetDeviceChannels(Device);
}