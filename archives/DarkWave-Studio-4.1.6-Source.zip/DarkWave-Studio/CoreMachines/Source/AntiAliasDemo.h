/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ANTIALIASDEMO_H
#define ANTIALIASDEMO_H

#include "DarkPlug.h"
#include "Control.h"
#include "SampleView.h"
#include "ComboBox.h"
#include "Font.h"
#include "ToolBar.h"
#include "ToolBarButton.h"
#include "Label.h"

#define SAMPLE_SINC              0
#define SAMPLE_WINDOW            1
#define SAMPLE_WINDOWEDSINC      2
#define SAMPLE_FREQUENCYRESPONSE 3
#define SAMPLE_REALCEPSTRUM      4
#define SAMPLE_MINIMUMPHASE      5
#define SAMPLE_SIGNAL            6
#define SAMPLE_OVERSAMPLED       7
#define SAMPLE_FFTFILTERKERNEL   8
#define SAMPLE_FFTSIGNAL         9
#define SAMPLE_FFTMULTIPLE       10
#define SAMPLE_IFFTSIGNAL        11
#define SAMPLE_DOWNSAMPLED       12

#undef SAMPLE_COUNT
#undef SAMPLE_BUFFER_COUNT

#define SAMPLE_COUNT             13
#define SAMPLE_BUFFER_COUNT      12

class CAntiAliasDemoGUI : public CControl
{
public:
               CAntiAliasDemoGUI(HWND parent);
              ~CAntiAliasDemoGUI();
  virtual void Generate();
  virtual void OnComboSelChange(CComboBox *comboBox);
  void         ShowSample(int sample);
  CSample     *AddFFTSample(int n, double *data);
  void         ShowSpeed(int samples, int time);

private:
  CSampleView    *View;
  CComboBox      *ViewCombo;
  CSample        *Samples[SAMPLE_COUNT];
  CToolBar       *ToolBar;
  CLabel         *SpeedLabel;
};

class CAntiAliasDemo : public CMachine
{
public:
               CAntiAliasDemo(CHost *host);
  virtual     ~CAntiAliasDemo();
  virtual HWND CreateGUI(HWND parent);
  virtual void Work();
  virtual void SetSampleRate(int sampleRate);
  virtual void SetBlockSamples(int blockSamples);

private:
  CAntiAliasDemoGUI *GUI;
};

class CAntiAliasDemoInfo : public CMachineInfo
{
public:
                    CAntiAliasDemoInfo(CHost *host);
  virtual CMachine *CreateMachine();

private:
  CHost *Host;
};

#endif