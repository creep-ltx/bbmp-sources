/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "BitFont.h"

CBitFont::CBitFont(CFrameBuffer *picture, int cellsX, int cellsY,
  int cellWidth, int cellHeight, int spacingX, int startCode, int endCode)
{
  Picture    = picture;
  CellsX     = cellsX;
  CellsY     = cellsY;
  CellWidth  = cellWidth;
  CellHeight = cellHeight;
  SpacingX   = spacingX;
  StartCode  = startCode;
  EndCode    = endCode;
}

CBitFont::~CBitFont()
{
}

void CBitFont::DrawText(CFrameBuffer *dst, char *text, int x, int y, int width, int height)
{
  int  i = 0, dx = 0, xSrc, ySrc, xDst, yDst, w, h;
  char c;

  while((c = text[i]) != 0)
  {
    if(c >= StartCode && c <= EndCode)
    {
      c     -= StartCode;
      xSrc   = (c % CellsX) * CellWidth;
      ySrc   = (c / CellsX) * CellHeight;
      xDst   = x + dx;
      yDst   = y;
      w      = CellWidth;
      h      = CellHeight;

      if(xDst < 0)
      {
        w    = w + xDst;
        xSrc = xSrc - xDst;
        xDst = 0;
      }
      if(w > 0)
        Picture->Draw(dst, xDst, yDst, xSrc, ySrc, w, h);
    }
    if(text[i] == '.' || text[i] == ':')
      dx += ((SpacingX * 2) / 3);
    else
      dx += SpacingX;
    i++;
  }
}