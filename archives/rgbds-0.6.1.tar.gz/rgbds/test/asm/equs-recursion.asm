recurse EQUS "recurse"
recurse
