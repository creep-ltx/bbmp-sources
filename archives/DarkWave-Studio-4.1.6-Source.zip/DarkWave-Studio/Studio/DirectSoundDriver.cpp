/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "DirectSoundDriver.h"
#include "Error.h"
#include "Core.h"
#include "ConvertBlock.h"
#include "Util.h"
#include <math.h>
#include <stdio.h>
#include <dsound.h>

#define POSSIBLE_SAMPLE_RATE_COUNT 5
extern double PossibleSampleRates[POSSIBLE_SAMPLE_RATE_COUNT];

const GUID IID_IDirectSoundBuffer8 = {0x6825a449, 0x7524, 0x4d82, 0x92, 0x0f, 0x50, 0xe3, 0x6a, 0xb3, 0xab, 0x1e};
const GUID IID_IDirectSoundNotify  = {0xb0210783, 0x89cd, 0x11d0, 0xaf, 0x8, 0x0, 0xa0, 0xc9, 0x25, 0xcd, 0x16};

CWriteThread::CWriteThread(CDirectSoundDriver *driver)
{
  int i;

  Driver = driver;
  for(i = 0; i < DSOUND_BUFFER_COUNT; i++)
    Events[i] = 0;

  NextEvent = 0;
}

CWriteThread::~CWriteThread()
{
}

void CWriteThread::SetEvents(HANDLE *events)
{
  int i;

  for(i = 0; i < DSOUND_BUFFER_COUNT; i++)
    Events[i] = events[i];
}

void CWriteThread::Work()
{
  if(WaitForSingleObject(Events[NextEvent], 100) == WAIT_OBJECT_0)
  {
    Driver->Work(NextEvent == 0 ? (DSOUND_BUFFER_COUNT - 1) : NextEvent - 1);
    NextEvent = (NextEvent + 1) % DSOUND_BUFFER_COUNT;
  }
}

bool CDirectSoundDriver::CanOpen()
{
  return GetDeviceCount() > 0;
}

BOOL CALLBACK DSEnumerateFunction(LPGUID lpGUID, LPCSTR lpcstrDescription, LPCSTR lpcstrModule, LPVOID lpContext)
{
  return ((CDirectSoundDriver*)lpContext)->DSEnumerateMethod(lpGUID, lpcstrDescription, lpcstrModule);
}

int CDirectSoundDriver::MakeFormat(int sampleRate, int bits, bool stereo)
{
  if(sampleRate == 11025)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_1M08;
      else
        return WAVE_FORMAT_1M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_1S08;
      else
        return WAVE_FORMAT_1S16;
    }
  }
  if(sampleRate == 22050)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_2M08;
      else
        return WAVE_FORMAT_2M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_2S08;
      else
        return WAVE_FORMAT_2S16;
    }
  }
  if(sampleRate == 44100)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_44M08;
      else
        return WAVE_FORMAT_44M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_44S08;
      else
        return WAVE_FORMAT_44S16;
    }
  }
  if(sampleRate == 48000)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_48M08;
      else
        return WAVE_FORMAT_48M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_48S08;
      else
        return WAVE_FORMAT_48S16;
    }
  }
  if(sampleRate == 96000)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_96M08;
      else
        return WAVE_FORMAT_96M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_96S08;
      else
        return WAVE_FORMAT_96S16;
    }
  }
  return 0;
}

BOOL CDirectSoundDriver::DSEnumerateMethod(LPGUID lpGUID, LPCSTR lpcstrDescription, LPCSTR lpcstrModule)
{
  SDirectSoundDevice *device;

  device = new SDirectSoundDevice;
  memset(device, 0, sizeof(SDirectSoundDevice));

  device->GUID = lpGUID;
  
  device->Description = CopyString((char*)lpcstrDescription);

  if(lpcstrModule != 0)
    device->Module = CopyString((char*)lpcstrModule);

  Devices->AddItem(device);

  return TRUE;
}

CDirectSoundDriver::CDirectSoundDriver()
{
  HRESULT s;
  int i, j;

  Stereo = true;
  Buffer = 0;
  ChannelCount = 2;
  IsOpen  = false;
  Device  = 0;
  Devices = new CArray<SDirectSoundDevice*>();
  BlockSamples = DSOUND_DEFAULT_LATENCY;

  WriteThread = 0;

  s = DirectSoundEnumerate(DSEnumerateFunction, (LPVOID)this);

  for(i = 0; i < Devices->Count; i++)
  {
    SDirectSoundDevice *device;

    device = Devices->Items[i];

    s = DirectSoundCreate8(device->GUID, &device->DirectSound, NULL);

    if(device->DirectSound)
    {
      device->Capabilities.dwSize = sizeof(DSCAPS);
      s = device->DirectSound->GetCaps(&device->Capabilities);
      if(s == DS_OK)
      {
        for(j = 0; j < POSSIBLE_SAMPLE_RATE_COUNT; j++)
        {
          if((device->Capabilities.dwMinSecondarySampleRate <= PossibleSampleRates[j]) &&
             (device->Capabilities.dwMaxSecondarySampleRate >= PossibleSampleRates[j]))
          {
            if(device->Capabilities.dwFlags & DSCAPS_SECONDARYMONO)
            {
              if(device->Capabilities.dwFlags & DSCAPS_SECONDARY8BIT)
                device->Formats |= MakeFormat((int)PossibleSampleRates[j], 8, false);
              if(device->Capabilities.dwFlags & DSCAPS_SECONDARY16BIT)
                device->Formats |= MakeFormat((int)PossibleSampleRates[j], 16, false);
            }
            if(device->Capabilities.dwFlags & DSCAPS_SECONDARYSTEREO)
            {
              if(device->Capabilities.dwFlags & DSCAPS_SECONDARY8BIT)
                device->Formats |= MakeFormat((int)PossibleSampleRates[j], 8, true);
              if(device->Capabilities.dwFlags & DSCAPS_SECONDARY16BIT)
                device->Formats |= MakeFormat((int)PossibleSampleRates[j], 16, true);
            }
          }
        }
      }  
    }
  }

  if(Devices->Count < 1)
    Device = -1;
  else
  {
    Format = ChooseFormat(Core->Options->Audio.DirectSoundFormat);
	  FormatProperties(Format, &SampleRate, &Bits, &Stereo);

    Device = Core->Options->Audio.ASIODevice;
    if((Device < 0) || (Device >= Devices->Count))
      Device = 0;

    Format = ChooseFormat(Core->Options->Audio.DirectSoundFormat);
    FormatProperties(Format, &SampleRate, &Bits, &Stereo);
   
    BlockSamples = Core->Options->Audio.DirectSoundLatency;
  }
}

CDirectSoundDriver::~CDirectSoundDriver()
{
  int i;

  if(IsOpen)
    Close();

  for(i = 0; i < Devices->Count; i++)
  {
    delete Devices->Items[i];
    Devices->Items[i] = 0;
  }
  Devices->Clear();
}

char* CDirectSoundDriver::GetName()
{
  return "DirectSound";
}

int CDirectSoundDriver::GetBlockSamples()
{
  return BlockSamples;
}

int CDirectSoundDriver::GetSampleRate()
{
  return SampleRate;
}

void CDirectSoundDriver::SetWriteCallback(AudioOutputWriteCallback *funcPtr)
{
  WriteCallback = funcPtr;
}

void CDirectSoundDriver::Open()
{
  DSBUFFERDESC        bufferDescription;
  LPDIRECTSOUNDBUFFER buffer;
  WAVEFORMATEX        waveFormat;
  const int           numNotifies = DSOUND_BUFFER_COUNT;
  DSBPOSITIONNOTIFY   notifies[DSOUND_BUFFER_COUNT];
  DWORD               *audioPtr1, audioBytes1, *audioPtr2, audioBytes2;
  int                  i;
  HRESULT              s;

  if((Device < 0) || (Device >= Devices->Count))
    return;

  Lock();

  Buffer = 0;

  FormatProperties(Format, &SampleRate, &Bits, &Stereo);

  memset(&bufferDescription, 0, sizeof(bufferDescription));
  bufferDescription.dwSize = sizeof(bufferDescription);
  bufferDescription.dwBufferBytes = (BlockSamples * (Stereo ? 2 : 1) * (Bits / 8) * DSOUND_BUFFER_COUNT);
  bufferDescription.dwFlags = DSBCAPS_GLOBALFOCUS | DSBCAPS_CTRLPOSITIONNOTIFY;
  bufferDescription.lpwfxFormat = &waveFormat;
  
  memset(&waveFormat, 0, sizeof(waveFormat));
  
  waveFormat.cbSize          = sizeof(WAVEFORMATEX);
  waveFormat.wFormatTag      = WAVE_FORMAT_PCM;
  waveFormat.nChannels       = Stereo ? 2 : 1;
  waveFormat.nSamplesPerSec  = SampleRate;
  waveFormat.wBitsPerSample  = Bits;
  waveFormat.nBlockAlign     = (waveFormat.nChannels * waveFormat.wBitsPerSample) / 8;
  waveFormat.nAvgBytesPerSec = waveFormat.nSamplesPerSec * waveFormat.nBlockAlign;
  
  Devices->Items[Device]->DirectSound->SetCooperativeLevel(Core->MainWindow->Handle, DSSCL_NORMAL);
  Devices->Items[Device]->DirectSound->CreateSoundBuffer(&bufferDescription, &buffer, NULL);
  buffer->QueryInterface(IID_IDirectSoundBuffer8, (LPVOID*)&Buffer);

  ChannelCount = Stereo ? 2 : 1;
  Channels = new double*[ChannelCount];
  for(i = 0; i < ChannelCount; i++)
  {
    Channels[i] = new double[BlockSamples];
  }

  for(i = 0; i < DSOUND_BUFFER_COUNT; i++)
  {
    Events[i] = CreateEvent(NULL, FALSE, FALSE, NULL);
  }
    
  WriteThread = new CWriteThread(this);
  WriteThread->SetEvents(Events);

  BlockBytes = (BlockSamples * waveFormat.nBlockAlign);

  Buffer->QueryInterface(IID_IDirectSoundNotify8, (LPVOID*)&Notify);

  for(i = 0; i < DSOUND_BUFFER_COUNT; i++)
  {
    notifies[i].dwOffset = i * BlockBytes;
    notifies[i].hEventNotify = Events[i];
  }

  s = Notify->SetNotificationPositions(numNotifies, notifies);
  if(s != DS_OK)
    ThrowString("Setting DirectSound Notification Positions Failed");

  Buffer->Lock(0, BlockBytes * DSOUND_BUFFER_COUNT, (LPVOID*)&audioPtr1, &audioBytes1, (LPVOID*)&audioPtr2, &audioBytes2, 0);  

  int c;

  for(c = 0; c < ChannelCount; c++)
    for(i = 0; i < BlockSamples; i++)
      Channels[c][i] = 0.0;

  for(i = 0; i < DSOUND_BUFFER_COUNT; i++)
    CopyBuffer(Channels, (void*)((char*)audioPtr1 + (i * BlockBytes)), BlockSamples); 
 
  Buffer->Unlock((LPVOID)audioPtr1, audioBytes1, (LPVOID)audioPtr2, audioBytes2);

  s = Buffer->Play(0, 0, DSBPLAY_LOOPING);
  if(s != DS_OK)
    ThrowString("Playing DirectSound Buffer Failed");

  IsOpen = true;

  WriteThread->Run();

  

  Release();
}

void CDirectSoundDriver::Work(int buffer)
{
  DWORD  *audioPtr1, audioBytes1, *audioPtr2, audioBytes2;
  HRESULT s;

  Lock();

  if(IsOpen)
  {
    WriteCallback(ChannelCount, Channels, BlockSamples);
    s = Buffer->Lock(buffer * BlockBytes, BlockBytes, (LPVOID*)&audioPtr1, &audioBytes1, (LPVOID*)&audioPtr2, &audioBytes2, 0);
    CopyBuffer(Channels, audioPtr1, BlockSamples);
    Buffer->Unlock((LPVOID)audioPtr1, audioBytes1, (LPVOID)audioPtr2, audioBytes2);
  }

  Release();
}

void CDirectSoundDriver::CopyBuffer(double **inBuffer, void *outBuffer, int samples)
{
  short  *outs;
  char   *outc;
 
  outs      = (short*)outBuffer;
  outc      = (char*)outBuffer;

  if(Stereo && (Bits == 16)) // Stereo 16
    ConvertStereoDoubleToStereoInt(inBuffer[0], inBuffer[1], outs, samples);
  else
  {
    if(Stereo) // Stereo 8
      ConvertStereoDoubleToStereoByte(inBuffer[0], inBuffer[1], outc, samples);
    else
    {
      if(Bits == 16) // Mono 16
        ConvertMonoDoubleToMonoInt(inBuffer[0], outs, samples);
      else // Mono 8
        ConvertMonoDoubleToMonoByte(inBuffer[0], outc, samples);
    }
  }
}


void CDirectSoundDriver::Close()
{ int i;

  Lock();

  if(IsOpen)
  {
    IsOpen = false;

    Release();

   
    WriteThread->Stop();
    delete WriteThread;
    WriteThread = 0;
    
    for(i = 0; i < DSOUND_BUFFER_COUNT; i++)
    {
      DeleteObject(Events[i]);  
      Events[i] = 0;
    }

    Lock();

    Buffer->Stop();
    Buffer->Release();
    Buffer = 0;

    for(i = 0; i < ChannelCount; i++)
    {
      delete Channels[i];
      Channels[i] = 0;
    }
    delete Channels;
    Channels = 0;
  }

  FormatProperties(Format, &SampleRate, &Bits, &Stereo);
  ChannelCount = Stereo ? 2 : 1;
  BlockSamples = Core->Options->Audio.DirectSoundLatency;

  Release();
}

int CDirectSoundDriver::GetNumChannels()
{
  return ChannelCount;
}

int CDirectSoundDriver::GetLatency()
{
  return BlockSamples;
}

char* CDirectSoundDriver::GetDeviceName(int device)
{
  if((device >= 0) && (device < Devices->Count))
    return CopyString(Devices->Items[device]->Description);
  else
    return 0;
}

int CDirectSoundDriver::GetDevice()
{
  return Device;
}

int CDirectSoundDriver::GetDeviceCount()
{
  return Devices->Count;
}

char *CDirectSoundDriver::DescribeFormat(int format)
{
  int   sampleRate, bits;
  bool  stereo;
  char *text;

  FormatProperties(format, &sampleRate, &bits, &stereo);
  text = new char[128];
  sprintf(text, "%0.1fkHz, %ibit, %s", ((float)sampleRate) / 1000.0f, bits, stereo ? "Stereo" : "Mono");
  return text;
}

int CDirectSoundDriver::ChooseFormat(int preferredFormat)
{
  int df;

  df = GetDeviceFormats(Device);
 
  if(df & preferredFormat)
    return preferredFormat;
  else
  {
    int  i, j;
    int  bits;
    bool stereo;
    const int sr[5] = {11025, 22050, 44100, 48000, 96000};
    int sampleRate;

    FormatProperties(preferredFormat, &sampleRate, &bits, &stereo);

    for(i = 0; i < 5; i++)
      if(sr[i] == sampleRate)
      {
        // closest sample rate with same bits and stereo

        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], bits, stereo) & df)
            return MakeFormat(sr[j], bits, stereo);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], bits, stereo) & df)
            return MakeFormat(sr[j], bits, stereo);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 16, true) & df)
            return MakeFormat(sr[j], 16, true);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 16, true) & df)
            return MakeFormat(sr[j], 16, true);
        

        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 16, false) & df)
            return MakeFormat(sr[j], 16, false);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 16, false) & df)
            return MakeFormat(sr[j], 16, false);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 8, true) & df)
            return MakeFormat(sr[j], 8, true);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 8, true) & df)
            return MakeFormat(sr[j], 8, true);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 8, false) & df)
            return MakeFormat(sr[j], 8, false);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 8, false) & df)
            return MakeFormat(sr[j], 8, false);
      }    
  }

  return 0;
}

void CDirectSoundDriver::FormatProperties(int format, int *sampleRate, int *bits, bool *stereo)
{
  int steps = 0;

  while((format & 0xF) == 0)
  {
    format >>= 4;
    steps++;
    if(steps >= POSSIBLE_SAMPLE_RATE_COUNT)
      throw "Invalid Format";
  }

  format = format & 0xF;

  *sampleRate = (int)PossibleSampleRates[steps];
  *bits       = format >= 4 ? 16 : 8;
  *stereo     = format == 2 || format == 8 ? true : false;
}

int CDirectSoundDriver::GetFormat()
{
  return Format;
}

int CDirectSoundDriver::GetDeviceFormats(int device)
{
  return Devices->Items[device]->Formats;
}

void CDirectSoundDriver::SetLatency(int latency)
{
  Core->Options->Audio.DirectSoundLatency = latency;
  BlockSamples = latency;
}

void CDirectSoundDriver::SetFormat(int format)
{
  Core->Options->Audio.DirectSoundFormat = format;
  Format = format;
}

void CDirectSoundDriver::SetDevice(int device)
{
  Core->Options->Audio.DirectSoundDevice = device;
  Device = device;
}

