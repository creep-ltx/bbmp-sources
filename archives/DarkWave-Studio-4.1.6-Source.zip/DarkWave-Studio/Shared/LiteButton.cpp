/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "LiteButton.h"
#include "LiteContainer.h"

#define STATE_IDLE   0
#define STATE_HOVER  1
#define STATE_CLICK  2

CLiteButton::CLiteButton(CLiteContainer *parent, int x, int y, int w, int h, CFrameBuffer *picture, CFrameBuffer *hoverPicture, CFrameBuffer *clickPicture) : CLiteControl(parent, x, y, w, h)
{
  Sticky = false;
  Enabled = true;
  Picture = picture;
  HoverPicture = hoverPicture;
  ClickPicture = clickPicture;
  State = STATE_IDLE;
}

CLiteButton::~CLiteButton()
{
}

void CLiteButton::Draw(CFrameBuffer *buffer)
{
  if(State == STATE_IDLE)
    Picture->Draw(buffer, X, Y, 0, 0, Picture->GetWidth(), Picture->GetHeight());

  if(State == STATE_HOVER)
    HoverPicture->Draw(buffer, X, Y, 0, 0, HoverPicture->GetWidth(), HoverPicture->GetHeight());

  if(State == STATE_CLICK)
    ClickPicture->Draw(buffer, X, Y, 0, 0, ClickPicture->GetWidth(), ClickPicture->GetHeight());
}

void CLiteButton::OnMouseMove(int x, int y)
{
  if(!Enabled)
    return;
  
  if(State == STATE_IDLE)
  {
    if(x >= X && y >= Y && x < X + Width && y < Y + Height)
    {
      State = STATE_HOVER;
      SetCapture();
      Parent->Render(X, Y, Width, Height);
      Parent->OnPaint();
      
    }
  }
else
  if((State == STATE_HOVER) || ((State == STATE_CLICK) && Sticky))
  {
    if(!(x >= X && y >= Y && x < X + Width && y < Y + Height))
    {
      if(State == STATE_HOVER)
        State = STATE_IDLE;
      ReleaseCapture();
      Parent->Render(X, Y, Width, Height);
      Parent->OnPaint();
    }
    else
      SetCapture();
  }
}

void CLiteButton::SetState(int newState)
{
  if(newState != State)
  {
    State = newState;
    Parent->Render(X, Y, Width, Height);
    Parent->OnPaint();
  }
}

void CLiteButton::OnLeftButtonDown(int x, int y)
{
  if(!Enabled)
    return;
  if(Sticky && (State == STATE_CLICK))
  {
    State = STATE_HOVER;
    Parent->OnButtonClick(this);
    Parent->Render(X, Y, Width, Height);
    Parent->OnPaint();
    
  }
  else
  if(State == STATE_HOVER)
  {
    State = STATE_CLICK;
    Parent->Render(X, Y, Width, Height);
    Parent->OnPaint();
  }
}

void CLiteButton::OnLeftButtonUp(int x, int y)
{
  if(!Enabled)
    return;
  if(State == STATE_CLICK)
  {
    Parent->OnButtonClick(this);
    if(!Sticky)
    {
      State = STATE_HOVER;
      Parent->Render(X, Y, Width, Height);
      Parent->OnPaint();
    }
  }
}