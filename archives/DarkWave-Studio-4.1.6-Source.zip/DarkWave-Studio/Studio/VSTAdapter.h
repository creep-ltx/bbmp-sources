/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef VSTADAPTER_H
#define VSTADAPTER_H

#include "DarkPlug.h"
#include "ListNode.h"
#include "VST.h"
#include "Control.h"

class CVSTAdapterInfo;

class CVSTAdapter : public CMachine, public CListNode<CVSTAdapter>
{
public:
                CVSTAdapter(CHost *host, vstMain main, char *directory, CVSTAdapterInfo *adapterInfo);
  virtual      ~CVSTAdapter();
  void          InitPorts();
  void          FreePorts();
  VstIntPtr     Dispatch(long opcode, long index, long value, void *ptr, float opt);
  VstIntPtr     Dispatch(long opcode);
  VstIntPtr     Invoke(VstInt32 opcode, VstInt32 index, VstIntPtr value, void *ptr, float opt);
  void          ProcessMIDIIn();
  void          Idle();
  VstTimeInfo  *GetTime(VstIntPtr flags);

  virtual void   DARKCALL Work();
    
  virtual void   DARKCALL GetPropertyName(int index, char *text);
  virtual void   DARKCALL GetPropertyDisplay(int index, char *text);
  virtual double DARKCALL GetProperty(int index);
  virtual void   DARKCALL SetProperty(int index, double value);
  virtual HWND   DARKCALL CreateGUI(HWND parent);

  virtual void   DARKCALL OnShowGUI();
  virtual void   DARKCALL OnHideGUI();
  virtual void   DARKCALL SetSampleRate(int sampleRate);
  virtual void   DARKCALL SetBlockSamples(int blockSamples);
  virtual void   DARKCALL WriteProperties(char **data, int *length, bool *isInner);
  virtual void   DARKCALL ReadProperties(char *data, int length, bool isInner);
  virtual void   DARKCALL GetProgramNameIndexed(int index, char *text);
  virtual void   DARKCALL SetProgram(int index);

  virtual bool   DARKCALL IsSynth();
  
  virtual void  DARKCALL GetNoteLabel(int index, char *text);
  
  AEffect       *Effect;

private:
  double         **Inputs64, **Outputs64;
  float          **Inputs32, **Outputs32;
  int              BlockSamples, SampleRate;
  CControl        *GUI;
  CPort           *MIDIIn;
  bool             WantIdle, WantEditIdle, WantMIDI;
  char            *Directory;
  VstTimeInfo      TimeInfo;
  VstEvents       *Events;
  int              NumInputs, NumOutputs;
  bool             CanProcess64;
  CVSTAdapterInfo *AdapterInfo;
};

class CVSTAdapterInfo : public CMachineInfo
{
public:
                             CVSTAdapterInfo(CHost *host, HMODULE module, vstMain main, bool newMainFormat, char *dllName, char *dir, char *vstPath, char *menuPath);
  virtual                   ~CVSTAdapterInfo();
  virtual CMachine* DARKCALL CreateMachine();
  void                       OnDestroyMachine();

private:
  CHost  *Host;
  HMODULE Module;
  vstMain Main;
  bool    NewMainFormat;
  char   *Directory, *VSTPath;
  int     RefCount;
};

#endif