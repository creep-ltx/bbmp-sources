/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <memory.h>
#include "Font.h"
#include "Error.h"

CFont::CFont(HDC hDC, char *faceName, double pointSize, bool bold)
{
  int height, logPixelsY;

  logPixelsY = GetDeviceCaps(hDC, LOGPIXELSY);
  height = (int)(pointSize * (logPixelsY / 72.0));

  Handle = CreateFontA(height, 0, 0, 0, bold ? FW_BOLD : FW_NORMAL, FALSE, FALSE, FALSE,
    DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
    DEFAULT_PITCH | FF_DONTCARE, faceName);

  if(Handle == NULL)
    ThrowString("Can't Create Font <%s>", faceName);
}

CFont::~CFont()
{
  DeleteObject(Handle);
}