/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "OptionsDialog.h"
#include "Core.h"
#include "IconList.h"
#include "Font.h"
#include "AudioOutOptions.h"
#include "VSTPaths.h"
#include "Button.h"
#include "../Resource.h"
#include "Util.h"

#define FRAME_AUDIO_OUT 0
#define FRAME_VST_PATHS 1

#define FRAME_COUNT     2

#define DIALOG_WIDTH_DEFAULT     640
#define DIALOG_HEIGHT_DEFAULT    320
#define DIALOG_WIDTH_MIN         400
#define DIALOG_HEIGHT_MIN        280

#define ICONLIST_X               8
#define ICONLIST_Y               8
#define ICONLIST_WIDTH           96
#define ICONLIST_HEIGHT(dh)      (dh - 16)
#define FRAME_X                  (ICONLIST_X + ICONLIST_WIDTH + 8)
#define FRAME_Y                  ICONLIST_Y
#define FRAME_WIDTH(dw)          (dw - (ICONLIST_WIDTH + 30))
#define APPLY_HEIGHT             24
#define APPLY_WIDTH              64
#define FRAME_HEIGHT(dh)         (ICONLIST_HEIGHT(dh) - (APPLY_HEIGHT + 8))
#define APPLY_X(dw)              (dw  - (APPLY_WIDTH + 8))
#define APPLY_Y(dh)              (dh  - (APPLY_HEIGHT + 8))

void COptionsDialog::OnResize(int newWidth, int newHeight)
{
  int i;

  newWidth  = max(newWidth,  DIALOG_WIDTH_MIN);
  newHeight = max(newHeight, DIALOG_HEIGHT_MIN);

  ApplyButton->Move(APPLY_X(newWidth), APPLY_Y(newHeight));
  IconList->Resize(ICONLIST_WIDTH, ICONLIST_HEIGHT(newHeight));

  for(i = 0; i < FRAME_COUNT; i++)
    if(Frames[i])
      Frames[i]->Resize(FRAME_WIDTH(newWidth), FRAME_HEIGHT(newHeight));

  CControl::OnResize(newWidth, newHeight);
}

COptionsDialog::COptionsDialog(CControl *parent)
: CDialog(parent, "Options", Core->Options->OptionsDialog.Width == 0 ? DIALOG_WIDTH_DEFAULT : max(DIALOG_WIDTH_MIN, Core->Options->OptionsDialog.Width), Core->Options->OptionsDialog.Height == 0 ? DIALOG_HEIGHT_DEFAULT : max(DIALOG_HEIGHT_MIN, Core->Options->OptionsDialog.Height), Core->ColorManager, true, false, true) 
{
  int i;

  SetFont(new CFont(DC, "Verdana", 10.0f, false));
  ApplyButton = new CButton(this, Font, "Apply", APPLY_X(Width), APPLY_Y(Height), APPLY_WIDTH, APPLY_HEIGHT);

  CurrentFrame = 0;

  Frames = new COptionsFrame*[FRAME_COUNT];
  for(i = 0; i < FRAME_COUNT; i++)
    Frames[i] = 0;
  IconList = new CIconList(this, ICONLIST_X, ICONLIST_Y, ICONLIST_WIDTH, ICONLIST_HEIGHT(Height), Font);
  
  IconList->AddItem(IDI_SPEAKER, "Audio Output");
  //IconList->AddItem(IDI_PAINT,   "Colors");
  IconList->AddItem(IDI_VST, "VST Paths");
  IconList->SelectItem(0);
  IconList->Update();

  IconList->Show();

  ApplyButton->Disable();
  ApplyButton->Show();


  ShowFrame(0);
}

COptionsDialog::~COptionsDialog()
{
  int i;

  for(i = 0; i < FRAME_COUNT; i++)
    if(Frames[i] != 0)
      delete Frames[i];
  delete IconList;
  delete ApplyButton;
}

void COptionsDialog::OnClose()
{
  if(Changed)
    ApplyChanges();
  Hide();
  Core->Options->OptionsDialog.Width  = Width;
  Core->Options->OptionsDialog.Height = Height;
}

void COptionsDialog::OnIconListSelectItem(int index)
{
  ShowFrame(index);
}

void COptionsDialog::ShowFrame(int index)
{
  if(index < 0 || index > FRAME_COUNT)
  {
    if(CurrentFrame != 0)
      CurrentFrame->Hide();
    CurrentFrame = 0;
  }
  else
  {
    if(CurrentFrame != 0)
      CurrentFrame->Hide();
    CurrentFrame = 0;

    if(Frames[index] == 0)
    {
      switch(index)
      {
        case FRAME_AUDIO_OUT:
          Frames[index] = new CAudioOutOptions(this, FRAME_X, FRAME_Y, FRAME_WIDTH(Width), FRAME_HEIGHT(Height));
          break;
        case FRAME_VST_PATHS:
          Frames[index] = new CVSTPaths(this, FRAME_X, FRAME_Y, FRAME_WIDTH(Width), FRAME_HEIGHT(Height));
          break;
      }
    }
    if(Frames[index] != 0)
    {
      CurrentFrame = Frames[index];
      CurrentFrame->Show();
    }
  }
}

void COptionsDialog::OnButtonPress(CButton *button)
{
  if(button == ApplyButton)
  {
    ApplyChanges();
  }
}

void COptionsDialog::ApplyChanges()
{
  int i;

  for(i = 0; i < FRAME_COUNT; i++)
    if(Frames[i] != 0)
      Frames[i]->ApplyChanges();
  Changed = false;
  ApplyButton->Disable();
}

void COptionsDialog::OnChange()
{
  Changed = true;
  ApplyButton->Enable();
}