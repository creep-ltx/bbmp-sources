/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CONTROL_H
#define CONTROL_H

#include <windows.h>

extern HINSTANCE AppInstance;

#include "ColorManager.h"
#include "FrameBuffer.h"

enum DrawBorderStyle
{
  bsFlat,
  bs3DRaised,
  bs3DSunken
};

class CDropList;
class CListBox;
class CToolBarButton;
class CSlider;
class CButton;
class CUpDown;
class CSizeBar;
class CFont;
class CBackBuffer;

class CControl
{
public:
                  CControl(CControl *parent, char* name, int x, int y, int width, int height, bool backBuffer);
                  CControl(HWND parent, CColorManager *colorManager, char *name, int x, int y, int width, int height, bool backBuffer);
                  CControl(CColorManager *colorManager);
                 ~CControl();
  virtual void    Show();
  virtual void    Show(int showState);
          void    Hide();
  virtual void    OnPaint();
  virtual void    OnResize(int newWidth, int newHeight);
  virtual LRESULT WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
          void    Resize(int newWidth, int newHeight);
  virtual bool    OnNCPaint(HDC hDC);
  virtual void    OnRightButtonDown(int x, int y);
  virtual void    OnRightButtonUp(int x, int y);
  virtual void    OnLeftButtonDown(int x, int y);
  virtual void    OnLeftButtonUp(int x, int y);
          void    Move(int x, int y);
          void    Move(int x, int y, int width, int height);
  virtual void    OnMouseMove(int x, int y);
  virtual void    OnScrollX(int newPos);
  virtual void    OnScrollY(int newPos);
  virtual void    OnLeftButtonDoubleClick(int x, int y);
          void    SetTopMost();
  virtual void    OnComboSelect(CDropList *comboBox);
  virtual void    OnListSelChange(CListBox *listBox);
  virtual void    OnListDblClick(CListBox *listBox);
  virtual void    OnSizeX(CSizeBar *sizeBar, int amount);
  virtual void    OnSizeY(CSizeBar *sizeBar, int amount);
  virtual void    OnToolBarButtonPress(CToolBarButton *button);
  virtual void    OnSliderChange(CSlider *slider, double value);
  void            DrawBorder(HDC hDC, DrawBorderStyle style, int x, int y, int width, int height);
  void            DrawBorder(HDC hDC, DrawBorderStyle style, int x, int y, int width, int height, CPen *lightPen, CPen *shadowPen);
  void            SetBackColor(ColorManagerColor color);
  void            Enable();
  void            Disable();
  virtual void    OnButtonPress(CButton *button);
  virtual void    OnUpDownChange(CUpDown *upDown);
  void            SetBorder(DrawBorderStyle style);
  virtual void    OnCaptureChanged(HWND newCapture);
  virtual void    OnRenameDialogSuccess();
  virtual void    OnIconListSelectItem(int index);
  virtual void    OnAppMessage(UINT message, WPARAM wParam, LPARAM lParam);
  virtual void    PostMessage(UINT message, WPARAM wParam, LPARAM lParam);

  int            X, Y, Width, Height;
  HWND           Handle;
  CControl      *Parent;
  CColorManager *ColorManager;
  HDC            DC;
  void           SetFont(CFont *font);
  void           SetFont(char *faceName, double pointSize, bool bold);
  virtual void   Update();
  virtual void   DrawControl();
  CFont         *Font;
  bool           OwnFont;

protected:
  void           DrawBox(HDC hDC, int x, int y, int width, int height, char *text);
  void           DrawBox(HDC hDC, int x, int y, int width, int height, char *text, bool lit);
  void           DrawLabel(HDC hDC, int x, int y, int width, int height, char *text);
  CBackBuffer   *GetBackBuffer();

  ColorManagerColor BackColor;
  HDC               BackDC;
  bool              SubInit;
  void              MakeBackBuffer();
  void              FillTexture(CFrameBuffer *texture);

protected:
  bool Border;
  CFrameBuffer     *Texture;

private:
  void Init();
  void MakeWindow(HWND parent, char *name, int x, int y, int width, int height);
  
  bool              NeedRedraw;
  DrawBorderStyle   BorderStyle;
  CBackBuffer      *BackBuffer;
};

#endif