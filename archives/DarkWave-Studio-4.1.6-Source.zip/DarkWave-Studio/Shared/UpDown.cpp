/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include "Font.h"
#include "UpDown.h"
#include "BackBuffer.h"
#include "Button.h"

#define BUTTON_WIDTH 12

#define UPDOWN_MODE_IDLE              0
#define UPDOWN_MODE_UP_PRESSED        1
#define UPDOWN_MODE_UP_PRESSED_OFF    2
#define UPDOWN_MODE_DOWN_PRESSED      3
#define UPDOWN_MODE_DOWN_PRESSED_OFF  4

#define BUTTON_NONE 0
#define BUTTON_UP   1
#define BUTTON_DOWN 2

LRESULT CALLBACK EditProcedure(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  CUpDown *upDown;

#ifdef WIN64
  upDown = (CUpDown*)(GetWindowLongPtr(hWnd, GWLP_USERDATA));
#else
  upDown = (CUpDown*)(GetWindowLong(hWnd, GWL_USERDATA));
#endif

  if(upDown)
    return upDown->EditWindowProc(hWnd, msg, wParam, lParam);
  else
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

CUpDown::CUpDown(CControl *parent, int x, int y, int width, int height, double min, double max, double step, double value, bool allowDecimal)
: CControl(parent, "UpDown", x, y, width, height, true)
{
  Mode = UPDOWN_MODE_IDLE;
  FMin = min;
  FMax = max;
  FValue = value;
  SetBorder(bs3DSunken);
  TextBox = CreateWindowA("EDIT", "UpDown", WS_CHILD, 0, 0, width - (BUTTON_WIDTH + 2), height, Handle, 0, 0, 0);  
  FStep = step;

  Timer = new CTimer(this, Handle);

#ifdef WIN64
  SetWindowLongPtr(TextBox, GWLP_USERDATA, (LONG_PTR)this);
  SubclassProc = (WNDPROC)GetWindowLongPtr(TextBox, GWLP_WNDPROC);
  SetWindowLongPtr(TextBox, GWLP_WNDPROC, (LONG_PTR)EditProcedure);
#else
  SetWindowLong(TextBox, GWL_USERDATA, (LONG)this);
  SubclassProc = (WNDPROC)GetWindowLong(TextBox, GWL_WNDPROC);
  SetWindowLong(TextBox, GWL_WNDPROC, (LONG)EditProcedure);
#endif

  SendMessage(TextBox, WM_SETFONT, (WPARAM)Font->Handle, TRUE);
  SetEditText();
  ShowWindow(TextBox, SW_SHOW);
  DrawControl();
}

CUpDown::~CUpDown()
{
#ifdef WIN64
  SetWindowLongPtr(TextBox, GWLP_WNDPROC, (LONG_PTR)SubclassProc);
#else
  SetWindowLong(TextBox, GWL_WNDPROC, (LONG)SubclassProc);
#endif
  DestroyWindow(TextBox);
}

void CUpDown::DrawControl()
{
  HDC hDC;
  
  hDC = BackDC;
  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();
  DrawButton(hDC, Width - BUTTON_WIDTH, 0, BUTTON_WIDTH, Height >> 1, true,  Mode == UPDOWN_MODE_UP_PRESSED);
  DrawButton(hDC, Width - BUTTON_WIDTH, Height >> 1, BUTTON_WIDTH, Height >> 1, false, Mode == UPDOWN_MODE_DOWN_PRESSED);
}

LRESULT CUpDown::EditWindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_CHAR:
    {
      if(wParam == 27) // esc
      {
        SetEditText();
        return 0;
      }
      if(wParam == 13) // return
      {
        ValidateText();
        Parent->OnUpDownChange(this);
        break;
      }
      if((wParam >= '0' && wParam <= '9') || wParam == '.' || wParam == 8 || wParam == ',')
        break;
      else
        return 0;
    }
    case WM_KILLFOCUS:
    {
      ValidateText();
      Parent->OnUpDownChange(this);
      break;
    }
  };

  return CallWindowProc(SubclassProc, TextBox, msg, wParam, lParam);
}

void CUpDown::SetEditText()
{
  int   n, i, j;
  char *text, *format = "%.2f";

  text = new char[16];
  sprintf(text, format, FValue);
  n = (int)strlen(text);
  
  for(i = 0; i < n; i++)
  {
    if(text[i] == '.')
    {
      for(j = n - 1; j >= i; j--)
      {
        if(text[j] == '.')
        {
          text[j] = 0;
          break;
        }
        else
        {
          if(text[j] == '0')
            text[j] = 0;
          else
            break;
        }
      }
      break;
    }
  }
  SetWindowTextA(TextBox, text);
  delete text;


}

void CUpDown::ValidateText()
{
  int    length, n;
  double newValue;
  char *text, null = 0;
  char *nullp = &null;

  length = (int)SendMessage(TextBox, WM_GETTEXTLENGTH, 0, 0);
  if(length < 1)
    newValue = FValue;
  else
  {
    text = new char[length + 1];
    n = (int)SendMessage(TextBox, WM_GETTEXT, length + 1, (LPARAM)text);
    if(n != length)
      newValue = FValue;
    else
    {
      newValue = (float)strtod(text, &nullp);
      if(newValue < FMin)
        newValue = FMin;
      else if(newValue > FMax)
        newValue = FMax;
    }
  }

  FValue = newValue;
  SetEditText();
}

double CUpDown::GetValue()
{
  return FValue;
}

void CUpDown::SetValue(double newValue)
{
  if(newValue < FMin)
    newValue = FMin;
  else
    if(newValue > FMax)
      newValue = FMax;

  FValue = newValue;
  SetEditText();
}

void CUpDown::DrawButton(HDC hDC, int x, int y, int width, int height, bool up, bool pressed)
{
  HGDIOBJ oldPen, oldBrush;
  POINT   p[3];

  ColorManager->Lock();

  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)ControlLight)->Handle);
  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)ControlLight)->Handle);

  if(up)
  {
    p[0].x = x + (width / 2) - 3;
    p[0].y = y + (height / 2) + 1;
    p[1].x = p[0].x + 3;
    p[1].y = p[0].y - 3;
    p[2].x = p[0].x + 6;
    p[2].y = p[0].y;
  }
  else
  {
    p[0].x = x + (width / 2)  - 3;
    p[0].y = y + (height / 2) - 2;
    p[1].x = p[0].x + 3;
    p[1].y = p[0].y + 3;
    p[2].x = p[0].x + 6;
    p[2].y = p[0].y;
  }

  Polygon(hDC, p, 3);

  SelectObject(hDC, oldPen);
  SelectObject(hDC, oldBrush);

  ColorManager->Release();

  DrawBorder(hDC, pressed ? bs3DSunken : bs3DRaised, x, y, width, height);
}

void CUpDown::OnLeftButtonDown(int x, int y)
{
  int button;

  button = InButton(x, y);
  if(button != BUTTON_NONE)
  {
    SetCapture(Handle);
    if(button == BUTTON_UP)
    {
      FValue += FStep;
      if(FValue > FMax)
        FValue = FMax;
      Mode = UPDOWN_MODE_UP_PRESSED;
    }
    if(button == BUTTON_DOWN)
    {
      FValue -= FStep;
      if(FValue < FMin)
        FValue = FMin;
      Mode = UPDOWN_MODE_DOWN_PRESSED;
    }
    SetEditText();
    Update();
    Parent->OnUpDownChange(this);
    TimerDelay = 500;
    Timer->Set(TimerDelay);
  }
}

void CUpDown::OnLeftButtonUp(int x, int y)
{
  if(Mode != UPDOWN_MODE_IDLE)
  {
    Timer->Kill();
    Mode = UPDOWN_MODE_IDLE;
    ReleaseCapture();
    Update();
  }
}

void CUpDown::OnMouseMove(int x, int y)
{
  int button;

  if(Mode != UPDOWN_MODE_IDLE)
  {
    button = InButton(x, y);
  
    if(Mode == UPDOWN_MODE_DOWN_PRESSED)
    {
      if(button != BUTTON_DOWN)
      {
        Mode = UPDOWN_MODE_DOWN_PRESSED_OFF;
        Update();
        return;
      }
    }
    
    if(Mode == UPDOWN_MODE_DOWN_PRESSED_OFF)
    {
      if(button == BUTTON_DOWN)
      {
        Mode = UPDOWN_MODE_DOWN_PRESSED;
        Update();
        return;
      }
    }    
    
    if(Mode == UPDOWN_MODE_UP_PRESSED)
    { 
      if(button != BUTTON_UP)
      {
        Mode = UPDOWN_MODE_UP_PRESSED_OFF;
        Update();
        return;
      }
    }
    
    if(Mode == UPDOWN_MODE_UP_PRESSED_OFF)
    {
      if(button == BUTTON_UP)
      {
        Mode = UPDOWN_MODE_UP_PRESSED;
        Update();
        return;
      }
    }
  }
}
  

int CUpDown::InButton(int x, int y)
{
  if((x >= (Width - BUTTON_WIDTH)) && (x < Width))
  {
    if((y >= 0) && (y < (Height >> 1)))
      return BUTTON_UP;
    if((y >= (Height >> 1)) && (y < Height))
      return BUTTON_DOWN;
  }
  return BUTTON_NONE;
}

void CUpDown::OnTimer(CTimer *timer)
{
  if(Mode == UPDOWN_MODE_UP_PRESSED)
  {
    if(TimerDelay > 100)TimerDelay -= 100;
    Timer->Set(TimerDelay);
    FValue += FStep;
    if(FValue > FMax)
      FValue = FMax;
    SetEditText();
    Parent->OnUpDownChange(this);
  }
  if(Mode == UPDOWN_MODE_DOWN_PRESSED)
  {
    if(TimerDelay > 100)TimerDelay -= 100;
    Timer->Set(TimerDelay);
    FValue -= FStep;
    if(FValue < FMin)
      FValue = FMin;
    SetEditText();
    Parent->OnUpDownChange(this);
  }
}

void CUpDown::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
}
