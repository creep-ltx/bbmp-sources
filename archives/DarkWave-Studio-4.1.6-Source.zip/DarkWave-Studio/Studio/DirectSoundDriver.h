/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DIRECTSOUNDDRIVER_H
#define DIRECTSOUNDDRIVER_H

#define DSOUND_MAX_LATENCY     2048
#define DSOUND_MIN_LATENCY     128
#define DSOUND_DEFAULT_LATENCY 512
#define DSOUND_GRANULARITY     64
#define DSOUND_BUFFER_COUNT    16

#include <windows.h>
#include <dsound.h>
#include "AudioOutputDriver.h"
#include "Mutex.h"
#include "Array.h"
#include "Thread.h"



struct SDirectSoundDevice
{
	LPGUID         GUID;
	char          *Description;
	char          *Module;
  IDirectSound8 *DirectSound;
  DSCAPS         Capabilities;
  int            Formats;
};

class CDirectSoundDriver;

class CWriteThread : public CThread
{
public:
         CWriteThread(CDirectSoundDriver *directSoundDriver);
        ~CWriteThread();
   void  SetEvents(HANDLE *events);
   void  Work();

private:
   HANDLE              Events[DSOUND_BUFFER_COUNT];
   CDirectSoundDriver *Driver;
   int                 NextEvent;
};

class CDirectSoundDriver : public CAudioOutputDriver, private CHostMutex
{
public:
                CDirectSoundDriver();
  virtual      ~CDirectSoundDriver();
  virtual void  SetWriteCallback(AudioOutputWriteCallback *funcPtr);
  virtual int   GetBlockSamples();
  virtual int   GetSampleRate();
  virtual char *GetName();
  virtual void  Open();
  virtual void  Close();
  virtual int   GetNumChannels();
  virtual bool  CanOpen();
          int   GetDeviceCount();
		      int   GetDevice();
		      char *GetDeviceName(int device);
		      int   GetLatency();
		      int   GetDeviceFormats(int device);
		      int   GetFormat();
		      char* DescribeFormat(int format);
		      void  SetDevice(int device);
		      void  SetFormat(int format);
		      void  SetLatency(int latency);
          void  FormatProperties(int format, int *sampleRate, int *bits, bool *stereo);
          int   MakeFormat(int sampleRate, int bits, bool stereo);
          int   ChooseFormat(int preferredFormat);
          void  CopyBuffer(double **inBuffer, void *outBuffer, int samples);
          void  Work(int buffer);
           
  BOOL          DSEnumerateMethod(LPGUID lpGUID, LPCSTR lpcstrDescription, LPCSTR lpcstrModule);
  
private:
  AudioOutputWriteCallback    *WriteCallback;
  CArray<SDirectSoundDevice*> *Devices;
  int                          Device;
  IDirectSoundBuffer8         *Buffer;
  IDirectSoundNotify8         *Notify;
  int                          BlockSamples;
  bool                         IsOpen;
  int                          Format;
  int                          SampleRate;
  int                          Bits;
  bool                         Stereo;
  HANDLE                       Events[DSOUND_BUFFER_COUNT];
  CWriteThread                *WriteThread;
  double                     **Channels;
  int                          ChannelCount;
  int                          BlockBytes;
};

#endif