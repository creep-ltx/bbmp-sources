/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "LiteControl.h"
#include "LiteContainer.h"

CLiteControl::CLiteControl(CLiteContainer *parent, int x, int y, int width, int height)
{
  Parent    = parent;
  X         = x;
  Y         = y;
  Width     = width;
  Height    = height;
  Visible   = true;
  WantMouse = true;
  Parent->AddControl(this);
}

CLiteControl::~CLiteControl()
{
  Parent->RemoveControl(this);
}

bool CLiteControl::InRect(int x1, int y1, int x2, int y2)
{
  int  X2, Y2;
  bool bHorz, bVert;

  X2 = X + Width  - 1;
  Y2 = Y + Height - 1;

  if(X >= x1 && X <= x2)
    bHorz = true;
  else if(X2 >= x1 && X2 <= x2)
    bHorz = true;
  else if(X < x1 && X2 > x2)
    bHorz = true;
  else
    bHorz = false;

  if(Y >= y1 && Y <= y2)
    bVert = true;
  else if(Y2 >= y1 && Y2 <= y2)
    bVert = true;
  else if(Y < y1 && Y2 > y2)
    bVert = true;
  else
    bVert = false;

  return(bHorz && bVert);
}

bool CLiteControl::InRect(int *x1, int *y1, int *x2, int *y2)
{
  if(InRect(*x1, *y1, *x2, *y2))
  {
    int thisX2, thisY2;

    thisX2 = X + Width  - 1;
    thisY2 = Y + Height - 1;
    
    if(X < *x1)
      *x1 = X;
    if(thisX2 > *x2)
      *x2 = thisX2;

    if(Y < *y1)
      *y1 = Y;
    if(thisY2 > *y2)
      *y2 = thisY2;

    return true;
  }
  return false;
}

bool CLiteControl::ContainsPoint(int x, int y)
{
  if(X <= x && X + Width > x && Y <= y && Y + Height > y)
    return true;
  else
    return false;
}

void CLiteControl::OnMouseMove(int x, int y)
{
}

void CLiteControl::OnLeftButtonDown(int x, int y)
{
}

void CLiteControl::OnLeftButtonUp(int x, int y)
{
}

void CLiteControl::SetCapture()
{
  Parent->SetCapture(this);
}

void CLiteControl::ReleaseCapture()
{
  Parent->ReleaseCapture(this);
}

void CLiteControl::Hide()
{
  Visible = false;
  Parent->Render(X, Y, Width, Height);
}

void CLiteControl::Show()
{
  Visible = true;
  Parent->Render(X, Y, Width, Height);
}