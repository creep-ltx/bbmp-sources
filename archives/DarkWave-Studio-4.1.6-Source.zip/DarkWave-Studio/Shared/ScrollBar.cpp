/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ScrollBar.h"
#include "Util.h"

#define TIMER_DELAY_1 400
#define TIMER_DELAY_2 50

#define BUTTON_SIZE     16
#define MIN_HANDLE_SIZE 16

#define ORIENT_UP       0
#define ORIENT_DOWN     1
#define ORIENT_LEFT     2
#define ORIENT_RIGHT    3

#define STATE_IDLE         0
#define STATE_SCROLLING    1
#define STATE_BUTTON_UP    2
#define STATE_BUTTON_DOWN  3
#define STATE_BUTTON_LEFT  4
#define STATE_BUTTON_RIGHT 5
#define STATE_PAGE_UP      6
#define STATE_PAGE_DOWN    7
#define STATE_PAGE_LEFT    8
#define STATE_PAGE_RIGHT   9

CScrollBar::CScrollBar(CControl *parent, int style, int x, int y, int width, int height, int minPos, int maxPos)
: CControl(parent, "ScrollBar", x, y, width, height, true)
{
  Parent   = parent;
  Style    = style;
  MinPos   = minPos;
  Pos      = minPos;
  MaxPos   = maxPos;
  State    = STATE_IDLE;
  PageSize = 1;
  LineSize = 1;

  Timer = new CTimer(this, Handle);

  BackColor = (ColorManagerColor)ControlLight;
  SubInit = true;
  SizeHandle();
  SetTopMost();
  DrawControl();
}

CScrollBar::~CScrollBar()
{
  delete Timer;
}

void CScrollBar::DrawControl()
{
  HDC hDC;

  hDC = BackDC;
  if((Style & SCROLLBAR_VERTICAL) == SCROLLBAR_VERTICAL)
    DrawVertical(hDC);
  else
    DrawHorizontal(hDC); 
}

void CScrollBar::DrawVertical(HDC hDC)
{
  int handleY;

  ColorManager->Lock();

  handleY = HandleY();
  ColorManager->GetBrush(BackColor)->FillRect(hDC, 0, BUTTON_SIZE, Width, Height - (BUTTON_SIZE * 2));

  if(State == STATE_PAGE_UP && MouseX >= 0 && MouseX < Width && MouseY >= BUTTON_SIZE && MouseY < handleY)
    ColorManager->GetBrush((ColorManagerColor)Black)->FillRect(hDC, 0, BUTTON_SIZE, Width, handleY - BUTTON_SIZE);

  if(State == STATE_PAGE_DOWN && MouseX >= 0 && MouseX < Width && MouseY >= handleY + HandleSize && MouseY < Height - BUTTON_SIZE)
    ColorManager->GetBrush((ColorManagerColor)Black)->FillRect(hDC, 0, handleY + HandleSize, Width, (Height - BUTTON_SIZE) - (handleY + HandleSize));

  ColorManager->Release();

  DrawHandle(hDC, 0, handleY, Width, HandleSize);
  
  if(State == STATE_BUTTON_UP && MouseX >= 0 && MouseX < Width && MouseY >= 0 && MouseY < BUTTON_SIZE)
    DrawButton(hDC, ORIENT_UP, true, 0, 0, Width, BUTTON_SIZE);
  else
    DrawButton(hDC, ORIENT_UP, false, 0, 0, Width, BUTTON_SIZE);
  
  if(State == STATE_BUTTON_DOWN && MouseX >= 0 && MouseX < Width && MouseY >= Height - BUTTON_SIZE && MouseY < Height)
    DrawButton(hDC, ORIENT_DOWN, true, 0, Height - BUTTON_SIZE, Width, BUTTON_SIZE);
  else
    DrawButton(hDC, ORIENT_DOWN, false, 0, Height - BUTTON_SIZE, Width, BUTTON_SIZE);
}

void CScrollBar::DrawHorizontal(HDC hDC)
{
  int handleX;

  ColorManager->Lock();

  handleX = HandleX();
  ColorManager->GetBrush(BackColor)->FillRect(hDC, BUTTON_SIZE, 0, Width - (BUTTON_SIZE * 2), Height);

  if(State == STATE_PAGE_LEFT && MouseX >= BUTTON_SIZE && MouseX < handleX && MouseY >= 0 && MouseY < Height)
    ColorManager->GetBrush((ColorManagerColor)Black)->FillRect(hDC, BUTTON_SIZE, 0, handleX - BUTTON_SIZE, Height);

  if(State == STATE_PAGE_RIGHT && MouseX >= handleX + HandleSize && MouseX < Width - BUTTON_SIZE && MouseY >= 0 && MouseY < Height)
    ColorManager->GetBrush((ColorManagerColor)Black)->FillRect(hDC, handleX + HandleSize, 0, (Width - BUTTON_SIZE) - (handleX + HandleSize), Height);

  ColorManager->Release();

  DrawHandle(hDC, handleX, 0, HandleSize, Height);

  if(State == STATE_BUTTON_LEFT && MouseX >= 0 && MouseX < BUTTON_SIZE && MouseY >= 0 && MouseY < Height)
    DrawButton(hDC, ORIENT_LEFT, true, 0, 0, BUTTON_SIZE, Height);
  else
    DrawButton(hDC, ORIENT_LEFT, false, 0, 0, BUTTON_SIZE, Height);

  if(State == STATE_BUTTON_RIGHT && MouseX >= Width - BUTTON_SIZE && MouseX < Width && MouseY >= 0 && MouseY < Height)
    DrawButton(hDC, ORIENT_RIGHT, true, Width - BUTTON_SIZE, 0, BUTTON_SIZE, Height);
  else
    DrawButton(hDC, ORIENT_RIGHT, false, Width - BUTTON_SIZE, 0, BUTTON_SIZE, Height);
}

void CScrollBar::DrawHandle(HDC hDC, int x, int y, int width, int height)
{
  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);
  ColorManager->Release();
  DrawBorder(hDC, bs3DRaised, x, y, width, height);
}

void CScrollBar::DrawButton(HDC hDC, int orientation, bool pressed, int x, int y, int width, int height)
{
  HGDIOBJ oldPen, oldBrush;
  POINT   p[3];

  ColorManager->Lock();

  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)ControlLight)->Handle);
  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)ControlLight)->Handle);

  switch(orientation)
  {
    case ORIENT_LEFT:
    {
      p[0].x = x + (width / 2) + 1;
      p[0].y = y + (height / 2) - 3;
      p[1].x = p[0].x - 3;
      p[1].y = p[0].y + 3;
      p[2].x = p[0].x;
      p[2].y = p[0].y + 6;
      break;
    }
    case ORIENT_RIGHT:
    {
      p[0].x = x + (width / 2) - 2;
      p[0].y = y + (height / 2)  - 3;
      p[1].x = p[0].x + 3;
      p[1].y = p[0].y + 3;
      p[2].x = p[0].x;
      p[2].y = p[0].y + 6;
      break;
    }
    case ORIENT_UP:
    {
      p[0].x = x + (width / 2) - 3;
      p[0].y = y + (height / 2) + 1;
      p[1].x = p[0].x + 3;
      p[1].y = p[0].y - 3;
      p[2].x = p[0].x + 6;
      p[2].y = p[0].y;
      break;
    }
    default: // ORIENT_DOWN
    {
      p[0].x = x + (width / 2)  - 3;
      p[0].y = y + (height / 2) - 2;
      p[1].x = p[0].x + 3;
      p[1].y = p[0].y + 3;
      p[2].x = p[0].x + 6;
      p[2].y = p[0].y;
      break;
    }
  }

  Polygon(hDC, p, 3);

  SelectObject(hDC, oldPen);
  SelectObject(hDC, oldBrush);

  ColorManager->Release();

  DrawBorder(hDC, pressed ? bs3DSunken : bs3DRaised, x, y, width, height);
}

void CScrollBar::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  SizeHandle();
  DrawControl();
}

int CScrollBar::HandleX()
{
  if((MaxPos - MinPos) <= 0)
    return BUTTON_SIZE;
  return BUTTON_SIZE + (int)((float)(Pos - MinPos) / (float)(MaxPos - MinPos) * (float)(Width - (HandleSize + (BUTTON_SIZE * 2))));
}

int CScrollBar::HandleY()
{
  if((MaxPos - MinPos) <= 0)
    return BUTTON_SIZE;
  else
    return BUTTON_SIZE + (int)((float)(Pos - MinPos) / (float)(MaxPos - MinPos) * (float)(Height - (HandleSize + (BUTTON_SIZE * 2))));
}

void CScrollBar::OnLeftButtonDown(int x, int y)
{
  int handleX, handleY;

  if((Style & SCROLLBAR_VERTICAL) == SCROLLBAR_VERTICAL)
  {
    if(y >= 0 && y < BUTTON_SIZE)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_BUTTON_UP;
      Update();
      SetCapture(Handle);
      SetPos(Pos - LineSize);
      Timer->Set(TIMER_DELAY_1);
    }

    if(y >= Height - BUTTON_SIZE && y < Height)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_BUTTON_DOWN;
      Update();
      SetCapture(Handle);
      SetPos(Pos + LineSize);
      Timer->Set(TIMER_DELAY_1);
    }

    handleY = HandleY();
    if(y >= handleY && y < handleY + HandleSize)
    {
      MouseY = y;
      InitialPos = Pos;
      State = STATE_SCROLLING;
      SetCapture(Handle);
    }

    if(y >= BUTTON_SIZE && y < handleY)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_PAGE_UP;
      SetCapture(Handle);
      SetPos(Pos - PageSize, true);
      Timer->Set(TIMER_DELAY_1);
    }

    if(y >= handleY + HandleSize && y < Height - BUTTON_SIZE)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_PAGE_DOWN;
      SetCapture(Handle);
      SetPos(Pos + PageSize, true);
      Timer->Set(TIMER_DELAY_1);
    }
  }
  else
  {
    if(x >= 0 && x < BUTTON_SIZE)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_BUTTON_LEFT;
      Update();
      SetCapture(Handle);
      SetPos(Pos - LineSize);
      Timer->Set(TIMER_DELAY_1);
    }

    if(x >= Width - BUTTON_SIZE && x < Width)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_BUTTON_RIGHT;
      Update();
      SetCapture(Handle);
      SetPos(Pos + LineSize);
      Timer->Set(TIMER_DELAY_1);
    }

    handleX = HandleX();
    if(x >= handleX && x < handleX + HandleSize)
    {
      MouseX = x;
      InitialPos = Pos;
      State = STATE_SCROLLING;
      SetCapture(Handle);
    }

    if(x >= BUTTON_SIZE && x < handleX)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_PAGE_LEFT;
      SetCapture(Handle);
      SetPos(Pos - PageSize, true);
      Timer->Set(TIMER_DELAY_1);
    }

    if(x >= handleX + HandleSize && x < Width - BUTTON_SIZE)
    {
      MouseX = x;
      MouseY = y;
      State = STATE_PAGE_RIGHT;
      SetCapture(Handle);
      SetPos(Pos + PageSize, true);
      Timer->Set(TIMER_DELAY_1);
    }
  }
}

void CScrollBar::OnMouseMove(int x, int y)
{
  int newPos;

  if(State == STATE_SCROLLING)
  {
    newPos = InitialPos;

    if((Style & SCROLLBAR_VERTICAL) == SCROLLBAR_VERTICAL)
      newPos += (int)((float)(y - MouseY) / (float)(Height - (HandleSize + (BUTTON_SIZE * 2))) * (float)(MaxPos - MinPos));   
    else
      newPos += (int)((float)(x - MouseX) / (float)(Width - (HandleSize + (BUTTON_SIZE * 2))) * (float)(MaxPos - MinPos));   

    SetPos(newPos);
  }

  if(State == STATE_PAGE_UP || State == STATE_PAGE_DOWN || State == STATE_PAGE_LEFT || State == STATE_PAGE_RIGHT)
  {
    MouseX = x;
    MouseY = y;
    Update();
  }  
  
  if(State == STATE_BUTTON_UP || State == STATE_BUTTON_DOWN || State == STATE_BUTTON_LEFT || State == STATE_BUTTON_RIGHT)
  {
    MouseX = x;
    MouseY = y;
    Update();
  }
 }

void CScrollBar::OnLeftButtonUp(int x, int y)
{
  if(State != STATE_IDLE)
  {
    State = STATE_IDLE;
    ReleaseCapture();
    Update();
  }
}

void CScrollBar::SetPos(int newPos)
{
  SetPos(newPos, false);
}

void CScrollBar::SetPos(int newPos, bool forceRedraw)
{
  if(newPos < MinPos)
    newPos = MinPos;
  else if(newPos > MaxPos)
    newPos = MaxPos;

  if(newPos != Pos)
  {
    Pos = newPos;
    Update();
    if((Style & SCROLLBAR_VERTICAL) == SCROLLBAR_VERTICAL)
      Parent->OnScrollY(newPos);
    else
      Parent->OnScrollX(newPos);
  }
  else if(forceRedraw)
  {
    Update();
  }
}

void CScrollBar::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
}

void CScrollBar::SetMaxPos(int value)
{
  if(value < 0)
    value = 0;
  MaxPos = value;
  SizeHandle();
  if(Pos > MaxPos)
    SetPos(MaxPos);
  else
    Update();
}

void CScrollBar::SizeHandle()
{
  int slideAreaSize;

  if(Style & SCROLLBAR_VERTICAL)
    slideAreaSize = Height - (BUTTON_SIZE * 2);
  else
    slideAreaSize = Width - (BUTTON_SIZE * 2);

  if((MaxPos - MinPos) <= 0)
    HandleSize = MIN_HANDLE_SIZE;
  else
    HandleSize = (slideAreaSize * PageSize) / max(1, (MaxPos - MinPos + PageSize)); 
  if(HandleSize < MIN_HANDLE_SIZE)
    HandleSize = MIN_HANDLE_SIZE;
  if(HandleSize > slideAreaSize)
    HandleSize = slideAreaSize;
}

void CScrollBar::SetPageSize(int value)
{
  PageSize = value;
  SizeHandle();
  Update();
}

int CScrollBar::GetMaxPos()
{
  return MaxPos;
}

void CScrollBar::OnTimer(CTimer *timer)
{
  switch(State)
  {
    case STATE_BUTTON_UP:
      if(MouseX >= 0 && MouseX < Width && MouseY >= 0 && MouseY < BUTTON_SIZE)
        SetPos(Pos - LineSize);
      Timer->Set(TIMER_DELAY_2);
      break;

    case STATE_BUTTON_DOWN:
      if(MouseX >= 0 && MouseX < Width && MouseY >= Height - BUTTON_SIZE && MouseY < Height)
        SetPos(Pos + LineSize);
      Timer->Set(TIMER_DELAY_2);
      break;
      
    case STATE_BUTTON_LEFT:
      if(MouseX >= 0 && MouseX < BUTTON_SIZE && MouseY >= 0 && MouseY < Height)
         SetPos(Pos - LineSize);
      Timer->Set(TIMER_DELAY_2);
      break;
  
    case STATE_BUTTON_RIGHT:
      if(MouseX >= Width - BUTTON_SIZE && MouseX < Width && MouseY >= 0 && MouseY < Height)
        SetPos(Pos + LineSize);
      Timer->Set(TIMER_DELAY_2);
      break;

    case STATE_PAGE_UP:
      if(MouseX >= 0 && MouseX < Width && MouseY >= BUTTON_SIZE && MouseY < HandleY()) 
        SetPos(Pos - PageSize, true);
      else
        Update();
      Timer->Set(TIMER_DELAY_2);
      break;

    case STATE_PAGE_DOWN:
      if(MouseX >= 0 && MouseX < Width && MouseY >= HandleY() + HandleSize && MouseY < Height - BUTTON_SIZE) 
        SetPos(Pos + PageSize, true);
      else
        Update();
      Timer->Set(TIMER_DELAY_2);
      break;

    case STATE_PAGE_LEFT:
      if(MouseY >= 0 && MouseY < Height && MouseX >= BUTTON_SIZE && MouseX < HandleX()) 
        SetPos(Pos - PageSize, true);
      else
        Update();
      Timer->Set(TIMER_DELAY_2);
      break;

    case STATE_PAGE_RIGHT:
      if(MouseY >= 0 && MouseY < Height && MouseX >= HandleX() + HandleSize && MouseX < Width - BUTTON_SIZE) 
        SetPos(Pos + PageSize, true);
      else
        Update();
      Timer->Set(TIMER_DELAY_2);
      break;

  }
}

void CScrollBar::SetLineSize(int value)
{
  LineSize = value;
}

int CScrollBar::GetPos()
{
  return Pos;
}