/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CONNECTOR_H
#define CONNECTOR_H

#include "Control.h"
#include "Connection.h"
#include "DarkPlug.h"
#include "Font.h"
#include "BackBuffer.h"

class CMachineContainer;

class CConnector : public CControl
{
public:
                  CConnector(CControl *parent, int x, int y, CPort *port, CMachineContainer *container);
  virtual        ~CConnector();
  void            AutoSize();
  LRESULT         WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
  void            OnResize(int newWidth, int newHeight);
  virtual void    DrawControl();
  virtual int     Connect(CConnector *connector, double volume);
  virtual void    Disconnect(int index);
  void            ClearConnections();

  CConnection      **Connections;
  int                ConnectionCount;
  CPort             *Port;
  CMachineContainer *Container;
  int                RXCount, TXCount;
  CControlBuffer    *Future;

private:
  void            DrawRXTX(HDC hDC, int x, int y, char *text, bool lit);
};

#endif