/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "IconButton.h"
#include "Core.h"

#define STATE_IDLE         0
#define STATE_PRESSED      1
#define STATE_PRESSED_DOWN 2

CIconButton::CIconButton(CControl *parent, int x, int y, int width, int height, HICON icon)
: CControl(parent, "IconButton", x, y, width, height, true)
{
  State = STATE_IDLE;
  Icon = icon;
  DrawControl();
  SubInit = true;
}

CIconButton::~CIconButton()
{
}

void CIconButton::DrawControl()
{
  HDC  hDC;
  int  x, y;
  RECT r;

  hDC = BackDC;

  r.left   = 0;
  r.top    = 0;
  r.right  = Width;
  r.bottom = Height;

  ColorManager->Lock();
  FillRect(hDC, &r, ColorManager->GetBrush((ColorManagerColor)ControlBack)->Handle);
  ColorManager->Release();

  x = (Width - 32) / 2;
  y = (Height - 32) / 2;

  if(State == STATE_PRESSED_DOWN)
    DrawIcon(hDC, x + 2, y + 2, Icon);
  else
    DrawIcon(hDC, x, y, Icon);
}

void CIconButton::OnLeftButtonDown(int x, int y)
{
  int x1, y1;

  x1 = (Width - 32)  / 2;
  y1 = (Height - 32) / 2;

  if(x >= x1 && x < x1 + 32 && y >= y1 && y < y1 + 32)
  {
    State = STATE_PRESSED_DOWN;
    Update();
    SetCapture(Handle);
  }
}

void CIconButton::OnMouseMove(int x, int y)
{
  int x1, y1;

  if(State != STATE_IDLE)
  {
    x1 = (Width - 32)  / 2;
    y1 = (Height - 32) / 2;

    if(x >= x1 && x < x1 + 32 && y >= y1 && y < y1 + 32)
      State = STATE_PRESSED_DOWN;
    else
      State = STATE_PRESSED;

    Update();
  }
}

void CIconButton::OnLeftButtonUp(int x, int y)
{
  if(State == STATE_PRESSED_DOWN)
    OnPress();
  if(State != STATE_IDLE)
  {
    ReleaseCapture();
    State = STATE_IDLE;
    Update();
  }
}

void CIconButton::OnPress()
{
}

void CIconButton::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
}