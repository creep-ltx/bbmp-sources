/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef UPDOWN_H
#define UPDOWN_H

#include "Control.h"
#include "Timer.h"

class CBackBuffer;
class CFont;

class CUpDown : public CControl, CTimerCallback
{
public:
               CUpDown(CControl *parent, int x, int y, int width, int height, double min, double max, double step, double value, bool allowDecimal);
              ~CUpDown();
  void         DrawControl();
  LRESULT      EditWindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
  void         SetEditText();
  void         ValidateText();
  double       GetValue();
  void         SetValue(double newValue);
  void         DrawButton(HDC hDC, int x, int y, int width, int height, bool up, bool pressed);
  void         OnLeftButtonDown(int x, int y);
  void         OnLeftButtonUp(int x, int y);
  void         OnMouseMove(int x, int y);
  int          InButton(int x, int y);
  virtual void OnTimer(CTimer* timer);
  virtual void OnLeftButtonDoubleClick(int x, int y);

private:
  HWND         TextBox;
  double       FMin, FMax, FValue, FStep;
  WNDPROC      SubclassProc;
  int          Mode, TimerDelay;
  CTimer      *Timer;
};



#endif