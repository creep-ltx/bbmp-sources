/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef OPTIONS_H
#define OPTIONS_H

#include "Array.h"

#pragma pack(push)
#pragma pack(4)

#define OPTIONS_MAGIC   'DwOp'
#define OPTIONS_VERSION 6

struct SOptionsHeader
{
  int Magic;
  int Version;
};

struct SOptionsAudio
{
  int    Driver;
  int    NullLatency;
  int    NullFormat;
  int    WaveDevice;
  int    WaveLatency;
  int    WaveFormat;
  int    DirectSoundDevice;
  int    DirectSoundLatency;
  int    DirectSoundFormat;
  int    ASIODevice;
  int    ASIOLatency;
  int    ASIOFormat;
  bool   DisableASIO;
  double MasterVolume;
};

struct SOptionsAudio5
{
  int  Driver;
  int  NullLatency;
  int  NullFormat;
  int  WaveDevice;
  int  WaveLatency;
  int  WaveFormat;
  int  DirectSoundDevice;
  int  DirectSoundLatency;
  int  DirectSoundFormat;
  int  ASIODevice;
  int  ASIOLatency;
  int  ASIOFormat;
  bool DisableASIO;
};

struct SOptionsAudio4
{
  int  Driver;
  int  NullLatency;
  int  NullFormat;
  int  WaveDevice;
  int  WaveLatency;
  int  WaveFormat;
  int  ASIODevice;
  int  ASIOLatency;
  int  ASIOFormat;
  bool DisableASIO;
};

struct SOptionsAudio3
{
  int Driver;
  int NullLatency;
  int NullFormat;
  int WaveDevice;
  int WaveLatency;
  int WaveFormat;
  int ASIODevice;
  int ASIOLatency;
  int ASIOFormat;
};

struct SOptionsAudio2
{
  int Driver;
  int WaveDevice;
  int WaveLatency;
  int WaveFormat;
  int ASIODevice;
  int ASIOLatency;
  int ASIOFormat;
};

struct SOptionsDialog
{
  int Width;
  int Height;
};

struct SVSTPathsHeader
{
  int Count;
};

struct SVSTPathHeader
{
  int Length;
};

#pragma pack(pop)

class COptions
{
public:
  COptions();
 ~COptions();

  SOptionsHeader  Header;
  SOptionsDialog  OptionsDialog;
  SOptionsAudio   Audio;
  CArray<char*>   VSTPaths;
};

#endif