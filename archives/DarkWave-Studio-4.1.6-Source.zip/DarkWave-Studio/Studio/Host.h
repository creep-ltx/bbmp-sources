/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DARKHOST_H
#define DARKHOST_H

#include "DarkPlug.h"
#include "BankServer.h"

#define MAX_NOTE 127

class CDarkHost : public CHost
{
public:
                     CDarkHost(int blockSamples, int sampleRate, int cpuFeatures);
                    ~CDarkHost();
  void               InitFrequencyTable();
  void               UpdateSamplePosition(int samples);
  void               ResetSamplePosition(int samples);
  void               SetSampleRateAndBlockSamples(int sampleRate, int blockSamples);
  void               SetBPM(double bpm);
  void               SetTPB(double tpb);

  virtual EError     DARKCALL RegisterMachineInfo(CMachineInfo *machineInfo);
  virtual EError     DARKCALL GetNoteFrequency(unsigned int note, double *frequency);
  virtual EError     DARKCALL GetBankServer(CBankServer **bankServer);
  virtual void       DARKCALL SetPropertyAutomated(CMachine *machine, int index, double value);
  virtual int        DARKCALL GetSamplePosition();
  virtual double     DARKCALL GetBPM();
  virtual double     DARKCALL GetTPB();
  virtual int        DARKCALL GetSamplesPerTick();
  virtual int        DARKCALL GetSampleRate();
  virtual int        DARKCALL GetBlockSamples();
  virtual bool       DARKCALL Supports(ESupports code);
  virtual int        DARKCALL GetCPUFeatures();

private:
  double             NoteTable[MAX_NOTE];
  int                SamplePosition, SampleRate, BlockSamples, SamplesPerTick;
  double             BPM, TPB;
  CHostBankServer   *BankServer;
  int                CPUFeatures;
};

#endif