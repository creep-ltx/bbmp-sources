/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "HDRecorder.h"
#include "../Resource.h"
#include "Util.h"
#include "Core.h"
#include "HeavyKnob.h"
#include "PeakMeter.h"
#include "BitFont.h"
#include "HDTrackMachine.h"
#include "SaveAsDialog.h"
#include "ConvertBlock.h"
#include <mmreg.h>

#define SPACING_X       8
#define SPACING_Y       8

#define TOOLBAR_HEIGHT 30

#define BUTTON_SAVE    0
#define BUTTON_RECORD  1

#define TRACKLIST_X SPACING_X
#define TRACKLIST_Y (TOOLBAR_HEIGHT + SPACING_Y)
#define TRACKLIST_W(w) (w - (SPACING_X * 2))
#define TRACKLIST_H(h) (h - (TRACKLIST_Y + SPACING_Y))

#define TRACK_HEIGHT 42
#define NAME_LABEL_WIDTH 280
#define VOLUME_X 0
#define VOLUME_Y 0
#define VOLUME_W 32
#define VOLUME_H 38

#define PEAKMETER_X ((VOLUME_X) + (VOLUME_W) + 4)
#define PEAKMETER_Y 8
#define PEAKMETER_W PEAK_METER_WIDTH_60
#define PEAKMETER_H (TRACK_HEIGHT - (SPACING_Y * 2))

#define TIME_X (PEAKMETER_X + PEAKMETER_W + SPACING_X)
#define TIME_Y PEAKMETER_Y
#define TIME_W (134)
#define TIME_H 20

#define FILE_LABEL_WIDTH_UNCHECKED(w) ((w - ((PEAKMETER_W + TIME_W + NAME_LABEL_WIDTH + (SPACING_X * 16)))))
#define FILE_LABEL_WIDTH(w) (FILE_LABEL_WIDTH_UNCHECKED(w) < 8 ? 8 : FILE_LABEL_WIDTH_UNCHECKED(w))

CTimeDisplay::CTimeDisplay(CControl *parent, int x, int y, int width, int height)
: CLiteContainer(parent, width, height, 0),
  CLiteControl(this, 0, 3, width, height - 3  )
{
  Time = 0.0f;
  CLiteContainer::BackColor = Black;
  Render();
}

CTimeDisplay::~CTimeDisplay()
{
}

void CTimeDisplay::SetTime(double time)
{
  if(Time != time)
  {
    Time = time;
    Render();
    Update();
  }
}

void CTimeDisplay::Draw(CFrameBuffer *frameBuffer)
{
  char text[64];

  sprintf(text, "%2i:%2i:%2i.%3i", (int)((fmod(Time / (60.0 * 60.0), 100.0))), (int)(fmod((Time / 60.0), 60.0)), (int)fmod(Time, 60.0), (int)(fmod(Time, 1.0) * 1000.0));
  if(text[0] == ' ')
    text[0] = '0';
  if(text[3] == ' ')
    text[3] = '0';
  if(text[6] == ' ')
    text[6] = '0';
  if(text[9] == ' ')
    text[9] = '0';
  if(text[10] == ' ')
    text[10] = '0';

  Core->FrameBuffers.DigitsFont->DrawText(frameBuffer, text, CLiteControl::X, CLiteControl::Y, CLiteControl::Width, CLiteControl::Height);
}

CHDTrack::CHDTrack(CHDTrackMachine *machine, CHDTrackList *parent, char *name, int x, int y, int width, int height, CFont *font)
: CToolBar(parent, x, y, width, height)
{
  Time = 0.0f;
  Machine = machine;
  Format = WAVE_FORMAT_IEEE_FLOAT;
  Recording = false;
  FileLabel = 0;
  SetBorder(bs3DRaised);
  
  VolumeKnob = new CHeavyKnob(this, VOLUME_X, VOLUME_Y, VOLUME_W, VOLUME_H, Core->FrameBuffers.Knob);
  AddControl(VolumeKnob, "Set Volume", VolumeKnob->Handle, 4);
  VolumeKnob->Knob->SetValue(1.0f);
  VolumeKnob->Show();

  PeakMeter = new CPeakMeter(this, PEAKMETER_X, PEAKMETER_Y, PEAKMETER_W, PEAKMETER_H);
  AddControl(PeakMeter, "Peak Volume");
  PeakMeter->Show();  
  
  TimeDisplay = new CTimeDisplay(this, 0, 0, TIME_W, TIME_H);
  AddControl(TimeDisplay, "Time");
  TimeDisplay->Render();
  TimeDisplay->CControl::Show();

    SaveButton = AddButton(IDI_SAVE, BUTTON_SAVE, 20, 20, "Select File To Save To", false); 
  RecordButton = AddButton(IDI_RECORD, BUTTON_RECORD, 20, 20, "Record Stream", true);
  
  NameLabel = new CLabel(this, "Track:", 0, 0, NAME_LABEL_WIDTH, TRACK_HEIGHT, DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
  FileLabel = new CLabel(this, "File:", 0, 0, FILE_LABEL_WIDTH(width), TRACK_HEIGHT, DT_VCENTER | DT_SINGLELINE | DT_PATH_ELLIPSIS);
  AddControl(NameLabel, "Track Name");
  AddControl(FileLabel, "File Name");
  NameLabel->Show();
  FileLabel->Show();

  SetFileName("");
}

void CHDTrack::OnResize(int newWidth, int newHeight)
{
  if(FileLabel)
    FileLabel->Resize(FILE_LABEL_WIDTH(newWidth), TRACK_HEIGHT);
  CToolBar::OnResize(newWidth, newHeight);
}

void CHDTrack::SetName(char *name)
{
  char text[1024];

  sprintf(text, "Name: %s", name);
  NameLabel->SetText(text);
}

void CHDTrack::SetFileName(char *newName)
{
  char text[1400];

  strcpy(FileName, newName);
  sprintf(text, "File: '%s'", FileName);
  FileLabel->SetText(text);
}

void CHDTrack::GetFileName(char *fileName)
{
  strcpy(fileName, FileName);
}

CHDTrack::~CHDTrack()
{
  if(Recording)
  {
    Lock();
    Close();
    Release();
  }
  delete TimeDisplay;
  delete VolumeKnob;
  delete PeakMeter;
  delete SaveButton;
  delete RecordButton;
}

CHDTrackList::CHDTrackList(CHDRecorder *parent, int x, int y, int width, int height, CFont *font)
: CControl(parent, "HDTrackList", x, y, width, height, false)
{
  SetBackColor((ColorManagerColor)WindowWorkspace);
  Items = new CArray<CHDTrack*>();
  Font = font;
  SetBorder(bs3DSunken);
  SubInit = true;
}

CHDTrackList::~CHDTrackList()
{
  ClearTracks();
  delete Items;
}

void CHDTrackList::ClearTracks()
{
  int i;

  for(i = 0; i < Items->Count; i++)
    delete Items->Items[i];
  Items->Clear();
}

void CHDTrackList::OnResize(int newWidth, int newHeight)
{
  int i;

  if(SubInit)
  {
    CHDTrack *item;

    for(i = 0; i < Items->Count; i++)
    {
      item = Items->Items[i];
      item->Resize(newWidth, TRACK_HEIGHT);
      //item->OnResize(newWidth, TRACK_HEIGHT);
    }
  }
  CControl::OnResize(newWidth, newHeight);
  RedrawWindow(Handle, NULL, NULL, RDW_FRAME | RDW_INVALIDATE | RDW_UPDATENOW);
}

int CHDTrackList::AddTrack(CHDTrackMachine *machine)
{
  CHDTrack *track;

  track = new CHDTrack(machine, this, machine->GetName(), 0, Items->Count * TRACK_HEIGHT, Width, TRACK_HEIGHT, Font); 
  Items->AddItem(track);
  track->Show();
  return Items->Count - 1;
}

void CHDTrackList::RemoveTrack(CHDTrackMachine *machine)
{
  CHDTrack *track;
  int i;
  bool removed = false;

  for(i = 0; i < Items->Count; i++)
  {
    track = Items->Items[i];
    if(track->Machine == machine)
    {
      Items->RemoveItem(i--);
      delete track;
      removed = true;
    }
    else
      if(removed)
      {
        track->Move(0, i * TRACK_HEIGHT);
      }
  }
 
}

CHDRecorder::CHDRecorder(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "HDRecorder", x, y, width, height, false)
{
  SetBorder(bs3DSunken);
  SetFont("Verdana", 9.0f, false);
  ToolBar = new CToolBar(this, 0, 0, width, TOOLBAR_HEIGHT);
  RecordButton = ToolBar->AddButton(IDI_RECORD, BUTTON_RECORD, 20, 20, "Record Stream", true);

  ToolBar->Show();
  TrackList = new CHDTrackList(this, TRACKLIST_X, TRACKLIST_Y, TRACKLIST_W(width), TRACKLIST_H(height), Font);
  TrackList->Show();
  SubInit = true;
}

CHDRecorder::~CHDRecorder()
{
  delete TrackList;
  delete ToolBar;
  delete RecordButton;
}

void CHDRecorder::Start()
{
  int i;

  for(i = 0; i < TrackList->Items->Count; i++)
    TrackList->Items->Items[i]->Lock();
  for(i = 0; i < TrackList->Items->Count; i++)
    TrackList->Items->Items[i]->Open();
  for(i = 0; i < TrackList->Items->Count; i++)
    TrackList->Items->Items[i]->Release();

  RecordButton->SetPressed(true);
}

void CHDRecorder::Stop()
{
  int i;

  for(i = 0; i < TrackList->Items->Count; i++)
    TrackList->Items->Items[i]->Lock();
  for(i = 0; i < TrackList->Items->Count; i++)
    TrackList->Items->Items[i]->Close();
  for(i = 0; i < TrackList->Items->Count; i++)
    TrackList->Items->Items[i]->Release();

  RecordButton->SetPressed(false);
}

void CHDRecorder::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == RecordButton)
  {
	  if(button->GetPressed())
	  {
		  Start();
	  }
	  else
	  {
		  Stop();
	  }
  }
}

void CHDRecorder::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
  {
    ToolBar->Resize(newWidth, TOOLBAR_HEIGHT);
    TrackList->Resize(TRACKLIST_W(newWidth), TRACKLIST_H(newHeight));
    RedrawWindow(Handle, NULL, NULL, RDW_FRAME | RDW_INVALIDATE | RDW_UPDATENOW);
  }
}

int CHDRecorder::AddTrack(CHDTrackMachine *machine)
{
  return TrackList->AddTrack(machine);
}

void CHDRecorder::RemoveTrack(CHDTrackMachine *machine)
{
  TrackList->RemoveTrack(machine);
}

void CHDRecorder::Idle()
{
	int i;

  for(i = 0; i < TrackList->Items->Count; i++)
  {
    CHDTrack *track;

    track = TrackList->Items->Items[i];
    
    track->Lock();
    track->Idle();
    track->Release();
  }
}

void CHDTrack::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == SaveButton)
  {
    char fileName[1024];
    char *filter = "WAV PCM 32-bit Float (*.wav)\0*.wav\0WAV PCM 16-bit Integer (*.wav)\0*.WAV\0\0";
    char *defExt = "wav";
    bool ok;
    int  nFilterIndex = 1;

    fileName[0] = 0;
    ok = SaveAsDialog(filter, defExt, fileName, &nFilterIndex);
    if(ok)
    {
      Lock();
      if(Recording)
        Close();
      SetFileName(fileName);
      switch(nFilterIndex)
      {
        case 1:
        {
          Format = WAVE_FORMAT_IEEE_FLOAT;
          break;
        }
        case 2:
        {
          Format = WAVE_FORMAT_PCM;
          break;
        }
        default:
        {
          Format = WAVE_FORMAT_IEEE_FLOAT;
          break;
        }
      }
      Release();
    }
  }

  if(button == RecordButton)
  {
    if(!RecordButton->GetPressed())
    {
      Lock();
      if(Recording)
        Close();
      Release();
    }
    else
    {
      Lock();
      Open();
      if(Recording)
        RecordButton->SetPressed(true);
      else
        RecordButton->SetPressed(false);
      Release();
    }
  }
}

void CHDTrack::Write(int samples, double *leftData, double *rightData)
{
  short *outs;
  float *outf;
  double  volume, leftPeak = 0.0, rightPeak = 0.0;
  int    i;

  if(!IsLocked())
    ThrowString("%s", "HD Track Not Locked On Write");

  volume = VolumeKnob->Knob->GetValue();

  for(i = 0; i < samples; i++)
  {
    double temp;

    leftData[i] *= volume;
    temp = fabs(leftData[i]);
    if(leftPeak < temp)
      leftPeak = temp;

    rightData[i] *= volume;
    temp = fabs(rightData[i]);
    if(rightPeak < temp)
      rightPeak = temp;
  }

  PeakMeter->SetPeak(leftPeak, rightPeak);

  if(Recording)
  {
    if(Format == WAVE_FORMAT_PCM)
    {
      outs = new short[samples * 2];
      ConvertStereoDoubleToStereoInt(leftData, rightData, outs, samples);
      fwrite(outs, samples * 4, 1, File);
      delete outs;
      Samples += samples;
    }
    if(Format == WAVE_FORMAT_IEEE_FLOAT)
    {
      outf = new float[samples * 2];
      ConvertStereoDoubleToStereoFloat(leftData, rightData, outf, samples);
      fwrite(outf, samples * 8, 1, File);
      delete outf;
      Samples += samples;
    }

    Time = (double)Samples / (double)(Core->Host->GetSampleRate());
  }

}

void CHDTrack::Write(int samples, double *monoData)
{
  short  *outs;
  float  *outf;
  double  volume, peak = 0.0f;
  int    i;

  if(!IsLocked())
    ThrowString("%s", "HD Track Not Locked On Write");

  volume = VolumeKnob->Knob->GetValue();

  for(i = 0; i < samples; i++)
  {
    double temp;

    monoData[i] *= volume;
    temp = fabs(monoData[i]);
    if(peak < temp)
      peak = temp;
  }

  PeakMeter->SetPeak(peak, peak);

  if(Recording)
  {
    if(Format == WAVE_FORMAT_PCM)
    {
      outs = new short[samples];
      ConvertMonoDoubleToMonoInt(monoData, outs, samples);
      fwrite(outs, samples * 2, 1, File);
      delete outs;
      Samples += samples;
    }
    if(Format == WAVE_FORMAT_IEEE_FLOAT)
    {
      outf = new float[samples];
      ConvertMonoDoubleToMonoFloat(monoData, outf, samples);
      fwrite(outf, samples * 4, 1, File);
      delete outf;
      Samples += samples;
    }

    Time = (double)Samples / (double)(Core->Host->GetSampleRate());
  }
}

void CHDTrack::Idle()
{  
  PeakMeter->Lock();
  PeakMeter->Idle();
  PeakMeter->Release();
  TimeDisplay->Lock();
  TimeDisplay->SetTime(Time);
  TimeDisplay->Release();
}

#define WAV_ID        'FFIR'
#define WAV_FORMAT    'EVAW'
#define WAV_FORMAT_ID ' tmf'
#define WAV_DATA_ID   'atad'

#pragma pack(push, 1)

struct WAVHeader
{
  unsigned int ID;        // 'RIFF'
  unsigned int ChunkSize;
  unsigned int Format;    // 'WAVE'
};

struct WAVChunkHeader
{
  unsigned int   ChunkID;
  long           ChunkSize;
};

struct WAVFormat
{
  short          FormatTag;
  unsigned short Channels;
  unsigned long  SamplesPerSec;
  unsigned long  AvgBytesPerSec;
  unsigned short BlockAlign;
  unsigned short BitsPerSample;
};

#pragma pack(pop)

void CHDTrack::Open()
{
  if(!IsLocked())
    ThrowString("%s", "HD Track Not Locked On Open");

  if(Recording)
    Close();

  Time = 0.0;

  File = fopen(FileName, "wb");
  if(File)
  {
    fseek(File, sizeof(WAVHeader) + sizeof(WAVChunkHeader) + sizeof(WAVFormat) + sizeof(WAVChunkHeader), 0);
    Samples = 0;

    Recording = true;
    RecordButton->SetPressed(true);
  }
  else
    RecordButton->SetPressed(false);
}

void CHDTrack::Close()
{
  if(!IsLocked())
    ThrowString("%s", "HD Track Not Locked On Close");

  if(Recording)
  {
    WAVHeader       header;
    WAVChunkHeader  chunkHeader;
    WAVFormat       format;

    Recording = false;

    fseek(File, 0, 0);

    header.ID        = WAV_ID;
    header.Format    = WAV_FORMAT;
    header.ChunkSize = (sizeof(WAVChunkHeader) * 2) + sizeof(WAVFormat) + (2 * Samples);

    fwrite(&header, sizeof(WAVHeader), 1, File);

    chunkHeader.ChunkID   = WAV_FORMAT_ID;
    chunkHeader.ChunkSize = sizeof(WAVFormat);

    fwrite(&chunkHeader, sizeof(WAVChunkHeader), 1, File);

    format.FormatTag = Format;
    format.Channels = Machine->Stereo ? 2 : 1;
    format.SamplesPerSec = Core->Host->GetSampleRate();
    format.BitsPerSample = (Format == WAVE_FORMAT_IEEE_FLOAT ? 32 : 16);
    format.BlockAlign = (format.BitsPerSample / 8) * format.Channels;
    format.AvgBytesPerSec = format.SamplesPerSec * format.BlockAlign;

    fwrite(&format, sizeof(WAVFormat), 1, File);

    chunkHeader.ChunkID = WAV_DATA_ID;
    chunkHeader.ChunkSize = format.BlockAlign * Samples;

    fwrite(&chunkHeader, sizeof(WAVChunkHeader), 1, File);

    fclose(File);
    File = 0;
  }
  RecordButton->SetPressed(false);
}
