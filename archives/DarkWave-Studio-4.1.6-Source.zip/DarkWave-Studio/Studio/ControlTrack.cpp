/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ControlTrack.h"

CControlTrack::CControlTrack(int parameter, int length)
{
  Property  = parameter;
  Entries   = new CArray<SControlEntry*>();
  
  Resize(length);
}

void CControlTrack::Resize(int newLength)
{
  if(newLength == Entries->Count)
    return;

  if(newLength < Entries->Count)
  {
    while(Entries->Count > newLength)
    {
      delete Entries->Items[Entries->Count - 1];
      Entries->RemoveItem(Entries->Count - 1);
    }
    return;
  }
  else
  {
    while(Entries->Count < newLength)
    {
      SControlEntry *entry;
 
      entry = new SControlEntry;
	    if(Property == PROPERTY_VELOCITY)
	    {
        entry->Used  = true;
        entry->Value = 1.0f;
	    }
	    else
	    {
        entry->Used  = false;
        entry->Value = 0.0f;
      }
    
      Entries->AddItem(entry);
    }
  }
}

CControlTrack::~CControlTrack()
{
  int i;

  for(i = 0; i < Entries->Count; i++)
    delete Entries->Items[i];
  Entries->Clear();
}