// ------------------------------------------------------
// Protrekkr
// Based on Juan Antonio Arguelles Rius's NoiseTrekker.
//
// Copyright (C) 2008-2025 Franck Charlet.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL FRANCK CHARLET OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
// ------------------------------------------------------

#ifndef _EDITOR_SEQUENCER_ED_H_
#define _EDITOR_SEQUENCER_ED_H_

// ------------------------------------------------------
// Includes
#if defined(__GCC__)
#include "../../include/variables.h"
#include "../../ui/include/misc_draw.h"
#elif !defined(__REPLAYER__)
#include "../include/variables.h"
#include "../ui/include/misc_draw.h"
#else
#include <include/variables.h>
#endif

// ------------------------------------------------------
// Variables
extern int Cur_Seq_Buffer;
extern char Selection_Name[20];

extern int Ext_Pos_Switch;
extern int Ext_Track_Switch;

// ------------------------------------------------------
// Functions
void Draw_Sequencer_Ed(void);
void Actualize_Seq_Ed(char gode);
void Mouse_Left_Sequencer_Ed(void);
void Mouse_Right_Sequencer_Ed(void);
void Actualize_Sequencer(void);
void Seq_Bound_Pattern(int posil);
void Toggle_Track_On_Off_Status(int posindex, int seqindex);
void Solo_Track_On_Off(int posindex, int seqindex);
void Display_Seq_Edit_Buttons(void);

#endif
