/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Util.h"
#include "MachineContainer.h"
#include "Core.h"
#include <xmmintrin.h>
#include <emmintrin.h>

#define CONNECTOR_PANEL_HEIGHT 15
#define TITLE_HEIGHT           16
#define CHAMFER_SIZE           5

#define MENU_ID_HIDEGUI        1
#define MENU_ID_SHOWDEFAULTGUI 2
#define MENU_ID_SHOWCUSTOMGUI  3
#define MENU_ID_RENAME         4
#define MENU_ID_RANDOMIZE      5
#define MENU_ID_DELETE         6
#define MENU_ID_GENPROGRAM     7

#define MENUBUTTON_X           17
#define MENUBUTTON_Y           7

#define PROGRAM_TOOLBAR_HEIGHT      24
#define PROGRAM_LABEL_WIDTH         60
#define PROGRAM_COMBO_WIDTH         180
#define PROGRAM_COMBO_ITEMHEIGHT    16
#define PROGRAM_COMBO_HEIGHT        16
#define PROGRAM_TOOLBAR_MIN_WIDTH   (PROGRAM_LABEL_WIDTH + PROGRAM_COMBO_WIDTH + 16)

CWorkThread::CWorkThread()
{
  CThread::SetPriority(THREAD_PRIORITY_TIME_CRITICAL);
}

void CWorkThread::Work()
{
  SleepEx(10, TRUE);
}

VOID CALLBACK MachineWorkAPC(ULONG_PTR dwParam)
{
  CMachineContainer *machine = (CMachineContainer*)dwParam;

  machine->Lock();
  machine->Work(true);
  machine->Release();
}

CMachineMenuButton::CMachineMenuButton(CMachineContainer *parent, int x, int y)
: CMenuButton(parent, x, y)
{
  Container = parent;
}

void CMachineMenuButton::OnMenuItem(int item)
{
  Container->OnMenuItem(item);
}

CMachineContainerIconButton::CMachineContainerIconButton(CControl *parent, int x, int y, int width, int height, HICON icon, CMachineContainer *container)
: CIconButton(parent, x, y, width, height, icon)
{
  Container = container;
}

void CMachineContainerIconButton::OnPress()
{
  Container->OnIconPress();
}


CMachineContainer::CMachineContainer(char *name, char *uniqueID, int x, int y, int offsetX, int offsetY, CMachine *machine, CMachineInfo *machineInfo, CMachineLoaderEntry *entry, CControl *parent, char *properties, int propertyBytes, bool isInner)
: CControl(parent, "MachineContainer", x < 0 ? 0 : x, y < 0 ? 0 : y, 128, 64, true)
{
  WorkDone       = true;
  VisibleControl = -1;
  Name           = CopyString(name);
  UniqueID       = CopyString(uniqueID);
  OffsetX        = offsetX;
  OffsetY        = offsetY;
  DefaultGUI     = 0;

  MenuButton = new CMachineMenuButton(this, Width - MENUBUTTON_X, MENUBUTTON_Y);
  MenuButton->Show();

  Machine = machine;

  if(properties)
    ReadProperties(properties, propertyBytes, isInner);

  if(Machine->ProgramCount > 0)
  {
    ProgramToolBar = new CProgramToolBar(this, 4, TITLE_HEIGHT + 3);
    ProgramToolBar->Show();
  }
  else
    ProgramToolBar = 0;
  MachineInfo = machineInfo;                
  TitleFont = new CFont(DC, "Verdana", 10.0, true);
  SetBkMode(BackDC, TRANSPARENT);
  SubInit = true;
  Machine->HostData = this;
  Machine->SetName(name);
  InitConnectors();
  
  ChildPanel = new CControl(this, "GUI Container", 4, TITLE_HEIGHT + 3 + (ProgramToolBar ? PROGRAM_TOOLBAR_HEIGHT : 0), 128, 64 - (TITLE_HEIGHT + CONNECTOR_PANEL_HEIGHT) - (ProgramToolBar ? PROGRAM_TOOLBAR_HEIGHT : 0), false);
  CustomGUI = Machine->CreateGUI(ChildPanel->Handle);
  if(Machine->PropertyCount > 0)
    DefaultGUI = new CDefaultGUI(ChildPanel, Machine);
  else
    DefaultGUI = 0;

  MenuButton->Menu->Append(MENU_ID_HIDEGUI,        "Hide GUI",         DefaultGUI != 0 || CustomGUI != 0 ? 0 : MF_GRAYED);
  MenuButton->Menu->Append(MENU_ID_SHOWDEFAULTGUI, "Show Default GUI", DefaultGUI != 0                   ? 0 : MF_GRAYED);
  MenuButton->Menu->Append(MENU_ID_SHOWCUSTOMGUI,  "Show Custom GUI",  CustomGUI  != 0                   ? 0 : MF_GRAYED);
  MenuButton->Menu->AppendSeparator();
  MenuButton->Menu->Append(MENU_ID_RENAME,         "Rename",           0);
  MenuButton->Menu->Append(MENU_ID_RANDOMIZE,      "Randomize",        Machine->PropertyCount > 0 ? 0 : MF_GRAYED);
  MenuButton->Menu->Append(MENU_ID_DELETE,         "Delete Machine",   strcmp("Master", Name) == 0 ? MF_GRAYED : 0);

  IconButton = new CMachineContainerIconButton(this, 4, TITLE_HEIGHT + 3 + (ProgramToolBar ? PROGRAM_TOOLBAR_HEIGHT : 0), 40, 40, entry->IconLarge, this); 

  SetVisibleControl(CONTROL_ICONBUTTON);

  WorkSemaphore = new CSemaphore(0, 0x7FFFFFFF);
  WorkThread = new CWorkThread();
  WorkThread->Run();
}

CMachineContainer::~CMachineContainer()
{
  delete ProgramToolBar;
  delete WorkThread;
  delete WorkSemaphore;
  FreeConnectors();
  delete MenuButton;
  delete ChildPanel;
  Machine->Delete();
  delete TitleFont;
  MachineInfo = 0;
  delete Name;
  delete UniqueID;
}

void CMachineContainer::DrawControl()
{
  HDC     hDC;
  POINT   points[6];
  int     titleWidth;
  HGDIOBJ oldBrush, oldPen, oldFont;
  RECT    rect;

  hDC = BackDC;
  
  ColorManager->Lock();

  ColorManager->GetBrush(BackColor)->FillRect(hDC, 0, 0, Width, Height);

  titleWidth = CalculateTitleWidth();

  points[0].x = 0; 
  points[0].y = 0;
  points[1].x = titleWidth - 1;
  points[1].y = 0;
  points[2].x = (titleWidth - TITLE_HEIGHT);
  points[2].y = TITLE_HEIGHT - 1;
  points[3].x = 0;
  points[3].y = TITLE_HEIGHT - 1;

  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)HighlightBack)->Handle);
  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)Black)->Handle);
  Polygon(hDC, points, 4);
  SelectObject(hDC, oldPen);
  SelectObject(hDC, oldBrush);
  
  points[0].x = titleWidth;
  points[0].y = 0;
  points[1].x = (Width - 1) - CHAMFER_SIZE;
  points[1].y = 0;
  points[2].x = (Width - 1);
  points[2].y = CHAMFER_SIZE;
  points[3].x = Width - 1;
  points[3].y = Height - 1;
  points[4].x = 0;
  points[4].y = Height - 1;
  points[5].x = 0;
  points[5].y = TITLE_HEIGHT - 1;

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)Black)->Handle);
  Polyline(hDC, points, 6);
  SelectObject(hDC, oldPen);

  rect.left = 4;
  rect.top = 1;
  rect.right = titleWidth - TITLE_HEIGHT;
  rect.bottom = TITLE_HEIGHT - 1;

  oldFont = (HFONT)SelectObject(hDC, (HFONT)TitleFont->Handle);
  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)HighlightText));
  DrawText(hDC, Name, (int)strlen(Name), &rect, DT_SINGLELINE);
  SelectObject(hDC, (HFONT)oldFont);

  points[0].x = 1;
  points[0].y = Height - 2;
  points[1].x = 1;
  points[1].y = TITLE_HEIGHT;
  points[2].x = titleWidth - (TITLE_HEIGHT + 0);
  points[2].y = TITLE_HEIGHT;
  points[3].x = titleWidth - 1;
  points[3].y = 1;
  points[4].x = Width - CHAMFER_SIZE;
  points[4].y = 1;
  
  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)ControlLight)->Handle);
  Polyline(hDC, points, 5);

  points[0].x = 2;
  points[0].y = Height - (CONNECTOR_PANEL_HEIGHT + 4);
  points[1].x = Width - 3;
  points[1].y = Height - (CONNECTOR_PANEL_HEIGHT + 4);
  points[2].x = Width - 3;
  points[2].y = TITLE_HEIGHT;
  Polyline(hDC, points, 3);


  SelectObject(hDC, oldPen);

  points[0].x = Width - CHAMFER_SIZE;
  points[0].y = 2;
  points[1].x = Width - 2;
  points[1].y = CHAMFER_SIZE;
  points[2].x = Width - 2;
  points[2].y = Height - 2;
  points[3].x = 1;
  points[3].y = Height - 2;

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)ControlShadow)->Handle);
  Polyline(hDC, points, 4);

  points[0].x = 2;
  points[0].y = Height - (CONNECTOR_PANEL_HEIGHT + 4);
  points[1].x = 2;
  points[1].y = TITLE_HEIGHT + 1;
  points[2].x = Width - 3;
  points[2].y = TITLE_HEIGHT + 1;
  Polyline(hDC, points, 3);

  SelectObject(hDC, oldPen);

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)Black)->Handle);
  oldBrush = SelectObject(hDC, ColorManager->GetBrush(BackColor)->Handle);
  Rectangle(hDC, 3, TITLE_HEIGHT + 2, Width - 3, Height - (CONNECTOR_PANEL_HEIGHT + 4));
  SelectObject(hDC, oldPen);
  SelectObject(hDC, oldBrush);

  ColorManager->Release();
}

void CMachineContainer::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  MenuButton->Move(Width - MENUBUTTON_X, MENUBUTTON_Y);
  IconButton->Resize(Width - 8, Height - (CONNECTOR_PANEL_HEIGHT + TITLE_HEIGHT + 3 + (ProgramToolBar ? PROGRAM_TOOLBAR_HEIGHT : 0)) - 10);
  SetBkMode(BackDC, TRANSPARENT);
  SetRegion();
}

void CMachineContainer::PrepareToWork()
{
  CPort        *port;
  CConnector   *connector;
  int           i;

  for(i = 0; i < ConnectorCount; i++)
  {
    connector = Connectors[i];
    port = connector->Port;
    if((port->Type & PT_INPUT) == PT_INPUT) // input port
    {
      if((port->Type & PT_CONTROL) == PT_CONTROL) // clear control data
        port->ControlBuffer->Clear();
    }
  }
  WorkDone = false;
}

void CMachineContainer::WorkAsync()
{
  QueueUserAPC(MachineWorkAPC, WorkThread->GetHandle(), (ULONG_PTR)this);
}

void CMachineContainer::WaitAsync()
{
  WorkSemaphore->Lock();
}

void CMachineContainer::Mix(int samples, double *in, double *out, double powerRatio)
{
  __m128d m;

#ifdef _DEBUG
  int i;
  
  for(i = 0; i < samples; i++)
    if(TestDenormal(in[i]) || TestDenormal(out[i]))
    {
      DebugPrint("%s\n", "Denormal Found");
    }
#endif

  
  if(Core->CPUFeatures & CPU_FEATURE_SSE2)
  {
    m = _mm_load1_pd(&powerRatio);
    
    if(SSE_ALIGNED2(in, out))
    { 
      while(samples >= 8)
      {
        _mm_store_pd(out, _mm_add_pd(_mm_load_pd(out), _mm_mul_pd(m, _mm_load_pd(in)))); 
        in  += 2;
        out += 2;

        _mm_store_pd(out, _mm_add_pd(_mm_load_pd(out), _mm_mul_pd(m, _mm_load_pd(in)))); 
        in  += 2;
        out += 2;

        _mm_store_pd(out, _mm_add_pd(_mm_load_pd(out), _mm_mul_pd(m, _mm_load_pd(in)))); 
        in  += 2;
        out += 2;

        _mm_store_pd(out, _mm_add_pd(_mm_load_pd(out), _mm_mul_pd(m, _mm_load_pd(in)))); 
        in  += 2;
        out += 2;

        samples -= 8;
      }
    }
    else
    {
      while(samples >= 8)
      {
        _mm_storeu_pd(out, _mm_add_pd(_mm_loadu_pd(out), _mm_mul_pd(m, _mm_loadu_pd(in)))); 
        in  += 2;
        out += 2;
  
        _mm_storeu_pd(out, _mm_add_pd(_mm_loadu_pd(out), _mm_mul_pd(m, _mm_loadu_pd(in)))); 
        in  += 2;
        out += 2;
  
        _mm_storeu_pd(out, _mm_add_pd(_mm_loadu_pd(out), _mm_mul_pd(m, _mm_loadu_pd(in)))); 
        in  += 2;
        out += 2;
  
        _mm_storeu_pd(out, _mm_add_pd(_mm_loadu_pd(out), _mm_mul_pd(m, _mm_loadu_pd(in)))); 
        in  += 2;
        out += 2;
  
        
        samples -= 8;
      }
    }
  }
  else
  {
    while(samples >= 8)
    {
      *(out++) += *(in++) * powerRatio;
      *(out++) += *(in++) * powerRatio;
      *(out++) += *(in++) * powerRatio;
      *(out++) += *(in++) * powerRatio;
      *(out++) += *(in++) * powerRatio;
      *(out++) += *(in++) * powerRatio;
      *(out++) += *(in++) * powerRatio;
      *(out++) += *(in++) * powerRatio;
      
      samples -= 8;
    }
  }

  while((samples--) > 0)
    *(out++) += *(in++) * powerRatio;
}

void CMachineContainer::Work(bool async)
{
  CPort        *port;
  CConnector   *connector;
  CConnection  *connection;
  CAudioBuffer *audioBufferIn, *audioBufferOut;
  int           i, j, k, l, samples;
  double        powerRatio, powerRatioFollow, v;
  bool          doneWork = false;
  bool          hasAUX = false;

  if(!WorkDone)
  {
	  WorkDone = true;
    
    for(i = 0; i < ConnectorCount; i++)
    {
      connector = Connectors[i];
      port = connector->Port;

      if((port->Type & PT_INPUT) == PT_INPUT) // input port
      {
        if((port->Type & PT_AUX) == PT_AUX)
          hasAUX = true;
        else
          for(j = 0; j < connector->ConnectionCount; j++) // work inputs
          {
            CMachineContainer *container;

            connection = connector->Connections[j];
            container  = connection->Input->Container;
            if(async)
    		  container->WorkAsync();
			else
			  container->Work(false);
          }
      }
    }

    for(i = 0; i < ConnectorCount; i++)
    {
      connector = Connectors[i];
      port = connector->Port;

      if((port->Type & PT_INPUT) == PT_INPUT) // input port
      {
        if((port->Type & PT_AUX) == PT_AUX)
          hasAUX = true;
        else
          for(j = 0; j < connector->ConnectionCount; j++) // work inputs
          {
            CMachineContainer *container;

            connection = connector->Connections[j];
            if((connection->Input->Port->Type & PT_AUX) == 0)
            {
              container  = connection->Input->Container;
              if(async)
				container->WaitAsync();
            }
          }
      }
    }

    for(i = 0; i < ConnectorCount; i++)
    {
      connector = Connectors[i];
      port = connector->Port;

      if((port->Type & PT_OUTPUT) == PT_OUTPUT) // output port
      {
        if((port->Type & PT_CONTROL) == PT_CONTROL) // clear control data
          port->ControlBuffer->Clear();
      }

      if((port->Type & PT_INPUT) == PT_INPUT) // input port
      {
        if((port->Type & PT_CONTROL) == PT_CONTROL) // move control data
        {
          for(j = 0; j < connector->ConnectionCount; j++)
          {
            connector->Connections[j]->Input->Port->ControlBuffer->CopyTo(port->ControlBuffer);
          }
        }
      
       if((port->Type & PT_AUX) == PT_AUX)
          hasAUX = true;
       else
         if((port->Type & PT_AUDIO) == PT_AUDIO) // move audio data
          {
            audioBufferIn = port->AudioBuffer;
            if(audioBufferIn->Stereo)
              for(k = 0; k < audioBufferIn->Samples; k++)
              {
                audioBufferIn->LeftData[k]  = 0.0;
                audioBufferIn->RightData[k] = 0.0;
              }
            else
              for(k = 0; k < audioBufferIn->Samples; k++)
              {
                audioBufferIn->MonoData[k]  = 0.0;
              }

            for(k = 0; k < connector->ConnectionCount; k++)
            {
              audioBufferOut   = connector->Connections[k]->Input->Port->AudioBuffer;
              samples          = audioBufferIn->Samples;
              powerRatio       = connector->Connections[k]->PowerRatio;
              powerRatioFollow = connector->Connections[k]->PowerRatioFollow;

              if(audioBufferOut->Samples < samples)
                samples = audioBufferOut->Samples;
              if(audioBufferIn->Stereo)
              {
                if(audioBufferOut->Stereo)
                {
                  if(powerRatioFollow == powerRatio)
                  {
                    Mix(samples, audioBufferOut->LeftData, audioBufferIn->LeftData, powerRatio);
                    Mix(samples, audioBufferOut->RightData, audioBufferIn->RightData, powerRatio);
                    // for(l = 0; l < samples; l++)
                    // {
                    //   audioBufferIn->LeftData[l]  += audioBufferOut->LeftData[l]  * powerRatioFollow;
                    //   audioBufferIn->RightData[l] += audioBufferOut->RightData[l] * powerRatioFollow;
                  }
                  else
                    for(l = 0; l < samples; l++)
                    {
                      powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                      audioBufferIn->LeftData[l]  += audioBufferOut->LeftData[l]  * powerRatioFollow;
                      audioBufferIn->RightData[l] += audioBufferOut->RightData[l] * powerRatioFollow;
                    }
                }
                else
                {
                  if(powerRatioFollow == powerRatio)
                  {
                    Mix(samples, audioBufferOut->MonoData, audioBufferIn->LeftData, powerRatio);
                    Mix(samples, audioBufferOut->MonoData, audioBufferIn->RightData, powerRatio);
                    // for(l = 0; l < samples; l++)
                    // {
                    //   v = audioBufferOut->MonoData[l] * powerRatioFollow;
                    //   audioBufferIn->LeftData[l]  += v;
                    //   audioBufferIn->RightData[l] += v;
                  }
                  else
                    for(l = 0; l < samples; l++)
                    {
                      powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                      v = audioBufferOut->MonoData[l] * powerRatioFollow;;
                      audioBufferIn->LeftData[l]  += v;
                      audioBufferIn->RightData[l] += v;
                    }
                }
              }
              else
              {
                if(audioBufferOut->Stereo)
                {
                  if(powerRatioFollow == powerRatio)
                  {
                    Mix(samples, audioBufferOut->LeftData,  audioBufferIn->MonoData, powerRatio * 0.5);
                    Mix(samples, audioBufferOut->RightData, audioBufferIn->MonoData, powerRatio * 0.5);
                    // for(l = 0; l < samples; l++)
                    // {
                    //   audioBufferIn->MonoData[l] += ((audioBufferOut->LeftData[l] + 
                    //     audioBufferOut->RightData[l]) * 0.5 * powerRatioFollow);
                  }
                  else
                    for(l = 0; l < samples; l++)
                    {
                      powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                      audioBufferIn->MonoData[l] += ((audioBufferOut->LeftData[l] + 
                        audioBufferOut->RightData[l]) * 0.5 * powerRatioFollow);
                    }
                }
                else
                {
                  if(powerRatioFollow == powerRatio)
                  {
                    Mix(samples, audioBufferOut->MonoData, audioBufferIn->MonoData, powerRatio);
                    // for(l = 0; l < samples; l++)
                    // {
                    //   audioBufferIn->MonoData[l] += audioBufferOut->MonoData[l] * powerRatioFollow;
                    // }
                  }
                  else
                    for(l = 0; l < samples; l++)
                    {
                      powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                      audioBufferIn->MonoData[l] += audioBufferOut->MonoData[l] * powerRatioFollow;
                    }
                }
              }
              connector->Connections[k]->PowerRatioFollow = powerRatioFollow;
            }
          }
        
      }
    }

    for(i = 0; i < ConnectorCount; i++)
    {
      connector = Connectors[i];
      port = connector->Port;

      if((port->Type & PT_INPUT) == PT_INPUT) // input port
      {
        if((port->Type & PT_CONTROL) == PT_CONTROL)
        {
          connector->Future->MoveFuture(port->ControlBuffer, Core->Host->GetBlockSamples());
        }
      }
    }

    Machine->Work();

    if(hasAUX)
    {
      for(i = 0; i < ConnectorCount; i++)
      {
        connector = Connectors[i];
        port = connector->Port;
        if((port->Type & PT_INPUT) == PT_INPUT) // input port
        {
          if((port->Type & PT_AUX) == PT_AUX)
            for(j = 0; j < connector->ConnectionCount; j++) // work inputs
            {
              CMachineContainer *container;

              connection = connector->Connections[j];
              container  = connection->Input->Container;
			  if(async)
                container->WorkAsync();
			  else
				container->Work(false);
            }
        }
      }

      for(i = 0; i < ConnectorCount; i++)
      {
        connector = Connectors[i];
        port = connector->Port;

        if((port->Type & PT_INPUT) == PT_INPUT) // input port
        {
          if((port->Type & PT_AUX) == PT_AUX)
            for(j = 0; j < connector->ConnectionCount; j++) // work inputs
            {
              CMachineContainer *container;

              connection = connector->Connections[j];
              container  = connection->Input->Container;
              if(async)
			    container->WaitAsync();
            }
        }
      }

      for(i = 0; i < ConnectorCount; i++)
      {
        connector = Connectors[i];
        port = connector->Port;

        if((port->Type & PT_AUX) == PT_AUX)
          if((port->Type & PT_AUDIO) == PT_AUDIO) // move audio data
            if((port->Type & PT_INPUT) == PT_INPUT)
          {
              audioBufferIn = port->AudioBuffer;

              for(k = 0; k < connector->ConnectionCount; k++)
              {
                audioBufferOut   = connector->Connections[k]->Input->Port->AudioBuffer;
                samples          = audioBufferIn->Samples;
                powerRatio       = connector->Connections[k]->PowerRatio;
                powerRatioFollow = connector->Connections[k]->PowerRatioFollow;

                if(audioBufferOut->Samples < samples)
                  samples = audioBufferOut->Samples;
                if(audioBufferIn->Stereo)
                {
                  if(audioBufferOut->Stereo)
                  {
                    if(powerRatioFollow == powerRatio)
                    {
                      Mix(samples, audioBufferOut->LeftData, audioBufferIn->LeftData, powerRatio);
                      Mix(samples, audioBufferOut->RightData, audioBufferIn->RightData, powerRatio);
                      // for(l = 0; l < samples; l++)
                      // {
                      //   audioBufferIn->LeftData[l]  += audioBufferOut->LeftData[l]  * powerRatioFollow;
                      //   audioBufferIn->RightData[l] += audioBufferOut->RightData[l] * powerRatioFollow;
                    }
                    else
                      for(l = 0; l < samples; l++)
                      {
                        powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                        audioBufferIn->LeftData[l]  += audioBufferOut->LeftData[l]  * powerRatioFollow;
                        audioBufferIn->RightData[l] += audioBufferOut->RightData[l] * powerRatioFollow;
                      }
                  }
                  else
                  {
                    if(powerRatioFollow == powerRatio)
                    {
                      Mix(samples, audioBufferOut->MonoData, audioBufferIn->LeftData, powerRatio);
                      Mix(samples, audioBufferOut->MonoData, audioBufferIn->RightData, powerRatio);
                      // for(l = 0; l < samples; l++)
                      // {
                      //   v = audioBufferOut->MonoData[l] * powerRatioFollow;
                      //   
                      //   audioBufferIn->LeftData[l]  += v;
                      //   audioBufferIn->RightData[l] += v;
                    }
                    else
                      for(l = 0; l < samples; l++)
                      {
                        powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                        
                        v = audioBufferOut->MonoData[l] * powerRatioFollow;
                        
                        audioBufferIn->LeftData[l]  += v;
                        audioBufferIn->RightData[l] += v;
                      }
                  }
                }
                else
                {
                  if(audioBufferOut->Stereo)
                  {
                    if(powerRatioFollow == powerRatio)
                    {
                      Mix(samples, audioBufferOut->LeftData,  audioBufferIn->MonoData, 0.5 * powerRatio);
                      Mix(samples, audioBufferOut->RightData, audioBufferIn->MonoData, 0.5 * powerRatio);
                      // for(l = 0; l < samples; l++)
                      // {
                      //   audioBufferIn->MonoData[l] += ((audioBufferOut->LeftData[l] + 
                       //    audioBufferOut->RightData[l]) * 0.5 * powerRatioFollow);
                    }
                    else
                      for(l = 0; l < samples; l++)
                      {
                        powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                        audioBufferIn->MonoData[l] += ((audioBufferOut->LeftData[l] + 
                          audioBufferOut->RightData[l]) * 0.5 * powerRatioFollow);
                      }
                  }
                  else
                  {
                    if(powerRatioFollow == powerRatio)
                    {
                      Mix(samples, audioBufferOut->MonoData, audioBufferIn->MonoData, powerRatio);
                      // for(l = 0; l < samples; l++)
                      // {
                      //   audioBufferIn->MonoData[l] += audioBufferOut->MonoData[l] * powerRatioFollow;
                      // 
                    }
                    else
                      for(l = 0; l < samples; l++)
                      {
                        powerRatioFollow = AdjustVolume(powerRatio, powerRatioFollow);
                        audioBufferIn->MonoData[l] += audioBufferOut->MonoData[l] * powerRatioFollow;
                      }
                  }
                }
                connector->Connections[k]->PowerRatioFollow = powerRatioFollow;
            }
          }
      }
      Machine->WorkAUX();
    }    
  }

  if(async)
    WorkSemaphore->Release();
}

void CMachineContainer::InitConnectors()
{
  int count;
  int i, x = 0;

  ConnectorPanel = new CControl(this, "ConnectorPanel", 0, 0, Width, CONNECTOR_PANEL_HEIGHT, false);
  ConnectorPanel->SetFont("Verdana", 7.0f, true);
  count = Machine->PortCount;
  ConnectorCount = count;
  Connectors = new CConnector*[count];
  for(i = 0; i < ConnectorCount; i++)
  {
    Connectors[i] = new CConnector(ConnectorPanel, x, 1, Machine->Ports[i], this);
    Connectors[i]->Show();
    x += Connectors[i]->Width + 2;
  }

  ConnectorPanel->Show();
}

void CMachineContainer::FreeConnectors()
{
  int i;

  for(i = 0; i < ConnectorCount; i++)
    delete Connectors[i];
  delete Connectors;
  Connectors = 0;
  delete ConnectorPanel;
  ConnectorPanel = 0;
  ConnectorCount = 0;
}

void CMachineContainer::PerformLayout()
{
  if(ProgramToolBar)
    ProgramToolBar->Resize(Width - 8, PROGRAM_TOOLBAR_HEIGHT);
  ConnectorPanel->Move(3, Height - (CONNECTOR_PANEL_HEIGHT + 3));
}

void CMachineContainer::AutoSize()
{
  int width, newWidth;
  int height, guiHeight, guiWidth;

  width = 32;

  newWidth = CalculateTitleWidth() + CHAMFER_SIZE + 8;
  if(width < newWidth)
    width = newWidth;

  if(ProgramToolBar)
  {
    if(width < PROGRAM_TOOLBAR_MIN_WIDTH)
      width = PROGRAM_TOOLBAR_MIN_WIDTH;
  }

  if(ConnectorCount > 0)
  {
    newWidth = Connectors[ConnectorCount - 1]->X + Connectors[ConnectorCount - 1]->Width;
    if(width < newWidth + 7)
      width = newWidth + 7;
    ConnectorPanel->Resize(newWidth, ConnectorPanel->Height);
  }

  GetGUISize(&guiWidth, &guiHeight);
  ChildPanel->Resize(guiWidth, guiHeight);

  guiWidth  += 8;
  guiHeight += 4;

  if(width < guiWidth)
    width = guiWidth;


  height = CONNECTOR_PANEL_HEIGHT + TITLE_HEIGHT + guiHeight + 3 + (ProgramToolBar ? PROGRAM_TOOLBAR_HEIGHT : 0);

  Resize(width, height);
}

void CMachineContainer::GetGUISize(int *width, int *height)
{
  RECT  rect;
  POINT point;

  switch(VisibleControl)
  {
    case CONTROL_DEFAULTGUI:
      *width  = DefaultGUI->Width;
      *height = DefaultGUI->Height;
      break;

    case CONTROL_CUSTOMGUI:
      GetWindowRect(CustomGUI, &rect);
      point.x = rect.right;
      point.y = rect.bottom;
      ScreenToClient(ChildPanel->Handle, &point);
      *width = point.x;
      *height = point.y;
      break;

    default:
      *width  = 40;
      *height = 40;
      break;
  }
}

int CMachineContainer::CalculateTitleWidth()
{
  HFONT oldFont;
  RECT  rect;
  HDC   hDC;

  hDC = BackDC;

  rect.left = 4;
  rect.top = 1;
  rect.right = Width;
  rect.bottom = TITLE_HEIGHT - 1;

  oldFont = (HFONT)SelectObject(hDC, (HFONT)TitleFont->Handle);
  DrawText(hDC, Name, (int)strlen(Name), &rect, DT_SINGLELINE | DT_CALCRECT);
  SelectObject(hDC, (HFONT)oldFont);

  return rect.right + TITLE_HEIGHT;
}

LRESULT CMachineContainer::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_LBUTTONDOWN:
    {
      Core->MainWindow->Studio->BringMachineToFront(this);
      Core->MainWindow->Studio->BeginUserMove(this);
      return 0;
    }
  }

  return CControl::WindowProc(hWnd, msg, wParam, lParam);
}

void CMachineContainer::SetRegion()
{
  HRGN  region;
  POINT points[5];

  points[0].x = 0;
  points[0].y = 0;
  points[1].x = Width - CHAMFER_SIZE;
  points[1].y = 0;
  points[2].x = Width;
  points[2].y = CHAMFER_SIZE;
  points[3].x = Width;
  points[3].y = Height;
  points[4].x = 0;
  points[4].y = Height;

  region = CreatePolygonRgn(points, 5, ALTERNATE);
  SetWindowRgn(Handle, region, TRUE);
}

void CMachineContainer::SetPropertyAutomated(int index, double value)
{
  Machine->SetProperty(index, value);
  if(DefaultGUI != 0)
    DefaultGUI->OnPropertyChange(index);
}

void CMachineContainer::Randomize()
{
  int i;
  
  Machine->Lock();
  Machine->BeforeSetProgram();
  for(i = 0; i < Machine->PropertyCount; i++)
    SetPropertyAutomated(i, (float)rand() / (float)RAND_MAX);
  Machine->AfterSetProgram();
  Machine->Release();
}

void CMachineContainer::Lock()
{
  Machine->Lock();
}

void CMachineContainer::Release()
{
  Machine->Release();
}

void CMachineContainer::OnIconPress()
{
  if(CustomGUI != 0)
    SetVisibleControl(CONTROL_CUSTOMGUI);
  else if(DefaultGUI != 0)
    SetVisibleControl(CONTROL_DEFAULTGUI);
}

void CMachineContainer::SetVisibleControl(int control)
{
  if(VisibleControl == CONTROL_CUSTOMGUI)
    Machine->OnHideGUI();

  VisibleControl = control;

  if(control != CONTROL_ICONBUTTON)
    IconButton->Hide();

  if(control != CONTROL_DEFAULTGUI)
    if(DefaultGUI != 0)
      DefaultGUI->Hide();

  if(control != CONTROL_CUSTOMGUI)
    if(CustomGUI != 0)
      ShowWindow(CustomGUI, SW_HIDE);

  if(control == CONTROL_ICONBUTTON)
  {
    ChildPanel->Hide();
    IconButton->Show();
  }

  if(control == CONTROL_DEFAULTGUI)
  {
    ChildPanel->Show();
    DefaultGUI->Show();
  }

  if(control == CONTROL_CUSTOMGUI)
  {
    ChildPanel->Show();
    ShowWindow(CustomGUI, SW_SHOW);
    Machine->OnShowGUI();
  }

  AutoSize();
  PerformLayout();
  SetRegion();
  DrawControl();

  Core->MainWindow->Studio->SizeScrollBars();
  Core->MainWindow->Studio->Update();
}

char *NewName = 0;

INT_PTR CALLBACK RenameDialogFunc(HWND hwndDlg,
    UINT uMsg,
    WPARAM wParam,
    LPARAM lParam
)
{
  if(uMsg == WM_CLOSE)
    EndDialog(hwndDlg, -1);
  if(uMsg == WM_COMMAND)
  {
    int id;

    id = GetDlgCtrlID((HWND)lParam);
    if(id == IDCANCEL)
      EndDialog(hwndDlg, -1);
    if(id == IDOK)
    {
      char name[1024];
      name[0] = 0;
      GetDlgItemTextA(hwndDlg, IDC_EDITNAME, name, 1023);
      NewName = CopyString(name);
      EndDialog(hwndDlg, 0);
    }
  }
  return FALSE;
}

bool RenameDialog(char **name, HWND hWnd)
{
  int s;

  s = (int)DialogBox(AppInstance, MAKEINTRESOURCE(IDD_RENAME), hWnd, RenameDialogFunc);
  if(s == 0)
  {
    if(NewName)
    {
      if(*name)
        delete *name;
      *name = NewName;
      NewName = 0;
      return true;
    }
  }
  return false;
}

void CMachineContainer::OnMenuItem(int item)
{
  switch(item)
  {
    case MENU_ID_HIDEGUI:
      SetVisibleControl(CONTROL_ICONBUTTON);
      break;

    case MENU_ID_SHOWDEFAULTGUI:
      SetVisibleControl(CONTROL_DEFAULTGUI);
      break;

    case MENU_ID_SHOWCUSTOMGUI:
      SetVisibleControl(CONTROL_CUSTOMGUI);
      break;
  
    case MENU_ID_RENAME:
      Core->MainWindow->Studio->ShowRenameDialog(this);
      break;

    case MENU_ID_RANDOMIZE:
      Randomize();
      break;   

    case MENU_ID_DELETE:
      Core->MainWindow->Studio->Lock();
      Core->MainWindow->Studio->RemoveMachine(this);
      Core->MainWindow->Studio->Release();
      break;

    case MENU_ID_GENPROGRAM:
    {
      FILE *f;
      char line[1024];
      char prop[1024];
      int  i;

      f = fopen("C:\\Program.txt", "wb");
      for(i = 0; i < Machine->PropertyCount; i++)
      {
        Machine->GetPropertyName(i, prop);
        sprintf(line, "%0.2f, // %s\n", Machine->GetProperty(i), prop);
        fwrite(line, strlen(line), 1, f);
      } 
      fclose(f);
  
      break;
    }
  }
}

void CMachineContainer::Rename(char *text)
{
  Machine->SetName(text);
  if(Name)
    delete Name;
  Name = CopyString(text);
  AutoSize();
  Update();
}

void CMachineContainer::UpdatePorts()
{
  FreeConnectors();
  ConnectorCount = 0;
  InitConnectors();
  AutoSize();
  PerformLayout();
}

void CMachineContainer::ReadProperties(char *data, int length, bool isInner)
{
  Machine->ReadProperties(data, length, isInner);
}

void CMachineContainer::WriteProperties(char **data, int *length, bool *isInner)
{
  Machine->WriteProperties(data, length, isInner);
}

#pragma pack(push)
#pragma pack(1)

struct ConnectionsHeader
{
  int ConnectionCount;
};

struct Connection
{
  int    Machine1;
  int    Connector1;
  int    Machine2;
  int    Connector2;
  double Volume;
};

struct OldConnection
{
  int    Machine1;
  int    Connector1;
  int    Machine2;
  int    Connector2;
  float  Volume;
};

#pragma pack(pop)

void CMachineContainer::WriteConnections(char **data, int *length)
{
  ConnectionsHeader   *ch;
  CConnector          *c;
  int connectionCount, i, j, n;
  Connection          *cn;
  CConnection         *ccn;

  connectionCount = 0;
  for(i = 0; i < ConnectorCount; i++)
  {
    c = Connectors[i];
    connectionCount += c->ConnectionCount;  
  }

  *length = sizeof(ConnectionsHeader) + (sizeof(Connection) * connectionCount);
  *data = new char[*length];

  ch = (ConnectionsHeader*)*data;
  ch->ConnectionCount = connectionCount;

  n = 0;
  for(i = 0; i < ConnectorCount; i++)
  {
    c = Connectors[i];
    for(j = 0; j < c->ConnectionCount; j++) 
    {
      cn = (Connection*)(*data + sizeof(ConnectionsHeader) + ((sizeof(Connection)) * n++)); 
      ccn = c->Connections[j];
      cn->Machine1 = ccn->Input->Port->Machine->Index;
      cn->Connector1 = ccn->Input->Port->Index;
      cn->Machine2 = ccn->Output->Port->Machine->Index;
      cn->Connector2 = ccn->Output->Port->Index;
      cn->Volume = ccn->PowerRatio;
    }
  }
}

void CMachineContainer::ReadConnections(char *data, int length, bool hasVolume, bool volumeIsFloat)
{
  ConnectionsHeader *ch;
  Connection *c;
  OldConnection *oc;
  int i;

  ch = (ConnectionsHeader*)data;

  for(i = 0; i < ch->ConnectionCount; i++)
  {
    if(volumeIsFloat)
    {
      oc = (OldConnection*)(data + sizeof(ConnectionsHeader) + ((sizeof(OldConnection) - (hasVolume ? 0 : 4)) * i));
      Core->MainWindow->Studio->ConnectConnectors(oc->Machine1, oc->Connector1, oc->Machine2, oc->Connector2, hasVolume ? (double)oc->Volume : 1.0);
    }
    else
    {
      c = (Connection*)(data + sizeof(ConnectionsHeader) + (sizeof(Connection) * i));
      Core->MainWindow->Studio->ConnectConnectors(c->Machine1, c->Connector1, c->Machine2, c->Connector2, c->Volume);
    }
  }
}

CProgramToolBar::CProgramToolBar(CMachineContainer *parent, int x, int y)
: CToolBar(parent, x, y, PROGRAM_TOOLBAR_MIN_WIDTH, PROGRAM_TOOLBAR_HEIGHT)
{
  int i;

  MachineContainer = parent;
  Label = new CLabel(this, "Program", 0, 0, PROGRAM_LABEL_WIDTH, PROGRAM_TOOLBAR_HEIGHT - 4, DT_VCENTER);
  AddControl(Label, "", Label->Handle, 4);
  DropList = new CDropList(this, "ProgramCombo", 0, 0, PROGRAM_COMBO_WIDTH, PROGRAM_COMBO_HEIGHT);
  AddControl(DropList, "Select Program", DropList->Handle);
  for(i = 0; i < MachineContainer->Machine->ProgramCount; i++)
  {
    char text[1024];
    MachineContainer->Machine->GetProgramNameIndexed(i, text);
    DropList->AddItem(text);
  }
}

CProgramToolBar::~CProgramToolBar()
{
  delete Label;
  delete DropList;
}

void CProgramToolBar::OnComboSelect(CDropList *comboBox)
{
  int i;

  if(comboBox == DropList)
  {
    MachineContainer->Machine->SetProgram(DropList->GetSelection());
    
    if(MachineContainer->DefaultGUI != 0)
      for(i = 0; i < MachineContainer->Machine->PropertyCount; i++)
        MachineContainer->DefaultGUI->OnPropertyChange(i);
  }
}