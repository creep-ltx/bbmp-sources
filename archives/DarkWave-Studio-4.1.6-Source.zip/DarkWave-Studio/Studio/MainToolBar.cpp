/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "MainToolBar.h"
#include "Util.h"
#include "Core.h"
#include "Label.h"
#include "UpDown.h"
#include "../Resource.h"

#define BUTTON_NEW  0
#define BUTTON_OPEN 1
#define BUTTON_SAVE 2

#define PEAK_METER_WIDTH  PEAK_METER_WIDTH_90
#define PEAK_METER_HEIGHT 18

#define MIN_BPM  1.0
#define MAX_BPM  1200.0
#define BPM_STEP 1.0

#define MIN_TPB  1.0
#define MAX_TPB  64.0
#define TPB_STEP 1.0

#define VOLUME_WIDTH         120
#define VOLUME_HEIGHT        26
#define VOLUME_RANGE_DB      40.0
#define VOLUME_MAX_GAIN      6.0
#define BUTTON_STUDIO        0
#define BUTTON_PATTERNEDITOR 1
#define BUTTON_BANKEXPLORER  2
#define BPM_LABEL_WIDTH      32
#define TPB_LABEL_WIDTH      32
#define LABEL_HEIGHT         14
#define BPM_UPDOWN_WIDTH     52
#define UPDOWN_HEIGHT        18
#define TPB_UPDOWN_WIDTH     52

CVolumeSlider::CVolumeSlider(CControl *parent)
: CSlider(parent, 0, 1, VOLUME_WIDTH, VOLUME_HEIGHT, SLIDER_HORIZONTAL)
{
  double dB;

  Value = 0.0;

  ToolTip = new CToolTip(parent->Handle);
  ToolTip->AddTool(Handle, "", true);
  
  if(Core->Volume == 0.0)
    SetValue(0.0);
  else
  {
    dB = PowerRatioTodB(Core->Volume) - VOLUME_MAX_GAIN;  
    SetValue(1.0 + (dB / VOLUME_RANGE_DB));
  }
}

void CVolumeSlider::OnChange(double newValue)
{
  double dB;
  char   text[32];
  RECT   r;
  
  if(newValue == 0.0)
  {
    Core->Volume = Core->Options->Audio.MasterVolume = 0.0;
    sprintf(text, "-Infinity dB");
  }
  else
  {
    dB = VOLUME_MAX_GAIN - ((1.0 - newValue) * VOLUME_RANGE_DB);
    Core->Volume = Core->Options->Audio.MasterVolume = dBToPowerRatio(dB);
    sprintf(text, "%.2f dB", PowerRatioTodB(Core->Volume));
  }
  
  CSlider::OnChange(newValue);
  ToolTip->UpdateText(Handle, text, true); 
  
  memset(&r, 0, sizeof(r));
  GetWindowRect(Handle, &r);
  
  ToolTip->TrackPosition(r.right, r.bottom);
}

void CVolumeSlider::BeforeChange()
{
  char text[32];
  RECT r;

  if(Core->Volume == 0.0)
    sprintf(text, "-Infinity dB");
  else
    sprintf(text, "%.2f dB", PowerRatioTodB(Core->Volume));

  ToolTip->UpdateText(Handle, text, true);
 
  memset(&r, 0, sizeof(r));
  GetWindowRect(Handle, &r);
  
  ToolTip->TrackPosition(r.right, r.bottom);  
  
  ToolTip->TrackActivate(Handle, true);
  
}

void CVolumeSlider::AfterChange()
{
  ToolTip->TrackActivate(Handle, false);
}


CMainToolBar::CMainToolBar(CControl *parent, int x, int y, int width, int height)
: CToolBar(parent, x, y, width, height)
{
  NewButton  = AddButton(IDI_NEW,  BUTTON_NEW,  20, 20, "New Project",  false);
  OpenButton = AddButton(IDI_OPEN, BUTTON_OPEN, 20, 20, "Open Project", false);
  SaveButton = AddButton(IDI_SAVE, BUTTON_SAVE, 20, 20, "Save Project", false);

  BPMLabel = new CLabel(this, "BPM:", 0, 0, BPM_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  AddControl(BPMLabel, "");
  BPMUpDown = new CUpDown(this, 0, 0, BPM_UPDOWN_WIDTH, UPDOWN_HEIGHT, MIN_BPM, MAX_BPM, BPM_STEP, Core->Host->GetBPM(), true);
  AddControl(BPMUpDown, "Beats Per Minute");
  
  TPBLabel = new CLabel(this, "TPB:", 0, 0, TPB_LABEL_WIDTH, LABEL_HEIGHT, DT_SINGLELINE | DT_RIGHT | DT_VCENTER);
  AddControl(TPBLabel, "");
  TPBUpDown = new CUpDown(this, 0, 0, TPB_UPDOWN_WIDTH, UPDOWN_HEIGHT, MIN_TPB, MAX_TPB, TPB_STEP, Core->Host->GetTPB(), true);
  AddControl(TPBUpDown, "Ticks Per Beat");

  VolumeSlider = new CVolumeSlider(this);
  AddControl(VolumeSlider, "Volume");

  PeakMeter = new CPeakMeter(this, 0, 0, PEAK_METER_WIDTH, PEAK_METER_HEIGHT);
  AddControl(PeakMeter, "Peak Meter (3dB Units)");
}

CMainToolBar::~CMainToolBar()
{
  delete NewButton;
  delete OpenButton;
  delete SaveButton;
  delete PeakMeter;
  delete BPMUpDown;
  delete BPMLabel;
  delete TPBUpDown;
  delete TPBLabel;
  delete VolumeSlider;
}

void CMainToolBar::OnToolBarButtonPress(CToolBarButton *button)
{
  if(button == NewButton)
  {
    Core->NewProject();
  }

  if(button == OpenButton)
  {
    Core->OpenProject();
  }

  if(button == SaveButton)
  {
    Core->SaveProject();
  }
}

void CMainToolBar::OnUpDownChange(CUpDown *upDown)
{
  if(upDown == BPMUpDown)
    Core->SetBPM(BPMUpDown->GetValue());

  if(upDown == TPBUpDown)
    Core->SetTPB(TPBUpDown->GetValue());
}

void CMainToolBar::Idle()
{
  PeakMeter->Lock();
  PeakMeter->Idle();
  PeakMeter->Release();
}