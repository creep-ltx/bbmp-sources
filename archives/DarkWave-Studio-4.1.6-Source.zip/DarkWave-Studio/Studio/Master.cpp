/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Master.h"
#include "Core.h"

CMasterInfo::CMasterInfo()
{
  Name = "Master";
  UniqueID = "Master";
}

CMachine *CMasterInfo::CreateMachine()
{
  return new CMaster(Core->Host);
}

CMaster::CMaster(CHost *host)
: CMachine(host)
{
  Ports = 0;
  PortCount = 0;

  InitPorts();
}

bool CMaster::IsSynth()
{
  return false;
}

bool CMaster::InitPorts()
{
  int i, channels;
  char name[32];

  channels = Core->AudioManager->GetOutputDriver()->GetNumChannels();

  if(channels == 1)
    if(PortCount == 1)
      if((Ports[0]->Type & PT_STEREO) == 0)
        return false;

  if(channels == 2)
    if(PortCount == 1)
      if((Ports[0]->Type & PT_STEREO) != 0)
        return false;

  if((channels > 2) && (channels == PortCount))
    return false;

  for(i = 0; i < PortCount; i++)
    delete Ports[i];
  PortCount = 0;

  if(Ports != 0)
  {
    delete Ports;
    Ports = 0;
  }

  
  switch(channels)
  {
    case 0:
    {
      break;
    }
    case 1:
    {
      Ports = new CPort*[1];
      Ports[0] = new CPort(Core->Host, this, PT_AUDIO | PT_INPUT | PT_MONO, "Line In");
      PortCount = 1;
      break;
    }
    case 2:
    {
      Ports = new CPort*[1];
      Ports[0] = new CPort(Core->Host, this, PT_AUDIO | PT_INPUT | PT_STEREO, "Line In");
      PortCount = 1;
      break;
    }
    default:
    {
      PortCount = channels;
      Ports = new CPort*[PortCount];
      for(i = 0; i < PortCount; i++)
      {
        sprintf(name, "Channel %i", i + 1);
        Ports[i] = new CPort(Core->Host, this, PT_AUDIO | PT_INPUT | PT_MONO, name);
      }
      break;
    }
  }

  return true;
}

CMaster::~CMaster()
{
  if(Ports)
  {
    delete Ports[0];
    delete Ports;
  }
}

void CMaster::Work()
{
}

void CMaster::SetSampleRate(int sampleRate)
{
}

void CMaster::SetBlockSamples(int blockSamples)
{
}