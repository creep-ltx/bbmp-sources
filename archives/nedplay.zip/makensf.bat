makedtt temp.ihd temp.dtt temp.dmc 0
ca65 nt2-22.asm
ld65 -C nsf.cfg -o song.nsf nt2-22.o -v
