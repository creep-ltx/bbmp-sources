/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MIDI_INPUT_DEVICE_H
#define MIDI_INPUT_DEVICE_H

#include <windows.h>
#include <mmsystem.h>

typedef void MIDIInputHook(void *userData, unsigned char status, unsigned char data1, unsigned char data2);

struct MIDIInputHookEntry
{
  MIDIInputHook *Hook;
  void          *UserData;
};

class CMIDIInputDevice
{
public:
       CMIDIInputDevice(unsigned int deviceID);
      ~CMIDIInputDevice();
  void Open();
  void Close();
  void AddHook(MIDIInputHook *hook, void *userData);
  void RemoveHook(MIDIInputHook *hook, void *userData);
  void OnMessage(unsigned int message, long param1, long param2);

  unsigned int ID;
  char        *Name;

private:
  void CallHooks(unsigned char status, unsigned char data1, unsigned char data2);

  MIDIInputHookEntry *Hooks;
  int                 HookCount;
  int                 OpenCount;
  HMIDIIN             Handle;
};

#endif