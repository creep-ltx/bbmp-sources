/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ROOMVIEW_H
#define ROOMVIEW_H

#include "SpatialVerb.h"
#include "ImageSource.h"

#define NODE_SRCLEFT  0
#define NODE_SRCRIGHT 1
#define NODE_DSTLEFT  2
#define NODE_DSTRIGHT 3

class CRoomView : public CLiteControl
{
public:
               CRoomView(CSpatialVerbGUI *parent, int x, int y, int width, int height, double alpha, CFrameBuffer *nodes, CSpatialVerb *machine);
              ~CRoomView();
  void         Update(CImageSource *leftImageSource, CImageSource *rightImageSource, SSize *roomSize, SPos *srcLeftPos, SPos *srcRightPos, SPos *dstLeftPos, SPos *dstRightPos, double totalTime);
  virtual void Draw(CFrameBuffer *frameBuffer);
  void         SetTime(double value);
  void         Render();
  void         NodePos(SPos *pos, int *x, int *y);
  void         RenderNode(int node);
  
  virtual void OnMouseMove(int x, int y);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);

  int          InNode(int x, int y);
  SPos        *NodePosPtr(int node);

private:
  CSpatialVerb    *Machine;
  CFrameBuffer    *RenderBuffer, *Nodes;
  CSpatialVerbGUI *GUI;
  double            Alpha;
  CImageSource    *LeftImageSource, *RightImageSource;
  SSize            RoomSize;
  SPos             SrcLeftPos, SrcRightPos, DstLeftPos, DstRightPos;
  double            TotalTime, Time;
  bool             ValidSource;
  int              CurrentNode, State, StartX, StartY;
  SPos             StartPos;
};

#endif