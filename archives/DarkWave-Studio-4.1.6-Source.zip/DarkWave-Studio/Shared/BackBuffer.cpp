/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "BackBuffer.h"

CBackBuffer::CBackBuffer(HDC targetDC, int width, int height)
{
  TargetDC = targetDC;
  Bitmap = 0;
  OldBitmap = 0;
  
  DC = CreateCompatibleDC(TargetDC);

  Resize(width, height);
}

CBackBuffer::~CBackBuffer()
{
  if(OldBitmap != 0)
  {
    SelectObject(DC, (HGDIOBJ)OldBitmap);
    OldBitmap = 0;
  }

  if(Bitmap != 0)
  {
    DeleteObject(Bitmap);
    Bitmap = 0;
  }

  if(DC != 0)
  {
    DeleteDC(DC);
    DC = 0;
  }
}

void CBackBuffer::Resize(int width, int height)
{
  if(OldBitmap != 0)
  {
    SelectObject(DC, (HGDIOBJ)OldBitmap);
    OldBitmap = 0;
  }

  if(Bitmap != 0)
  {
    DeleteObject(Bitmap);
    Bitmap = 0;
  }

  //if(DC != 0)
  //{
  //  DeleteDC(DC);
  //  DC = 0;
  //}

  //DC = CreateCompatibleDC(TargetDC);
  Bitmap = CreateCompatibleBitmap(TargetDC, width, height);
  OldBitmap = (HBITMAP)SelectObject(DC, (HGDIOBJ)Bitmap);
  Width = width;
  Height = height;
}

void CBackBuffer::Draw()
{
  Draw(0, 0, Width, Height);
}

void CBackBuffer::Draw(int x, int y, int width, int height)
{
  BitBlt(TargetDC, x, y, width, height, DC, x, y, SRCCOPY);
}