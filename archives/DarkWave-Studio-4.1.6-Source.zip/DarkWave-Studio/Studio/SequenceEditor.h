/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SEQUENCE_EDITOR_H
#define SEQUENCE_EDITOR_H

#include "Control.h"
#include "ToolBar.h"
#include "ScrollBar.h"
#include "DropList.h"
#include "MachineContainer.h"
#include "Array.h"
#include "Font.h"
#include "SizeBar.h"
#include "Sequence.h"
#include "Mutex.h"
#include "SequenceView.h"
#include "..\Resource.h"

class CUpDown;
class CLabel;

class CSequenceEditor : public CControl, public CHostMutex
{
public:
               CSequenceEditor(CControl *parent, int x, int y, int width, int height);
              ~CSequenceEditor();
  

          void AddTrack(CConnector *port);
  virtual void OnResize(int newWidth, int newHeight);
  void         PerformLayout();
  void         UpdatePatternCombo(int track);
  virtual void OnComboSelect(CDropList *comboBox);
  virtual void OnToolBarButtonPress(CToolBarButton *button);
  void         OnAddPattern(CPattern *pattern);
  void         OnRemovePattern(CPattern *pattern);
  void         Work();
  void         Play();
  void         Stop();
  void         OnUpDownChange(CUpDown *upDown);
  void         ResizeSequence(int newLength);
  void         Animate();
  void         RemoveMachine(CMachineContainer *machine);
  void         WriteSequence(char **buffer, int *size);
  void         ReadSequence(char *buffer, int size);
  void         ClearTracks();
  void         OnResizePattern(CPattern *pattern);

  CSequenceView  *SequenceView;

private:
  
  CSequence      *Sequence;
  CToolBar       *SequenceToolBar, *TrackToolBar;
  CDropList      *PatternCombo;
  CToolBarButton *PlayButton, *StopButton, *LoopButton, *RecordButton;
  double          PlayOffset;
  bool            Playing, Loop;
  CUpDown        *LengthUpDown;
  CLabel         *LengthLabel;
};

#endif