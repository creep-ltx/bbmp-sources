/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ConvertBlock.h"
#include <math.h>

void ConvertMonoFloatToMonoInt(float *in, short *out, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(out++) = ConvertAudioFloatToInt(*(in++));
  }
}

void ConvertMonoDoubleToMonoInt(double *in, short *out, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(out++) = ConvertAudioDoubleToInt(*(in++));
  }
}

void ConvertMonoDoubleToMonoByte(double *in, char *out, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(out++) = ConvertAudioDoubleToByte(*(in++));
  }
}

void ConvertMonoDoubleToMonoFloat(double *in, float *out, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(out++) = (float)*(in++);
  }
}

void ConvertMonoFloatToMonoDouble(float *in, double *out, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(out++) = (double)*(in++);
  }
}

void ConvertStereoDoubleToMonoFloat(double *inLeft, double *inRight, float *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = (float)*(inLeft++);
    *(outPtr++) = (float)*(inRight++);
  }
}

void ConvertStereoFloatToStereoFloat(float *inLeft, float *inRight, float *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = *(inLeft++);
    *(outPtr++) = *(inRight++);
  }
}

void ConvertStereoDoubleToStereoFloat(double *inLeft, double *inRight, float *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = (float)*(inLeft++);
    *(outPtr++) = (float)*(inRight++);
  }
}

void ConvertStereoDoubleToStereoInt(double *inLeft, double *inRight, short *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioDoubleToInt(*(inLeft++));
    *(outPtr++) = ConvertAudioDoubleToInt(*(inRight++));
  }
}

void ConvertStereoFloatToStereoInt(float *inLeft, float *inRight, short *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioFloatToInt(*(inLeft++));
    *(outPtr++) = ConvertAudioFloatToInt(*(inRight++));
  }
}

void ConvertStereoFloatToMonoInt(float *inLeft, float *inRight, short *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioFloatToInt((*(inLeft++) + *(inRight++)) * 0.5f);
  }
}  

void ConvertStereoDoubleToMonoInt(double *inLeft, double *inRight, short *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioDoubleToInt((*(inLeft++) + *(inRight++)) * 0.5f);
  }
}  

void ConvertStereoFloatToStereoByte(float *inLeft, float *inRight, char *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioFloatToByte(*(inLeft++));
    *(outPtr++) = ConvertAudioFloatToByte(*(inRight++));
  }
}

void ConvertStereoFloatToMonoByte(float *inLeft, float *inRight, char *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioFloatToByte((*(inLeft++) + *(inRight++)) * 0.5f);
  }
}  

void ConvertStereoDoubleToMonoByte(double *inLeft, double *inRight, char *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioDoubleToByte((*(inLeft++) + *(inRight++)) * 0.5);
  }
}

void ConvertStereoDoubleToStereoByte(double *inLeft, double *inRight, char *outPtr, unsigned int blockSize)
{
  while(blockSize--)
  {
    *(outPtr++) = ConvertAudioDoubleToByte(*(inLeft++));
    *(outPtr++) = ConvertAudioDoubleToByte(*(inRight++));
  }
}

