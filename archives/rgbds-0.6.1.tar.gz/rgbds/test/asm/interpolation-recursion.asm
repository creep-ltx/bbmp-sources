recurse EQUS "\{recurse\}"
{recurse}
