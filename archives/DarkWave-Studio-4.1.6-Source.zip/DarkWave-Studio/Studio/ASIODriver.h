/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ASIODRIVER_H
#define ASIODRIVER_H

#define IEEE754_64FLOAT 1

#include <windows.h>
#include <asio.h>
#include "asiodrivers.h"
#include "AudioOutputDriver.h"
#include "Mutex.h"

#define ASIO_MAX_NAME 256

struct SASIODeviceInfo
{
  char       Name[ASIO_MAX_NAME];
  int        DeviceFormats;
  long       MinBufferSize, MaxBufferSize, PreferredSize, Granularity;
  int        NumChannels;
};

class CASIODriver : public CAudioOutputDriver, private CHostMutex
{
public:
                       CASIODriver();
  virtual             ~CASIODriver();
  virtual void         SetWriteCallback(AudioOutputWriteCallback *funcPtr);
  virtual int          GetBlockSamples();
  virtual int          GetSampleRate();
  virtual char        *GetName();
  virtual void         Open();
  virtual void         Close();
          void         WriteBlock(int block);
          void         BlockFinished(int block);
          int          GetDeviceCount();
          char        *GetDeviceName(int index);
          int          GetDevice();
          int          GetDeviceFormats(int index);
          long         GetDeviceChannels(int index);
          char        *DescribeFormat(int format);
          void         FormatProperties(int format, int *sampleRate, int *bits, bool *stereo);
          int          GetFormat();
          int          ChooseFormat(int preferredFormat);
          void         SetDevice(int device);
          void         SetFormat(int format);
          int          GetLatency();
          void         SetLatency(int latency);
          int          GetMaxBufferSize(int index);
          int          GetMinBufferSize(int index);
          int          GetPreferredSize(int index);
          int          GetGranularity(int index);
          virtual int  GetNumChannels();
          virtual bool CanOpen();
           
private:
  AudioOutputWriteCallback *WriteCallback;
  int                       SampleRate, BlockSamples, Bits;
  double                  **MixBuffer;
  SASIODeviceInfo          *DeviceInfo;
  int                       DeviceCount;
  int                       Device, Format, Latency;
  int                       ChannelCount;
  void                    **Channels;
  AsioDrivers              *Drivers;
  ASIOBufferInfo           *BufferInfo;
  ASIOChannelInfo          *ChannelInfo;
  ASIOCallbacks             CallBacks;
  bool						          IsOpen;
};
  
#endif
