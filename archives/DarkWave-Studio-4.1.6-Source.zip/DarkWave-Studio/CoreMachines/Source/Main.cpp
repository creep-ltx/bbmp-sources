/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "DarkPlug.h"
#include "BassHead.h"
#include "Echo.h"
#include "Kick.h"
#include "DrumKit.h"
#include "SpatialVerb.h"
#include "Core.h"
#include "AntiAliasFilter.h"
#include "Mixer.h"
#include "Distort.h"
#include "Crunch.h"
#include "StereoSplitter.h"
#include "StereoJoiner.h"

void DARKCALL DarkPlugInit(HINSTANCE dllInstance, CHost *host)
{
  Core = new CCore(dllInstance, host, host->GetCPUFeatures());
  host->RegisterMachineInfo(new CAntiAliasFilterInfo(host));
  host->RegisterMachineInfo(new CBassHeadInfo(host));
  host->RegisterMachineInfo(new CBassHeadPolyphonicInfo(host));
  host->RegisterMachineInfo(new CCrunchInfo(host));
  host->RegisterMachineInfo(new CDistortInfo(host));
  host->RegisterMachineInfo(new CDrumKitInfo(host));
  host->RegisterMachineInfo(new CEchoInfo(host));
  host->RegisterMachineInfo(new CKickInfo(host));
  host->RegisterMachineInfo(new CMixerInfo(host));
  host->RegisterMachineInfo(new CSpatialVerbInfo(host));
  host->RegisterMachineInfo(new CStereoJoinerInfo(host));
  host->RegisterMachineInfo(new CStereoSplitterInfo(host));
}