/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include "RIFFLoader.h"
#include "Error.h"

#ifdef _DEBUG
  #define DEBUGPRINT
#endif


CRIFFLoader::CRIFFLoader()
{
  Data = 0;
}

CRIFFLoader::~CRIFFLoader()
{
  if(Data != 0)
    delete Data;
}

EError CRIFFLoader::Load(char *fileName, unsigned int type)
{
  FILE            *f;
  size_t           n;
  SRIFFHeaderChunk header;
  char            *data;
  EError           error;
#ifdef _DEBUGPRINT
  char            *shortName, *scan;

  if(Data != 0)
  {
    delete Data;
    Data = 0;
  }

  shortName = fileName;
  scan = fileName;
  while(scan[0] != 0)
  {
    if(scan[0] == '\\' || scan[0] == '/')
      shortName = scan + 1;
    scan++;
  }

  DebugPrint("--- Loading RIFF File '%s' ---\n", shortName);
#endif

  f = fopen(fileName, "rb");
  if(f == 0)
    return errorCantAccessFile;

  n = fread(&header, sizeof(SRIFFHeaderChunk), 1, f);
  if(n != 1)
  {
    fclose(f);
    return errorBadFile;
  }

  if(header.Type != CHUNKTYPE_RIFF)
  {
    fclose(f);
    return errorBadFile;
  }

  if(header.FormType != type)
  {
    fclose(f);
    return errorBadFile;
  }

  data = new char[header.Length - 4];
  n = fread(data, header.Length - 4, 1, f);
  fclose(f);
  if(n != 1)
    return errorBadFile;

  error = ParseList((SRIFFListChunk*)&header, data, 0, RIFF_CONTEXT_MAIN);

#ifdef _DEBUGPRINT
  if(error == errorOK)
    DebugPrint("--- Succesfully Loaded RIFF File '%s' ---\n", shortName);
#endif

  if(error == errorOK)
    Data = data;
  else
    delete data;

  return error;
}

EError CRIFFLoader::ParseList(SRIFFListChunk *chunk, char *data, unsigned int level, int context)
{
  unsigned int offset;
  SRIFFChunk  *subChunk;
  char        *subData;
  EError       error;

  #ifdef _DEBUGPRINT
    unsigned int i;
    for(i = 0; i < (level << 1); i++)
      DebugPrint(" ");
    DebugPrint("List  Type: '%c%c%c%c'\n", BYTE(0, chunk->ListType), BYTE(1, chunk->ListType), BYTE(2, chunk->ListType), BYTE(3, chunk->ListType));
  #endif

  offset = 0;
  while(offset + sizeof(SRIFFChunk) < chunk->Length + 4)
  {
    subChunk = (SRIFFChunk*)(data + offset);
    #ifdef _DEBUGPRINT
      for(i = 0; i < ((level << 1) + 2); i++)
        DebugPrint(" ");
      DebugPrint("Chunk Type: '%c%c%c%c'\n", BYTE(0, subChunk->Type), BYTE(1, subChunk->Type), BYTE(2, subChunk->Type), BYTE(3, subChunk->Type));
    #endif    
    
    if(subChunk->Type == CHUNKTYPE_LIST)
      if(subChunk->Length < 4)
        return errorBadFile;

    if(subChunk->Length > (chunk->Length - offset + 4))
      return errorBadFile;

    if(subChunk->Type == CHUNKTYPE_LIST)
      subData = data + offset + sizeof(SRIFFListChunk);
    else
      subData = data + offset + sizeof(SRIFFChunk);

    error = ParseChunk((SRIFFChunk*)subChunk, subData, level + 1, context);
    if(error != errorOK)
      return error;

    offset += sizeof(SRIFFChunk) + subChunk->Length;
  }

  return errorOK;
}