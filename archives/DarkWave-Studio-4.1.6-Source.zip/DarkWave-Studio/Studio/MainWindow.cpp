/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "../Resource.h"
#include "MainWindow.h"
#include "Core.h"
#include "Error.h"

#define TOOLBAR_HEIGHT                    30
#define CONTROL_X                         8
#define CONTROL_Y                         36
#define CONTROL_WIDTH(width)              (width - 16)       
#define CONTROL_HEIGHT(height)            (height - 46)

CMainWindow::CMainWindow()
  : CWindow("DarkWave Studio", 640, 480, Core->ColorManager)
{
  HICON iconSmall, iconBig;
  HMENU menu;
  int i;

  CWindow::MakeBackBuffer();

  OptionsDialog = 0;

  iconSmall = Core->AppIconSmall;
  iconBig   = Core->AppIconLarge;

  SendMessage(CWindow::Handle, WM_SETICON, ICON_SMALL, (LPARAM)iconSmall);
  SendMessage(CWindow::Handle, WM_SETICON, ICON_BIG,   (LPARAM)iconBig);

  menu = LoadMenu(AppInstance, MAKEINTRESOURCE(IDM_MAINMENU));
  i = GetLastError();

  SetMenu(CWindow::Handle, menu);

  MainToolBar = new CMainToolBar((CWindow*)this, 0, 0, CWindow::Width, TOOLBAR_HEIGHT);
  MainToolBar->Show();

  TabControl = new CTabControl((CWindow*)this, CONTROL_X, CONTROL_Y, CONTROL_WIDTH(CWindow::Width), CONTROL_HEIGHT(CWindow::Height));

  PatternEditor = new CPatternEditor(TabControl, 8, 8, 64, 64);
  SequenceEditor = new CSequenceEditor(TabControl, 8, 8, 64, 64);
  HDRecorder = new CHDRecorder(TabControl, 8, 8, 64, 64);
  Studio = new CStudio(TabControl, PatternEditor, HDRecorder, 8, 8, 64, 64);
  BankExplorer = new CBankExplorer(Core->Host, TabControl, 8, 8, 64, 64);
  PresetEditor = new CPresetEditor(TabControl, 8, 8, 64, 64);
  ProjectInfo = new CProjectInfo(TabControl, 8, 8, 64, 64);

  TabControl->AddTab(Studio, "Studio", 0);
  TabControl->AddTab(PatternEditor, "Pattern Editor", 0);
  TabControl->AddTab(SequenceEditor, "Sequence Editor", 0);
  TabControl->AddTab(HDRecorder, "HD Recorder", 0);
  TabControl->AddTab(ProjectInfo, "Project Info", 0);

#ifdef _DEBUG
//  TabControl->AddTab(BankExplorer, "Bank Explorer", IDI_BANKEXPLORER);
//  TabControl->AddTab(PresetEditor, "Preset Editor", IDI_PRESETBANK);
#endif

  ShowControl(MAINWINDOW_CONTROL_STUDIO);
  TabControl->Show();

  CWindow::SubInit = true;
  SampleAnalyzer = 0;

  //OnResize(Width, Height);
}

CMainWindow::~CMainWindow()
{
  delete TabControl;
  delete BankExplorer;
  delete PresetEditor;
  if(OptionsDialog)
    delete OptionsDialog;
  delete Studio;
  delete MainToolBar;
  if(SampleAnalyzer)
    delete SampleAnalyzer;
  delete HDRecorder;
  delete PatternEditor;
  delete SequenceEditor;
  delete ProjectInfo;
}

void CMainWindow::OnClose()
{
  Core->Quit();
}

LRESULT CMainWindow::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch(msg)
  {
    case WM_COMMAND:
    {
      try
      {
        switch(LOWORD(wParam))
        {
          case ID_FILE_NEWPROJECT:
          {
            Core->NewProject();
            break;
          }
          case ID_FILE_OPENPROJECT:
          {
            Core->OpenProject();
            break;
          }
          case ID_FILE_SAVEPROJECT:
          case ID_FILE_SAVEPROJECTAS:
          {
              if(LOWORD(wParam) == ID_FILE_SAVEPROJECT)
              {
                Core->SaveProject();
              }
              if(LOWORD(wParam) == ID_FILE_SAVEPROJECTAS)
              {
                Core->SaveProjectAs();
              }
            break;
          }
          case ID_FILE_EXIT:
          {
            Core->Quit();
            break;
          }
          case ID_TOOLS_SAMPLEANALYZER:
          {
            if(SampleAnalyzer == 0)
              SampleAnalyzer = new CSampleAnalyzer();
            SampleAnalyzer->Show();
            break;
          }
          case ID_VIEW_STUDIO:
          {
            ShowControl(MAINWINDOW_CONTROL_STUDIO);
            break;
          }
          case ID_VIEW_PATTERNEDITOR:
          {
            ShowControl(MAINWINDOW_CONTROL_PATTERNEDITOR);
            break;
          }
          case ID_VIEW_SEQUENCEEDITOR:
          {
            ShowControl(MAINWINDOW_CONTROL_SEQUENCEEDITOR);
            break;
          }
          case ID_VIEW_HDRECORDER:
          {
            ShowControl(MAINWINDOW_CONTROL_HDRECORDER);
            break;
          }
          case ID_VIEW_PROJECTINFO:
          {
            ShowControl(MAINWINDOW_CONTROL_PROJECTINFO);
            break;
          }
          case ID_VIEW_OPTIONS:
          {
            if(!OptionsDialog)
              OptionsDialog = new COptionsDialog((CWindow*)this);
            OptionsDialog->Show();
            break;
          }
          case ID_HELP_CONTENTS:
          {
            Core->ShowHelp();
            break;
          }
          case ID_HELP_ABOUT:
          {
            Core->AboutBox->Show(SW_SHOW);
            break;
          }
        }
      }
      catch(char *theError)
      {
        DisplayError("%s", theError);
      }
      return 0;
    }
    default:
    {
      return CWindow::WindowProc(hWnd, msg, wParam, lParam);
    }
  }
}

void CMainWindow::OnResize(int newWidth, int newHeight)
{
  CWindow::OnResize(newWidth, newHeight);
 
  if(CWindow::SubInit)
  {
    MainToolBar->Resize(newWidth, TOOLBAR_HEIGHT);
    MainToolBar->Update();

    TabControl->Resize(CONTROL_WIDTH(newWidth), CONTROL_HEIGHT(newHeight));
  }
}

void CMainWindow::ShowControl(int control)
{
  TabControl->ShowTab(control);
}

void CMainWindow::DrawControl()
{
  ColorManager->Lock();
  ColorManager->GetBrush(ControlBack)->FillRect(BackDC, 0, 0, Width, Height);
  ColorManager->Release();
  //CControl::FillTexture(Core->FrameBuffers.Texture);
}