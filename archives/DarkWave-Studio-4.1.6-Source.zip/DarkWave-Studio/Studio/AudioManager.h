/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef AUDIOMANAGER_H
#define AUDIOMANAGER_H

#include "AudioOutputDriver.h"
#include "Array.h"

#define OUTPUT_DRIVER_NULL         0
#define OUTPUT_DRIVER_WAVE         1
#define OUTPUT_DRIVER_DIRECT_SOUND 2
#define OUTPUT_DRIVER_ASIO         3

class CAudioManager
{
public:
  CAudioManager();
 ~CAudioManager();

  void                OpenOutput(AudioOutputWriteCallback *funcPtr);
  void                CloseOutput();
  CAudioOutputDriver *GetOutputDriver(int index);
  CAudioOutputDriver *GetOutputDriver();
  int                 GetCurrentOutputDriver();
  int                 GetOutputDriverCount();
  
  int                          OutputDriver;
private:
  CArray<CAudioOutputDriver*> *OutputDrivers;
};

#endif