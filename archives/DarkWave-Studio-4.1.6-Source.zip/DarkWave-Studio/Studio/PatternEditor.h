/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef PATTERN_EDITOR_H
#define PATTERN_EDITOR_H

#include "Control.h"
#include "ToolBar.h"
#include "ScrollBar.h"
#include "NoteView.h"
#include "ControlView.h"
#include "DropList.h"
#include "MachineContainer.h"
#include "Array.h"
#include "Font.h"
#include "SizeBar.h"
#include "Pattern.h"
#include "Mutex.h"
#include "RenameDialog.h"

class CUpDown;

class CPatternEditor : public CControl, public CHostMutex
{
public:
               CPatternEditor(CControl *parent, int x, int y, int width, int height);
              ~CPatternEditor();
  virtual void OnResize(int newWidth, int newHeight);
  void         PerformLayout();
  void         AddMachine(CMachineContainer *machine);
  void         RemoveMachine(CMachineContainer *machine);
  virtual void OnSizeY(CSizeBar *sizeBar, int amount);
  bool         MachineHasValidPorts(CMachineContainer *machine);
  bool         IsValidPort(CPort *port);
  void         LoadPorts();
  void         OnComboSelect(CDropList *comboBox);
  void         AddPort(CConnector *port);
  void         InitStaticCombos();
  void         ClearPatterns();
  void         LoadMachine(CMachineContainer *machine);
  void         LoadMachinePatterns(bool clear);
  virtual void OnToolBarButtonPress(CToolBarButton *button);
  void         AddPattern();
  void         RemovePattern();
  void         DuplicatePattern();
  char        *GeneratePatternName();
  CPattern    *FindPattern(char *name);
  int          PatternIndex(CPattern *pattern);
  int          MachinePatternIndex(CPattern *pattern);
  void         LoadPattern(CPattern *pattern);
  virtual void OnScrollX(int newPos);
  void         Work();
  void         LoadPort(CConnector *port);
  void         Animate();
  void         SetBlockSamples(int blockSamples);
  void         SetSampleRate(int sampleRate);
  CArray<CPattern*>          *Patterns;
  void         WritePatterns(char **buffer, int *size, int machine);
  void         ReadPatterns(char *buffer, int size, int machine);
  CPattern*    GetPattern(int index);
  virtual void OnRenameDialogSuccess();
  void         UpdateMachineNames();
  virtual void OnUpDownChange(CUpDown *upDown);
  void         Transpose(int amount);

private:
  CToolBar                   *PatternToolBar, *NoteToolBar, *ControlToolBar;
  CScrollBar                 *ScrollBarH;
  CNoteView                  *NoteView;
  CControlView               *ControlView;
  CDropList                  *MachineCombo, *PatternCombo, *PortCombo, *PropertyCombo;
  CToolBarButton             *AddPatternButton, *RemovePatternButton, *RenamePatternButton;
  CToolBarButton             *PlayButton, *StopButton, *LoopButton;
  CToolBarButton             *AddControlTrackButton, *RemoveControlTrackButton;
  CToolBarButton             *EditModeButton, *SelectModeButton;
  CToolBarButton             *DuplicatePatternButton, *TransposeUpButton, *TransposeDownButton;
  int                         NoteViewHeight;
  float                       NoteViewPercent;
  CArray<CMachineContainer*> *Machines;
  CArray<CConnector*>        *Ports;
  CSizeBar                   *SizeBar;
  CMachineContainer          *CurrentMachine;
  CArray<CPattern*>          *MachinePatterns;
  CArray<int>                *Properties;
  CPattern                   *CurrentPattern;
  CConnector                 *CurrentPort;
  CRenameDialog              *RenameDialog;
  CUpDown                    *PatternLengthUpDown, *NoteLengthUpDown;
  CLabel                     *PatternLengthLabel,  *NoteLengthLabel;
};

#endif