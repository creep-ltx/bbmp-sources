/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DROP_LIST_H
#define DROP_LIST_H

#include "Menu.h"
#include "Array.h"

class CDropListItem 
{
public:
  CDropListItem(char *text, int id);
 ~CDropListItem();

  char *Text;
  int   ID;
};

class CDropList : public CControl
{
public:
               CDropList(CControl *parent, char *name, int x, int y, int width, int height);
              ~CDropList();
  int          AddItem(char *text);
  void         RemoveItem(int index);
  void         DrawButton(HDC hDC, int x, int y, int width, int height, bool up, bool pressed);
  virtual void OnSelChange();
  int          GetSelection();
  void         Clear();
  void         SetSelection(int selection);
  void         DrawCombo(HWND hWnd, HDC dc);
  virtual void DrawControl();
  virtual void OnLeftButtonDown(int x, int y);
  
private:
  CControl                *Parent;
  CMenu                   *Menu;
  bool                     Dropped;
  CArray<CDropListItem *> *Items;
  int                      CurrentSelection;
  CFont                   *Font;
  int                      NextID;
};

#endif