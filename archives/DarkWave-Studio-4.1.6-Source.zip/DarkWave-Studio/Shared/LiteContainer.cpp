/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "LiteContainer.h"

CLiteContainer::CLiteContainer(CControl *parent, int width, int height, CFrameBuffer *background)
: CControl(parent, "", 0, 0, width, height, true)
{
  Background = background;
  Border = false;

  if(Background)
    if(Background->GetWidth() != Width || Background->GetHeight() != Height || Background->GetAlpha() == true)
      throw "CLiteContainer : Invalid Background Picture";

  RenderBuffer = new CFrameBuffer(Width, Height, false);

  FirstControl = 0;
  Capture        = 0;

  SubInit = true;

  Render();
}

CLiteContainer::CLiteContainer(HWND parent, int width, int height, CFrameBuffer *background)
: CControl(parent, 0, "", 0, 0, width, height, true)
{
  Border = false;

  Background = background;

  if(Background)
    if(Background->GetWidth() != Width || Background->GetHeight() != Height || Background->GetAlpha() == true)
      throw "CLiteContainer : Invalid Background Picture";

  RenderBuffer = new CFrameBuffer(Width, Height, false);

  FirstControl = 0;
  Capture        = 0;

  SubInit = true;

  Render();
}

CLiteContainer::~CLiteContainer()
{
  delete RenderBuffer;
}

void CLiteContainer::Render()
{
  Render(0, 0, Width, Height);
}

void CLiteContainer::DrawBackground(int x1, int y1, int x2, int y2, int w, int h)
{
  if(Background)
    Background->Draw(RenderBuffer, x1, y1, x1, y1, w, h);
  else
  {
    if((Texture != 0) && SubInit)
      Texture->TextureFill(RenderBuffer, CControl::X, CControl::Y);
    else
      RenderBuffer->Fill(ColorManager->GetColor(ControlBack), x1, y1, w, h);
  }
}

void CLiteContainer::Render(int x, int y, int width, int height)
{
  int           x2, y2;
  CLiteControl *control;
 
  x2 = x + width  - 1;
  y2 = y + height - 1;

  if(x2 >= Width)
    x2 = Width - 1;

  if(y2 >= Height)
    y2 = Height - 1;

  if(x2 < 0 || y2 < 0)
    return;

  if(x < 0)
    x = 0;

  if(y < 0)
    y = 0;

  width  = x2 - x + 1;
  height = y2 - y + 1;

  if((width < 1) || (height < 1))
    return;

 RenderBuffer->SetClip(x, y, x2, y2);
 DrawBackground(x, y, x2, y2, width, height);

  control = FirstControl;
  while(control != 0)
  {
    if(control->InRect(x, y, x2, y2) && control->Visible)
      control->Draw(RenderBuffer);
    control = control->GetNext();
  }

  Lock();
  if(GetBackBuffer())
  {
    RenderBuffer->Draw(GetBackBuffer(), x, y, width, height);
    GetBackBuffer()->Draw(x, y, width, height);
  }
  Release();
}

void CLiteContainer::AddControl(CLiteControl *control)
{
  control->Attach(&FirstControl);
}

void CLiteContainer::RemoveControl(CLiteControl *control)
{
  control->Detach();
}

void CLiteContainer::SetCapture(CLiteControl *control)
{
  Capture = control;
  ::SetCapture(Handle);
}

void CLiteContainer::ReleaseCapture(CLiteControl *control)
{
  if(Capture == control)
  {
    Capture = 0;
    ::ReleaseCapture();
  }
}

CLiteControl *CLiteContainer::ControlAt(int x, int y)
{
  CLiteControl *control, *cc = 0;

  control = FirstControl;
  while(control != 0)
  {
    if(control->WantMouse && control->ContainsPoint(x, y))
      cc = control;
    control = control->GetNext();
  }

  return cc;
}

void CLiteContainer::OnMouseMove(int x, int y)
{
  CLiteControl *control;

  if(Capture)
    control = Capture;
  else
    control = ControlAt(x, y);

  if(control)
    control->OnMouseMove(x, y);
}

void CLiteContainer::OnLeftButtonDown(int x, int y)
{
  CLiteControl *control;

  if(Capture)
    control = Capture;
  else
    control = ControlAt(x, y);

  if(control)
    control->OnLeftButtonDown(x, y);
}

void CLiteContainer::OnLeftButtonUp(int x, int y)
{
  CLiteControl *control;

  if(Capture)
    control = Capture;
  else
    control = ControlAt(x, y);

  if(control)
    control->OnLeftButtonUp(x, y);
}

void CLiteContainer::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
}

void CLiteContainer::ShowToolTip(CLiteControl *control, char *text)
{
}

void CLiteContainer::OnPaint()
{
  Lock();
  if(GetBackBuffer())
  {
    if(RenderBuffer)
      RenderBuffer->Draw(GetBackBuffer());
    GetBackBuffer()->Draw();
  }
  Release();
}

void CLiteContainer::DrawControl()
{
}

void  CLiteContainer::OnLiteSliderDown(CLiteSlider *slider, double value)
{
}

void  CLiteContainer::OnLiteSliderChange(CLiteSlider *slider, double value)
{
}

void CLiteContainer::OnButtonClick(CLiteButton *button)
{
}