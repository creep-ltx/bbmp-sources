/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <string.h>
#include "MachineLoader.h"
#include "DarkPlug.h"
#include "Error.h"
#include "Core.h"

CMachineLoader::CMachineLoader()
{
  Entries = new CArray<CMachineLoaderEntry*>;
}

CMachineLoader::~CMachineLoader()
{
  while(Entries->Count > 0)
  {
    delete Entries->Items[Entries->Count - 1];
    Entries->RemoveItem(Entries->Count - 1);
  }
  
  delete Entries;
}

void CMachineLoader::SearchPath(char *path)
{
  int             length, dllPathLength;
  char           *searchPath, *dllPath;
  WIN32_FIND_DATA findData;
  HANDLE          findHandle;
  bool            foundFile;

  length = (int)strlen(path);
  searchPath = new char[length + 7];
  sprintf(searchPath, "%s\\*.dll", path);

  findHandle = FindFirstFile(searchPath, &findData); 
  if(findHandle != INVALID_HANDLE_VALUE)
  {
    foundFile = true;
    while(foundFile)
    {
      if((findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
      {
        dllPathLength = (int)strlen(findData.cFileName);
        dllPath = new char[length + dllPathLength + 2];
        sprintf(dllPath, "%s\\%s", path, findData.cFileName);
        LoadDLL(dllPath);
        delete dllPath;
      }
      foundFile = (FindNextFile(findHandle, &findData) != 0);
    }
    FindClose(findHandle);
  }
  delete searchPath;
}

void CMachineLoader::LoadDLL(char *path)
{
  HMODULE       module;
  DarkPlugInit  initFunc;
  char          text[1024];
  char          file[1024];
  size_t        i, j, n;

  j = 0;
  n = strlen(path);
  for(i = 0; i < n; i++)
    if(path[i] == '\\')
      j = i + 1;
  strcpy(file, path + j);

  sprintf(text, "Loading PlugIn Library %s...", file);
  Core->AboutBox->SetLabelText(text);

  module = LoadLibrary(path);
  initFunc = (DarkPlugInit)GetProcAddress(module, "DarkPlugInit");
  if(initFunc != 0)
    initFunc(module, Core->Host);
  else
    FreeLibrary(module);
}

void CMachineLoader::AddEntry(CMachineInfo *machineInfo)
{
  CMachineLoaderEntry *entry;

  entry = new CMachineLoaderEntry(machineInfo);  
  Entries->AddItem(entry);
}

int CMachineLoader::MenuPathDepth(char *machinePath)
{
  int i, j;
    
  if(strlen(machinePath) > 0)
    j = 1;
  else
    j = 0;
  
  for(i = 0; machinePath[i] != 0; i++)
    if(machinePath[i] == '\\')
      j++;
  
  return j;
}

void CMachineLoader::MenuPathItem(char *machinePath, int depth, char *pathItem)
{
  int i, j, k, l;  
   
  for(i = j = k = l = 0; ; i++)
  {
    if(machinePath[i] == '\\')
    {
      if(j > 0)
        k = l + 2;
      else
        k = l;
      l = i - 1;
      if(j == depth)
        break;
      j++;
    }
    if(machinePath[i] == 0)
    {
      if(j > 0)
        k = l + 2;
      else
        k = l;
      l = i - 1;
      break;
    }
  }
  
  for(i = k; i <= l; i++)
    pathItem[i - k] = machinePath[i];
  pathItem[i - k] = 0;
}

bool CMachineLoader::CompareMachineInfo(CMachineInfo *m1, CMachineInfo *m2)
{
  int s;
  int i, d1, d2, md;
  
  d1 = MenuPathDepth(m1->MenuPath);
  d2 = MenuPathDepth(m2->MenuPath);
  
  md = d1 < d2 ? d1 : d2;
  
  for(i = 0; i < md; i++)
  {
    char p1[1024];
    char p2[1024];
    
    MenuPathItem(m1->MenuPath, i, p1);
    MenuPathItem(m2->MenuPath, i, p2);
    
    _strlwr(p1);
    _strlwr(p2);
    
    s = strcmp(p1, p2);
    if(s > 0)
      return true;
    if(s < 0)
      return false;
  }

  if(d1 > d2)
    return false;
  
  if(d1 < d2)
    return true;
  
  
  char n1[1024];
  char n2[1024];
  
  strcpy(n1, m1->Name);
  _strlwr(n1);
  
  strcpy(n2, m2->Name);
  _strlwr(n2);
  
  s = strcmp(n1, n2);
  if(s > 0)
    return true;
  else
    return false;
}

void CMachineLoader::Sort()
{
  int  i;
  bool more;
  
  if(Entries->Count < 3)
    return;
  
  more = true;
  while(more)
  {  
    more = false;
    for(i = 1; i < (Entries->Count - 1); i++)
    {
      if(CompareMachineInfo(Entries->Items[i]->MachineInfo, Entries->Items[i + 1]->MachineInfo))
      {
        CMachineLoaderEntry *a, *b;

        a = Entries->Items[i];
        b = Entries->Items[i + 1];

        Entries->Items[i]     = b;
        Entries->Items[i + 1] = a;
        
        more = true;
      }      
      
    }
  }
}

void CMachineLoader::CreateMachine(char *name, CMachine **machine, CMachineInfo **machineInfo)
{
  CMachineLoaderEntry *entry;
  CMachineInfo        *info;
  int                  i;
  
  for(i = 0; i < Entries->Count; i++)
  {
    entry = Entries->Items[i];
    
    if(strcmp(entry->MachineInfo->Name, name) == 0)
    {
      info = entry->MachineInfo;
      *machine = info->CreateMachine();
      if(machineInfo != 0)
        *machineInfo = info;
      return;
    }
  }
  
  ThrowString("Machine <%s> Not Found", name);
}