/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Mutex.h"
#include "Error.h"

CHostMutex::CHostMutex()
{
  Mutex = CreateMutex(NULL, FALSE, NULL);
  if(Mutex == NULL)
    ThrowString("Can't Create Mutex, Error Code 0x%x", GetLastError());
  Locked = false;
}

CHostMutex::~CHostMutex()
{
  CloseHandle(Mutex);
}

void CHostMutex::Lock()
{
  DWORD s;

  s = WaitForSingleObject(Mutex, INFINITE);
  if(s == WAIT_OBJECT_0)
  {
    Locked = true;
  }
  else
    ThrowString("Can't Lock Mutex, Error Code 0x%x", s);
}

void CHostMutex::Release()
{
  if(Locked)
  {
    Locked = false;
    if(ReleaseMutex(Mutex) == 0)
      throw "Can't Release Mutex";
  }
  else
    throw "Mutex Not Locked, Can't Release";
}