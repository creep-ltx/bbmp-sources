/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef TOOLBARBUTTON_H
#define TOOLBARBUTTON_H

#include "Control.h"
#include "BackBuffer.h"

#define TOOLBARBUTTON_STYLE_DEFAULT 0
#define TOOLBARBUTTON_STYLE_TOGGLE  1

class CToolBarButton : public CControl
{
public:
               CToolBarButton(CControl *parent, int x, int y, int width, int height, int iconID, int iconWidth, int iconHeight, int id, int style);
              ~CToolBarButton();
  void         DrawControl();
  int          GetID();
  void         Redraw();
  void         AutoSizeWidth();
  virtual void OnMouseMove(int x, int y);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  virtual void OnLeftButtonDoubleClick(int x, int y);
  bool         GetPressed();
  void         SetPressed(bool value);
  virtual void OnCaptureChanged(HWND newCapture);
  CControl               *Parent;

private:
  HICON                   Icon;
  int                     IconWidth, IconHeight;
  int                     ID, State, Style;
  bool                    Pressed;
};


#endif