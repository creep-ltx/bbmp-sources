/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include <windows.h>
#include "SaveAsDialog.h"
#include "Error.h"

#ifdef WIN64

#pragma pack(push, 8)

typedef struct tagOFNA64 {
   DWORD        lStructSize;
   HWND         hwndOwner;
   HINSTANCE    hInstance;
   LPCSTR       lpstrFilter;
   LPSTR        lpstrCustomFilter;
   DWORD        nMaxCustFilter;
   DWORD        nFilterIndex;
   LPSTR        lpstrFile;
   DWORD        nMaxFile;
   LPSTR        lpstrFileTitle;
   DWORD        nMaxFileTitle;
   LPCSTR       lpstrInitialDir;
   LPCSTR       lpstrTitle;
   DWORD        Flags;
   WORD         nFileOffset;
   WORD         nFileExtension;
   LPCSTR       lpstrDefExt;
   LPARAM       lCustData;
   LPOFNHOOKPROC lpfnHook;
   LPCSTR       lpTemplateName;
   void *		pvReserved;
   DWORD        dwReserved;
   DWORD        FlagsEx;
} OPENFILENAME64;

#define OPENFILENAME OPENFILENAME64

#pragma pack(pop)

#endif

bool SaveAsDialog(char *filter, char *defExt, char *fileName, int *nFilterIndex)
{
  OPENFILENAME ofn;
  
  memset(&ofn, 0, sizeof(OPENFILENAME));
  ofn.lStructSize = sizeof(OPENFILENAME);
  ofn.lpstrFilter = filter;
  ofn.lpstrFile = fileName;
  ofn.nMaxFile = 1024;
  ofn.nFilterIndex = *nFilterIndex;
  ofn.Flags = OFN_NOREADONLYRETURN | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
  ofn.lpstrDefExt = defExt;

  if(GetSaveFileName((LPOPENFILENAMEA)&ofn) == FALSE)
    return false;
  else
  {
    *nFilterIndex = ofn.nFilterIndex;
    return true;
  }
}

bool OpenDialog(char *filter, char *defExt, char *fileName, int *nFilterIndex)
{
  OPENFILENAME ofn;
  
  memset(&ofn, 0, sizeof(OPENFILENAME));
  ofn.lStructSize = sizeof(OPENFILENAME);
  ofn.lpstrFilter = filter;
  ofn.lpstrFile = fileName;
  ofn.nMaxFile = 1024;
  ofn.nFilterIndex = *nFilterIndex;
  ofn.Flags = 0;
  ofn.lpstrDefExt = defExt;

  if(GetOpenFileName((LPOPENFILENAMEA)&ofn) == FALSE)
    return false;
  else
  {
    *nFilterIndex = ofn.nFilterIndex;
    return true;
  }
}


