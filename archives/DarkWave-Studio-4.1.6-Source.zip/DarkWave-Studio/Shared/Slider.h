/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SLIDER_H
#define SLIDER_H

#include "Control.h"
#include "BackBuffer.h"
#include "Pen.h"

#define SLIDER_HORIZONTAL 0
#define SLIDER_VERTICAL   1
#define SLIDER_BORDER     2

class CSlider : public CControl
{
public:
               CSlider(CControl *parent, int x, int y, int width, int height, int flags);
              ~CSlider();
  void         DrawControl();
  virtual void BeforeChange();
  virtual void OnChange(double newValue);
  virtual void AfterChange();
  void         SetValue(double newValue);
  void         DrawGroove(HDC hDC, int x, int y, int width, int height);
  void         DrawHandle(HDC hDC);
  void         HandleRect(int *x1, int *y1, int *x2, int *y2);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnRightButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  virtual void OnMouseMove(int x, int y);
          void ShowPopup(int x, int y);

protected:
  double       Value, StartValue;
  int          State, StartPos, Flags;
  bool         MouseCaptured;
  CControl    *Parent;
};

#endif