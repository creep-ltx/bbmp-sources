/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ImpulseView.h"
#include "Util.h"

CImpulseView::CImpulseView(CLiteContainer *parent, int x, int y, int width, int height, double dBRange, double alpha, bool twoTone)
: CLiteControl(parent, x, y, width, height)
{
  DBRange = dBRange;
  Alpha   = alpha;
  TwoTone = twoTone;
  RenderBuffer = new CFrameBuffer(Width, Height, true);
  RenderBuffer->Fill(0);
  RenderBuffer->DrawRect(0, 0, Width, Height, 0, (unsigned char)(Alpha * 0xFF));
}

CImpulseView::~CImpulseView()
{
  delete RenderBuffer;
}

void CImpulseView::Update(int samples, double *data)
{
  int            x, y, y2, s, alpha, alpha2, alpha3, maxAlpha, maxAlpha2;
  double          value, invDBRange, blend, blend2;
  unsigned char *pixel;
  
  RenderBuffer->Fill(0);
  maxAlpha = (int)(Alpha * 0xFF);
  maxAlpha2 = maxAlpha >> 1;
  RenderBuffer->DrawRect(0, 0, Width, Height, 0, (unsigned char)maxAlpha);
  invDBRange = 1.0f / DBRange;
  blend  = Alpha * 0.5f;
  blend2 = blend * 0.5f;

  alpha  = (int)(blend  * 0xFF);
  alpha2 = (int)(blend2 * 0xFF);

  for(s = 0; s < samples; s++)
  {
    if(data[s] == 0.0f)
      value = -DBRange;
    else
      value = PowerRatioTodB(data[s]);
    if(value < -DBRange)
      value = -DBRange;
    else if(value > 0.0f)
      value = 0.0f;
    value = -(value * invDBRange);

    x = (s * (Width - 2) / samples);
    y = floor_int(value * (Height - 2));

    for(y2 = y; y2 < Height - 2; y2++)
    {
      pixel = RenderBuffer->GetPixel4(x + 1, y2 + 1);
      if(y2 == y || !TwoTone)
      {
        alpha3 = pixel[3] + alpha;
        if(alpha3 > maxAlpha)
          alpha3 = maxAlpha;
      }
      else
      {
        alpha3 = pixel[3] + alpha2;
        if(alpha3 > maxAlpha2)
          alpha3 = maxAlpha2;
      }
      pixel[3] = (unsigned char)alpha3;
    }
  }

  Parent->Render(X, Y, Width, Height);
}

void CImpulseView::Draw(CFrameBuffer *frameBuffer)
{
  RenderBuffer->Draw(frameBuffer, X, Y, 0, 0, Width, Height);
}