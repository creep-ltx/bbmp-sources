/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "DarkPlugAdapter.h"

VstInt32 CDarkPlugAdapter::processEvents (VstEvents* events)
{
  int i;

  if(events)
  {
    for(i = 0; i < events->numEvents; i++)
    {
      VstEvent *event;
      VstMidiEvent *midi;

      event = events->events[i];
      if(event->type == kVstMidiType)
      {
        midi = (VstMidiEvent*)event;
        if(Machine->Ports[0]->Type && PT_CONTROL)
        {
          unsigned char status, data1, data2;

          SControlMessage message;
          status = midi->midiData[0];
          data1  = midi->midiData[1];
          data2  = midi->midiData[2];


          if(status >= 0x90 && status <= 0x9F && data2 == 0) // NoteOn, Velocity = 0
            status -= 0x10;                                  // Convert To NoteOff

          if(status >= 0x90 && status <= 0x9F) // NoteOn
          {
            memset(&message, 0, sizeof(SControlMessage));
            message.BlockSample = midi->deltaFrames;
            message.Type = CONTROL_MESSAGE_NOTE_ON;
            message.NoteOn.Note      = data1;
            Machine->Host->GetNoteFrequency(data1, &message.NoteOn.Frequency);
            message.NoteOn.Velocity  = ((1.0f / 127.0f) * (float)data2);
            Machine->Ports[0]->ControlBuffer->Write(&message);
          }

          if(status >= 0x80 && status <= 0x8F) // NoteOff
          {
            memset(&message, 0, sizeof(SControlMessage));
            message.BlockSample = midi->deltaFrames;
            message.Type = CONTROL_MESSAGE_NOTE_OFF;
            message.NoteOff.Note      = data1;
            Machine->Ports[0]->ControlBuffer->Write(&message);
          }
        }        
      }
    }
  }

  return 1;
}

CDarkPlugAdapter::CDarkPlugAdapter(CMachine *machine, audioMasterCallback audioMaster, int uid)
: AudioEffectX(audioMaster, machine->ProgramCount, machine->PropertyCount)
{
  int i;

  InPort = OutPort = 0;
  UID          = uid;
  Machine      = machine;
  AudioMaster  = audioMaster;
  BlockSamples = 0;
  GUI          = 0;
  numParams    = Machine->PropertyCount;
  numPrograms  = Machine->ProgramCount;
  cEffect.numPrograms = Machine->ProgramCount;
  cEffect.numParams = Machine->PropertyCount;
  machine->Effect = getAeffect();
  for(i = 0; i < Machine->PortCount; i++)
  {
    if((InPort == 0) && (Machine->Ports[i]->Type == (PT_INPUT | PT_AUDIO | PT_STEREO)))
      InPort = Machine->Ports[i]; 
    
    if((OutPort == 0) && (Machine->Ports[i]->Type == (PT_OUTPUT | PT_AUDIO | PT_STEREO)))
      OutPort = Machine->Ports[i]; 
  }

  if(InPort)
    setNumInputs(2);
  else
    setNumInputs(0);
  if(OutPort)
    setNumOutputs(2);

  setUniqueID(uid);
  canProcessReplacing(true);

  this->cEffect.flags |= (effFlagsCanReplacing | effFlagsHasEditor | effFlagsCanDoubleReplacing);
  if(Machine->IsSynth())
	  this->cEffect.flags |= effFlagsIsSynth; 
  setEditor(this);
}

CDarkPlugAdapter::~CDarkPlugAdapter()
{
  editor = 0;
  if(Machine)
  {
    delete Machine;
    Machine = 0;
  }
}

void CDarkPlugAdapter::close()
{
  if(GUI != 0)
  {
    Machine->OnHideGUI();
    GUI = 0;
  }
}

bool CDarkPlugAdapter::beginSetProgram()
{
  Machine->BeforeSetProgram();
  return true;
}

bool CDarkPlugAdapter::endSetProgram()
{
  Machine->AfterSetProgram();
  return true;
}

VstInt32 CDarkPlugAdapter::beginLoadBank(VstPatchChunkInfo *ptr)
{
  return 1;
}

VstInt32 CDarkPlugAdapter::beginLoadProgram(VstPatchChunkInfo *ptr)
{
  return 1;
}


void CDarkPlugAdapter::processReplacing(float** inputs, float** outputs, VstInt32 sampleFrames)
{
  int i;
  CAudioBuffer *buffer;

  if(BlockSamples != sampleFrames)
  {
    Machine->SetBlockSamples(sampleFrames);
    BlockSamples = sampleFrames;
  }

  if(InPort)
  {
    buffer = InPort->AudioBuffer;
    for(i = 0; i < sampleFrames; i++)
    {
      buffer->LeftData[i]  = (double)inputs[0][i];
      buffer->RightData[i] = (double)inputs[1][i];
    }
  }

  Machine->Work();

  if(OutPort)
  {
    buffer = OutPort->AudioBuffer;
    for(i = 0; i < sampleFrames; i++)
    {
      outputs[0][i] = (float)buffer->LeftData[i];
      outputs[1][i] = (float)buffer->RightData[i];
    }
  }
}

void CDarkPlugAdapter::processDoubleReplacing(double** inputs, double** outputs, VstInt32 sampleFrames)
{
  int i;
  CAudioBuffer *buffer;

  if(BlockSamples != sampleFrames)
  {
    Machine->SetBlockSamples(sampleFrames);
    BlockSamples = sampleFrames;
  }

  if(InPort)
  {
    buffer = InPort->AudioBuffer;
    for(i = 0; i < sampleFrames; i++)
    {
      buffer->LeftData[i]  = inputs[0][i];
      buffer->RightData[i] = inputs[1][i];
    }
  }

  Machine->Work();

  if(OutPort)
  {
    buffer = OutPort->AudioBuffer;
    for(i = 0; i < sampleFrames; i++)
    {
      outputs[0][i] = buffer->LeftData[i];
      outputs[1][i] = buffer->RightData[i];
    }
  }
}

bool CDarkPlugAdapter::open(void* ptr)
{ 
  if(GUI != 0)
  {
    delete GUI;
    GUI = 0;
  }

  GUI = Machine->CreateGUI((HWND)(ptr));
  return false;
}

bool CDarkPlugAdapter::getRect(ERect** rect)
{
  *rect = &Rect;
  return Machine->GetGUIRect(&(*rect)->top, &(*rect)->left, &(*rect)->right, &(*rect)->bottom);
}

void CDarkPlugAdapter::setParameter(VstInt32 index, float value)
{
  Machine->SetProperty(index, value);
}

float CDarkPlugAdapter::getParameter(VstInt32 index)
{
  float p;

  p = (float)Machine->GetProperty(index);
  return p;
}

void CDarkPlugAdapter::setParameterAutomated(VstInt32 index, float value)
{
  Machine->SetPropertyAutomated(index, value);
}

void CDarkPlugAdapter::getParameterLabel(VstInt32 index, char* label)
{
  label[0] = 0;
}

inline void strcpy_n(char *dst, unsigned int nBytes, char *src)
{
  while(nBytes--)
  {
    if(nBytes == 0)
	{
	  *dst = 0;
	  break;
    }

    *(dst) = *(src++);
	if(*dst == 0)
		break;
	dst++;
  }
}

void CDarkPlugAdapter::getParameterDisplay(VstInt32 index, char* text)
{
  char buffer[MAX_PROPERTY_DISPLAY_STRING];
  buffer[0] = 0;
  Machine->GetPropertyValueDisplay(index, Machine->GetProperty(index), buffer);
  strcpy_n(text, kVstMaxParamStrLen, buffer);
}

void CDarkPlugAdapter::getParameterName(VstInt32 index, char* text)
{
  char buffer[MAX_PROPERTY_NAME_STRING];
  buffer[0] = 0;
  Machine->GetPropertyName(index, buffer);
  strcpy_n(text, kVstMaxParamStrLen, buffer);
}

void CDarkPlugAdapter::setSampleRate(float sampleRate)
{
  Machine->SetSampleRate((int)sampleRate);
}

void CDarkPlugAdapter::setBlockSize(VstInt32 blockSize)
{
  Machine->SetBlockSamples(blockSize);
  Machine->ResizeAudioPorts(blockSize);
}

void CDarkPlugAdapter::setProgram(int program)
{
  Machine->SetProgram(program);
}

VstInt32 CDarkPlugAdapter::getProgram()
{
  return Machine->GetProgram();
}

void CDarkPlugAdapter::setProgramName(char *name)
{
  Machine->SetProgramName(name);
}

void CDarkPlugAdapter::getProgramName (char *name)
{
  char buffer[MAX_PROGRAM_NAME_STRING];

  Machine->GetProgramName(buffer);
  strcpy_n(name, kVstMaxProgNameLen, buffer);
}

bool CDarkPlugAdapter::getProgramNameIndexed(VstInt32 category, VstInt32 index, char* name)
{
  char buffer[MAX_PROGRAM_NAME_STRING];

  Machine->GetProgramNameIndexed(index, buffer);
  strcpy_n(name, kVstMaxProgNameLen, buffer);
  return true;
}

void CDarkPlugAdapter::idle()
{
  Machine->OnIdle();
}

CHostAdapter::CHostAdapter(audioMasterCallback audioMaster)
{
  AudioMaster = audioMaster;
}

CHostAdapter::~CHostAdapter()
{
}

EError CHostAdapter::RegisterMachineInfo(CMachineInfo *machineInfo)
{
  return errorNotImplemented; 
}

EError CHostAdapter::GetNoteFrequency(unsigned int note, double *frequency)
{
  return errorNotImplemented; 
}

EError CHostAdapter::GetBankServer(CBankServer **bankServer)
{
  return errorNotImplemented; 
}

void CHostAdapter::SetPropertyAutomated(CMachine *machine, int index, double value)
{
  Dispatch((AEffect*)machine->Effect, audioMasterAutomate, index, 0, 0, (float)value);  
}

int CHostAdapter::GetSamplePosition()
{
  return 0;
}

double CHostAdapter::GetBPM()
{
  return 120.0;
}

double CHostAdapter::GetTPB()
{
  return 16.0;
}

int CHostAdapter::GetSamplesPerTick()
{
  return (int)((60.0 / (GetBPM() * GetTPB())) * (double)GetSampleRate());
}


int CHostAdapter::GetSampleRate()
{
  return Dispatch(0, audioMasterGetSampleRate, 0, 0, 0, 0);
}

int CHostAdapter::GetBlockSamples()
{
  return Dispatch(0, audioMasterGetBlockSize, 0, 0, 0, 0);
}

bool CHostAdapter::Supports(ESupports code)
{
  return false;
}

int CHostAdapter::GetCPUFeatures()
{
  return 0;
}

VstIntPtr CHostAdapter::Dispatch(AEffect *effect, VstInt32 opcode, VstInt32 index, VstIntPtr value, void* ptr, float opt)
{
  return AudioMaster(effect, opcode, index, value, ptr, opt);
}

bool CDarkPlugAdapter::getVendorString(char *text)
{
  strcpy(text, "ExperimentalScene");
  return true;
}

bool CDarkPlugAdapter::getProductString(char *text)
{
  if(Machine->GetName())
  {
	strcpy_n(text, kVstMaxProductStrLen, Machine->GetName());
    return true;
  }
  else
    return false;
}
