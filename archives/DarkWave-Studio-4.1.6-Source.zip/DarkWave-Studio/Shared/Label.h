/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CLABEL_H
#define CLABEL_H

#include "Control.h"

class CFont;
class CBackBuffer;

class CLabel : public CControl
{
public:
               CLabel(CControl *parent, char *text, int x, int y, int width, int height, int flags);
              ~CLabel();
  void         DrawControl();
  void         SetText(char *text);
  void         SetWantClicks(bool newWantClicks);
  virtual void OnLeftButtonDown(int x, int y);

private:
  char        *Text;
  int          Flags;
  bool         WantClicks;
};

#endif