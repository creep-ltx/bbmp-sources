/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "TabControl.h"
#include "Core.h"

#define LABEL_HEIGHT    20
#define EXTRA_HEIGHT    2
#define TAB_AREA_HEIGHT (LABEL_HEIGHT + EXTRA_HEIGHT)
#define CHAMFER_WIDTH   10
#define ICON_WIDTH      16
#define ICON_HEIGHT     16

CTabControl::CTabControl(CControl *parent, int x, int y, int width, int height)
: CControl(parent, "TabControl", x, y, width, height, true)
{
  SetFont(new CFont(DC, "Verdana", 10.0f, true));
  CurrentControl = -1;
  Controls = new CArray<STabItem>();
  SubInit = true;
  Update();
}

CTabControl::~CTabControl()
{
  int i;

  for(i = 0; i < Controls->Count; i++)
  {
    if(Controls->Items[i].Icon)
      DestroyIcon(Controls->Items[i].Icon);
  }

  delete Controls;
}

void CTabControl::OnResize(int newWidth, int newHeight)
{
  int i;

  CControl::OnResize(newWidth, newHeight);

  if(SubInit)
  {
    for(i = 0; i < Controls->Count; i++)
      SizeControl(i);
  }
}

void CTabControl::SizeControl(int index)
{
  int width, height;

  width  = Width - 8;
  height = Height - (TAB_AREA_HEIGHT + 6);

  Controls->Items[index].Control->Resize(width, height);
}

void CTabControl::DrawControl()
{
  int     i;
  HDC     hDC;
  HGDIOBJ oldFont, oldPen, oldBrush;
  
  hDC = BackDC;

  ColorManager->Lock();

  ColorManager->GetBrush((ColorManagerColor)ControlBack)->FillRect(hDC, 0, 0, Width, Height);
  

 // CControl::FillTexture(Core->FrameBuffers.Texture);

  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)HighlightBack)->Handle);
  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)Black)->Handle);
  Rectangle(hDC, 0, LABEL_HEIGHT - 1, Width, Height);
  SelectObject(hDC, oldBrush);
  SelectObject(hDC, oldPen);

  ColorManager->GetBrush((ColorManagerColor)HighlightBack)->FillRect(hDC, 1, TAB_AREA_HEIGHT, Width - 2, Height - (TAB_AREA_HEIGHT + 1));

  ColorManager->Release();

  SetBkMode(hDC, TRANSPARENT);
  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)HighlightText));
  oldFont = SelectObject(hDC, Font->Handle);
  for(i = Controls->Count - 1; i >= 0; i--)
    if(i != CurrentControl)
      DrawTab(hDC, i);
  if(CurrentControl != -1)
    DrawTab(hDC, CurrentControl);
  SelectObject(hDC, oldFont);

}

void CTabControl::DrawTab(HDC hDC, int index)
{
  RECT     r;
  STabItem *item;
  int      x;
  POINT    p[4];
  HPEN     nullPen;
  HGDIOBJ  oldBrush, oldPen;

  item     = &Controls->Items[index];
  x = item->Left;
  
  p[0].x = x;
  p[0].y = LABEL_HEIGHT - 1;
  p[1].x = x + CHAMFER_WIDTH;
  p[1].y = 0;
  p[2].x = x + item->Width - (1 + CHAMFER_WIDTH);
  p[2].y = 0;
  p[3].x = x + item->Width - 1;
  p[3].y = p[0].y + 1;

  ColorManager->Lock();

  nullPen = CreatePen(PS_NULL, 0, 0);
  oldPen = SelectObject(hDC, nullPen);
  oldBrush = SelectObject(hDC, ColorManager->GetBrush((ColorManagerColor)HighlightBack)->Handle);
  Polygon(hDC, p, 4);
  SelectObject(hDC, oldBrush);
  SelectObject(hDC, oldPen);
  DeleteObject(nullPen);

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)ControlLight)->Handle);
  Polyline(hDC, p, 4);

  if(CurrentControl == index)
  {
    if(index > 0)
    {
      MoveToEx(hDC, 0, p[0].y, 0);
      LineTo(hDC, p[0].x, p[0].y);
    }
    if(index < Controls->Count - 1)
    {
      MoveToEx(hDC, p[3].x, p[0].y, 0);
      LineTo(hDC, Width - 1, p[0].y);
    }
  }

  SelectObject(hDC, oldPen);
  ColorManager->Release();

  x += CHAMFER_WIDTH + 2;

  if(item->Icon)
  {
    DrawIconEx(hDC, x, 2, item->Icon, 16, 16, 0, 0, DI_NORMAL);
    x += 18;
  }

  r.left   = x;
  r.top    = 1;
  r.bottom = LABEL_HEIGHT - 2;
  r.right  = r.left + item->Width - (CHAMFER_WIDTH + 1);

  DrawText(hDC, item->Label, (int)strlen(item->Label), &r, DT_SINGLELINE | DT_LEFT | DT_VCENTER);
}

void CTabControl::AddTab(CControl *control, char *name, int iconID)
{
  STabItem item;

  item.Control = control;
  item.Icon    = 0;
  item.Label   = name;
  item.Left    = 0;
  item.Width   = (2 * CHAMFER_WIDTH) + 4;

  control->Move(4, TAB_AREA_HEIGHT + 2);

  if(iconID != 0)
    item.Icon = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(iconID), IMAGE_ICON, 16, 16, 0);

  if(Controls->Count > 0)
    item.Left = Controls->Items[Controls->Count - 1].Left  +
                Controls->Items[Controls->Count - 1].Width -
                (CHAMFER_WIDTH);

  if(item.Icon)
    item.Width += 22;

  HFONT oldFont;
  RECT  rect;
  HDC   hDC;

  hDC = BackDC;

  memset(&rect, 0, sizeof(RECT));

  //rect.left = 4;
  //rect.top = 1;
  //rect.right = Width;
  //rect.bottom = TITLE_HEIGHT - 1;

  oldFont = (HFONT)SelectObject(hDC, Font->Handle);
  DrawText(hDC, item.Label, (int)strlen(item.Label), &rect, DT_SINGLELINE | DT_CALCRECT);
  SelectObject(hDC, (HFONT)oldFont);

  item.Width += rect.right - 1;

  Controls->AddItem(item);
  SizeControl(Controls->Count - 1);
}

void CTabControl::ShowTab(int index)
{
  int      i;
  CControl *control;

  if(index >= 0 && index < Controls->Count)
    CurrentControl = index;
  else
    CurrentControl = -1;

  for(i = 0; i < Controls->Count; i++)
  {
    control = Controls->Items[i].Control;
    if(i == index)
    {
      control->Show();
    }
    else
      control->Hide();
  }
  Update();
}

void CTabControl::OnLeftButtonDoubleClick(int x, int y)
{
  OnLeftButtonDown(x, y);
}

void CTabControl::OnLeftButtonDown(int x, int y)
{
  int       i, x1, x2;
  STabItem *item;

  if(y >= 0 && y < TAB_AREA_HEIGHT)
  {
    for(i = 0; i < Controls->Count; i++)
    {
      item = &Controls->Items[i];
      x1 = item->Left;
      x2 = item->Left + item->Width - 1;
      if(i > 0)
        x1 += CHAMFER_WIDTH >> 1;
      if(i < Controls->Count - 1)
        x2 -= CHAMFER_WIDTH >> 1;
      if(x >= x1 && x <= x2)
      {
        ShowTab(i);
        break;
      }
    }
  }
}