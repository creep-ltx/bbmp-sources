/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "IconList.h"
#include "Core.h"
#include "Font.h"

#define ROW_HEIGHT   64
#define LABEL_HEIGHT 24

CIconList::CIconList(CControl *parent, int x, int y, int width, int height, CFont *font)
: CControl(parent, "IconList", x, y, width, height, true)
{
  SelectedIndex = -1;

  Font = font;

  SetBorder(bs3DSunken);
  
  Icons  = new CArray<HICON>();
  Labels = new CArray<const char*>();

  SubInit = true;
  DrawControl();
}

CIconList::~CIconList()
{
  int i;

  for(i = 0; i < Icons->Count; i++)
    DestroyIcon(Icons->Items[i]);
  delete Icons;
  delete Labels;
}


void CIconList::DrawControl()
{
  HDC     hDC;
  int     i, x, y;
  RECT    r;
  HGDIOBJ oldFont;
  bool    resetColor = true;

  hDC = BackDC;

  x        = (Width - 32) >> 1;
  y        = (ROW_HEIGHT - (LABEL_HEIGHT + 32)) >> 1;
  r.left   = 2;
  r.right  = Width - 4;
  r.top    = y + 32;
  r.bottom = r.top + LABEL_HEIGHT;

  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)WindowWorkspace)->FillRect(hDC, 0, 0, Width, Height);

  oldFont = SelectObject(hDC, Font->Handle);

  for(i = 0; i < Icons->Count && y < Height; i++)
  {
    if(SelectedIndex == i)
    {
      ColorManager->GetBrush((ColorManagerColor)HighlightBack)->FillRect(hDC, 0, i * ROW_HEIGHT, Width, ROW_HEIGHT);
      SetBkColor(hDC, ColorManager->GetColor((ColorManagerColor)HighlightBack));
      SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)HighlightText));
      resetColor = true;
    }
    else
    {
      if(resetColor)
      {
        SetBkColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlBack));
        SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlText));
        resetColor = false;
      }
    }

    DrawIcon(hDC, x, y, Icons->Items[i]);
    DrawText(hDC, Labels->Items[i], (int)strlen(Labels->Items[i]), &r, DT_SINGLELINE | DT_VCENTER | DT_CENTER);
    
    y        += ROW_HEIGHT;
    r.top    += ROW_HEIGHT;
    r.bottom += ROW_HEIGHT;
  }

  SelectObject(hDC, oldFont);
  ColorManager->Release();
}

void CIconList::AddItem(int iconID, const char *label)
{
  HICON icon;

  icon = (HICON)LoadImage(AppInstance, MAKEINTRESOURCE(iconID), IMAGE_ICON,
    32, 32, LR_DEFAULTCOLOR);
  Icons->AddItem(icon);
  Labels->AddItem(label);
}

void CIconList::SelectItem(int index)
{
  SelectedIndex = index;
  Parent->OnIconListSelectItem(index);
}

void CIconList::OnLeftButtonDown(int x, int y)
{
  int item;

  item = y / ROW_HEIGHT;
  if(item < 0 || item >= Icons->Count)
    return;

  if(item != SelectedIndex)
  {
    SelectItem(item);
    Update();
  }
}