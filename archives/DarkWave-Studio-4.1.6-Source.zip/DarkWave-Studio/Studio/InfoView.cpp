/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#include "InfoView.h"
#include "Core.h"
#include "Util.h"

// CInfoItem

CInfoItem::CInfoItem(char *name, char *text)
{
  Name = 0;
  Text = 0;
  SetName(name);
  SetText(text);
  Expanded = false;
}

CInfoItem::~CInfoItem()
{
  delete Name;
  delete Text;
}

void CInfoItem::SetName(char *name)
{
  if(Name != 0)
    delete Name;
  Name = CopyString(name, &NameLength);
}

void CInfoItem::SetText(char *text)
{
  if(Text != 0)
    delete Text;
  Text = CopyString(text, &TextLength);
}

// CInfoView

CInfoView::CInfoView(CControl *parent, CFont *font, char *name, int x, int y, int width, int height, int itemHeight)
: CControl(parent, name, x, y, width, height, true),
  CBankClient(Core->Host)
{
  Header = 0;
  NamePercent = 0.25f;
  BankIndex = -1;
  Font = font;
  ItemHeight = itemHeight;
  Items = new CArray<CInfoItem*>();
  SubInit = true;
  SetBorder(bs3DSunken);
  Scale();
  DrawControl();
  ConnectBankServer();
}

CInfoView::~CInfoView()
{
  DisconnectBankServer();
  Clear();
  if(Header != 0)
    delete Header;
  delete Items;
}

void CInfoView::DrawControl()
{
  HDC     hDC;
  int     i, y;
  HGDIOBJ oldFont;

  hDC = BackDC;

  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)TextAreaBack)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();

  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaHighlightText));
  SetBkMode(hDC, TRANSPARENT);
  oldFont = SelectObject(hDC, Font->Handle);
  y = 0;

  if(Header)
  {
    DrawHeader(hDC);
    y += ItemHeight;
  }

  for(i = 0; i < Items->Count; i++)
  {
    y = DrawItem(hDC, i, y);
  }
  SelectObject(hDC, oldFont);
}

void CInfoView::SetHeader(char *text)
{
  if(Header)
    delete Header;
  Header = CopyString(text);
  Update();
}

int CInfoView::DrawItem(HDC hDC, int index, int y)
{
  RECT           r;
  CInfoItem     *item;
  bool           selected;
  COLORREF       oldTextColor;

  selected = false; //index == Selection;

  item = Items->Items[index];

  // Draw Info Name 

  r.left   = 0;
  r.right  = NameWidth - 1;
  r.top    = y;
  r.bottom = y + ItemHeight - 1;

  InflateRect(&r, -4, -1);

  if(selected)
  {
    oldTextColor = SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaSelText));
    ColorManager->Lock();
    ColorManager->GetBrush((ColorManagerColor)TextAreaSelBack)->FillRect(hDC, 0, y, NameWidth, ItemHeight);
    ColorManager->Release();
  }
  else
  {
    ColorManager->Lock();
    ColorManager->GetBrush((ColorManagerColor)TextAreaHighlightBack)->FillRect(hDC, 0, y, Width, ItemHeight);
    ColorManager->Release();
  }

  DrawText(hDC, item->Name, item->NameLength, &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS); 
  DrawCellBorder(hDC, 0, y, NameWidth, ItemHeight);
  
  if(selected)
  {
    SetTextColor(hDC, oldTextColor);
  }

  // Draw Info Text

  r.left   = NameWidth;
  r.right  = Width - 1;
  r.top    = y;
  r.bottom = y + ItemHeight - 1;

  InflateRect(&r, -4, -1);

  if(selected)
  {
    oldTextColor = SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaSelText));
    ColorManager->Lock();
    ColorManager->GetBrush((ColorManagerColor)TextAreaSelBack)->FillRect(hDC, NameWidth, y, TextWidth, ItemHeight);
    ColorManager->Release();
  }
  else
  {
    oldTextColor = SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)TextAreaText));
    ColorManager->Lock();
    ColorManager->GetBrush((ColorManagerColor)TextAreaBack)->FillRect(hDC, NameWidth, y, TextWidth, ItemHeight);
    ColorManager->Release();
  }

  DrawText(hDC, item->Text, item->TextLength, &r, DT_LEFT | DT_VCENTER | DT_END_ELLIPSIS); 
  DrawCellBorder(hDC, NameWidth, y, TextWidth, ItemHeight);
  SetTextColor(hDC, oldTextColor);

  return y + ItemHeight;
}

void CInfoView::DrawHeader(HDC hDC)
{
  RECT          r;
  COLORREF      oldTextColor;

  r.left   = 0;
  r.right  = Width - 1;
  r.top    = 0;
  r.bottom = ItemHeight - 1;

  InflateRect(&r, -4, -1);

  ColorManager->Lock();
  ColorManager->GetBrush((ColorManagerColor)HighlightBack)->FillRect(hDC, 0, 0, Width, ItemHeight);
  ColorManager->Release();

  oldTextColor = SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)HighlightText));  
  DrawText(hDC, Header, (int)strlen(Header), &r, DT_LEFT | DT_SINGLELINE | DT_VCENTER); 
  DrawCellBorder(hDC, 0, 0, Width, ItemHeight);
  SetTextColor(hDC, oldTextColor);

}


void CInfoView::DrawCellBorder(HDC hDC, int x, int y, int width, int height)
{
  HGDIOBJ oldPen;

  ColorManager->Lock();
  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)ControlShadow)->Handle);
  MoveToEx(hDC, x, y + height - 1, NULL);
  LineTo(hDC, x + width - 1, y + height - 1);
  LineTo(hDC, x + width - 1, y - 1);
  SelectObject(hDC, oldPen);
  ColorManager->Release();
}

void CInfoView::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
  {
    Scale();
    DrawControl();
  }
}

void CInfoView::Scale()
{
  NameWidth = (int)(Width * NamePercent);
  TextWidth = Width - NameWidth;
}

void CInfoView::ShowBank(int index)
{
  int count, i;
  EError error;

  Clear();

  if(index < 0)
    return;

  BankServer->Lock();
  error = BankServer->GetBankInfoCount(index, &count);
  if(error != errorOK)
  {
    BankServer->Release();
    return;
  }

  BankIndex = index;

  for(i = 0; i < count; i++)
  {
    char       *name, *text;
    int        nameLength, textLength;
    CInfoItem *item;

    error = BankServer->GetBankInfoNameLength(BankIndex, i, &nameLength);
    if(error == errorOK)
      error = BankServer->GetBankInfoTextLength(BankIndex, i, &textLength);
    if(error == errorOK)
    {
      name = new char[nameLength + 1];
      text = new char[textLength + 1];
      error = BankServer->GetBankInfoName(BankIndex, i, name);
    }
    if(error == errorOK)
      error = BankServer->GetBankInfoText(BankIndex, i, text);
    if(error == errorOK)
    {
      item = new CInfoItem(name, text);
      delete name, text;
      Items->AddItem(item);
    }
    if(error != errorOK)
    {
      BankServer->Release();
      return;
    }
  }

  BankServer->Release();

  Update();
}

void CInfoView::Clear()
{
  int i;

  BankIndex = -1;
  for(i = 0; i < Items->Count; i++)
    delete Items->Items[i];
  Items->Clear();
  Update();
}

void CInfoView::Update()
{
  DrawControl();
  OnPaint();
}