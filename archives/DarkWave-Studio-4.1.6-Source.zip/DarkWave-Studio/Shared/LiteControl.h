/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef LITECONTROL_H
#define LITECONTROL_H

class CLiteContainer;

#include "FrameBuffer.h"
#include "ListNode.h"

class CLiteControl : public CListNode<CLiteControl>
{
public:
               CLiteControl(CLiteContainer *parent, int x, int y, int width, int height);
              ~CLiteControl();
  virtual void Draw(CFrameBuffer *frameBuffer) = 0;
  bool         InRect(int x1, int y1, int x2, int y2);
  bool         InRect(int *x1, int *y1, int *x2, int *y2);
  virtual void OnMouseMove(int x, int y);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  void         SetCapture();
  void         ReleaseCapture();
  bool         ContainsPoint(int x, int y);
  int          X, Y, Width, Height;
  void         Hide();
  void         Show();

  bool Visible, WantMouse;

protected:
  CLiteContainer *Parent;
};

#endif