# Loader validation

What was actually measured, and how. Numbers are from the development record;
renders are diagnostic artifacts, regenerated locally rather than committed.

## 1. Parser cross-check against independent implementations

The container, order-list, pattern, row-token, instrument, and sample-location
algorithms were compared field-by-field against two independent reference
parsers — one Python, one standalone C++ — written from the same format
research.

| Check | Result |
| --- | --- |
| Container/header/pattern/global pass | 118/118 files in the then-current corpus snapshot |
| Per-channel row-token decode | 27,560/27,560 tracks, exact byte consumption |
| Pattern start/end row relation (`reserved`/`last_row`) | 100% corpus-wide |
| FX-chain slots (section 4) | 134/134 slots across 39 files |
| Sample sub-chunk size invariant | 1,221/1,221 located samples size-exact |
| Pre-0.76 instrument records | 499 records across 9 files, 872 sample sub-chunks located exactly |

"Exact byte consumption" means every chunk, record, and track closes on its
declared boundary with no slack bytes — the acceptance bar used throughout the
format research. The current Python verifier covers 140 files.

## 2. Compilation and reproducibility

Reproduced from nothing but a clone and the instructions in `README.md`:

1. `git clone https://github.com/OpenMPT/openmpt.git`, checked out at
   `0eafb124c` (libopenmpt 0.9.0-pre.13, r25644) and confirmed to contain no
   reference to `skm` or `ALIM3`.
2. Applied only the integration steps in `README.md`, with a script that fails
   if any documented anchor is missing. Resulting diff against pristine
   upstream: six files, ten insertions — `Sndfile.h` (2), `Sndfile.cpp` (1),
   `Tables.cpp` (1), `build/autotools/Makefile.am` (1),
   `build/android_ndk/Android.mk` (1), `contrib/fuzzing/all_formats.dict` (4).
   No core engine file is touched, so measurements reflect a stock `soundlib`.
3. Full clean build: 320 translation units, **no errors and no compiler
   warnings** under the project's standard warning set, C++23.
4. `bin/libopenmpt_test`, upstream's own regression suite, passes (`RESULT:
   PASS`), so the loader does not disturb existing formats.
5. Every file in the private corpus loads through this build: **171/171, with
   no load failures, no hangs and no crashes** (30 s per-file bound), and
   2293/2483 samples carry names.
6. Every `.skm` fixture in the research repository's public corpus loads
   through this build as its manifest says it should: **77/78 load, and the
   78th is the one marked `expected_parse: reject`**
   (`generated/truncated-inside-ogg-stream.skm`), which the loader rejects.
   The three other deliberately malformed Ogg fixtures — `ogg-bad-magic`,
   `ogg-inner-length-overrun`, `ogg-missing-ff-padding` — load with the
   unusable sample dropped rather than failing or crashing. This is the one
   figure here that is reproducible from two public clones and nothing else.

Note when reproducing item 6: `openmpt123 --info` exits 0 even for a file it
could not load, so a sweep must inspect its output for `errors loading` rather
than trusting the exit status. Both sweeps above were re-run under that stricter
check.

An earlier draft claimed renders were bit-identical to an independently
prepared checkout. That comparison was invalid — `openmpt123` is statically
linked and had not been rebuilt — and the claim is withdrawn. See section 5.

Separately, Kaitai-generated Python and C# parsers built from the same format
spec run across all 140 corpus files; the C# target builds on .NET 8.

The Ogg path was checked against a **stock, unpatched** `SampleFormatVorbis.cpp`:
all four Ogg-bearing corpus fixtures load. Excluding Skale's full four-byte
`01 00 FF FF` pad is therefore sufficient on its own, and this loader carries no
dependency on `openmpt-stb-vorbis-progress.patch`. Before the exclusion was
widened from two bytes to four, three of those four hung indefinitely on the
same stock tree.


## 3. Controlled single-variable fixtures

Each fixture changes one thing and is saved as both `.skm` and `.xm`, so
Skale's own XM export serves as decoded ground truth for identical musical
content. The numbers below are identifiers from the private research corpus,
which contains third-party material and is not distributed.

Where a behaviour is also covered by a redistributable fixture, the public
equivalent is named. Those are *separately authored* files in the research
repository under `tests/fixtures/`, not copies of the numbered ones — they
exercise the same format behaviour and can be used to re-check the loader
against it, but the results in the last column were established on the private
fixtures.

| Fixture | Isolates | Established result | Public equivalent |
| --- | --- | --- | --- |
| 69 | Sample loop fields | Start/end are absolute little-endian `u32` values | `generated/forward-loop-64-192.skm` |
| 70 | Stereo PCM16 | Stored length is interleaved values; channel order and signed PCM16 decode correct | `authentic/sample-stereo-pcm16-076.skm` |
| 71–72 | Mono PCM16, finetune | Original-mode preamp baseline, linear periods, full 8-bit finetune precision | `authentic/sample-mono-pcm16-pingpong-loop-076.skm` (PCM16 only) |
| 73 | PCM8 | Embedded PCM8 is signed; WAV import/export differs by XOR `0x80` | `authentic/sample-mono-pcm8-076.skm`, `authentic/sample-stereo-pcm8-076.skm` |
| 74–75 | Row timing | Default and non-default BPM/speed schedule exact row intervals | `generated/song-metadata-timing-4ch.skm` |
| 76 | Mixer strip | 0.76 fader is linear; `BAL=+0.5` is hard right | `authentic/mx-vol-076.skm`, `authentic/mx-bal-076.skm` |
| 77–78 | Loop playback | Forward endpoints copy directly; ping-pong needs IT endpoint behaviour | `generated/forward-loop-64-192.skm`, `generated/pingpong-loop-0-sample-end.skm` |
| 79–80 | Save modes / Ogg | "Perfect" converts to PCM16; "Ogg" preserves a decodable Vorbis stream | `authentic/sample-mono-ogg-081.skm` with its `-source-pcm-` baseline |
| 81–82 | Sample volume/pan | Volume is `SKM * 2`; sample pan uses a soft-balance law | `authentic/sp-vol-076.skm`, `authentic/sp-pan-076.skm` |
| 83 | Volume envelope | Enabled value 32 is a linear −6 dB envelope level | `authentic/envelope-edited-076.skm` with its `envelope-baseline-076.skm` |
| 84–85 | Legacy keymap | Pre-0.76 direct keymap selects the slots Skale displays | `authentic/keymap-two-sample-075.skm` |
| 86 | Channel-count gain | Skale is channel-count independent; compensate OpenMPT Original mode for 0.71+ | none |

## 4. Whole-song render comparison

Skale exported 44.1 kHz stereo 16-bit references with normalisation disabled and
VST/FX removed. A comparison script aligns both renders by their 10 ms RMS
envelopes and reports duration, onset, envelope correlation, level, stereo
balance, peaks, and clipping.

**`the dream engine.skm`** — version 0.70, 32 channels, 17 orders/patterns, 35
instruments, 34 PCM samples, no Ogg.

| Metric | Result |
| --- | --- |
| Duration | 120.0543 s vs Skale's 120.0239 s |
| 50 ms energy-envelope median error | −0.14 dB |
| Total energy error | +0.17 dB |
| Envelope correlation | 0.917 |
| Stereo balance | 1.71 dB right vs Skale's 0.48 dB (1.23 dB unexplained) |

This file established the version boundary in gain staging: applying the 0.71+
channel-count compensation to a 0.70 module made OpenMPT 2.98 dB too loud and
clipped 10,128 frames. Retaining Original mode's legacy attenuation for 0.70
produced the numbers above. Fixtures 83 and 86 confirm the 0.76 side.

**`aws_chords.skm`** — version 0.71, compared against a no-VST Skale export.

| Metric | Before envelope import | After |
| --- | --- | --- |
| 20 ms energy-envelope correlation | 0.806 | 0.969 |
| Median active-window level | +1.42 dB | −1.24 dB |
| Stereo balance | 0.16 dB left | 0.84 dB right (Skale: 0.36 dB right) |
| Clipped frames | 473 | 189 |

Duration 61.540 s vs Skale's 61.510 s. Removing the module's Freeverb2 and mda
Stereo plugins in Skale changed its own render by roughly 1.69 dB, confirming
Skale had resolved and loaded them — so the no-VST export is the correct
control for a loader that does not host plugins.

Treat whole-song comparisons as integration tests, not golden references.

## 5. Module-type change verification (2026-08-25)

The loader uses plain `MOD_TYPE_XM`. An intermediate revision used a composite
type (`MOD_TYPE_SKM = 0x40000000 | MOD_TYPE_XM`); the whole-song figures in
section 4 were originally produced with `MOD_TYPE_XM`, so this is a return to
the measured basis rather than a departure from it.

`GetType() == MOD_TYPE_XM` gates roughly fifteen sites in `Snd_fx.cpp` and
`Sndmix.cpp` — period/frequency conversion under linear slides, tempo handling,
fadeout — so the change can affect playback and was measured.

**Method note.** An earlier attempt at this comparison was invalid and its
result is withdrawn. `openmpt123` is statically linked, so rebuilding only
`bin/libopenmpt.so` between variants left the binary unchanged and every render
came from one executable; the "bit-identical" result it produced was an
artifact. The measurements below rebuild the full target per variant, and the
`openmpt123` mtime was checked to differ between runs (16:03:48 vs 16:04:53,
251 translation units recompiled and 10 binaries relinked each time).

**Sample data differs.** The variants are not bit-identical:

| Fixture | samples differing | max delta | RMS difference | first difference |
| --- | --- | --- | --- | --- |
| `the dream engine.skm` | 64.74% | 8703 | −10.8 dB rel. signal | t = 11.246 s |
| `aws_chords.skm` | 50.41% | 12104 | −16.4 dB rel. signal | t = 0.260 s |

**Fidelity does not.** Against the Skale references, via `compare_renders.py`
(10 ms window, 2 s alignment search):

| Metric | `MOD_TYPE_XM` | composite |
| --- | --- | --- |
| dream waveform corr | 0.81855 | 0.81870 |
| dream envelope corr | 0.87512 | 0.87324 |
| dream level delta | −1.643 dB | −1.654 dB |
| dream balance delta | 0.264 dB | 0.257 dB |
| aws waveform corr | 0.95154 | 0.94551 |
| aws envelope corr | 0.98026 | 0.97892 |
| aws level delta | +0.469 dB | +0.383 dB |
| aws balance delta | −0.093 dB | −0.072 dB |

Differences sit in the third and fourth decimal, and each variant wins some
metrics and loses others. Many samples differing while aligned correlation is
unchanged is the signature of a small phase/timing drift, not a systematic
change. **Neither variant is measurably closer to Skale.**

The case for `MOD_TYPE_XM` therefore rests on integration, not fidelity: it
needs no `Snd_defs.h` change, it preserves one of only two free `MODTYPE` bits,
and it makes `GetModSpecifications()` return `ModSpecs::xmEx` instead of falling
through to `default: ModSpecs::mod`, which declares `instrumentMax = 0`, no
envelopes, 64-row patterns and 31 samples for a loader that imports all four.

**Continuity with section 4.** Re-measuring `the dream engine` on this checkout
at section 4's 50 ms window gives envelope correlation 0.90564 against the
0.917 recorded there, with waveform correlation, level delta, balance, pitch and
recurrence unchanged. The residual reflects engine drift between the original
checkout and r25644. (At the tool's 10 ms default the same render reads 0.87512;
window size accounts for most of the apparent gap.)

## 6. Known gaps in the evidence

- Section 4 (VST/FX), section 5's buses and sends, section 6 (VSTi/routing), and
  native effects `0x10..0x13` are unimplemented and therefore untested.
- Three 0.76-family instrument records with 716/784-byte prefixes fall back to
  their first playable sample; their keymap encoding is unestablished.
- The volume column's non-plain families are undecoded; only the verified plain
  `0..128` family and the `xx 80` absent-volume sentinel are imported.
- Note value `0x80` is provisionally mapped to Note Cut on 315 corpus
  occurrences; `0x81` (Note Off) is verified.
- The load-time command-8 panning conversion tracks the active instrument only
  within a pattern, so a pattern entered with a held instrument, or reused under
  two different instruments, is approximated. See the comment in the source.
- The `mpt::Charset::Windows1252` choice for text fields is inferred from Skale
  being a Win32 application; it has not been confirmed against a module with
  high-byte characters.
