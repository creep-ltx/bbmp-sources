
#include "Core.h"
#include "DarkPlugAdapter.h"
#include "SpatialVerb.h"
#include "Resource.h"
#include "DetectCPU.h"

CCore    *Core = 0;
HINSTANCE AppInstance = 0;

CCore::CCore(int cpuFeatures, audioMasterCallback audioMaster)
{
  CPUFeatures  = cpuFeatures;

  SpatialVerbGraphics.Background = new CFrameBuffer(IDR_SPATIALVERB_BACKGROUND);
  SpatialVerbGraphics.Knob       = new CFrameBuffer(IDR_SPATIALVERB_KNOB);
  SpatialVerbGraphics.SliderH    = new CFrameBuffer(IDR_SPATIALVERB_SLIDER_H);
  SpatialVerbGraphics.SliderV    = new CFrameBuffer(IDR_SPATIALVERB_SLIDER_V);
  SpatialVerbGraphics.Nodes      = new CFrameBuffer(IDR_SPATIALVERB_NODES);
  SpatialVerbGraphics.LCDFont    = new CFrameBuffer(IDR_Y2KMUTTER);
    
  Host = new CHostAdapter(audioMaster);
}

CCore::~CCore()
{
  delete Host;
  delete SpatialVerbGraphics.Background;
  delete SpatialVerbGraphics.Knob;
  delete SpatialVerbGraphics.SliderH;
  delete SpatialVerbGraphics.SliderV;
  delete SpatialVerbGraphics.Nodes;
  delete SpatialVerbGraphics.LCDFont;
}


AudioEffect* createEffectInstance(audioMasterCallback audioMaster, HINSTANCE hInstance)
{
  AppInstance = hInstance;
  if(Core == 0)
    Core = new CCore(DetectProcessorFeatures(), audioMaster);
  return new CDarkPlugAdapter(new CSpatialVerb(Core->Host, &(Core->SpatialVerbGraphics)), audioMaster, 'ESSV');
}
