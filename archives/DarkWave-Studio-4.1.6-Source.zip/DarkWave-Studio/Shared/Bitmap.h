/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef BITMAP_H
#define BITMAP_H

#include <windows.h>
extern HINSTANCE AppInstance;

class CBitmap
{
public:
      CBitmap(int resourceID);
     ~CBitmap();
 void Draw(HDC targetDC, int srcX, int srcY, int width, int height, int dstX, int dstY);

  int Width, Height;

private:
  HBITMAP Bitmap;
  HDC     DC;
  HGDIOBJ OldBitmap;
};

#endif