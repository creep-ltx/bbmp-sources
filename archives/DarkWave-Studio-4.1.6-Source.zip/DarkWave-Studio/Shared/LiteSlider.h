/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef LITE_SLIDER_H
#define LITE_SLIDER_H

#include "LiteControl.h"
#include "LiteContainer.h"
#include "DarkPlug.h"

class CLiteSlider : public CLiteControl
{
public:
               CLiteSlider(CLiteContainer *parent, int x, int y, int size, bool vertical, CFrameBuffer *picture, CMachine *machine, int property);
               CLiteSlider(CLiteContainer *parent, int x, int y, int size, int knobOffsetY, CFrameBuffer *knob, CFrameBuffer *back, CMachine *machine, int property);
              ~CLiteSlider();
  virtual void Draw(CFrameBuffer *frameBuffer);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnMouseMove(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  void         SetValue(double value);
  void         ShowToolTip(double value);

private:
  CFrameBuffer *Knob, *Back;
  double        Value, StartValue;
  int           MaxDistance, Property, StartPos, KnobY;
  bool          Vertical, Moving;
  CMachine     *Machine;
};


#endif