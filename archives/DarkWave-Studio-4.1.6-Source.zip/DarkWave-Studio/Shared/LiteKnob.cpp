/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "LiteKnob.h"
#include <stdio.h>

CLiteKnob::CLiteKnob(CLiteContainer *parent, CMachine *machine, int property,
  CFrameBuffer *picture, int x, int y, int height)
  : CLiteControl(parent, x, y, picture->GetWidth(), height)
{
  Picture  = picture;
  Machine  = machine;
  Property = property;
  if(machine)
    Value = machine->GetProperty(Property);
  else
    Value = 0.5f;
  Steps    = picture->GetHeight() / Height;
  Moving   = false;
}

CLiteKnob::~CLiteKnob()
{
}

void CLiteKnob::Draw(CFrameBuffer *frameBuffer)
{
  int picture;
  int y;

  picture = (int)(Value * (Steps - 1));
  y = picture * Height;
  Picture->Draw(frameBuffer, X, Y, 0, y, Width, Height);
}

void CLiteKnob::OnLeftButtonDown(int x, int y)
{
  StartY     = y;
  StartValue = Value;
  Moving     = true;
  if(Machine)
  {
    Machine->Lock();
    ShowToolTip(Value);
    Machine->Release();
  }
  SetCapture();
}

void CLiteKnob::OnMouseMove(int x, int y)
{
  int   newStep;
  double newValue;

  if(!Moving)
    return;

  newValue = StartValue + ((StartY - y) / 100.0f);
  newStep  = (int)(newValue * (Steps - 1));
  if(newStep < 0)
    newStep = 0;
  else if(newStep > Steps - 1)
    newStep = Steps - 1;
  newValue = (double)newStep / (double)(Steps - 1);
  if(newValue != Value)
  {
    if(Machine)
    {
      Machine->Lock();
	  Parent->Lock();
      ShowToolTip(newValue);
      Machine->SetPropertyAutomated(Property, newValue);
      Parent->Release();
	  Machine->Release();
    }
    else
      SetValue(newValue);
  }
}

void CLiteKnob::OnLeftButtonUp(int x, int y)
{
  ReleaseCapture();
  Moving = false;
}

void CLiteKnob::SetValue(double value)
{
  Value = value;
  Parent->Render(X, Y, Width, Height);
}

double CLiteKnob::GetValue()
{
  return Value;
}

void CLiteKnob::ShowToolTip(double value)
{
  char name[MAX_PROPERTY_NAME_STRING], display[MAX_PROPERTY_DISPLAY_STRING], text[MAX_PROPERTY_NAME_STRING + MAX_PROPERTY_DISPLAY_STRING];

  Machine->GetPropertyName(Property, name);
  Machine->GetPropertyValueDisplay(Property, value, display);
  sprintf(text, "%s %s", name, display);
  Parent->ShowToolTip(this, text);
}