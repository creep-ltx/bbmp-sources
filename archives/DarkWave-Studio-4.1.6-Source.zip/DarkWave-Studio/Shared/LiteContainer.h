/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef LITE_CONTAINER_H
#define LITE_CONTAINER_H


#include "LiteSlider.h"
#include "LiteButton.h"
#include "Window.h"
#include "Mutex.h"

class CLiteSlider;

class CLiteContainer : public CControl, public CMutex
{
public:
                CLiteContainer(CControl *parent, int width, int height, CFrameBuffer *background);
                CLiteContainer(HWND parent, int width, int height, CFrameBuffer *background);
               ~CLiteContainer();
          void  Render();
          void  Render(int x, int y, int width, int height);
          void  AddControl(CLiteControl *control);
          void  RemoveControl(CLiteControl *control);
          void  SetCapture(CLiteControl *control);
          void  ReleaseCapture(CLiteControl *control);
  CLiteControl *ControlAt(int x, int y);
  virtual void  OnMouseMove(int x, int y);
  virtual void  OnLeftButtonDown(int x, int y);
  virtual void  OnLeftButtonUp(int x, int y);
  virtual void  OnLeftButtonDoubleClick(int x, int y);
  virtual void  OnLiteSliderDown(CLiteSlider *slider, double value);
  virtual void  OnLiteSliderChange(CLiteSlider *slider, double value);
  virtual void  OnButtonClick(CLiteButton *button);
  virtual void  ShowToolTip(CLiteControl *control, char *text);
  virtual void  OnPaint();
  virtual void  DrawBackground(int x1, int y1, int x2, int y2, int w, int h);
  virtual void  DrawControl();

  CFrameBuffer  *Background;
  CFrameBuffer  *RenderBuffer;
  CLiteControl  *FirstControl;
  CLiteControl  *Capture;
};

#endif