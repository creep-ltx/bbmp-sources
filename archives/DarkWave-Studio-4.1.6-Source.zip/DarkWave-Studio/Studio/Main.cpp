/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include <windows.h>

#include "Core.h"
#include "Error.h"

int __stdcall WinMain(HINSTANCE thisInstance, HINSTANCE prevInstance, LPSTR cmdLine, int cmdShow)
{
  if(!strcmp(cmdLine, "/DISABLEASIO"))
  {
    COptions *options;
    
    options = new COptions();
    options->Audio.DisableASIO = true;
    delete options;
    MessageBoxA(NULL, "ASIO Support Disabled", "DarkWave Studio", MB_OK);
    return 0;
  }

  if(!strcmp(cmdLine, "/ENABLEASIO"))
  {
    COptions *options;
    
    options = new COptions();
    options->Audio.DisableASIO = false;
    delete options;
    MessageBoxA(NULL, "ASIO Support Enabled", "DarkWave Studio", MB_OK);
    return 0;
  }

  Core = new CCore();
  
  try
  {
    if(Core->Init(thisInstance))
    {
    try
    {
      if(cmdLine[0] != 0)
      {
        if(cmdLine[0] == '\"' && cmdLine[strlen(cmdLine) - 1] == '\"')
        {
          cmdLine[strlen(cmdLine) - 1] = 0;
          Core->ProjectFileName = CopyString(cmdLine + 1);
          Core->ReadProject(cmdLine + 1);
          Core->DisplayProjectTitle();
          
        }
        else
        {
          Core->ProjectFileName = CopyString(cmdLine);
          Core->ReadProject(cmdLine);
          Core->DisplayProjectTitle();
        }
      }
      else
        Core->NewProject();

      Core->Run();
    }
    catch(char *theError)
    {
      DisplayError("%s", theError);
    }
      Core->Free();
    }
  }
  catch(char *theError)
  {
    DisplayError("%s", theError);
  }
  delete Core;

  return 0;
}