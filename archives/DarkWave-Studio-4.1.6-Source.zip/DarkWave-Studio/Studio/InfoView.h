/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INFOVIEW_H
#define INFOVIEW_H

#include "Control.h"
#include "BackBuffer.h"
#include "Font.h"
#include "DarkPlug.h"
#include "Array.h"

class CInfoItem
{
public:
       CInfoItem(char *name, char *text);
      ~CInfoItem();
  void SetName(char *name);
  void SetText(char *text);

  char *Name, *Text;
  int   NameLength, TextLength;
  bool  Expanded;
};

class CInfoView : public CControl, public CBankClient
{
public:
               CInfoView(CControl *parent, CFont *font, char *name, int x, int y, int width, int height, int itemHeight);
              ~CInfoView();
  void         DrawControl();
  virtual void OnResize(int newWidth, int newHeight);
  void         ShowBank(int index);
  void         Clear();
  void         Update();
  int          DrawItem(HDC hDC, int index, int y);
  void         Scale();
  void         DrawCellBorder(HDC hDC, int x, int y, int width, int height);
  void         DrawHeader(HDC hDC);
  void         SetHeader(char *text);

private:
  CArray<CInfoItem*> *Items;
  float               NamePercent;
  int                 BankIndex, ItemHeight, NameWidth, TextWidth;
  char               *Header;
};

#endif