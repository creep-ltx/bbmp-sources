/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "WaveOutDriver.h"
#include "Error.h"
#include "Core.h"
#include "ConvertBlock.h"
#include <math.h>
#include <stdio.h>
#include <mmsystem.h>

#define POSSIBLE_SAMPLE_RATE_COUNT 5
double PossibleSampleRates[POSSIBLE_SAMPLE_RATE_COUNT] = {11025.0, 22050.0, 44100.0, 48000.0, 96000.0};

bool CWaveOutDriver::CanOpen()
{
  return (DeviceCount > 0);
}

void CALLBACK WaveOutProc(HWAVEOUT waveOut, UINT msg, DWORD_PTR instanceData, 
  DWORD_PTR param1, DWORD_PTR param2)
{
  CWaveOutDriver *driver;

  if(msg == WOM_DONE)
  {
    driver = (CWaveOutDriver*)instanceData;
    driver->BlockFinished((LPWAVEHDR)param1);
  }
}

void DefaultWaveOutCallback(int nChannels, double **channels, int samples)
{
  int channel, sample;

  for(channel = 0; channel < nChannels; channel++)
  {
    for(sample = 0; sample < samples; sample++)
      channels[channel][sample] = 0.0;
  }
}

CWaveOutDriver::CWaveOutDriver()
{
  int i;

  SampleRate = 44100;
  BlockSamples = 4096;

  DeviceCount = waveOutGetNumDevs();
  DeviceCaps  = new WAVEOUTCAPS[DeviceCount];
  memset(DeviceCaps, 0, sizeof(WAVEOUTCAPS) * DeviceCount);
    
  for(i = 0; i < DeviceCount; i++)
    waveOutGetDevCaps(i, &DeviceCaps[i], sizeof(WAVEOUTCAPS));

  if(Core->Options->Audio.Driver == OUTPUT_DRIVER_WAVE)
  {
    if(Core->Options->Audio.WaveDevice < DeviceCount)
      Device = Core->Options->Audio.WaveDevice;
    if(Core->Options->Audio.WaveLatency < WAVE_MIN_LATENCY)
      SetLatency(WAVE_DEFAULT_LATENCY);
    else
      SetLatency(Core->Options->Audio.WaveLatency);
  }
  else
  {
    Device = 0;
    SetLatency(WAVE_DEFAULT_LATENCY);
  }

  if(DeviceCount < 1)
    Device = -1;

  if(Device != -1)
  {
	Format = ChooseFormat(Core->Options->Audio.WaveFormat);
	FormatProperties(Format, &SampleRate, &Bits, &Stereo);
  }

  WriteCallback = &DefaultWaveOutCallback;
  BlockSamples = CalcBlockSamples(Latency, SampleRate);
  Buffer[0] = 0;
  Buffer[1] = 0;
  WaveOut = 0;
  PlayBlocks = false;
}

CWaveOutDriver::~CWaveOutDriver()
{
}

char* CWaveOutDriver::GetName()
{
  return "Windows Waveform Audio";
}

int CWaveOutDriver::GetBlockSamples()
{
  return BlockSamples;
}

int CWaveOutDriver::GetSampleRate()
{
  return SampleRate;
}

void CWaveOutDriver::SetWriteCallback(AudioOutputWriteCallback *funcPtr)
{
  WriteCallback = funcPtr;
}

void CWaveOutDriver::Open()
{
  MMRESULT     s;
  WAVEFORMATEX format;
  int          block;
  int          bps;

  BlockSamples = Latency;
  
  Lock();

  bps  = Stereo ? 2 : 1;
  bps *= Bits == 16 ? 2 : 1;

  format.wFormatTag      = WAVE_FORMAT_PCM;
  format.nChannels       = Stereo ? 2 : 1;
  format.nSamplesPerSec  = SampleRate;
  format.wBitsPerSample  = Bits;
  format.nBlockAlign     = (format.nChannels * format.wBitsPerSample) / 8;
  format.nAvgBytesPerSec = format.nSamplesPerSec * format.nBlockAlign;
  format.cbSize          = 0;

  s = waveOutOpen(&WaveOut, Device, &format, (DWORD_PTR)&WaveOutProc, (DWORD_PTR)this,
    CALLBACK_FUNCTION);

  if(s != MMSYSERR_NOERROR)
  {
    WaveOut = 0;
    Release();
    DisplayError("WaveOut: waveOutOpen Failed <Error Code 0x%x>", s);
    return;
  }
  
  for(block = 0; block < 2; block++)
  {
    Buffer[block] = new char[BlockSamples * bps];
  
    memset(&Header[block], 0, sizeof(WAVEHDR));
    Header[block].lpData = (LPSTR)(Buffer[block]);
    Header[block].dwBufferLength = BlockSamples * bps;
    Header[block].dwLoops = 1;

    s = waveOutPrepareHeader(WaveOut, &Header[block], sizeof(WAVEHDR));
    if(s != MMSYSERR_NOERROR)
      ThrowString("WaveOut: waveOutPrepareHeader Failed <Error Code: 0x%x>", s);

    MixBuffer[block] = new double[BlockSamples];
  }

  WriteBlock(0);
  WriteBlock(1);

  PlayBlocks = true;
  Release();
}

void CWaveOutDriver::Close()
{
  int block;

  Lock();
  PlayBlocks = false;
  Release();

  if(WaveOut != 0)
    waveOutReset(WaveOut);

  for(block = 0; block < 2; block ++)
  {
    if(Buffer[block])
    {
      waveOutUnprepareHeader(WaveOut, &Header[block], sizeof(WAVEHDR)); 
      Buffer[block] = 0;
    }
  }

  if(WaveOut != 0)
  {
    waveOutClose(WaveOut);
    WaveOut = 0;
  }

  FormatProperties(Format, &SampleRate, &Bits, &Stereo);
  BlockSamples = CalcBlockSamples(Latency, SampleRate);
}

int CWaveOutDriver::GetNumChannels()
{
  return Stereo ? 2 : 1;
}

void CWaveOutDriver::WriteBlock(int block)
{
  double *inLeft, *inRight;
  short  *outs;
  char   *outc;

  WriteCallback(Stereo ? 2 : 1, MixBuffer, BlockSamples);
 
  inLeft    = MixBuffer[0];
  inRight   = MixBuffer[1];
  outs      = (short*)Buffer[block];
  outc      = (char*)Buffer[block];

  if(Stereo && Bits == 16) // Stereo 16
    ConvertStereoDoubleToStereoInt(inLeft, inRight, outs, BlockSamples);
  else
  {
    if(Stereo) // Stereo 8
      ConvertStereoDoubleToStereoByte(inLeft, inRight, outc, BlockSamples);
    else
    {
      if(Bits == 16) // Mono 16
        ConvertStereoDoubleToMonoInt(inLeft, inRight, outs, BlockSamples);
      else // Mono 8
        ConvertStereoDoubleToMonoByte(inLeft, inRight, outc, BlockSamples);
    }
  }
  waveOutWrite(WaveOut, &Header[block], sizeof(WAVEHDR));
}

void CWaveOutDriver::BlockFinished(WAVEHDR *header)
{
  int block;

  Lock();
  
  if(PlayBlocks)
  {
    for(block = 0; block < 2; block ++)
    {
      if(&Header[block] == header)
      {
        WriteBlock(block);
        break;
      }
    }
  }

  Release();
}

int CWaveOutDriver::GetDeviceCount()
{
  return DeviceCount;
}

char *CWaveOutDriver::GetDeviceName(int index)
{
  return DeviceCaps[index].szPname;
}

int CWaveOutDriver::GetDeviceFormats(int index)
{
  return DeviceCaps[index].dwFormats;
}

int CWaveOutDriver::GetDevice()
{
  return Device;
}

char *CWaveOutDriver::DescribeFormat(int format)
{
  int   sampleRate, bits;
  bool  stereo;
  char *text;

  FormatProperties(format, &sampleRate, &bits, &stereo);
  text = new char[128];
  sprintf(text, "%0.1fkHz, %ibit, %s", ((float)sampleRate) / 1000.0f, bits, stereo ? "Stereo" : "Mono");
  return text;
}

void CWaveOutDriver::FormatProperties(int format, int *sampleRate, int *bits, bool *stereo)
{
  int steps = 0;

  while((format & 0xF) == 0)
  {
    format >>= 4;
    steps++;
    if(steps >= POSSIBLE_SAMPLE_RATE_COUNT)
      throw "Invalid Format";
  }

  format = format & 0xF;

  *sampleRate = (int)PossibleSampleRates[steps];
  *bits       = format >= 4 ? 16 : 8;
  *stereo     = format == 2 || format == 8 ? true : false;
}

int CWaveOutDriver::GetFormat()
{
  return Format;
}

int MakeFormat(int sampleRate, int bits, bool stereo)
{
  if(sampleRate == 11025)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_1M08;
      else
        return WAVE_FORMAT_1M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_1S08;
      else
        return WAVE_FORMAT_1S16;
    }
  }
  if(sampleRate == 22050)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_2M08;
      else
        return WAVE_FORMAT_2M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_2S08;
      else
        return WAVE_FORMAT_2S16;
    }
  }
  if(sampleRate == 44100)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_44M08;
      else
        return WAVE_FORMAT_44M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_44S08;
      else
        return WAVE_FORMAT_44S16;
    }
  }
  if(sampleRate == 48000)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_48M08;
      else
        return WAVE_FORMAT_48M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_48S08;
      else
        return WAVE_FORMAT_48S16;
    }
  }
  if(sampleRate == 96000)
  {
    if(!stereo)
    {
      if(bits == 8)
        return WAVE_FORMAT_96M08;
      else
        return WAVE_FORMAT_96M16;
    }
    else
    {
      if(bits == 8)
        return WAVE_FORMAT_96S08;
      else
        return WAVE_FORMAT_96S16;
    }
  }
  return 0;
}

int CWaveOutDriver::ChooseFormat(int preferredFormat)
{
  int df;

  df = GetDeviceFormats(Device);
 
  if(df & preferredFormat)
    return preferredFormat;
  else
  {
    int  i, j;
    int  bits;
    bool stereo;
    const int sr[5] = {11025, 22050, 44100, 48000, 96000};
    int sampleRate;

    FormatProperties(preferredFormat, &sampleRate, &bits, &stereo);

    for(i = 0; i < 5; i++)
      if(sr[i] == sampleRate)
      {
        // closest sample rate with same bits and stereo

        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], bits, stereo) & df)
            return MakeFormat(sr[j], bits, stereo);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], bits, stereo) & df)
            return MakeFormat(sr[j], bits, stereo);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 16, true) & df)
            return MakeFormat(sr[j], 16, true);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 16, true) & df)
            return MakeFormat(sr[j], 16, true);
        

        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 16, false) & df)
            return MakeFormat(sr[j], 16, false);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 16, false) & df)
            return MakeFormat(sr[j], 16, false);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 8, true) & df)
            return MakeFormat(sr[j], 8, true);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 8, true) & df)
            return MakeFormat(sr[j], 8, true);
        
        for(j = i; j < 5; j++)
          if(MakeFormat(sr[j], 8, false) & df)
            return MakeFormat(sr[j], 8, false);
        for(j = i - 1; j >= 0; j--)
          if(MakeFormat(sr[j], 8, false) & df)
            return MakeFormat(sr[j], 8, false);
      }    
  }

  return 0;
}

void CWaveOutDriver::SetDevice(int device)
{
  Device = device;
  Core->Options->Audio.WaveDevice = device;
}

void CWaveOutDriver::SetFormat(int format)
{
  Format = format;
  Core->Options->Audio.WaveFormat = format;
}

int CWaveOutDriver::CalcBlockSamples(int latency, int sampleRate)
{
  return latency;
}

int CWaveOutDriver::GetLatency()
{
  return Latency;
}

void CWaveOutDriver::SetLatency(int latency)
{
  if(latency < WAVE_MIN_LATENCY)
    latency = WAVE_MIN_LATENCY;
  if(latency > WAVE_MAX_LATENCY)
    latency = WAVE_MAX_LATENCY;
  latency = latency - (latency % WAVE_GRANULARITY);

  Latency = latency;
  Core->Options->Audio.WaveLatency = latency;
}