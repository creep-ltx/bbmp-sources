; BCC = JB
; BCS = JAE
;.ORG    $008000
;.MODULE NES_NT2_ReplayCode


SQRWAV1_CHN             = 0
SQRWAV2_CHN             = 1
TRIWAV_CHN              = 2
NOSWAV_CHN              = 3
DPCM_CHN                = 4

NED_HDR_VERSION         = $00
NED_HDR_HEADERSIZE      = $01
NED_HDR_FLAGS           = $02
NED_HDR_INITTEMPO       = $03
NED_HDR_RESTARTPOS      = $04
NED_HDR_NUMINSTS        = $05
NED_HDR_NUMINSTS_DPCM   = $06
NED_HDR_SONGLENGTH      = $07
NED_HDR_NUMPATS         = $08
NED_HDR_NUMPATS_SQ1     = $08
NED_HDR_NUMPATS_SQ2     = $09
NED_HDR_NUMPATS_TRI     = $0A
NED_HDR_NUMPATS_NOISE   = $0B
NED_HDR_NUMPATS_DPCM    = $0C
NED_HDR_SIZEOF          = $10


NED_EffPortaUp          = $01
NED_EffPortaDown        = $02
NED_EffTonePorta        = $03
NED_EffVibrato          = $04
NED_EffTremolo          = $07
NED_EffArpeggio         = $08
NED_EffVolSlide         = $0A
NED_EffSetVol           = $0C
NED_EffBrkPat           = $0D
NED_EffSetSpeed         = $0F

NED_PERIODLIMIT = $0A
NED_CHANNELS    = $04

;NED_TEMP_BASE   = $00
;NED_STATIC_BASE = $10

NED_ZTRAM_BASE  = $C0
NED_ZRAM_BASE   = $D0
NED_RAM_BASE    = $300

        ; Temporary data, may be used by other routines


.segment "ZEROPAGE"


NED_TempWord    = NED_ZTRAM_BASE + $08
NED_TempWordLo  = NED_ZTRAM_BASE + $08
NED_TempWordHi  = NED_ZTRAM_BASE + $09

NED_CurrChn     = NED_ZTRAM_BASE + $0A
NED_Temp1       = NED_ZTRAM_BASE + $0B
NED_Temp2       = NED_ZTRAM_BASE + $0C
NED_Temp3       = NED_ZTRAM_BASE + $0D
NED_Temp4       = NED_ZTRAM_BASE + $0E
NED_Temp5       = NED_ZTRAM_BASE + $0F
NED_TempWord2   = NED_ZTRAM_BASE + $0E
NED_TempWord2Lo = NED_ZTRAM_BASE + $0E
NED_TempWord2Hi = NED_ZTRAM_BASE + $0F



        ; Static data, must NOT be used by other routines!



NED_NedAddr             = NED_ZRAM_BASE + $00
NED_CurrTick            = NED_ZRAM_BASE + $02
NED_Speed               = NED_ZRAM_BASE + $03
NED_CurrRow             = NED_ZRAM_BASE + $04
NED_CurrOrder           = NED_ZRAM_BASE + $05
NED_SongLength          = NED_ZRAM_BASE + $06
NED_RestartPos          = NED_ZRAM_BASE + $07
NED_OrderAddr           = NED_ZRAM_BASE + $08
NED_InstAddr            = NED_ZRAM_BASE + $0A


NED_ChnPeriodLo         = NED_ZRAM_BASE + $0C
NED_ChnPatOffs          = NED_ZRAM_BASE + $10
NED_ChnVblanksLeft      = NED_ZRAM_BASE + $15
NED_ChnLastTone         = NED_ZRAM_BASE + $19

NED_Reg4015             = NED_ZRAM_BASE + $1F


.segment "DATA"


NED_ChnVolume           = NED_RAM_BASE + $00
NED_ChnPattern          = NED_RAM_BASE + $04
NED_ChnPeriodHi         = NED_RAM_BASE + $08
NED_ChnLastInst         = NED_RAM_BASE + $10
NED_ChnPortaTone        = NED_RAM_BASE + $14
NED_ChnPortaSpeed       = NED_RAM_BASE + $18


NED_ChnPeriodHiLast     = NED_RAM_BASE + $AC
NED_ChnTotalVBlanks     = NED_RAM_BASE + $1C

NED_ChnAutoVolumeSlide  = NED_RAM_BASE + $20
NED_ChnVolumeSlide      = NED_RAM_BASE + $24

NED_ChnReg0             = NED_RAM_BASE + $94
NED_ChnArpeggio         = NED_RAM_BASE + $98

NED_ChnBigTick          = NED_RAM_BASE + $9C
NED_ChnAutoPorta        = NED_RAM_BASE + $A0


;NED_ChnAutoArpXY        = NED_STATIC_BASE + $28
NED_ChnAutoArpX         = NED_RAM_BASE + $28

NED_ChnAutoArpY         = NED_RAM_BASE + $A4
NED_ChnAutoArpNL        = NED_RAM_BASE + $A8


NED_ChnAutoArpZ         = NED_RAM_BASE + $2C
NED_ChnVibratoPos       = NED_RAM_BASE + $30
NED_ChnVibrato          = NED_RAM_BASE + $34
NED_ChnAutoVibrato      = NED_RAM_BASE + $38
NED_ChnTremoloPos       = NED_RAM_BASE + $3C
NED_ChnTremolo          = NED_RAM_BASE + $40
NED_ChnAutoTremolo      = NED_RAM_BASE + $44
NED_ChnLoopedNoise      = NED_RAM_BASE + $4C

NED_ChnTone             = NED_RAM_BASE + $50 
NED_ChnInst             = NED_RAM_BASE + $55
NED_ChnEff              = NED_RAM_BASE + $5A
NED_ChnEffParm          = NED_RAM_BASE + $5F

NED_ChnTotalPats        = NED_RAM_BASE + $E0

NED_ChnPatPtrsAddrLo    = NED_RAM_BASE + $64
NED_ChnPatPtrsAddrHi    = NED_RAM_BASE + $69
NED_ChnPatAddrLo        = NED_RAM_BASE + $6E
NED_ChnPatAddrHi        = NED_RAM_BASE + $73
NED_ChnNibAddrOdd       = NED_RAM_BASE + $78


NED_ChnLastVolume       = NED_RAM_BASE + $B4

;NED_LoopStart           = NED_STATIC_BASE + $3D
;NED_LoopLength          = NED_STATIC_BASE + $3E
;NED_SampleNote          = NED_STATIC_BASE + $3F
;NED_SampleInst          = NED_STATIC_BASE + $40
;NED_SmpNum              = NED_STATIC_BASE + $41
;NED_Length              = NED_STATIC_BASE + $42

NED_TotalPatsDPCM       = NED_RAM_BASE + $E4

NED_ChnPatRowsToSkip    = NED_RAM_BASE + $8A
NED_ChnPatRowsTotal     = NED_RAM_BASE + $8F

NED_PAL_Counter = $FF



.segment "NSFHEADER"

.byte 'N','E','S','M',$1A
.byte $01
.byte 1  ; number of songs
.byte 1
.word loadstart
.word NSF_InitSong
.word NSF_Play
.byte "title                          ",0
.byte "author                         ",0
.byte "copyright                      ",0
.word $411A
.byte 0,0,0,0,0,0,0,0
.word $4E20
.byte 2   ; Dual PAL/NTSC
.byte 0
.byte 0,0,0,0


.segment "SAMPLES"
.incbin "temp.dmc"

.segment "CODE"

loadstart:

jmp NSF_Play
jmp NSF_InitSong



ProgramEntry:   sei
                cld
                LDX     #$FF
                TXS

                lda     #$40
                sta     $2000

Again:          lda     #$9E
                sta     $2001
@WaitVblank:    lda     $2002
;                bpl     @WaitVblank

@WaitVblankB:
                lda     $2002
;                bpl     @WaitVblankB

                lda     #$00
                sta     $2001

                LDA     #<NED_SONG
                LDX     #>NED_SONG
                JSR     NED_SetupNED

                lda     #$1E
                sta     $2001
                lda     #$80
                sta     $2000

DumLoop:        jmp     DumLoop



NED_SetupNED:
                STA     NED_NedAddr
                STX     NED_NedAddr+1

                LDA     #NED_HDR_SIZEOF
                CLC
                ADC     NED_NedAddr
                STA     NED_InstAddr
                LDA     NED_NedAddr+1
                ADC     #0
                STA     NED_InstAddr+1

                LDY     #NED_HDR_INITTEMPO
                LDA     (NED_NedAddr),Y
                STA     NED_Speed
                INY
                LDA     (NED_NedAddr),Y
                STA     NED_RestartPos
                INY
                INY
                INY
                LDA     (NED_NedAddr),Y
                STA     NED_SongLength
                INY

; Load total patterns indicator for every synth channel
                LDA     (NED_NedAddr),Y
                STA     NED_ChnTotalPats
                INY
                LDA     (NED_NedAddr),Y
                STA     NED_ChnTotalPats+1
                INY
                LDA     (NED_NedAddr),Y
                STA     NED_ChnTotalPats+2
                INY
                LDA     (NED_NedAddr),Y
                STA     NED_ChnTotalPats+3
                INY
                LDA     (NED_NedAddr),Y
                STA     NED_TotalPatsDPCM
                INY

                iny
                iny
                iny


                TYA
                CLC
                ADC     #128
                STA     NED_Temp1

                LDA     NED_NedAddr     ; Calc Order Address
                ADC     NED_Temp1
                STA     NED_OrderAddr
                LDA     NED_NedAddr+1
                ADC     #0
                STA     NED_OrderAddr+1

                LDA     NED_SongLength
                ASL

                asl
                ;ADC     NED_SongLength

                ADC     NED_Temp1
                STA     NED_Temp1

                lda     #0
                adc     #0
                sta     NED_Temp2

                LDA     NED_NedAddr     ; Calc pattern pointers pointers
                ADC     NED_Temp1
                STA     NED_ChnPatPtrsAddrLo
                LDA     NED_NedAddr+1
                ;ADC     #0
                adc     NED_Temp2
                STA     NED_ChnPatPtrsAddrHi
                
                ; Make it calc the rest too...

                lda     NED_ChnTotalPats
                asl
                adc     NED_ChnPatPtrsAddrLo
                sta     NED_ChnPatPtrsAddrLo+1
                lda     #0
                adc     NED_ChnPatPtrsAddrHi
                sta     NED_ChnPatPtrsAddrHi+1

                lda     NED_ChnTotalPats+1
                asl
                adc     NED_ChnPatPtrsAddrLo+1
                sta     NED_ChnPatPtrsAddrLo+2
                lda     #0
                adc     NED_ChnPatPtrsAddrHi+1
                sta     NED_ChnPatPtrsAddrHi+2

                lda     NED_ChnTotalPats+2
                asl
                adc     NED_ChnPatPtrsAddrLo+2
                sta     NED_ChnPatPtrsAddrLo+3
                lda     #0
                adc     NED_ChnPatPtrsAddrHi+2
                sta     NED_ChnPatPtrsAddrHi+3

                lda     NED_ChnTotalPats+3
                asl
                adc     NED_ChnPatPtrsAddrLo+3
                sta     NED_ChnPatPtrsAddrLo+4
                lda     #0
                adc     NED_ChnPatPtrsAddrHi+3
                sta     NED_ChnPatPtrsAddrHi+4



                LDA     #0
                LDX     #3
@ClearChnLoop:
                STA     NED_ChnVolume,X
                STA     NED_ChnPeriodLo,X
                STA     NED_ChnPeriodHi,X
                STA     NED_ChnLastTone,X
                STA     NED_ChnLastInst,X
                STA     NED_ChnPortaTone,X
                STA     NED_ChnPortaSpeed,X
                STA     NED_ChnReg0,X
                STA     NED_ChnVolumeSlide,X
                STA     NED_ChnAutoVolumeSlide,X
                STA     NED_ChnArpeggio,X
                STA     NED_ChnAutoArpX,X
                STA     NED_ChnAutoArpY,X
                STA     NED_ChnAutoArpZ,X
                STA     NED_ChnVibratoPos,X
                STA     NED_ChnVibrato,X
                STA     NED_ChnAutoVibrato,X
                STA     NED_ChnTremoloPos,X
                STA     NED_ChnTremolo,X
                STA     NED_ChnAutoTremolo,X
                STA     NED_ChnVblanksLeft,X
                STA     NED_ChnLoopedNoise,X
                STA     NED_ChnTone,X
                STA     NED_ChnInst,X
                STA     NED_ChnEff,X
                STA     NED_ChnEffParm,X
                STA     NED_ChnBigTick,X

                DEX
                BPL     @ClearChnLoop

                STA     NED_CurrRow
                STA     NED_CurrOrder

                sta     NED_Reg4015
                sta     $4015

                ;LDA     #$05
                ;STA     NED_PAL_Counter

                LDX     NED_Speed
                inx
                STX     NED_CurrTick

                RTS
                


NED_SetVolume:
                cmp     #0
                BPL     @VolumeAbove0
                LDA     #0
@VolumeAbove0:  
                CMP     #63
                BCC     @VolumeBelow64
                LDA     #63
@VolumeBelow64:
                LSR
                LSR
                ORA     NED_ChnReg0,X

                LDY     NED_Chn2RegIndex,X

                STA     $4000,Y
                RTS

NED_SetPeriod:
                CPX     #NOSWAV_CHN
                BEQ     @SetPeriodNoise
                cpx     #TRIWAV_CHN
                beq     @SetPeriodTri


                LDY     NED_Chn2RegIndex,X

                STA     $4002,Y

                lda     #$08    ; Compensates for the bug Matt found
                sta     $4001,Y

                LDA     NED_Temp1

                cmp     NED_ChnPeriodHiLast,X
                beq     :+       ; No update needed
                sta     NED_ChnPeriodHiLast,X
                ORA     #8
                STA     $4003,Y
:
                RTS

@SetPeriodNoise:
                AND     #$0F
                ORA     NED_ChnLoopedNoise,X
                STA     $400E
                LDA     #8
                STA     $400F
                RTS


@SetPeriodTri:
                LDY     NED_Chn2RegIndex,X

                STA     $4002,Y
                LDA     NED_Temp1
                ORA     #8
                STA     $4003,Y
                RTS



NED_PlayNED:

                        LDA     NED_Speed
                        BEQ     @Halted
                        INC     NED_CurrTick
                        CMP     NED_CurrTick
                        beq     :+
                        bpl     @UpdateTx
:
                                LDA     #0
                                STA     NED_CurrTick
                                LDA     NED_CurrRow
                                CMP     #64
                                BCC     @DontIncOrder
                                        LDA     #0
                                        STA     NED_CurrRow
                                        LDX     NED_CurrOrder
                                        INX
                                        CPX     NED_SongLength
                                        BCC     @DontRestartSong
                                                LDX     NED_RestartPos
                                        @DontRestartSong:
                                        STX     NED_CurrOrder
                                @DontIncOrder:
                        jmp     NED_UpdateT0

@UpdateTx:
                                lda     #6
;                                sta     $2001
                

                LDX     #3
                

: ;-
                        lda     NED_ChnVblanksLeft,X
                        bmi     @HoldNoteOnTx
                        sec
                        sbc     #1
                        bpl     @DontSetNoteOffTx
                                lda     NED_ChnBitIndexInv,X
                                and     NED_Reg4015
                                sta     NED_Reg4015
                                lda     #0

@DontSetNoteOffTx:
                        sta     NED_ChnVblanksLeft,X

@HoldNoteOnTx:
                        cpx     #TRIWAV_CHN
                        bne     :+
                        lda     #$FF
                        sta     $4008
:


                dex
                bpl     :--



                lda     $4015
                and     #$10
                bne     :+
                lda     NED_Reg4015
                and     #$0F
                sta     NED_Reg4015
:
                LDA     NED_Reg4015
                STA     $4015



                LDX     #3
@UpdateChannels:
                CPX     #TRIWAV_CHN
                BEQ     :+
                jsr     DoVolEffsTx
:
                jsr     DoPitchEffsTx
@DontSetPeriod:
                DEX
                BPL     @UpdateChannels


@Halted:
                INC     NED_ChnBigTick
                INC     NED_ChnBigTick+1
                INC     NED_ChnBigTick+2
                INC     NED_ChnBigTick+3

                RTS

DoVolEffsTx:
                lda     NED_ChnEff,X
                cmp     #NED_EffVolSlide
                bne     @NoEffVolSlideTx
                        LDA     NED_ChnEffParm,X
                        BEQ     :+
                                STA     NED_ChnVolumeSlide,X
                        :
                        lda     NED_ChnVolumeSlide,X
                        tay
                        and     #$F0
                        beq     :+
                        lsr
                        lsr
                        lsr
                        lsr
                        ;adc     NED_Temp1
                        adc     NED_ChnVolume,X
                        sta     NED_ChnVolume,X
                        jmp     @EffVolSlideDone
:
                        tya
                        and     #$0F            ; remove!
                        eor     #$FF
                        sec
                        adc     NED_ChnVolume,X
                        sta     NED_ChnVolume,X
                        ;sta     NED_Temp1
                        ;lda     NED_ChnVolume,X
                        ;sec
                        ;sbc     NED_Temp1
                        ;sta     NED_Temp1

@EffVolSlideDone:
                        jmp     :+

@NoEffVolSlideTx:
                lda     NED_ChnAutoVolumeSlide,X
                beq     :+
                        clc
                        adc     NED_ChnVolume,X
                        sta     NED_ChnVolume,X
:

                ldy     NED_ChnEff,X
                ;lda     NED_ChnTremolo,X
                cpy     #NED_EffTremolo
                bne     :++
                LDA     NED_ChnEffParm,X
                BEQ     :+
                STA     NED_ChnTremolo,X
:               LDA     NED_ChnTremolo,X
                bNE     @DoTremolo
: 
                lda     NED_ChnAutoTremolo,X
                bne     @DoTremolo

                LDA     NED_ChnVolume,X
                BPL     :+
                LDA     #0
:
                CMP     #63
                BCC     :+
                LDA     #63
:
                STA     NED_ChnVolume,X
                Jmp     NED_SetVolume
                



@DoTremolo:

                PHA
                and     #$0F

                ldy     NED_ChnTremoloPos,X
                jsr     ReadSineTab

                bmi     @NegativeTremDelta

                clc
                adc     NED_ChnVolume,X
                jsr     NED_SetVolume

                PLA

                lsr
                lsr
                lsr
                lsr
                clc
                adc     NED_ChnTremoloPos,X
                cmp     #32
                bpl     @ResetTremPos
                sta     NED_ChnTremoloPos,X

                rts

@NegativeTremDelta:
                clc
                adc     NED_ChnVolume,X
                jsr     NED_SetVolume

                PLA

                lsr
                lsr
                lsr
                lsr
                clc
                adc     NED_ChnTremoloPos,X
                cmp     #32
                bpl     @ResetTremPos
                sta     NED_ChnTremoloPos,X

                rts

@ResetTremPos:
                sec     ; prolly' not needed
                sbc     #64
                sta     NED_ChnTremoloPos,X

                rts



; In: A = Depth (in lower nibble), Y = Position

ReadSineTab:
                bmi     @PositionNegative
                dey
                bmi     @PositionZero
                ora     Pos2TabPos,Y

                tay
                lda     VibAndTremTab,Y

                clc

                rts

@PositionNegative:
                PHA
                tya
                eor     #$FF
                and     #31
                tay

                DEY

                PLA
                ora     Pos2TabPos,Y


                tay
                lda     VibAndTremTab,Y

                eor     #$FF
                clc
                adc     #1

                CMP     #$80

                ;sec
                rts

@PositionZero:
                lda     #0
                clc
                rts

;    ______ sign bit in carry
;   |
;   V
;   Xxxxxxxxx


DoVibrato:
                PHA
                and     #$0F

                ldy     NED_ChnVibratoPos,X

                jsr     ReadSineTab

                ROR
                bmi     @NegativeVibDelta
;                BPL     ++++++++
;                LDA     #0
;++++++++

                clc
                adc     NED_ChnPeriodLo,X
                tay
                lda     NED_ChnPeriodHi,X
                adc     #0
                sta     NED_Temp1
                tya
                jsr     NED_SetPeriod

                PLA

                lsr
                lsr
                lsr
                lsr
                clc

                adc     NED_ChnVibratoPos,X
                cmp     #32
                bpl     @ResetVibPos
                sta     NED_ChnVibratoPos,X

                rts

@NegativeVibDelta:
                clc
                adc     NED_ChnPeriodLo,X
                tay

                ;ROR     ; Invert CARRY
                ;CLC
                ;EOR     #$80
                ;ADC     #$80

                lda     NED_ChnPeriodHi,X
                adc     #$FF
                sta     NED_Temp1
                tya
                jsr     NED_SetPeriod

                PLA

                lsr
                lsr
                lsr
                lsr
                clc
                adc     NED_ChnVibratoPos,X
                cmp     #32
                bpl     @ResetVibPos
                sta     NED_ChnVibratoPos,X

                rts

@ResetVibPos:
                sec     ; prolly' not needed
                sbc     #64
                sta     NED_ChnVibratoPos,X

                rts


DoPitchEffsTx:  jsr     DoArpEffsTx
                ;jsr     DoPortaEffsTx
                Jmp     DoPortaEffsTx
minus:
                ldy     NED_ChnEff,X
                ;lda     NED_ChnVibrato,X
                cpy     #NED_EffVibrato
                BNE     :++
                LDA     NED_ChnEffParm,X
                BEQ     :+
                STA     NED_ChnVibrato,X
                :
                LDA     NED_ChnVibrato,X
                bNE     DoVibrato
:

                lda     NED_ChnAutoVibrato,X
                bne     DoVibrato

                LDA     NED_ChnPeriodHi,X
                STA     NED_Temp1
                LDA     NED_ChnPeriodLo,X
                Jmp     NED_SetPeriod




DoPortaEffsTx:
                lda     NED_ChnEff,X
                cmp     #NED_EffTonePorta
                beq     @DoTonePorta

                cmp     #NED_EffPortaUp
                beq     @DoPortaUp
                cmp     #NED_EffPortaDown
                beq     @DoPortaDown
                lda     NED_ChnAutoPorta,X
                bne     @DoAutoPorta
                jmp     minus


@DoAutoPorta:
                lda     NED_ChnAutoPorta,X
                bmi     @DoAutoPortaUp
                clc
                adc     NED_ChnPeriodLo,X
                sta     NED_ChnPeriodLo,X
                lda     NED_ChnPeriodHi,X
                adc     #0
                sta     NED_ChnPeriodHi,X
                jmp     minus

@DoAutoPortaUp:
                clc
                adc     NED_ChnPeriodLo,X
                sta     NED_ChnPeriodLo,X
                lda     NED_ChnPeriodHi,X
                adc     #$FF
                sta     NED_ChnPeriodHi,X
                jmp     minus

@DoPortaUp:
                LDA     NED_ChnEffParm,X
                BEQ     :+
                        STA     NED_ChnPortaSpeed,X
                :

                lda     NED_ChnPeriodLo,X
                sec
                sbc     NED_ChnPortaSpeed,X
                sta     NED_ChnPeriodLo,X
                lda     NED_ChnPeriodHi,X
                sbc     #0
                sta     NED_ChnPeriodHi,X
                jmp     minus

@DoPortaDown:
                LDA     NED_ChnEffParm,X
                BEQ     :+
                        STA     NED_ChnPortaSpeed,X
                :

                lda     NED_ChnPeriodLo,X
                clc
                adc     NED_ChnPortaSpeed,X
                sta     NED_ChnPeriodLo,X
                lda     NED_ChnPeriodHi,X
                adc     #0
                sta     NED_ChnPeriodHi,X
                jmp     minus

@DoTonePorta:
                LDA     NED_ChnTone,X
                BEQ     :+
                STA     NED_ChnPortaTone,X
:
                LDA     NED_ChnEffParm,X
                BEQ     :+
                        STA     NED_ChnPortaSpeed,X
                :

                ldy     NED_ChnPortaTone,X

                lda     Tone2PeriodLoTab-1,Y
                sta     NED_TempWordLo
                lda     Tone2PeriodHiTab-1,Y
                sta     NED_TempWordHi

                sec
                lda     NED_ChnPeriodLo,X
                sbc     NED_TempWordLo
                lda     NED_ChnPeriodHi,X
                sbc     NED_TempWordHi
                bmi     @TonePortaDown
                bPL     @TonePortaUp

                jmp     minus

@TonePortaDown:
                lda     NED_ChnPeriodLo,X

                clc     ; prolly' not needed

                adc     NED_ChnPortaSpeed,X
                sta     NED_ChnPeriodLo,X
                lda     NED_ChnPeriodHi,X
                adc     #0
                sta     NED_ChnPeriodHi,X

                sec
                lda     NED_ChnPeriodLo,X
                sbc     NED_TempWordLo
                lda     NED_ChnPeriodHi,X
                sbc     NED_TempWordHi
                bpl     @StopTonePorta

                jmp     minus

@TonePortaUp:
                lda     NED_ChnPeriodLo,X

                sec     ; prolly' not needed

                sbc     NED_ChnPortaSpeed,X
                sta     NED_ChnPeriodLo,X
                lda     NED_ChnPeriodHi,X
                sbc     #0
                sta     NED_ChnPeriodHi,X

                sec
                lda     NED_ChnPeriodLo,X
                sbc     NED_TempWordLo
                lda     NED_ChnPeriodHi,X
                sbc     NED_TempWordHi
                bmi     @StopTonePorta

                jmp     minus

@StopTonePorta:
                lda     NED_TempWordLo
                sta     NED_ChnPeriodLo,X
                lda     NED_TempWordHi
                sta     NED_ChnPeriodHi,X

                jmp     minus



DoArpEffsTx:
                lda     NED_ChnEff,X
                cmp     #NED_EffArpeggio
                beq     @DoArpeggioTx
                lda     NED_ChnAutoArpX,X
                bne     DoAutoArpeggio
                lda     NED_ChnAutoArpY,X
                bne     DoAutoArpeggio
                lda     NED_ChnAutoArpZ,X
                bne     DoAutoArpeggio
                rts

@DoArpeggioTx:
                jMP     DoArpeggio

;@DoAutoArpeggioTx
;                JMP      DoAutoArpeggio

DoAutoArpeggio:

                lda     NED_ChnBigTick,X
                ldy     NED_ChnAutoArpNL,X
                bne     @DoNonLoopedArpeggio
                and     #3
@DoNonLoopedArpeggio:
                cmp     #0
                beq     @DoAutoArp0
                cmp     #1
                beq     @DoAutoArpX
                cmp     #2
                beq     @DoAutoArpY
                cmp     #3
                beq     @DoAutoArpZ
                rts


@DoAutoArp0:
                ldy     NED_ChnLastTone,X
                lda     Tone2PeriodHiTab-1,Y
                sta     NED_ChnPeriodHi,X
                STA     NED_Temp1
                lda     Tone2PeriodLoTab-1,Y
                sta     NED_ChnPeriodLo,X

                Jmp     NED_SetPeriod


@DoAutoArpX:

                lda     NED_ChnLastTone,X
                clc     ; Optimize!
                adc     NED_ChnAutoArpX,X
                tay


                lda     Tone2PeriodHiTab-1,Y
                sta     NED_ChnPeriodHi,X
                STA     NED_Temp1
                lda     Tone2PeriodLoTab-1,Y
                sta     NED_ChnPeriodLo,X

                Jmp     NED_SetPeriod


@DoAutoArpY:
                lda     NED_ChnLastTone,X
                clc     ; Optimize!
                adc     NED_ChnAutoArpY,X

                tay


                lda     Tone2PeriodHiTab-1,Y
                sta     NED_ChnPeriodHi,X
                STA     NED_Temp1
                lda     Tone2PeriodLoTab-1,Y
                sta     NED_ChnPeriodLo,X

                Jmp     NED_SetPeriod



@DoAutoArpZ:

                lda     NED_ChnLastTone,X
                clc     ; Optimize!
                adc     NED_ChnAutoArpZ,X

                tay

                lda     Tone2PeriodHiTab-1,Y
                sta     NED_ChnPeriodHi,X
                STA     NED_Temp1
                lda     Tone2PeriodLoTab-1,Y
                sta     NED_ChnPeriodLo,X

                Jmp     NED_SetPeriod




ChangeVolume:
                sta     NED_ChnVolume,X
                jmp     DoneExEffsT0

SetSpeed:      sta     NED_Speed
                jmp     DoneExEffsT0

BreakPattern:  sec
                sbc     #1
                sta     NED_CurrRow
                lda     NED_CurrOrder
                clc
                adc     #1
                cmp     NED_SongLength
                bcc     :+
                        lda     NED_RestartPos
:
                sta     NED_CurrOrder
                jmp     DoneExEffsT0


DoEffsT0:
                ldy     NED_ChnEff,X
                BEQ     :+
                LDA     NED_ChnEffParm,X
                cpy     #NED_EffSetVol
                beq     ChangeVolume
                cpy     #NED_EffSetSpeed
                beq     SetSpeed
                cpy     #NED_EffBrkPat
                beq     BreakPattern
:
DoneExEffsT0:

                lda     NED_ChnEffParm,X
                cpy     #NED_EffArpeggio
                beq     @DoArpeggioT0
                lda     NED_ChnAutoArpX,X
                bne     @DoAutoArpeggioT0
                lda     NED_ChnAutoArpY,X
                bne     @DoAutoArpeggioT0
                lda     NED_ChnAutoArpZ,X
                bne     @DoAutoArpeggioT0


                lda     NED_ChnTone,X
                beq     :+
                lda     NED_ChnEff,X
                cmp     #NED_EffTonePorta
                BEQ     :+

                LDA     NED_ChnPeriodHi,X
                STA     NED_Temp1
                LDA     NED_ChnPeriodLo,X
                Jmp     NED_SetPeriod

:
                rts



@DoArpeggioT0:
                jsr     DoArpeggio

                LDA     NED_ChnPeriodHi,X
                STA     NED_Temp1
                LDA     NED_ChnPeriodLo,X
                Jmp     NED_SetPeriod

@DoAutoArpeggioT0:
                JMP     DoAutoArpeggio




DoArpeggio:
                lda     NED_ChnEffParm,X
                beq     @NoArpParm
                        sta     NED_ChnArpeggio,X
@NoArpParm:
                sec
                lda     NED_CurrTick
                beq     @DoArp0
@DoArpLoop:      cmp     #1
                beq     @DoArpX
                cmp     #2
                beq     @DoArpY
                sbc     #3
                bne     @DoArpLoop

@DoArp0:
                ldy     NED_ChnLastTone,X

                lda     Tone2PeriodLoTab-1,Y
                sta     NED_ChnPeriodLo,X
                lda     Tone2PeriodHiTab-1,Y
                sta     NED_ChnPeriodHi,X
                rts

@DoArpX:
                lda     NED_ChnArpeggio,X
                lsr
                lsr
                lsr
                lsr
                clc
                adc     NED_ChnLastTone,X

                tay

                lda     Tone2PeriodLoTab-1,Y
                sta     NED_ChnPeriodLo,X
                lda     Tone2PeriodHiTab-1,Y
                sta     NED_ChnPeriodHi,X
                rts

@DoArpY:
                lda     NED_ChnArpeggio,X
                and     #$0F
                clc
                adc     NED_ChnLastTone,X
                
                tay

                lda     Tone2PeriodLoTab-1,Y
                sta     NED_ChnPeriodLo,X
                lda     Tone2PeriodHiTab-1,Y
                sta     NED_ChnPeriodHi,X
                rts

; If instrument has not changed, just reset (& reload) volume and 
; reset misc things.

SameInstrument:
                LDA     NED_ChnTotalVBlanks,X   ; 4
                STA     NED_ChnVblanksLeft,X    ; 4
                LDA     NED_ChnLastVolume,X     ; 4
                STA     NED_ChnVolume,X         ; 4
                LDA     NED_ChnBitIndex,X       ; 4
                ORA     NED_Reg4015             ; 3/4
                STA     NED_Reg4015             ; 3/4
                JMP     NoInst                 ; 3

NED_UpdateT0:

                                ;lda     #6
                                ;sta     $2001

                JSR     GetSNotes

                ;INC     NED_CurrRow
                ;RTS

                LDX     #3
ChnLoop:

                LDA     NED_ChnInst,X
                Bne     @YesInst
                jmp     NoInst

@YesInst:
                        CMP     NED_ChnLastInst,X
                        BEQ     SameInstrument

                        sta     NED_ChnLastInst,X       ; 4
                        asl                             ; 2
                        asl                             ; 2
                        asl                             ; 2
                        adc     #(256-8)                ; 2
                        tay                             ; 2

                        lda     (NED_InstAddr),Y        ; 5
                        iny                             ; 2

                        sta     NED_ChnReg0,X           ; 4
                        lda     (NED_InstAddr),Y        ; 5
                        iny                             ; 2
                        sta     NED_ChnAutoPorta,X      ; 4
                        lda     (NED_InstAddr),Y        ; 5
                        iny                             ; 2
                        sta     NED_ChnAutoVibrato,X    ; 4
                        lda     (NED_InstAddr),Y        ; 5
                        iny                             ; 2
                        sta     NED_ChnAutoTremolo,X    ; 4     
                        lda     (NED_InstAddr),Y        ; 5     63


                        bmi     @VolumeSlideGoesUp     ; 2/3

                        iny                             ; 2
                        and     #$7F                    ; 2
                        ;sta     NED_ChnVblanksLeft,X
                        sta     NED_Temp1               ; 3
                        lda     NED_ChnReg0,X           ; 4
                        asl                             ; 2
                        asl                             ; 2
                        and     #$80                    ; 2
                        ora     NED_Temp1               ; 3
                        sta     NED_ChnVblanksLeft,X    ; 4
                        sta     NED_ChnTotalVBlanks,X   ; 4
                        lda     (NED_InstAddr),Y        ; 5
                        sta     NED_Temp1               ; 3
                        and     #$F0                    ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        sta     NED_ChnVolume,X         ; 4

                        STA     NED_ChnLastVolume,X     ; 4

                        lda     NED_Temp1               ; 3
                        and     #$0F                    ; 2
                        eor     #$FF                    ; 2
                        clc                             ; 2
                        adc     #1                      ; 2
                        sta     NED_ChnAutoVolumeSlide,X        ; 61

                        jmp     :+
@VolumeSlideGoesUp:
                        iny                             ; 2
                        and     #$7F                    ; 2
                        ;sta     NED_ChnVblanksLeft,X

                        sta     NED_Temp1               ; 3

                        lda     NED_ChnReg0,X           ; 4
                        asl                             ; 2
                        asl                             ; 2
                        and     #$80                    ; 2
                        ora     NED_Temp1               ; 3
                        sta     NED_ChnVblanksLeft,X    ; 4
                        sta     NED_ChnTotalVBlanks,X   ; 4

                        lda     (NED_InstAddr),Y        ; 5
                        sta     NED_Temp1               ; 3
                        and     #$F0                    ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        sta     NED_ChnVolume,X         ; 4
                        lda     NED_Temp1               ; 3
                        and     #$0F                    ; 2

                        sta     NED_ChnAutoVolumeSlide,X        ; 4
:
                        iny                             ; 2
                        lda     (NED_InstAddr),Y        ; 5
                        iny                             ; 2
                        sta     NED_Temp1               ; 3
                        asl                             ; 2
                        and     #$80                    ; 2
                        sta     NED_ChnLoopedNoise,X    ; 4
                        lda     NED_Temp1               ; 3
                        and     #$20                    ; 2
                        sta     NED_ChnAutoArpNL,X      ; 4
                        lda     (NED_InstAddr),Y        ; 5
                        tay                             ; 2
                        and     #$0F                    ; 2     38

                        bcs     @ReversedArpeggio      ; 2/3

                        sta     NED_ChnAutoArpX,X       ; 4
                        tya                             ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        sta     NED_ChnAutoArpY,X       ; 4
                        lda     NED_Temp1               ; 3
                        and     #$0F                    ; 2
                        sta     NED_ChnAutoArpZ,X       ; 4     27
                        jmp     :+
@ReversedArpeggio:
                        eor     #$FF                    ; 2
                        clc                             ; 2
                        adc     #1                      ; 2
                        sta     NED_ChnAutoArpX,X       ; 4
                        tya                             ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        lsr                             ; 2
                        eor     #$FF                    ; 2
                        clc                             ; 2
                        adc     #1                      ; 2
                        sta     NED_ChnAutoArpY,X       ; 4
                        lda     NED_Temp1               ; 3
                        and     #$0F                    ; 2
                        eor     #$FF                    ; 2
                        clc                             ; 2
                        adc     #1                      ; 2
                        sta     NED_ChnAutoArpZ,X       ; 4
:


                        LDA     NED_ChnBitIndex,X       ; 4
                        ORA     NED_Reg4015             ; 3/4
                        STA     NED_Reg4015             ; 3/4
NoInst:

                ;LDA     NED_ChnTone,X
                LDy     NED_ChnTone,X
                BEQ     @NoTone
                        ;cmp     #97
                        cPY     #97
                        beq     @NoteOff

                        ;STA     NED_ChnLastTone,X
                        STy     NED_ChnLastTone,X


                        lda     #0
                        sta     NED_ChnBigTick,X
                        STA     NED_ChnTremoloPos,X

                        lda     NED_ChnTotalVBlanks,X
                        sta     NED_ChnVblanksLeft,X

                        LDA     NED_ChnBitIndex,X
                        ORA     NED_Reg4015
                        STA     NED_Reg4015

                        lda     NED_ChnEff,X
                        cmp     #NED_EffTonePorta
                        beq     @SkipPeriodSetToneRead

                        ;should make sure period is only updated when needed
                        lda     #$FF
                        sta     NED_ChnPeriodHiLast,X


                        LDA     #0
                        STA     NED_ChnVibratoPos,X


                        ;ldY     NED_ChnLastTone,X

                        CPX     #NOSWAV_CHN
                        BEQ     @ChnIsNoise


                        LDA     Tone2PeriodLoTab-1,Y
                        STA     NED_ChnPeriodLo,X
                        LDA     Tone2PeriodHiTab-1,Y
:
                        STA     NED_ChnPeriodHi,X


                        LDA     NED_ChnBitIndex,X
                        ORA     NED_Reg4015
                        STA     NED_Reg4015

@SkipPeriodSetToneRead:

@NoTone:

                        DEX
                        bmi     @ExitChnLoop
                        jmp     ChnLoop
@ExitChnLoop:

;                        INC     NED_CurrRow
;                        RTS

                        jsr     UpdateDPCMT0

                        jmp     UpdateChannelsT0


@NoteOff:       LDA     NED_ChnBitIndexInv,X
                AND     NED_Reg4015
                STA     NED_Reg4015
                jmp     @NoTone

@ChnIsNoise:
                        dey
                        STy     NED_ChnPeriodLo,X
                        ;DEC     NED_ChnPeriodLo,X
                        LDA     #0
                        jmp     :-



UpdateDPCMT0:   ldx     #DPCM_CHN
                lda     NED_ChnTone,X
                beq     @NoSampleTone
                        ;sta     NED_ChnLastTone,X
@NoSampleTone:
                lda     NED_ChnInst,X
                beq     @NoSampleInst
                        ;sta     NED_ChnLastInst,X
@NoSampleInst:
                lda     NED_ChnTone,X
                cmp     #97
                beq     @SetSampleToneOff
                cmp     #0
                bne     @PlaySample
                lda     NED_ChnInst,X
                bne     @PlaySample

                rts

@SetSampleToneOff:


                lda     NED_Reg4015
                and     #$0F
                sta     $4015
                rts

@PlaySample:
                lda     NED_Reg4015
                and     #$0f
                sta     $4015

                ldy     NED_ChnTone,X
                dey
                lda     NED_ChnInst,X
                sec
                sbc     #1

                jsr     GetDPCMRegs
                

                sty     $4010
                sta     $4011

                INX
                INX

                stx     $4012
                lda     NED_Temp1
                sta     $4013

                lda     NED_Reg4015
                ora     #$10
                sta     NED_Reg4015
                sta     $4015

                rts


PatternIsEmpty: lda     #0
                STA     NED_ChnPatRowsTotal,X
                jmp     BackFromPatternIsEmpty


GetSNotes:       LDA     #$40
                STA     NED_Temp3
                LDA     #0

                LDX     #4      ; This now includes DPCM!!!

@ClearLoop:      STA     NED_ChnTone,X
                STA     NED_ChnInst,X
                STA     NED_ChnEff,X
                STA     NED_ChnEffParm,X
                DEX
                BPL     @ClearLoop
                
                
                LDA     NED_CurrRow
                BNE     DontRecalcPtrs0
                LDA     NED_CurrTick
                BNE     DontRecalcPtrs0
                jmp     :+
DontRecalcPtrs0:  jmp     DontRecalcPtrs
:


                        LDA     NED_CurrOrder
                        ASL
                        asl
                        TAY
                        LDA     (NED_OrderAddr),Y
                        iny

                        tax
                        and     #$1F
                        asl
                        sta     NED_ChnPattern+0
                        LDA     (NED_OrderAddr),Y
                        sta     NED_Temp1
                        lsr
                        sty     NED_Temp2
                        tay
                        and     #$3E
                        sta     NED_ChnPattern+2
                        txa
                        ror
                        tax
                        tya
                        lsr
                        txa
                        ror
                        ror
                        ror
                        and     #$3E
                        sta     NED_ChnPattern+1
                        asl     NED_Temp1

                        ldy     NED_Temp2
                        iny
                        LDA     (NED_OrderAddr),Y
                        tax
                        rol
                        asl
                        and     #$3E

                        sta     NED_ChnPattern+3
                        txa
                        lsr
                        lsr
                        lsr
                        and     #$3E
                        sta     NED_ChnPattern+4

                        ldx     #4      ; includes DPCM
:
                        LDA     NED_ChnPatPtrsAddrLo,X
                        STA     NED_TempWordLo
                        LDA     NED_ChnPatPtrsAddrHi,X
                        STA     NED_TempWordHi


                        ldy     NED_ChnPattern,X
                        LDA     (NED_TempWord),Y
                        INY
                        CMP     #0
                        bNE     :+
                        STA     NED_Temp1
                        LDA     (NED_TempWord),Y
                        bne     Buggar
                        ;beq     PatternIsEmpty
                        jmp     PatternIsEmpty
Buggar:
                        lda     NED_Temp1
:

                        clc

                        ADC     NED_NedAddr
                        STA     NED_ChnPatAddrLo,X
                        STA     NED_TempWord2Lo
                        ;INY
                        LDA     (NED_TempWord),Y
                        ADC     NED_NedAddr+1
                        STA     NED_ChnPatAddrHi,X
                        STA     NED_TempWord2Hi

                        LDY     #0              ; Read StartRow & EndRow vars
                        LDA     (NED_TempWord2),Y
                        STA     NED_ChnPatRowsToSkip,X
                        INY
                        LDA     (NED_TempWord2),Y
                        ;clc     ; remove! probably not needed
                        ADC     #1
                        STA     NED_ChnPatRowsTotal,X

                        ADC     #1
                        ;adc     #5
                        LSR
                        clc
                        ADC     #2
                        STA     NED_ChnPatOffs,x
                        lda     #0
                        sta     NED_ChnNibAddrOdd,x

BackFromPatternIsEmpty:
                        dex
                        bpl     :--

DontRecalcPtrs:

                LDX     #4      ; This now includes DPCM!!!
@DecodeChnLoop:
                DEC     NED_ChnPatRowsTotal,X
                BMI     @DoneDecoding0
                DEC     NED_ChnPatRowsToSkip,X
                BPL     @DoneDecoding0

                jmp     :+
@DoneDecoding0:
                JMP     @DoneDecoding
:

                LDA     NED_ChnPatAddrLo,X
                STA     NED_TempWord
                LDA     NED_ChnPatAddrHi,X
                STA     NED_TempWord+1

@DecodeChn0:    LDA     NED_CurrRow                             ; 3
                LSR                                             ; 2
                TAY                                             ; 2
                INY
                INY
                LDA     (NED_TempWord),Y                        ; 5
                BCC     @LowerNib                               ; 2
                        LSR                                     ; 2
                        LSR                                     ; 2
                        LSR                                     ; 2
                        LSR                                     ; 2
@LowerNib:
                ldy     NED_ChnNibAddrOdd,x
                sty     NED_Temp1
                bit     NED_Temp1
                LDY     NED_ChnPatOffs,x                        ; 3
                LSR                                             ; 2
                STA     NED_Temp1                               ; 3

                BCC     @ToneNotPresent                         ; 2
;                beq     +
;                .byte $FF
;+

                        cpx     #NOSWAV_CHN
                        beq     @NoiseTone
                        bvs   @ToneAddrOdd
                                LDA     (NED_TempWord),Y        ; 5
                                INY                             ; 2
                                ;clv
                                JMP     @ToneDecoded            ; 3
@ToneAddrOdd:
                        LDA     (NED_TempWord),Y                ; 5
                        AND     #$F0                            ; 2

                        STA     NED_Temp2                       ; 3
                        INY                                     ; 2
                        LDA     (NED_TempWord),Y                ; 5
                        AND     #$0F                            ; 2

                        ORA     NED_Temp2                       ; 3
                        ;bit     NED_Temp3
                        jmp     @ToneDecoded

@NoiseTone:
                        bvs     @NosToneAddrOdd
                                lda     (NED_TempWord),Y
                                and     #$0F
                                ;clc
                                ;adc     #1
                                SBC     #$FF
                                bit     NED_Temp3
                                jmp     @ToneDecoded

@NosToneAddrOdd:        lda     (NED_TempWord),Y
                        lsr
                        lsr
                        lsr
                        lsr
                        clc
                        adc     #1
                        ;SBC     #$FF
                        iny
                        clv

@ToneDecoded:
                STA     NED_ChnTone,x                           ; 3


@ToneNotPresent:
                LSR     NED_Temp1                               ; 5
                BCC     @InstNotPresent                         ; 2
                        bvs     @InstAddrOdd
                                LDA     (NED_TempWord),Y        ; 5
                                AND     #$0F                    ; 2

                                ADC     #0
                                STA     NED_ChnInst,x                           ; 3

                                bit     NED_Temp3
                                JMP     @InstDecoded            ; 3

@InstAddrOdd:
                        LDA     (NED_TempWord),Y                ; 5
                        LSR                                     ; 2
                        LSR                                     ; 2
                        LSR                                     ; 2
                        LSR                                     ; 2
                        INY                                     ; 2

                        CLC
                        ADC     #1
                        STA     NED_ChnInst,x                           ; 3
                        clv     ; will work now?...
                        
@InstDecoded:                                                   ; 2
                ;STA     NED_ChnInst,x                           ; 3
                ;inc     NED_ChnInst,x                           ; 5-6
@InstNotPresent:
                LSR     NED_Temp1                               ; 5
                BCC     @EffectNotPresent
                        bvs     @EffectAddrOdd
                                LDA     (NED_TempWord),Y        ; 5
                                AND     #$0F                    ; 2
                                bit     NED_Temp3
                                JMP     @EffectDecoded          ; 3
@EffectAddrOdd:
                        LDA     (NED_TempWord),Y                ; 5
                        LSR                                     ; 2
                        LSR                                     ; 2
                        LSR                                     ; 2
                        LSR                                     ; 2
                        INY                                     ; 2
                        clv     ; will work now?...

@EffectDecoded:
                STA     NED_ChnEff,x                            ; 3
@EffectNotPresent:
                LSR     NED_Temp1                               ; 5
                BCC     @EffParmNotPresent                      ; 2
                        bvs     @EffParmAddrOdd
                                LDA     (NED_TempWord),Y        ; 5
                                INY                             ; 2
                                ;clv
                                JMP     @EffParmDecoded         ; 3
@EffParmAddrOdd:
                        LDA     (NED_TempWord),Y                ; 5
                        AND     #$F0                            ; 2

                        STA     NED_Temp2                       ; 3
                        INY                                     ; 2
                        LDA     (NED_TempWord),Y                ; 5
                        AND     #$0F                            ; 2

                        ORA     NED_Temp2                       ; 3
                        ;bit     NED_Temp3

@EffParmDecoded:
                STA     NED_ChnEffParm,x                        ; 3
@EffParmNotPresent:

                STY     NED_ChnPatOffs,x

                LDA     #$40
                BVS     @DontClearV
                        LDA     #0
@DontClearV:
                STa     NED_ChnNibAddrOdd,x                     ; 3 =~= 180 c
                                                ; (180*4)/114=6-7 rasterlines
@DoneDecoding:
                dex
                bmi     :+
                jmp     @DecodeChnLoop
:


                RTS





UpdateChannelsT0:
                        ldx     #3
:
                        ;lda     NED_ChnVblanksLeft,X
                        ldy     NED_ChnVblanksLeft,X
                        bmi     @HoldNoteOnT0
                        ;sec
                        ;sbc     #1
                        dey
                        bpl     @DontSetNoteOffT0
                                lda     NED_ChnBitIndexInv,X
                                and     NED_Reg4015
                                sta     NED_Reg4015
                                lda     #0
                                ldy     #0

@DontSetNoteOffT0:
                        ;sta     NED_ChnVblanksLeft,X
                        sty     NED_ChnVblanksLeft,X
                        ;beq     @NotTriChn
@HoldNoteOnT0:

                dex
                bpl     :-


                lda     $4015
                and     #$10
                bne     :+
                lda     NED_Reg4015
                and     #$0F
                sta     NED_Reg4015
:

                        LDA     NED_Reg4015
                        STA     $4015


                        ldx     #3
@UpdateLoop:
                        jsr     DoEffsT0
                        CPX     #TRIWAV_CHN
                        BEQ     @SkipSetVolume
                        lda     NED_ChnInst,X
                        bne     @SetVolume
                        lda     NED_ChnEff,X
                        cmp     #NED_EffSetVol
                        beq     @SetVolume
                        jmp     @SkipSetVolume

@SetVolume:
                        LDA     NED_ChnVolume,X
                        LSR
                        LSR
                        ORA     NED_ChnReg0,X
                        LDY     NED_Chn2RegIndex,X
                        STA     $4000,Y
@SkipSetVolume:

                        dex
                        bpl     @UpdateLoop

                        INC     NED_ChnBigTick
                        INC     NED_ChnBigTick+1
                        INC     NED_ChnBigTick+2
                        INC     NED_ChnBigTick+3

                        INC     NED_CurrRow


                        RTS

VblankInt:


                ldx     #$00
                ldy     #$10
                @Loop:
                dex
                bne     @Loop
                dey
                bne     @Loop


                dec     NED_PAL_Counter
                bpl     DontSkip
                lda     #$05
                sta     NED_PAL_Counter
;                jmp     Skip

                lda     #$1E
;                sta     $2001

DontSkip:       JSR     NED_PlayNED
Skip:
                lda     #$06
;                sta     $2001
                rti

IRQhandler:     rti


NSF_Play:

                BIT     NED_PAL_Counter ; Don't skip if running on PAL...
                BMI     @DontSkip

                dec     NED_PAL_Counter
                BPL     @DontSkip
                lda     #$05
                sta     NED_PAL_Counter
                jmp     @Skip

@DontSkip:     Jmp     NED_PlayNED
@Skip:

                rts

NSF_InitSong:
                ldy     #$FF
                                
                DEX
                BEQ     @RunningOnPal
                ldy     #$05
@RunningOnPal:
                sty     NED_PAL_Counter

                asl
                tay

                lda     NED_Songs+1,Y
                tax
                lda     NED_Songs,Y


;                LDA     #<NED_SONG
;                LDX     #>NED_SONG

                JSR     NED_SetupNED
                rts

.segment "RODATA"

NED_SEV_Emulator:       .byte     $C0

NED_NibbleNegationTab:  .byte     $00,$FF,$FE,$FD,$FC,$FB,$FA,$F9
                        .byte     $F8,$F7,$F6,$F5,$F4,$F3,$F2,$F1

NED_Chn2RegIndex:       .byte     $00,$04,$08,$0C

NED_ChnBitIndex:        .byte     $01,$02,$04,$08
NED_ChnBitIndexInv:     .byte     $FE,$FD,$FB,$F7



Pos2TabPos:     .byte $00,$10,$20,$30,$40,$50,$60,$70
                .byte $80,$90,$A0,$B0,$C0,$D0,$E0,$F0
                .byte $E0,$D0,$C0,$B0,$A0,$90,$80,$70
                .byte $60,$50,$40,$30,$20,$10,$00

VibAndTremTab:  .byte 0, 0, 0, 1, 1, 1, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5
                .byte 0, 0, 1, 2, 3, 3, 4, 5, 6, 6, 7, 8, 9, 9, 10, 11
                .byte 0, 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 15, 16, 17
                .byte 0, 1, 3, 4, 6, 7, 9, 10, 12, 13, 15, 16, 18, 19, 21, 22
                .byte 0, 1, 3, 5, 7, 9, 11, 13, 15, 16, 18, 20, 22, 24, 26, 28
                .byte 0, 2, 4, 6, 8, 11, 13, 15, 17, 19, 22, 24, 26, 28, 30, 33
                .byte 0, 2, 5, 7, 10, 12, 15, 17, 20, 22, 25, 27, 30, 32, 35, 37
                .byte 0, 2, 5, 8, 11, 14, 16, 19, 22, 25, 28, 30, 33, 36, 39, 42
                .byte 0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 40, 43, 46
                .byte 0, 3, 6, 9, 13, 16, 19, 23, 26, 29, 33, 36, 39, 43, 46, 49
                .byte 0, 3, 7, 10, 14, 17, 21, 24, 28, 31, 35, 38, 42, 45, 49, 52
                .byte 0, 3, 7, 11, 14, 18, 22, 25, 29, 33, 36, 40, 44, 47, 51, 55
                .byte 0, 3, 7, 11, 15, 19, 22, 26, 30, 34, 38, 41, 45, 49, 53, 57
                .byte 0, 3, 7, 11, 15, 19, 23, 27, 31, 35, 39, 42, 46, 50, 54, 58
                .byte 0, 3, 7, 11, 15, 19, 23, 27, 31, 35, 39, 43, 47, 51, 55, 59
                .byte 0, 3, 7, 11, 15, 19, 23, 27, 31, 35, 39, 43, 47, 51, 55, 59


Tone2PeriodLoTab: .byte $5C, $9C, $E8, $3C, $9C, $2F, $72, $EC, $FF, $F2, $80, $14
                 .byte $AE, $4E, $F4, $9E, $4E, $1,  $B9, $76, $35, $F9, $C0, $8A 
                 .byte $57, $27, $FA, $CF, $A7, $81, $5D, $3B, $1B, $FD, $E0, $C5 
                 .byte $AC, $94, $7D, $68, $53, $40, $2E, $1D, $D,  $FE, $F0, $E3 
                 .byte $D6, $CA, $BE, $B4, $AA, $A0, $97, $8F, $87, $7F, $78, $71
                 .byte $6B, $65, $5F, $5A, $55, $50, $4C, $47, $43, $40, $3C, $39 
                 .byte $35, $32, $30, $2D, $2A, $28, $26, $24, $22, $20, $1E, $1C 
                 .byte $1B, $19, $18, $16, $15, $14, $13, $12, $11, $10, $F,  $E

Tone2PeriodHiTab:  .byte $7, $7, $7, $7, $7, $7, $7, $7, $7, $7, $7, $7
                 .byte $6, $6, $5, $5, $5, $5, $4, $4, $4, $3, $3, $3 
                 .byte $3, $3, $2, $2, $2, $2, $2, $2, $2, $1, $1, $1 
                 .byte $1, $1, $1, $1, $1, $1, $1, $1, $1, $0, $0, $0 
                 .byte $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0 
                 .byte $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0 
                 .byte $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0 
                 .byte $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0, $0

NED_Songs: ; = *
NED_Songsx:
                .addr     ned1
                .addr     ned2
                .addr     ned3
                .addr     ned4
                .addr     ned5
                .addr     ned6
                .addr     ned7
                .addr     ned8
                .addr ned9
                .addr ned10
                .addr ned11
                .addr ned12
                .addr ned13
                .addr ned14
                .addr ned15
                .addr ned16
                .addr ned17


NED_SONG = *

.include "songs.asm"

.segment "CODE"

.INClude "DPCMCODE.INC"


