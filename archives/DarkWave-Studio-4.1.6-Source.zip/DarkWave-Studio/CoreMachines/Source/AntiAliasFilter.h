/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef ANTI_ALIAS_FILTER_H
#define ANTI_ALIAS_FILTER_H

#include "DarkPlug.h"
#include "Control.h"
#include "FIR.h"
#include "LiteKnob.h"
#include "LiteButton.h"

class CAntiAliasFilterGUI;
class CAntiAliasFilterInfo;

class CAntiAliasFilter : public CMachine
{
public:
                CAntiAliasFilter(CHost *host, CAntiAliasFilterInfo *info);
  virtual      ~CAntiAliasFilter();
  void          GenerateFIRs();
  CStereoFIR   *CreateFIR(int zc, int oversampling);
  virtual void  DARKCALL Work();
  void          DARKCALL ProcessMessage(SControlMessage *message);
  virtual void  DARKCALL GetPropertyName(int index, char *text);
  virtual void  DARKCALL GetPropertyValueDisplay(int index, double value, char *text);
  virtual double DARKCALL GetProperty(int index);
  virtual void  DARKCALL SetProperty(int index, double value);
  virtual HWND  DARKCALL CreateGUI(HWND parent);
  void          DARKCALL SetSampling(bool value);
  virtual void  DARKCALL SetSampleRate(int sampleRate);
  virtual void  DARKCALL SetBlockSamples(int blockSamples);
  virtual bool  DARKCALL GetGUIRect(short *x1, short *y1, short *x2, short *y2);
  virtual void  DARKCALL OnShowGUI();
  virtual bool  DARKCALL IsSynth();

private:
  CColorManager        *ColorManager;

  int                   nSamples;

  int           SampleRate, BlockSamples;
  double        *Properties;
  CStereoFIR  **Filters;  
  int           Oversampling;       
  CAntiAliasFilterGUI   *GUI;
  CAntiAliasFilterInfo  *Info;
};



class CAntiAliasFilterInfo : public CMachineInfo
{
public:
                     CAntiAliasFilterInfo(CHost *host);
                    ~CAntiAliasFilterInfo();
  CMachine* DARKCALL CreateMachine();

  CFrameBuffer *Background, *ButtonsOn, *ButtonsOff;
private:
  CHost *Host;
};

struct SArea
{
  int x1, y1, x2, y2;
};

class CAntiAliasFilterGUI : public CLiteContainer 
{
public:
                CAntiAliasFilterGUI(HWND parent, CAntiAliasFilter *antiAliasFilter, CAntiAliasFilterInfo *info);
               ~CAntiAliasFilterGUI();
  void          SetProperty(int index, double value);
  virtual void  OnShowGUI();
  virtual void  DrawBackground(int x1, int y1, int x2, int y2, int w, int h);
  virtual void  OnLeftButtonDown(int x, int y);

private:
  SArea                 ButtonArea[5];
  int                   Button;
  CAntiAliasFilter     *AntiAliasFilter;
  CAntiAliasFilterInfo *Info;
};


#endif
