/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef LITEBUTTON_H
#define LITEBUTTON_H

#include "LiteControl.h"

#define STATE_IDLE   0
#define STATE_HOVER  1
#define STATE_CLICK  2

class CLiteButton : public CLiteControl
{
public:

  CLiteButton(CLiteContainer *parent, int x, int y, int w, int h, CFrameBuffer *picture, CFrameBuffer *hoverPicture, CFrameBuffer *clickPicture);
 ~CLiteButton();
  virtual void Draw(CFrameBuffer *buffer);
  CFrameBuffer *Picture, *HoverPicture, *ClickPicture;
  virtual void OnMouseMove(int x, int y);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  virtual void SetState(int newState);
  bool Enabled;
  bool Sticky;
  int  State;
};



#endif