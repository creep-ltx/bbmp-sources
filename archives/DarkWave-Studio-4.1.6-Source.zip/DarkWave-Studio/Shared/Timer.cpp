/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "Timer.h"

VOID CALLBACK TimerFunction(HWND hWnd, UINT msg, UINT_PTR idEvent, DWORD dwTime)
{
  CTimer *timer;

  timer = (CTimer*)idEvent;

  if(msg == WM_TIMER && timer != 0)
  {
    timer->OnTimer();
  }
}

CTimer::CTimer(CTimerCallback *callback, HWND window)
{
  Callback = callback;
  Window = window;
  Timer = 0;
}

CTimer::~CTimer()
{
  if(Timer != 0)
    Kill();
}

void CTimer::Set(int delay)
{
  if(Timer != 0)
    Kill();

  Timer = SetTimer(Window, (UINT_PTR)this, delay, &TimerFunction);
}

void CTimer::Kill()
{
  KillTimer(NULL, Timer);
  Timer = 0;
}

void CTimer::OnTimer()
{
  Callback->OnTimer(this);
}