/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef PEAK_METER_H
#define PEAK_METER_H

#include "Control.h"
#include "../Shared/BackBuffer.h"
#include "../Shared/FrameBuffer.h"
#include "../Shared/DarkPlug.h"

#define PEAK_METER_BORDER_H  2
#define PEAK_METER_BORDER_V  2
#define PEAK_METER_LED_WIDTH 2
#define PEAK_METER_LED_GAP   1
#define PEAK_METER_WIDTH_90  ((2 * PEAK_METER_BORDER_H) + (30 * (PEAK_METER_LED_WIDTH + PEAK_METER_LED_GAP)) + 2)
#define PEAK_METER_WIDTH_60  ((2 * PEAK_METER_BORDER_H) + (20 * (PEAK_METER_LED_WIDTH + PEAK_METER_LED_GAP)) + 2)
#define PEAK_METER_WIDTH_30  ((2 * PEAK_METER_BORDER_H) + (10 * (PEAK_METER_LED_WIDTH + PEAK_METER_LED_GAP)) + 2)

class CPeakMeter : public CControl, public CMutex
{
public:
              CPeakMeter(CControl *parent, int x, int y, int width, int height);
             ~CPeakMeter();
 void         DrawControl();
 void         SetPeak(double left, double right);
 void         Idle();
 void         Redraw();
 double       ClipPeakToDB(double value);
 void         MaxPeakDB(double newDB, double &oldDB, DWORD &lastTick);
 void         IdleInner(DWORD &lastTick, DWORD thisTick, double &peakDB);
 void         DrawBar(int x, int y, int ledHeight, int ledCount, double currentDB, double peakDB, double minDB, COLORREF colors[3]);
 void         DrawLED(int x, int y, int height, int offset, COLORREF colors[3], bool on);

private:
  CFrameBuffer *FrameBuffer;
  double        PeakDBLeft, PeakDBRight, CurrentDBLeft, CurrentDBRight;
  DWORD         LastTickLeft, LastTickRight;
};

#endif