/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2011 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "StereoJoiner.h"

CStereoJoiner::CStereoJoiner(CHost *host)
: CMachine(host)
{
  PropertyCount = 0;

  BlockSamples = host->GetBlockSamples();
  
  PortCount = 3;
  Ports = new CPort*[3];
  Ports[0] = new CPort(host, this, PT_AUDIO | PT_INPUT  | PT_MONO,   "Left In");
  Ports[1] = new CPort(host, this, PT_AUDIO | PT_INPUT  | PT_MONO,   "Right In");
  Ports[2] = new CPort(host, this, PT_AUDIO | PT_OUTPUT | PT_STEREO, "Stereo Out");
}

void CStereoJoiner::SetBlockSamples(int blockSamples)
{
  BlockSamples = blockSamples;
}

void CStereoJoiner::SetSampleRate(int sampleRate)
{
}

bool CStereoJoiner::IsSynth()
{
  return false;
}

CStereoJoiner::~CStereoJoiner()
{
  delete Ports[0];
  delete Ports[1];
  delete Ports[2];
  delete Ports;
}

void CStereoJoiner::Work()
{
  int i;
  double *inLeft, *inRight;
  double *outLeft, *outRight;
  
  inLeft  = Ports[0]->AudioBuffer->MonoData;
  inRight = Ports[1]->AudioBuffer->MonoData;

  outLeft  = Ports[2]->AudioBuffer->LeftData;
  outRight = Ports[2]->AudioBuffer->RightData;
  
  for(i = 0; i < BlockSamples; i++)
  {
    *(outLeft++)  = *(inLeft++);
    *(outRight++) = *(inRight++);
  }  
}

CStereoJoinerInfo::CStereoJoinerInfo(CHost *host)
{
  Host = host;
  Name = "ES StereoJoiner";
  UniqueID = "DarkPlug::ES StereoJoiner";
}

CMachine *CStereoJoinerInfo::CreateMachine()
{
  return new CStereoJoiner(Host);
}

