/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef BANKEXPLORER_H
#define BANKEXPLORER_H

#include "Control.h"
#include "ListBox.h"
#include "InfoView.h"
#include "ToolBar.h"
#include "FileDialog.h"
#include "DarkPlug.h"
#include "SizeBar.h"

class CBankExplorer : public CControl, public CBankClient
{
public:
               CBankExplorer(CHost *host, CControl *parent, int x, int y, int width, int height);
              ~CBankExplorer();
  virtual void OnResize(int newWidth, int newHeight);
  virtual void OnToolBarButtonPress(CToolBarButton *button);
  void         LoadBank();
  virtual void DARKCALL OnAddBank(int bankIndex);
  void         PerformLayout();
  virtual void OnListSelChange(CListBox *listBox);
  void         ShowBank(int index);
  virtual void OnSizeX(CSizeBar *sizeBar, int amount);
  virtual void OnSizeY(CSizeBar *sizeBar, int amount);
  float        NewPercent(int amount, int max, float oldPercent);
  virtual void OnListDblClick(CListBox *listBox);

private:
  CListBox       *BankList, *PresetList, *SampleList;
  CInfoView      *InfoView;
  CToolBar       *ToolBar;
  CToolBarButton *LoadButton;
  CFileDialog    *LoadDialog;
  float           BankListPercent,  InfoViewPercent,  PresetListPercent;
  int             BankListWidth,    InfoViewHeight,   PresetListWidth;
  CSizeBar       *BankListSizeBar, *InfoViewSizeBar, *PresetListSizeBar;
};

#endif