/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef COLOR_MANAGER_H
#define COLOR_MANAGER_H

#include "Brush.h"
#include "Pen.h"
#include "DarkPlug.h"

enum ColorManagerColor
{
  Black,
  White,
  ControlBack,
  ControlBackDisabled,
  ControlText,
  ControlTextDisabled,
  ControlLight,
  ControlShadow,
  WindowWorkspace,
  HighlightBack,
  HighlightText,
  FlatBack,
  FlatText,
  CableLight,
  CableShadow,
  CableBack,
  KeyWhiteBack,
  KeyWhiteBackPressed,
  KeyWhiteText,
  KeyWhiteTextActive,
  KeyBlackBack,
  KeyBlackBackPressed,
  KeyBlackText,
  KeyBlackTextActive,
  GridCell,
  GridCellAlt,
  GridCellAlt2,
  GridLine,
  GridLineInner,
  NoteLight,
  NoteShadow,
  NoteBack,
  NoteBackHighlight,
  NoteText,
  LCDBack,
  LCDLight,
  TextAreaBack,
  TextAreaText,
  TextAreaSelBack,
  TextAreaSelText,
  TextAreaHighlightBack,
  TextAreaHighlightText,
  MeterLow,
  MeterMid,
  MeterHigh,
  SelectBox
};

#define COLOR_MANAGER_COLOR_COUNT 46

struct ColorManagerPreset
{
  COLORREF Colors[COLOR_MANAGER_COLOR_COUNT];
};

class CColorManager : public CMutex
{
public:
                 CColorManager();
                 CColorManager(CColorManager *parent);
                 CColorManager(CHost *host);
                ~CColorManager();
  int            GetColor(ColorManagerColor color);
  CBrush        *GetBrush(ColorManagerColor color);
  CPen          *GetPen(ColorManagerColor color);
  void           SetColor(ColorManagerColor color, COLORREF value);
  virtual void DARKCALL  Lock();
  virtual void DARKCALL  Release();

private:
  int                 PresetCount, CurrentPreset;
  ColorManagerPreset *Presets;
  CBrush             *Brushes[COLOR_MANAGER_COLOR_COUNT];
  CPen               *Pens[COLOR_MANAGER_COLOR_COUNT];
  bool                InheritColors[COLOR_MANAGER_COLOR_COUNT];
  CColorManager      *Parent;
};

#endif