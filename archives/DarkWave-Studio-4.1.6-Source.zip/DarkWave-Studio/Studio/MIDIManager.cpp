/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "MIDIManager.h"

CMIDIManager::CMIDIManager()
{
  int i;

  InputDeviceCount = midiInGetNumDevs();
  InputDevices = new CMIDIInputDevice*[InputDeviceCount];
  for(i = 0; i < InputDeviceCount; i++)
    InputDevices[i] = new CMIDIInputDevice(i);

  OutputDeviceCount = midiOutGetNumDevs();
  OutputDevices = new CMIDIOutputDevice*[OutputDeviceCount];
  for(i = 0; i < OutputDeviceCount; i++)
    OutputDevices[i] = new CMIDIOutputDevice(i);
}

CMIDIManager::~CMIDIManager()
{
  int i;

  for(i = 0; i < InputDeviceCount; i++)
    delete InputDevices[i];
  delete InputDevices;

  for(i = 0; i < OutputDeviceCount; i++)
    delete OutputDevices[i];
  delete OutputDevices;
}

