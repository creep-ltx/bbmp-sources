/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef AUDIO_OUT_OPTIONS_H
#define AUDIO_OUT_OPTIONS_H

#include "OptionsFrame.h"
#include "NullDriver.h"
#include "ASIODriver.h"
#include "WaveOutDriver.h"
#include "DirectSoundDriver.h"

class CDropList;
class CLabel;
class CAudioOutOptions;
class CWaveOutDriver;

class CAudioOutDriverOptions : public CFrame
{
public:
               CAudioOutDriverOptions(CAudioOutOptions *parent, char *name, int x, int y, int width, int height);
  virtual     ~CAudioOutDriverOptions();
  virtual bool ApplyChanges() = 0;
  void         OnChange();

private:
  CAudioOutOptions *AudioOutOptions;
};

class CWaveOutOptions : public CAudioOutDriverOptions
{
public:
               CWaveOutOptions(CAudioOutOptions *parent, int x, int y, int width, int height);
  virtual     ~CWaveOutOptions();
  void         ShowDevice(int device);
  virtual void OnComboSelect(CDropList *comboBox);
  virtual bool ApplyChanges();
  virtual void OnSliderChange(CSlider *slider, double value);
  virtual void OnResize(int newWidth, int newHeight);

private:
  CLabel         *DeviceLabel, *FormatLabel, *LatencyLabel;
  CDropList      *DeviceCombo, *FormatCombo;
  CWaveOutDriver *Driver;
  CSlider        *LatencySlider;
  int             DeviceCount, Device, *DeviceFormats, DeviceFormatCount;
  int             DeviceFormat, Latency;
};

class CNullOutOptions : public CAudioOutDriverOptions
{
public:
               CNullOutOptions(CAudioOutOptions *parent, int x, int y, int width, int height);
  virtual     ~CNullOutOptions();
  void         ShowDevice(int device);
  virtual void OnComboSelect(CDropList *comboBox);
  virtual bool ApplyChanges();
  virtual void OnSliderChange(CSlider *slider, double value);
  virtual void OnResize(int newWidth, int newHeight);

private:
  CLabel         *DeviceLabel, *FormatLabel, *LatencyLabel;
  CDropList      *DeviceCombo, *FormatCombo;
  CNullDriver    *Driver;
  CSlider        *LatencySlider;
  int             DeviceCount, Device, *DeviceFormats, DeviceFormatCount;
  int             DeviceFormat, Latency;
};

class CASIOOutOptions : public CAudioOutDriverOptions
{
public:
               CASIOOutOptions(CAudioOutOptions *parent, int x, int y, int width, int height);
  virtual     ~CASIOOutOptions();
  void         ShowDevice(int device);
  virtual bool ApplyChanges();
  virtual void OnSliderChange(CSlider *slider, double value);
  virtual void OnComboSelect(CDropList *comboBox);
  virtual void OnResize(int newWidth, int newHeight); 
private:
  CLabel         *DeviceLabel, *FormatLabel, *LatencyLabel, *ChannelsLabel;
  CDropList      *DeviceCombo, *FormatCombo;
  CASIODriver    *Driver;
  CSlider        *LatencySlider;
  int             DeviceCount, Device, *DeviceFormats, DeviceFormatCount;
  int             DeviceFormat, Latency;
};

class CDirectSoundOptions : public CAudioOutDriverOptions
{
public:
               CDirectSoundOptions(CAudioOutOptions *parent, int x, int y, int width, int height);
  virtual     ~CDirectSoundOptions();
  void         ShowDevice(int device);
  virtual void OnComboSelect(CDropList *comboBox);
  virtual bool ApplyChanges();
  virtual void OnSliderChange(CSlider *slider, double value);
  virtual void OnResize(int newWidth, int newHeight);

private:
  CLabel             *DeviceLabel, *FormatLabel, *LatencyLabel;
  CDropList          *DeviceCombo, *FormatCombo;
  CDirectSoundDriver *Driver;
  CSlider            *LatencySlider;
  int                 DeviceCount, Device, *DeviceFormats, DeviceFormatCount;
  int                 DeviceFormat, Latency;
};

class CAudioOutOptions : public COptionsFrame
{
public:
               CAudioOutOptions(COptionsDialog *parent, int x, int y, int width, int height);
  virtual     ~CAudioOutOptions();
  void         ShowDriver(int index);
  virtual void ApplyChanges();
  virtual void OnComboSelect(CDropList *comboBox);
  virtual void OnResize(int newWidth, int newHeight);

private:
  CDropList               *DriverCombo;
  CLabel                  *DriverLabel;
  CAudioOutDriverOptions **DriverOptions, *CurrentDriverOptions;
  int                      DriverOptionCount;
  bool                     DriverChanged;
};

#endif