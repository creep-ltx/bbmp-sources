/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "MIDIInputDevice.h"
#include "Error.h"
#include "Core.h"

void CALLBACK MIDIInCallback(HMIDIIN hMIDIIn, UINT msg, DWORD_PTR instanceData, DWORD param1,DWORD param2)
{
  ((CMIDIInputDevice*)instanceData)->OnMessage(msg, param1, param2);
}

CMIDIInputDevice::CMIDIInputDevice(unsigned int deviceID)
{
  MIDIINCAPS caps;
  MMRESULT   s;
  size_t     len;

  ID = deviceID;
  Hooks = 0;
  HookCount = 0;
  OpenCount = 0;
  Handle = 0;

  s = midiInGetDevCaps(ID, &caps, sizeof(MIDIINCAPS));
  if(s != MMSYSERR_NOERROR)
    ThrowString("midiInGetDevCaps Returned 0x%x For Device ID %n", s, ID);

  len = strlen(caps.szPname) + 1;
  Name = new char[len];
  strcpy(Name, caps.szPname);
}

CMIDIInputDevice::~CMIDIInputDevice()
{
  while(OpenCount > 0)
    Close();
  if(HookCount > 0)
    delete Hooks;
  delete Name;
}

void CMIDIInputDevice::Open()
{
  MMRESULT s;

  if(OpenCount == 0)
  {
    s = midiInOpen(&Handle, ID, (DWORD_PTR)&MIDIInCallback, (DWORD_PTR)this, CALLBACK_FUNCTION);
    if(s != MMSYSERR_NOERROR)
      ThrowString("midiInOpen For Device <%s> Failed With Error Code 0x%x", Name, s);
    s = midiInStart(Handle);
    if(s != MMSYSERR_NOERROR)
      ThrowString("midiInStart For Device <%s> Failed With Error Code 0x%x", Name, s);
  }
  OpenCount++;
}

void CMIDIInputDevice::Close()
{
  MMRESULT s;

  if(OpenCount > 0)
  {
    OpenCount -= 1;
    if(OpenCount == 0)
    {
      s = midiInClose(Handle);
      Handle = 0;
      if(s != MMSYSERR_NOERROR)
        ThrowString("midiInClose For Device <%s> Failed With Error Code 0x%x", Name, s);
    }
  }
}

void CMIDIInputDevice::OnMessage(unsigned int message, long param1, long param2)
{
  unsigned char status, data1, data2;

  if(message == MIM_DATA)
  {
    status = LOBYTE(LOWORD(param1));
    data1  = HIBYTE(LOWORD(param1));
    data2  = LOBYTE(HIWORD(param1));
    CallHooks(status, data1, data2);
  }
}

void CMIDIInputDevice::AddHook(MIDIInputHook *hook, void *userData)
{
  int                 i;
  MIDIInputHookEntry *newHooks;

  for(i = 0; i < HookCount; i++)
    if(Hooks[i].Hook == hook && Hooks[i].UserData == userData)
      ThrowString("AddHook: Hook Already Added");

  if(HookCount == 0)
  {
    Hooks = new MIDIInputHookEntry[1];
    Hooks[0].Hook = hook;
    Hooks[0].UserData = userData;
    HookCount = 1;
  }
  else
  {
    newHooks = new MIDIInputHookEntry[HookCount + 1];
    for(i = 0; i < HookCount; i++)
    {
      newHooks[i].Hook     = Hooks[i].Hook;
      newHooks[i].UserData = Hooks[i].UserData;
    }

    newHooks[HookCount].Hook     = hook;
    newHooks[HookCount].UserData = userData;

    delete Hooks;
    Hooks = newHooks;
    HookCount++;
  }
}

void CMIDIInputDevice::RemoveHook(MIDIInputHook *hook, void *userData)
{
  int                 i, j;
  MIDIInputHookEntry *newHooks;
  bool                found;

  found = false;
  for(i = 0; i < HookCount; i++)
    if(Hooks[i].Hook == hook && Hooks[i].UserData == userData)
    {
      found = true;
      break;
    }

  if(!found)
    ThrowString("RemoveHook: Not Found");

  if(HookCount == 1)
  {
    delete Hooks;
    HookCount = 0;
  }
  else
  {
    j = 0;
    newHooks = new MIDIInputHookEntry[HookCount - 1];

    for(i = 0; i < HookCount; i++)
    {
      if(Hooks[i].Hook != hook || Hooks[i].UserData != userData)
      {
        newHooks[j].Hook = Hooks[i].Hook;
        newHooks[j++].UserData = Hooks[i].UserData;
      }
    }
    delete Hooks;
    Hooks = newHooks;
    HookCount--;
  }
}

void CMIDIInputDevice::CallHooks(unsigned char status, unsigned char data1, unsigned char data2)
{
  int i;

  for(i = 0; i < HookCount; i++)
    (Hooks[i].Hook)(Hooks[i].UserData, status, data1, data2);
}