/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CONTROLVIEW_H
#define CONTROLVIEW_H

#include "Control.h"
#include "ScrollBar.h"
#include "BackBuffer.h"
#include "Pattern.h"
#include "ToolTip.h"
#include "Util.h"

class CControlView : public CControl
{
public:
               CControlView(CControl *parent, int x, int y, int width, int height, CScrollBar *scrollBarH);
              ~CControlView();
  virtual void OnResize(int newWidth, int newHeight);
  void         DrawControl();
  void         LoadPattern(CPattern *pattern);
  void         ScrollVertical(int offsetY);
  void         ScrollHorizontal(int offsetX);
  void         SizeControl();
  void         DrawGrid(HDC hDC);
  void         DrawControlChanges(HDC hDC);
  void         DrawHeaders(HDC hDC);
  void         DrawControlChange(HDC hDC, int pos, int row, SControlEntry *controlChange);
  void         DrawHeader(HDC hDC, int x, int y, int track);
  void         TrackLabel(int track, char *label);
  virtual void OnScrollX(int newPos);
  virtual void OnScrollY(int newPos);
  void         ControlChangeAt(int x, int y, int *row, int *pos);
  virtual void OnMouseMove(int x, int y);
  float        GetControlChangeValue(int row, int pos);
  void         SetControlChangeValue(int row, int pos, float value);
  void         GetControlChangeValueDisplay(int row, int pos, float value, char *text);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  virtual void OnLeftButtonDoubleClick(int x, int y);
  virtual void OnRightButtonDown(int x, int y);
  void         AddTrack(int parameter);
  void         RemoveTrack(int parameter);
  int          FindTrack(int parameter);
  bool         AddControlChange(int x, int y);
  void         RemoveControlChange(int x, int y);
  int          CellAt(int x);
  int          RowAt(int y);
  int          RowY(int row);

private:
  CScrollBar  *ScrollBarV, *ScrollBarH;
  CPattern    *Pattern;
  CFont       *HeaderFont;
  CToolTip    *ToolTip;
  int          Rows, Cols, OffsetX, OffsetY, LeftCol, LeftColX, TopRow, TopRowY;
  int          RightCol, BottomRow, MaxTopRow, MaxLeftCol;
  int          Mode, State;
  int          CurrentRow, CurrentPos, MouseX, MouseY;
  float        StartValue;
};

#endif