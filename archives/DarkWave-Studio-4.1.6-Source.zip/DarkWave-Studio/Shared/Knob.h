/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef KNOB_H
#define KNOB_H

#include "Control.h"
#include "Bitmap.h"
#include "BackBuffer.h"
#include "DarkPlug.h"
#include "Font.h"
#include "ToolTip.h"

class CKnob : public CControl
{
public:
               CKnob(CControl *parent, CToolTip *toolTip, CFont *font, CBitmap *bitmap, int imageWidth, int imageHeight, int x, int y, int width, int height);
              ~CKnob();
  void         DrawControl();
  virtual void OnPaint();
  void         BindToMachine(CMachine *machine, int parameter);
  virtual void OnLeftButtonDown(int x, int y);
  virtual void OnMouseMove(int x, int y);
  virtual void OnLeftButtonUp(int x, int y);
  void         SetValue(double value);
  void         UpdateToolTipText();

private:
  CBitmap     *Bitmap;
  CMachine    *Machine;
  CToolTip    *ToolTip;
  double       Value;
  int          Property, ImageWidth, ImageHeight, ImageCount;
  char        *Label;
  int          StartY;
  double       StartValue;
  bool         Moving;
};

#endif