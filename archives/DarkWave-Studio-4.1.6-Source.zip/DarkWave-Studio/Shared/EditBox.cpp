/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <windows.h>
#include "EditBox.h"
#include "Font.h"
#include <commctrl.h>

LRESULT EditProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  CEditBox *editBox;

  editBox = (CEditBox*)GetWindowLongPtrA(hWnd, GWLP_USERDATA);
	  return editBox->EditProc(hWnd, msg, wParam, lParam);
}

CEditBox::CEditBox(CControl *parent, char *name, int x, int y, int width, int height, bool multiline)
: CControl(parent, "EditContainer", x, y, width, height, false)
{
  Parent = parent;
  SetBorder(bs3DSunken);
  
  EditHandle = CreateWindowA("EDIT", name, WS_CHILD | (multiline ? ES_MULTILINE : 0), 
    1, 1, width - 2, height - 2, Handle, 0, AppInstance, 0);

  SetWindowLongPtrA(EditHandle, GWLP_USERDATA, (LONG_PTR)this);
  OldProc = (WNDPROC)SetWindowLongPtrA(EditHandle, GWLP_WNDPROC, (LONG_PTR)::EditProc);
  SendMessage(EditHandle, WM_SETFONT, (WPARAM)Font->Handle, TRUE);
  ShowWindow(EditHandle, SW_SHOW);
  SubInit = true;
}

void CEditBox::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  MoveWindow(EditHandle, 1, 1, Width - 2, Height - 2, TRUE);
  RedrawWindow(Handle, NULL, NULL, RDW_FRAME | RDW_INVALIDATE | RDW_UPDATENOW);
}

CEditBox::~CEditBox()
{
  DestroyWindow(EditHandle);
}

LRESULT CEditBox::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{    
  return CControl::WindowProc(hWnd, msg, wParam, lParam);
}

LRESULT CEditBox::EditProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  return OldProc(hWnd, msg, wParam, lParam);
}

char* CEditBox::GetText()
{
  int length;
  char *text;

  length = GetWindowTextLengthA(EditHandle) + 1;
  text = new char[length];
  GetWindowTextA(EditHandle, text, length);
  return text;
}

void CEditBox::SetText(char *text)
{
  SetWindowTextA(EditHandle, text);
}