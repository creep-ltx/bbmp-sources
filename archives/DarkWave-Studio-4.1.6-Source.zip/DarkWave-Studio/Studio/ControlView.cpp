/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ControlView.h"
#include "Core.h"

#define SCROLLBAR_SIZE 16
#define ROW_HEIGHT     128
#define HEADER_WIDTH   96
#define CELL_WIDTH     16
#define COL_WIDTH      (4 * CELL_WIDTH)
#define CELL_HEIGHT    14
#define TOOLTIP_X      18
#define TOOLTIP_Y      18

#define STATE_IDLE     0
#define STATE_WILLMOVE 1
#define STATE_MOVING   2

CControlView::CControlView(CControl *parent, int x, int y, int width, int height, CScrollBar *scrollBarH)
: CControl(parent, "NoteView", x, y, width, height, true)
{  
  Pattern = 0;
  OffsetY = 0;
  State   = STATE_IDLE;

  ToolTip = new CToolTip(Handle);
  ToolTip->AddTool(Handle, "", true);
  
  BackColor = (ColorManagerColor)WindowWorkspace;

  ScrollBarH = scrollBarH;
  ScrollBarV = new CScrollBar(this, SCROLLBAR_VERTICAL, Width - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, Height, 0, 0);
  ScrollBarV->SetLineSize(ROW_HEIGHT);
  ScrollBarV->Show();
  
  HeaderFont = new CFont(DC, "Verdana", 9.0f, true);
  SubInit = true;

  Rows = 0;
  Cols = 0;
  SizeControl();
  ScrollVertical(0);

  DrawControl();
}

CControlView::~CControlView()
{
  delete ToolTip;
  delete ScrollBarV;
  delete HeaderFont;
}

void CControlView::DrawControl()
{
  HDC hDC;

  hDC = BackDC;
  SetBkMode(hDC, TRANSPARENT);
  ColorManager->Lock();
  ColorManager->GetBrush(BackColor)->FillRect(hDC, 0, 0, Width, Height);
  ColorManager->Release();
  if(Pattern != 0)
  {
    DrawGrid(hDC);
    DrawControlChanges(hDC);
    DrawHeaders(hDC);
  }
}

void CControlView::LoadPattern(CPattern *pattern)
{
  Pattern = pattern;
  if(Pattern != 0)
  {
    Cols = Pattern->Length;
    Rows = Pattern->ControlTracks->Count;
  }
  else
  {
    Cols = 0;
    Rows = 0;
  }
  SizeControl();
  ScrollHorizontal(ScrollBarH->GetPos());
  ScrollVertical(0);
  ScrollBarV->SetPos(OffsetY);
  Update();
}

void CControlView::ScrollVertical(int offsetY)
{
  OffsetY   = offsetY;
  TopRow    = max(0, min(MaxTopRow, offsetY / ROW_HEIGHT));
  TopRowY   = (TopRow * ROW_HEIGHT) - offsetY;
  BottomRow = min(Rows - 1, TopRow + (Height / ROW_HEIGHT) + 1);
}

void CControlView::ScrollHorizontal(int offsetX)
{
  OffsetX   = offsetX;
  LeftCol   = min(MaxLeftCol, offsetX / COL_WIDTH);
  LeftColX  = HEADER_WIDTH + (LeftCol * COL_WIDTH) - offsetX;
  RightCol  = min(Cols - 1, LeftCol + ((Width - HEADER_WIDTH - SCROLLBAR_SIZE) / COL_WIDTH) + 1);
}

void CControlView::SizeControl()
{
  int maxPos;

  maxPos = (Rows * ROW_HEIGHT) - Height;
  ScrollBarV->SetMaxPos(maxPos);
  ScrollBarV->SetPageSize(Height - ROW_HEIGHT);
  MaxTopRow = min(Rows - 1, max(0, Rows - (Height / ROW_HEIGHT)));
  if(maxPos > 0)
    ScrollBarV->Show();
  else
    ScrollBarV->Hide();

  MaxLeftCol = min(Cols - 1, max(0, Cols - ((Width - HEADER_WIDTH - SCROLLBAR_SIZE) / COL_WIDTH)));
}

void CControlView::DrawGrid(HDC hDC)
{
  int     x, y, i;
  int     row, col;
  HGDIOBJ oldPen, oldPen2;
  CBrush *brush;

  ColorManager->Lock();

  oldPen = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)GridLine)->Handle);

  x = LeftColX;
  for(col = LeftCol; col <= RightCol; col++)
  {
    y = TopRowY;
    if(col % 8 < 4)
      brush = ColorManager->GetBrush((ColorManagerColor)GridCell);
    else
      brush = ColorManager->GetBrush((ColorManagerColor)GridCellAlt);

    for(row = TopRow; row <= BottomRow; row++)
    {
      brush->FillRect(hDC, x, y, COL_WIDTH - 1, ROW_HEIGHT - 1);
      MoveToEx(hDC, x, y + ROW_HEIGHT - 1, NULL);
      LineTo(hDC, x + COL_WIDTH - 1, y + ROW_HEIGHT - 1);
      LineTo(hDC, x + COL_WIDTH - 1, y - 1);
      oldPen2 = SelectObject(hDC, ColorManager->GetPen((ColorManagerColor)GridLineInner)->Handle);
      for(i = 1; i < 4; i++)
      {
        MoveToEx(hDC, x + (CELL_WIDTH * i), y, NULL);
        LineTo(hDC, x + (CELL_WIDTH * i), y + ROW_HEIGHT - 1);
      }
      SelectObject(hDC, oldPen2);
      y += ROW_HEIGHT;
    }
    x += COL_WIDTH;
  }

  SelectObject(hDC, oldPen);

  ColorManager->Release();
}

void CControlView::DrawControlChanges(HDC hDC)
{
  int            i, row;  
  CControlTrack *track;

  if(Pattern == 0 || Rows == 0)
    return;

  for(row = TopRow; row <= BottomRow; row++)
  {
    track = Pattern->ControlTracks->Items[row];
    for(i = (LeftCol * 4); i < ((RightCol + 1) * 4); i++)
    {
      if(track->Entries->Items[i]->Used)
        DrawControlChange(hDC, i, row, track->Entries->Items[i]); 
    }
  }
}

void CControlView::DrawControlChange(HDC hDC, int pos, int row, SControlEntry *controlChange)
{
  int x, y, width, height;
  ColorManagerColor color;

  if((State != STATE_IDLE) && (CurrentPos == pos) && (CurrentRow == row))
    color = (ColorManagerColor)NoteBackHighlight;
  else
    color = (ColorManagerColor)NoteBack;


  x      = LeftColX + ((pos - (LeftCol * 4)) * CELL_WIDTH);
  y      = TopRowY  + (row - TopRow) * ROW_HEIGHT;
  width  = CELL_WIDTH;
  height = CELL_HEIGHT;

  y += (int)((ROW_HEIGHT - CELL_HEIGHT) * (1.0f - controlChange->Value));

  ColorManager->Lock();
  ColorManager->GetBrush(color)->FillRect(hDC, x + 1, y + 1, width - 2, height - 2);
  DrawBorder(hDC, bs3DRaised, x, y, width, height, ColorManager->GetPen((ColorManagerColor)NoteLight), ColorManager->GetPen((ColorManagerColor)NoteShadow));
  ColorManager->Release();
}

void CControlView::DrawHeaders(HDC hDC)
{
  int     row;
  int     y;
  HGDIOBJ oldFont;

  oldFont = SelectObject(hDC, HeaderFont->Handle);

  y = TopRowY;
  for(row = TopRow; row <= BottomRow; row++)
  {
    DrawHeader(hDC, 0, y, row);
    y += ROW_HEIGHT;
  }

  SelectObject(hDC, oldFont);
}

void CControlView::DrawHeader(HDC hDC, int x, int y, int track)
{
  CBrush *brush;
  RECT    r;
  char    label[256];

  DrawBorder(hDC, bs3DRaised, x, y, HEADER_WIDTH, ROW_HEIGHT);

  ColorManager->Lock();

  brush = ColorManager->GetBrush((ColorManagerColor)ControlBack);
  SetTextColor(hDC, ColorManager->GetColor((ColorManagerColor)ControlText));

  brush->FillRect(hDC, x + 1, y + 1, HEADER_WIDTH - 2, ROW_HEIGHT - 2);
  
  ColorManager->Release();

  r.left   = x + 1;
  r.right  = x + HEADER_WIDTH - 1;
  r.top    = y + 1;
  r.bottom = y + ROW_HEIGHT - 1;

  TrackLabel(track, label);

  DrawText(hDC, label, (int)strlen(label), &r, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
}

void CControlView::TrackLabel(int track, char *label)
{
  int parameter;

  parameter = Pattern->ControlTracks->Items[track]->Property;
  if(parameter == PROPERTY_VELOCITY)
    strcpy(label, "Velocity");
  else
    Pattern->Port->Container->Machine->GetPropertyName(parameter, label);
}

void CControlView::OnScrollY(int newPos)
{
  ScrollVertical(newPos);
  Update();
}

void CControlView::OnScrollX(int newPos)
{
  ScrollHorizontal(newPos);
  Update();
}

void CControlView::OnResize(int newWidth, int newHeight)
{
  CControl::OnResize(newWidth, newHeight);
  if(SubInit)
  {
    ScrollBarV->Move(newWidth - SCROLLBAR_SIZE, 0, SCROLLBAR_SIZE, newHeight);
    SizeControl();
    ScrollVertical(OffsetY);
    Update();
  }
}

int CControlView::CellAt(int x)
{
  int cell;

  cell = (LeftCol * 4) + ((x - LeftColX) / CELL_WIDTH);
  if((cell / 4) >= LeftCol && (cell / 4) <= RightCol && cell >= 0 && cell < (Pattern->Length * 4))
    return cell;
  else
    return -1;
}

int CControlView::RowAt(int y)
{
  int row;

  row = TopRow + ((y - TopRowY) / ROW_HEIGHT);
  if(row >= TopRow && row <= BottomRow)
    return row;
  else
    return -1;
}

void CControlView::ControlChangeAt(int x, int y, int *row, int *pos)
{
  int cell;
  int cellY;
  int irow;

  if(Pattern == 0)
  {
    *row = -1;
    *pos = -1;
    return;
  }

  cell = CellAt(x);
  if(cell != -1)
  {
    irow = RowAt(y);
    if(irow != -1)
    {
      cellY  = TopRowY  + (irow - TopRow) * ROW_HEIGHT;
      cellY += (int)((ROW_HEIGHT - CELL_HEIGHT) * (1.0f - GetControlChangeValue(irow, cell)));
      if(y >= cellY && y < cellY + CELL_HEIGHT)
      {
        if(Pattern->ControlTracks->Items[irow]->Entries->Items[cell]->Used)
        {
          *row  = irow;
          *pos  = cell;
          return;
        }
      }
    }
  }
  *row = -1;
  *pos = -1;
}

float CControlView::GetControlChangeValue(int row, int pos)
{
  return (float)Pattern->ControlTracks->Items[row]->Entries->Items[pos]->Value;
}

void CControlView::GetControlChangeValueDisplay(int row, int pos, float value, char *text)
{
  int index;

  index = Pattern->ControlTracks->Items[row]->Property;
  Pattern->Port->Container->Machine->GetPropertyValueDisplay(index, value, text);
}

void CControlView::SetControlChangeValue(int row, int pos, float value)
{
  Pattern->ControlTracks->Items[row]->Entries->Items[pos]->Value = value;
}

void CControlView::OnMouseMove(int x, int y)
{
  int row, pos;

  if(State == STATE_IDLE)
  {
    ControlChangeAt(x, y, &row, &pos);
    CurrentRow = row;
    CurrentPos = pos;
    if(row != -1 && pos != -1)
    {
      SetCursor(LoadCursor(NULL, IDC_SIZENS));
      SetCapture(Handle);
      State = STATE_WILLMOVE;
      Update();
    }
    return;
  }

  if(State == STATE_WILLMOVE)
  {
    ControlChangeAt(x, y, &row, &pos);
    CurrentRow = row;
    CurrentPos = pos;
    if(row == -1 || pos == -1)
    {
      SetCursor(LoadCursor(NULL, IDC_ARROW));
      ReleaseCapture();
      State = STATE_IDLE;
      Update();
    }
    return;
  }

  if(State == STATE_MOVING)
  {
    int   moveY;
    float newValue;
    char  display[MAX_PROPERTY_DISPLAY_STRING];
    POINT p;

    moveY = y - MouseY;
    newValue = StartValue - ((float)moveY / (float)(ROW_HEIGHT - CELL_HEIGHT));
    if(newValue < 0.0f)
      newValue = 0.0f;
    else if(newValue > 1.0f)
      newValue = 1.0f;
    
    p.x = x;
    p.y = y;
    ClientToScreen(Handle, &p);
    ToolTip->TrackPosition(p.x + TOOLTIP_X, p.y + TOOLTIP_Y);
    SetControlChangeValue(CurrentRow, CurrentPos, newValue);

    GetControlChangeValueDisplay(CurrentRow, CurrentPos, newValue, display);
    ToolTip->UpdateText(Handle, display, true);

    Update();
  }
}

void CControlView::OnLeftButtonDoubleClick(int x, int y)
{
  CControlView::OnLeftButtonDown(x, y);
}

void CControlView::OnLeftButtonDown(int x, int y)
{
  char display[MAX_PROPERTY_DISPLAY_STRING];

  if(State == STATE_WILLMOVE)
  {
    POINT p;

    State = STATE_MOVING;
    MouseX = x;
    MouseY = y;
    StartValue = GetControlChangeValue(CurrentRow, CurrentPos);
    GetControlChangeValueDisplay(CurrentRow, CurrentPos, StartValue, display);
    ToolTip->UpdateText(Handle, display, true);
    p.x = x;
    p.y = y;
    ClientToScreen(Handle, &p);
    ToolTip->TrackPosition(p.x + TOOLTIP_X, p.y + TOOLTIP_Y);
    ToolTip->TrackActivate(Handle, true);

    return;
  }

  if(State == STATE_IDLE)
  {
    POINT p;
    int row, pos;
    
    if(AddControlChange(x, y))
    {
      State = STATE_MOVING;
      MouseX = x;
      MouseY = y;
      ControlChangeAt(x, y, &row, &pos);
      CurrentRow = row;
      CurrentPos = pos;
      SetCursor(LoadCursor(NULL, IDC_SIZENS));
      SetCapture(Handle);
      StartValue = GetControlChangeValue(CurrentRow, CurrentPos);
      GetControlChangeValueDisplay(CurrentRow, CurrentPos, StartValue, display);
      ToolTip->UpdateText(Handle, display, true);
      p.x = x;
      p.y = y;
      ClientToScreen(Handle, &p);
      ToolTip->TrackPosition(p.x + TOOLTIP_X, p.y + TOOLTIP_Y);
      ToolTip->TrackActivate(Handle, true);
    }
    return;
  }
}

void CControlView::OnRightButtonDown(int x, int y)
{
  if(State == STATE_WILLMOVE)
  {
    RemoveControlChange(x, y);
    SetCursor(LoadCursor(NULL, IDC_ARROW));
    ReleaseCapture();
    State = STATE_IDLE;
  }
}

void CControlView::OnLeftButtonUp(int x, int y)
{
  int row, pos;

  if(State == STATE_MOVING)
  {
    ToolTip->TrackActivate(Handle, false);
    ControlChangeAt(x, y, &row, &pos);
    CurrentRow = row;
    CurrentPos = pos;
    if(row == -1 || pos == -1)
    {
      SetCursor(LoadCursor(NULL, IDC_ARROW));
      ReleaseCapture();
      State = STATE_IDLE;
    }
    else
      State = STATE_WILLMOVE;
  }
}

int CControlView::FindTrack(int parameter)
{
  int i;

  if(Pattern == 0)
    return -1;

  for(i = 0; i < Pattern->ControlTracks->Count; i++)
    if(Pattern->ControlTracks->Items[i]->Property == parameter)
      return i;

  return -1;
}

void CControlView::AddTrack(int parameter)
{
  int i;

  if(Pattern == 0)
    return;

  i = FindTrack(parameter);
  if(i == -1)
  {
    Pattern->AddControlTrack(parameter);
    Rows = Rows + 1;
    SizeControl();
    ScrollVertical(max(0, (Rows * ROW_HEIGHT) - Height));
    ScrollBarV->SetPos(OffsetY, false);
    Update();
  }
}

void CControlView::RemoveTrack(int parameter)
{
  int i;

  if(Pattern == 0)
    return;

  i = FindTrack(parameter);
  if(i != -1)
  {
    Pattern->RemoveControlTrack(i);
    Rows = Rows - 1;
    SizeControl();
    ScrollVertical(OffsetY);
    ScrollBarV->SetPos(OffsetY, false);
    Update();
  }
}

bool CControlView::AddControlChange(int x, int y)
{
  int            cell, row;
  SControlEntry *entry;
  float          value;

  if(Pattern == 0)
    return false;

  cell = CellAt(x);
  row  = RowAt(y);

  if(cell != -1 && row != -1)
  {
    entry = Pattern->ControlTracks->Items[row]->Entries->Items[cell];
    if(!entry->Used)
    {
      value = 1.0f - ((float)(y - RowY(row)) / (float)(ROW_HEIGHT - CELL_HEIGHT));
      if(value < 0.0f)
        value = 0.0f;
      else if(value > 1.0f)
        value = 1.0f;
      entry->Value = value;
      entry->Used  = true;
      Update();
      return true;
    }
  }
  
  return false;
}

void CControlView::RemoveControlChange(int x, int y)
{
  int            row, pos;
  SControlEntry *entry;

  if(Pattern == 0)
    return;

  ControlChangeAt(x, y, &row, &pos);
  if(row != -1 && pos != -1)
  {
    entry = Pattern->ControlTracks->Items[row]->Entries->Items[pos];
    entry->Used  = false;
    entry->Value = 0.0f;
    Update();
  }
}

int CControlView::RowY(int row)
{
  return TopRowY + ((row - TopRow) * ROW_HEIGHT);
}

