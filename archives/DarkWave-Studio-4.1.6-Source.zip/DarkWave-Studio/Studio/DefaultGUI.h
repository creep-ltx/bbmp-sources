/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DEFAULT_GUI_H
#define DEFAULT_GUI_H

#include "DarkPlug.h"
#include "Control.h"
#include "Slider.h"
#include "Font.h"
#include "BackBuffer.h"
#include "ScrollBar.h"

class CDefaultGUI;

class CDefaultGUISlider : public CSlider
{
public:
  CDefaultGUISlider(CDefaultGUI *gui, int index, int x, int y, int width, int height); 
  virtual void OnChange(double newValue);

private:
  CDefaultGUI *GUI;
  int          Index;
};

class CDefaultGUI : public CControl
{
public:
              CDefaultGUI(CControl *parent, CMachine *machine);
             ~CDefaultGUI();
 void         DrawControl();
 void         DrawLabel(HDC hDC, char *text, int flags, int x, int y, int width, int height);
 virtual void OnSliderChange(int index, double newValue);
 void         OnPropertyChange(int index);
 virtual void OnScrollY(int newPos);

private:
  CMachine           *Machine;
  int                 PropertyCount, TotalHeight, TopRow, MaxTopRow, VisibleRows;
  char              **PropertyNames;
  char              **PropertyDisplays;
  double             *PropertyValues;
  CDefaultGUISlider **Sliders;
  CScrollBar         *ScrollBarV;
};

#endif