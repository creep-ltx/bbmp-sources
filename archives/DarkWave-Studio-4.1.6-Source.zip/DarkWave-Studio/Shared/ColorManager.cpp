/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/



#include "ColorManager.h"
#include "Error.h"

const COLORREF DefaultColorManagerColors[COLOR_MANAGER_COLOR_COUNT] =
{
  RGB(0x00, 0x00, 0x00), // BLACK
  RGB(0xFF, 0xFF, 0xFF), // WHITE
  RGB(0x20, 0x20, 0x20), // CONTROL BACK
  RGB(0x40, 0x40, 0x40), // CONTROL BACK DISABLED
  RGB(0xF0, 0xF0, 0xF0), // CONTROL TEXT 
  RGB(0x80, 0x80, 0x80), // CONTROL TEXT DISABLED
  RGB(0x60, 0x60, 0x60), // CONTROL LIGHT
  RGB(0x40, 0x40, 0x40), // CONTROL SHADOW
  RGB(0x33, 0x33, 0x33), // WINDOW WORKSPACE
  RGB(0x00, 0x00, 0x00), // HIGHLIGHT BACK
  RGB(0xF0, 0xF0, 0xF0), // HIGHLIGHT TEXT
  RGB(0x00, 0x00, 0x00), // FLAT BACK
  RGB(0x00, 0x96, 0xCC), // FLAT TEXT
  RGB(0x00, 0xBB, 0xFF), // CABLE LIGHT
  RGB(0x00, 0x70, 0x99), // CABLE SHADOW
  RGB(0x00, 0x96, 0xCC), // CABLE BACK
  RGB(0xF0, 0xF0, 0xF0), // KEY WHITE BACK
  RGB(0xD0, 0xD0, 0xD0), // KEY WHITE BACK PRESSED
  RGB(0x00, 0x00, 0x00), // KEY WHITE TEXT
  RGB(0x00, 0x96, 0xCC), // KEY WHITE ACTIVE
  RGB(0x00, 0x00, 0x00), // KEY BLACK BACK
  RGB(0x40, 0x40, 0x40), // KEY BLACK BACK PRESSED
  RGB(0xF0, 0xF0, 0xF0), // KEY BLACK TEXT
  RGB(0x00, 0x96, 0xCC), // KEY BLACK 
  RGB(0x40, 0x40, 0x40), // GRID CELL
  RGB(0x60, 0x60, 0x60), // GRID CELL ALT
  RGB(0x80, 0x80, 0x80), // GRID CELL ALT 2
  RGB(0x00, 0x00, 0x00), // GRID LINE
  RGB(0x00, 0x10, 0x00), // GRID LINE INNER
  RGB(0x00, 0xBB, 0xFF), // NOTE LIGHT
  RGB(0x00, 0x70, 0x99), // NOTE SHADOW
  RGB(0x00, 0x96, 0xCC), // NOTE BACK
  RGB(0x00, 0xA8, 0xE5), // NOTE BACK HIGHLIGHT
  RGB(0x00, 0x00, 0x00), // NOTE TEXT
  RGB(0x20, 0x20, 0x20), // LCD BACK
  RGB(0xA0, 0xA0, 0xA0), // LCD LIGHT
  RGB(0x00, 0x00, 0x00), // TEXT AREA BACK
  RGB(0x00, 0x96, 0xCC), // TEXT AREA TEXT
  RGB(0x00, 0x96, 0xCC), // TEXT AREA SEL BACK
  RGB(0x00, 0x00, 0x00), // TEXT AREA SEL TEXT
  RGB(0x00, 0x96, 0xCC), // TEXT HIGHLIGHT BACK
  RGB(0x00, 0x00, 0x00), // TEXT HIGHLIGHT TEXT
  RGB(0x00, 0xF0, 0x00), // LEVEL LOW
  RGB(0xF0, 0xF0, 0x00), // LEVEL MID
  RGB(0xF0, 0x00, 0x00), // LEVEL HIGH
  RGB(0x00, 0x96, 0xCC)  // SELECT BOX
};

void DARKCALL CColorManager::Lock()
{
  CMutex::Lock();
  if(Parent)
  {
    Parent->Lock();
  }
}

void DARKCALL CColorManager::Release()
{
  if(Parent)
    Parent->Release();
  CMutex::Release();
}

CColorManager::CColorManager()
{
  int i;

  Parent = 0;
  Presets = new ColorManagerPreset[1];
  PresetCount = 1;
  CurrentPreset = 0;

  for(i = 0; i < COLOR_MANAGER_COLOR_COUNT; i++)
  {
    Presets[0].Colors[i] = DefaultColorManagerColors[i];
    Brushes[i] = 0;
    Pens[i]    = 0;
    InheritColors[i] = false;
  }
}

CColorManager::CColorManager(CHost *host)
{
  // TODO: Load Colors From Host
  int i;

  Parent = 0;
  Presets = new ColorManagerPreset[1];
  PresetCount = 1;
  CurrentPreset = 0;

  for(i = 0; i < COLOR_MANAGER_COLOR_COUNT; i++)
  {
    Presets[0].Colors[i] = DefaultColorManagerColors[i];
    Brushes[i] = 0;
    Pens[i]    = 0;
    InheritColors[i] = false;
  }
}


CColorManager::CColorManager(CColorManager *parent)
{
  int i;

  Parent = parent;
  Presets = new ColorManagerPreset[1];
  PresetCount = 1;
  CurrentPreset = 0;

  for(i = 0; i < COLOR_MANAGER_COLOR_COUNT; i++)
  {
    Presets[0].Colors[i] = 0;
    Brushes[i] = 0;
    Pens[i] = 0;
    InheritColors[i] = true;
  }
}

CColorManager::~CColorManager()
{
  int i;

  for(i = 0; i < COLOR_MANAGER_COLOR_COUNT; i++)
  {
    if(Brushes[i] != 0)
      delete Brushes[i];
    if(Pens[i] != 0)
      delete Pens[i];
  }
}

int CColorManager::GetColor(ColorManagerColor color)
{
  if(color >= 0 && color < COLOR_MANAGER_COLOR_COUNT)
  {
    if(InheritColors[color])
      return Parent->GetColor(color);
    else
      return Presets[CurrentPreset].Colors[color];
  }
  else
    throw "ColorManager: Invalid Color Requested";
}

CPen *CColorManager::GetPen(ColorManagerColor color)
{
#ifdef _DEBUG
  if(!IsLocked())
    DebugPrint("ColorManager::GetPen() - Not Locked");
#endif

  if(color >= 0 && color < COLOR_MANAGER_COLOR_COUNT)
  {
    if(InheritColors[color])
      return Parent->GetPen(color);
    if(Pens[color] == 0)
      Pens[color] = new CPen(GetColor(color));
    return Pens[color];
  }
  else
    throw "ColorManager: Invalid Color Requested";
}

CBrush *CColorManager::GetBrush(ColorManagerColor color)
{
#ifdef _DEBUG
  if(!IsLocked())
    DebugPrint("ColorManager::GetBrush() - Not Locked");
#endif

  if(color >= 0 && color < COLOR_MANAGER_COLOR_COUNT)
  {
    if(InheritColors[color])
    {
      return Parent->GetBrush(color);
    }
    if(Brushes[color] == 0)
      Brushes[color] = new CBrush(GetColor(color));
    return Brushes[color];
  }
  else
    throw "ColorManager: Invalid Color Requested";
}

void CColorManager::SetColor(ColorManagerColor color, COLORREF value)
{
  if(color >= 0 && color < COLOR_MANAGER_COLOR_COUNT)
  {
    if(Brushes[color] != 0)
    {
      delete Brushes[color];
      Brushes[color] = 0;
    }

    if(Pens[color] != 0)
    {
      delete Pens[color];
      Pens[color] = 0;
    }

    Presets[CurrentPreset].Colors[color] = value;
    InheritColors[color] = false;
  }
  else
    throw "ColorManager: Invalid Color Requested";
}