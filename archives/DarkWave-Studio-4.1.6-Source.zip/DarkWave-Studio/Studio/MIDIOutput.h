/*  ExperimentalScene DarkWave Studio
    Copyright (C) 2004-2012 Daniel Werner
    http://www.experimentalscene.com/

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MIDI_OUTPUT_H
#define MIDI_OUTPUT_H

#include "DarkPlug.h"
#include "Control.h"
#include "DropList.h"
#include "Font.h"
#include "MIDIManager.h"

class CMIDIOutput;
class CMIDIOutputGUI;

class CMIDIOutputGUI : public CControl
{
public:
               CMIDIOutputGUI(HWND parent, CMIDIOutput *midiInput);
              ~CMIDIOutputGUI();
  void         OpenDevice(int index);
  virtual void OnComboSelect(CDropList *comboBox);
  CDropList    *DeviceCombo, *ChannelCombo;

private:
  CMIDIOutput   *MIDIOutput;
};

class CMIDIOutput : public CMachine
{
public:
                 CMIDIOutput(CHost *host);
  virtual       ~CMIDIOutput();
  virtual void   DARKCALL Work();
  virtual HWND   DARKCALL CreateGUI(HWND parent);
  void           OpenDevice(int index);
  void           CloseDevice();
  virtual void   DARKCALL SetSampleRate(int sampleRate);
  virtual void   DARKCALL SetBlockSamples(int blockSamples);
  virtual bool   DARKCALL IsSynth();
  virtual double DARKCALL GetProperty(int index);
  virtual void   DARKCALL SetProperty(int index, double value);
  virtual void   DARKCALL GetPropertyName(int index, char *text);
  virtual void   DARKCALL GetPropertyValueDisplay(int index, double value, char *text);
  void           SetChannel(int channel);
  virtual void   DARKCALL ReadProperties(char *data, int length, bool isInner);
  virtual void   DARKCALL WriteProperties(char **data, int *length, bool *isInner);

  CMIDIOutputDevice *Device;
  int Channel;
private:
  CMIDIOutputGUI    *GUI;
  CControlBuffer    *FutureBuffer;
  LARGE_INTEGER      PerformanceFrequency;
  int                SampleRate, BlockSamples;
  double            *Properties;
};

class CMIDIOutputInfo : public CMachineInfo
{
public:
                             CMIDIOutputInfo();
  virtual CMachine* DARKCALL CreateMachine();
};

#endif