// ------------------------------------------------------
// Protrekkr
// Based on Juan Antonio Arguelles Rius's NoiseTrekker.
//
// Copyright (C) 2008-2022 Franck Charlet.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//  1. Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//
//  2. Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL FRANCK CHARLET OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
// OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
// HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
// LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE.
// ------------------------------------------------------

#ifndef _SOUNDDRIVER_DUMMY_H_
#define _SOUNDDRIVER_DUMMY_H_

#include <memory.h>
#include <stdint.h>
#include <stdlib.h>

// ------------------------------------------------------
// Includes

#define STDCALL
#define FALSE 0
#define TRUE 1

// ------------------------------------------------------
// Constants
/*
#define AUDIO_PCM_FREQ 44100

#define AUDIO_DBUF_CHANNELS 2
#define AUDIO_DBUF_RESOLUTION 16
*/

// ------------------------------------------------------
// Types
typedef uint32_t Uint32;
typedef uint8_t Uint8;
typedef int32_t int32;
typedef int8_t int8;

// ------------------------------------------------------
// Functions
static constexpr int AUDIO_Latency = 0;

inline void AUDIO_ResetTimer(void) {}
inline int AUDIO_GetSamples(void) { return 0; }

#endif
